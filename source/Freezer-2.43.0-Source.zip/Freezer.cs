using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Management;
using System.Xml.Linq;

[assembly: AssemblyTitle("Freezer")]
[assembly: AssemblyDescription("Freezer Native PC Optimizer")]
[assembly: AssemblyProduct("Freezer")]
[assembly: AssemblyVersion("2.43.0.0")]
[assembly: AssemblyFileVersion("2.43.0.0")]

namespace FreezerNative
{
    internal static class UiFontCache
    {
        private static readonly object Gate = new object();
        private static readonly Dictionary<string, Font> Fonts = new Dictionary<string, Font>(StringComparer.Ordinal);

        public static Font Get(string family, float size, FontStyle style)
        {
            string key = family + "|" + size.ToString("R", CultureInfo.InvariantCulture) + "|" + ((int)style).ToString(CultureInfo.InvariantCulture);
            lock (Gate)
            {
                Font font;
                if (!Fonts.TryGetValue(key, out font))
                {
                    font = new Font(family, size, style, GraphicsUnit.Point);
                    Fonts.Add(key, font);
                }
                return font;
            }
        }

        public static void DisposeAll()
        {
            lock (Gate)
            {
                foreach (Font font in Fonts.Values) try { font.Dispose(); } catch { }
                Fonts.Clear();
            }
        }
    }

    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.ThreadException += delegate(object sender, System.Threading.ThreadExceptionEventArgs args) { FreezerLog.Write("UI thread exception", args.Exception); };
            AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs args) { FreezerLog.Write("Unhandled exception", args.ExceptionObject as Exception); };
            try { Application.Run(new FreezerForm()); }
            catch (Exception ex)
            {
                FreezerLog.Write("Application start/run exception", ex);
                try
                {
                    string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Freezer");
                    Directory.CreateDirectory(root);
                    string log = Path.Combine(root, "startup-error.log");
                    File.WriteAllText(log, ex.ToString(), Encoding.UTF8);
                    Localizer.Current = Preferences.Load(Path.Combine(root, "settings.ini")).Language;
                    ThemedDialog.Show(null, Localizer.T("startup.title"), Localizer.T("startup.details") + "\r\n" + log, false);
                    return;
                }
                catch { }
                MessageBox.Show(ex.ToString(), "Freezer", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { UiFontCache.DisposeAll(); }
        }
    }

    internal static class FreezerLog
    {
        private static readonly object Gate = new object();
        private const long MaxBytes = 524288;
        private static string LogPath
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Freezer", "logs", "freezer.log"); }
        }
        public static void Write(string message, Exception error)
        {
            try
            {
                string path = LogPath;
                lock (Gate)
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    FileInfo info = new FileInfo(path);
                    if (info.Exists && info.Length > MaxBytes)
                    {
                        string third = path + ".3", second = path + ".2", first = path + ".1";
                        if (File.Exists(third)) File.Delete(third);
                        if (File.Exists(second)) File.Move(second, third);
                        if (File.Exists(first)) File.Move(first, second);
                        File.Move(path, first);
                    }
                    string detail = error == null ? String.Empty : error.ToString();
                    string user = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
                    string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                    if (!String.IsNullOrEmpty(user)) detail = detail.Replace(user, "%USERPROFILE%");
                    if (!String.IsNullOrEmpty(local)) detail = detail.Replace(local, "%LOCALAPPDATA%");
                    string line = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture) + " [" + (message ?? "event") + "]" +
                        (String.IsNullOrEmpty(detail) ? String.Empty : Environment.NewLine + detail) + Environment.NewLine;
                    File.AppendAllText(path, line, new UTF8Encoding(false));
                }
            }
            catch { }
        }
    }

    internal sealed class Preferences
    {
        public string Language = "de";
        public string Accent = "orange";
        public bool ReduceMotion;
        public string Motion = "fast";
        public string OverlaySize = "standard";
        public int OverlayOpacity = 90;
        public bool OverlayShowCpu = true, OverlayShowGpu = true, OverlayShowRam = true, OverlayShowFps = true;
        public bool RestorePointNoticeShown;
        public bool IntroTutorialCompleted;
        public bool MinimizeToTray = true;
        public bool AutoUpdateCheck;
        public string NetworkQosPolicyName = "";
        public string NetworkQosApp = "";
        public bool CrosshairEnabled;
        public string CrosshairScreen = "";
        public string CrosshairShape = "plus";
        public string CrosshairColor = "lime";
        public int CrosshairSize = 20;
        public int CrosshairGap = 4;
        public int CrosshairThickness = 2;
        public int CrosshairOpacity = 100;
        public bool CrosshairOutline = true;
        public bool CrosshairGlow;
        public Dictionary<string, string> CrosshairPresets = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public string SelectedGame = "game.fortnite";
        public bool FortniteBackgroundCustomized;
        public Dictionary<string, string> GameProfiles = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, string> GameLaunchPaths = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, string> GameStretchProfiles = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, string> StretchOriginalModes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, int> NvidiaColorProfiles = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, string> NvidiaColorAdjustments = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, string> NvidiaGameProfiles = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public string NvidiaSelectedDisplay = "";
        public Dictionary<string, int> AmdColorProfiles = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, string> AmdColorAdjustments = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, string> AmdGameProfiles = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public string AmdSelectedDisplay = "";
        public string ActiveNvidiaColorGame = "";
        public string ActiveAmdColorGame = "";
        public string ActiveNvidiaColorProfile = "";
        public string ActiveAmdColorProfile = "";

        public static Preferences Load(string path)
        {
            Preferences p = new Preferences();
            try
            {
                foreach (string line in File.ReadAllLines(path, Encoding.UTF8))
                {
                    int split = line.IndexOf('=');
                    if (split <= 0) continue;
                    string key = line.Substring(0, split);
                    string value = line.Substring(split + 1);
                    if (key == "language" && Localizer.Languages.ContainsKey(value)) p.Language = value;
                    else if (key == "accent" && Palette.Accents.ContainsKey(value)) p.Accent = value;
                    else if (key == "reduceMotion") { p.ReduceMotion = value == "1"; if (p.ReduceMotion) p.Motion = "off"; }
                    else if (key == "animation" && new[] { "fast", "slow", "off" }.Contains(value)) { p.Motion = value; p.ReduceMotion = value == "off"; }
                    else if (key == "overlaySize" && new[] { "compact", "standard", "large" }.Contains(value)) p.OverlaySize = value;
                    else if (key == "overlayOpacity") { int opacity; if (Int32.TryParse(value, out opacity)) p.OverlayOpacity = Math.Max(70, Math.Min(100, opacity)); }
                    else if (key == "overlayShowCpu") p.OverlayShowCpu = value == "1";
                    else if (key == "overlayShowGpu") p.OverlayShowGpu = value == "1";
                    else if (key == "overlayShowRam") p.OverlayShowRam = value == "1";
                    else if (key == "overlayShowFps") p.OverlayShowFps = value == "1";
                    else if (key == "restorePointNoticeShown") p.RestorePointNoticeShown = value == "1";
                    else if (key == "introTutorialCompleted") p.IntroTutorialCompleted = value == "1";
                    else if (key == "minimizeToTray") p.MinimizeToTray = value == "1";
                    else if (key == "autoUpdateCheck") p.AutoUpdateCheck = value == "1";
                    else if (key == "networkQosPolicyName") p.NetworkQosPolicyName = Regex.IsMatch(value, "^FreezerGameQoS_[A-Fa-f0-9]{8}$") ? value : "";
                    else if (key == "networkQosApp") p.NetworkQosApp = value;
                    else if (key == "crosshairEnabled") p.CrosshairEnabled = value == "1";
                    else if (key == "crosshairScreen") p.CrosshairScreen = value;
                    else if (key == "crosshairShape" && new[] { "plus", "x", "circle", "dot", "square", "diamond", "t", "brackets", "cross", "circleCross", "chevron", "star", "custom" }.Contains(value)) p.CrosshairShape = value;
                    else if (key == "crosshairColor" && new[] { "white", "lime", "cyan", "yellow", "red", "magenta", "orange", "purple", "pink", "blue" }.Contains(value)) p.CrosshairColor = value;
                    else if (key == "crosshairSize") { int n; if (Int32.TryParse(value, out n)) p.CrosshairSize = Math.Max(8, Math.Min(48, n)); }
                    else if (key == "crosshairGap") { int n; if (Int32.TryParse(value, out n)) p.CrosshairGap = Math.Max(0, Math.Min(16, n)); }
                    else if (key == "crosshairThickness") { int n; if (Int32.TryParse(value, out n)) p.CrosshairThickness = Math.Max(1, Math.Min(5, n)); }
                    else if (key == "crosshairOpacity") { int n; if (Int32.TryParse(value, out n)) p.CrosshairOpacity = Math.Max(10, Math.Min(100, n)); }
                    else if (key == "crosshairOutline") p.CrosshairOutline = value == "1";
                    else if (key == "crosshairGlow") p.CrosshairGlow = value == "1";
                    else if (key.StartsWith("crosshairPreset.", StringComparison.Ordinal))
                    {
                        string presetName, presetData;
                        if (TryDecodeToken(key.Substring("crosshairPreset.".Length), out presetName) && TryDecodeToken(value, out presetData) && presetName.Length > 0 && presetData.Length < 256)
                            p.CrosshairPresets[presetName] = presetData;
                    }
                    else if (key == "selectedGame" && value.StartsWith("game.", StringComparison.Ordinal)) p.SelectedGame = value;
                    else if (key == "fortniteBackground") p.FortniteBackgroundCustomized = value == "1";
                    else if (key == "nvidiaDisplay") p.NvidiaSelectedDisplay = value;
                    else if (key == "amdDisplay") p.AmdSelectedDisplay = value;
                    else if (key == "activeNvidiaColorGame") p.ActiveNvidiaColorGame = value;
                    else if (key == "activeAmdColorGame") p.ActiveAmdColorGame = value;
                    else if (key == "activeNvidiaColorProfile") { string profile; if (TryDecodeToken(value, out profile)) p.ActiveNvidiaColorProfile = profile; }
                    else if (key == "activeAmdColorProfile") { string profile; if (TryDecodeToken(value, out profile)) p.ActiveAmdColorProfile = profile; }
                    else if (key.StartsWith("nvidiaColor.", StringComparison.Ordinal))
                    {
                        string[] ids = key.Substring("nvidiaColor.".Length).Split('.'); int level; string profileName, displayName;
                        if (ids.Length == 2 && Int32.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out level) && TryDecodeToken(ids[0], out profileName) && TryDecodeToken(ids[1], out displayName))
                            p.NvidiaColorProfiles[profileName + "\t" + displayName] = level;
                    }
                    else if (key.StartsWith("nvidiaColorExtra.", StringComparison.Ordinal))
                    {
                        string[] ids = key.Substring("nvidiaColorExtra.".Length).Split('.'); string profileName, displayName;
                        if (ids.Length == 2 && TryDecodeToken(ids[0], out profileName) && TryDecodeToken(ids[1], out displayName)) p.NvidiaColorAdjustments[profileName + "\t" + displayName] = value;
                    }
                    else if (key.StartsWith("nvidiaGame.", StringComparison.Ordinal))
                    {
                        string profileName; if (TryDecodeToken(value, out profileName)) p.NvidiaGameProfiles[key.Substring("nvidiaGame.".Length)] = profileName;
                    }
                    else if (key.StartsWith("amdColor.", StringComparison.Ordinal))
                    {
                        string[] ids = key.Substring("amdColor.".Length).Split('.'); int level; string profileName, displayName;
                        if (ids.Length == 2 && Int32.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out level) && TryDecodeToken(ids[0], out profileName) && TryDecodeToken(ids[1], out displayName))
                            p.AmdColorProfiles[profileName + "\t" + displayName] = level;
                    }
                    else if (key.StartsWith("amdColorExtra.", StringComparison.Ordinal))
                    {
                        string[] ids = key.Substring("amdColorExtra.".Length).Split('.'); string profileName, displayName;
                        if (ids.Length == 2 && TryDecodeToken(ids[0], out profileName) && TryDecodeToken(ids[1], out displayName)) p.AmdColorAdjustments[profileName + "\t" + displayName] = value;
                    }
                    else if (key.StartsWith("amdGame.", StringComparison.Ordinal))
                    {
                        string profileName; if (TryDecodeToken(value, out profileName)) p.AmdGameProfiles[key.Substring("amdGame.".Length)] = profileName;
                    }
                    else if (key.StartsWith("gameLaunch.", StringComparison.Ordinal) && value.Length > 0) p.GameLaunchPaths[key.Substring("gameLaunch.".Length)] = value;
                    else if (key.StartsWith("gameStretch.", StringComparison.Ordinal)) { string profile; if (TryDecodeToken(value, out profile)) p.GameStretchProfiles[key.Substring("gameStretch.".Length)] = profile; }
                    else if (key.StartsWith("stretchOriginal.", StringComparison.Ordinal) && Regex.IsMatch(value, "^\\d{3,5}x\\d{3,5}x\\d{1,4}$"))
                        p.StretchOriginalModes[key.Substring("stretchOriginal.".Length)] = value;
                    else if (key.StartsWith("game.", StringComparison.Ordinal) && value.Length > 0)
                        p.GameProfiles[key.Substring(5)] = value;
                }
            }
            catch { }
            return p;
        }

        public void Save(string path)
        {
            StringBuilder b = new StringBuilder();
            b.AppendLine("language=" + Language);
            b.AppendLine("accent=" + Accent);
            b.AppendLine("reduceMotion=" + (ReduceMotion ? "1" : "0"));
            b.AppendLine("animation=" + Motion);
            b.AppendLine("overlaySize=" + OverlaySize);
            b.AppendLine("overlayOpacity=" + OverlayOpacity.ToString(CultureInfo.InvariantCulture));
            b.AppendLine("overlayShowCpu=" + (OverlayShowCpu ? "1" : "0"));
            b.AppendLine("overlayShowGpu=" + (OverlayShowGpu ? "1" : "0"));
            b.AppendLine("overlayShowRam=" + (OverlayShowRam ? "1" : "0"));
            b.AppendLine("overlayShowFps=" + (OverlayShowFps ? "1" : "0"));
            b.AppendLine("restorePointNoticeShown=" + (RestorePointNoticeShown ? "1" : "0"));
            b.AppendLine("introTutorialCompleted=" + (IntroTutorialCompleted ? "1" : "0"));
            b.AppendLine("minimizeToTray=" + (MinimizeToTray ? "1" : "0"));
            b.AppendLine("autoUpdateCheck=" + (AutoUpdateCheck ? "1" : "0"));
            b.AppendLine("networkQosPolicyName=" + (NetworkQosPolicyName ?? ""));
            b.AppendLine("networkQosApp=" + (NetworkQosApp ?? "").Replace("\r", "").Replace("\n", "").Replace("=", ""));
            b.AppendLine("crosshairEnabled=" + (CrosshairEnabled ? "1" : "0"));
            b.AppendLine("crosshairScreen=" + (CrosshairScreen ?? "").Replace("\r", "").Replace("\n", "").Replace("=", ""));
            b.AppendLine("crosshairShape=" + CrosshairShape);
            b.AppendLine("crosshairColor=" + CrosshairColor);
            b.AppendLine("crosshairSize=" + CrosshairSize.ToString(CultureInfo.InvariantCulture));
            b.AppendLine("crosshairGap=" + CrosshairGap.ToString(CultureInfo.InvariantCulture));
            b.AppendLine("crosshairThickness=" + CrosshairThickness.ToString(CultureInfo.InvariantCulture));
            b.AppendLine("crosshairOpacity=" + CrosshairOpacity.ToString(CultureInfo.InvariantCulture));
            b.AppendLine("crosshairOutline=" + (CrosshairOutline ? "1" : "0"));
            b.AppendLine("crosshairGlow=" + (CrosshairGlow ? "1" : "0"));
            foreach (KeyValuePair<string, string> preset in CrosshairPresets)
                if (!String.IsNullOrWhiteSpace(preset.Key) && preset.Key.Length <= 40 && (preset.Value ?? "").Length < 256)
                    b.AppendLine("crosshairPreset." + EncodeToken(preset.Key) + "=" + EncodeToken(preset.Value));
            b.AppendLine("selectedGame=" + (SelectedGame ?? "game.fortnite").Replace("=", "").Replace("\r", "").Replace("\n", ""));
            b.AppendLine("fortniteBackground=" + (FortniteBackgroundCustomized ? "1" : "0"));
            b.AppendLine("nvidiaDisplay=" + CleanSettingValue(NvidiaSelectedDisplay));
            b.AppendLine("amdDisplay=" + CleanSettingValue(AmdSelectedDisplay));
            b.AppendLine("activeNvidiaColorGame=" + CleanSettingValue(ActiveNvidiaColorGame));
            b.AppendLine("activeAmdColorGame=" + CleanSettingValue(ActiveAmdColorGame));
            b.AppendLine("activeNvidiaColorProfile=" + EncodeToken(ActiveNvidiaColorProfile));
            b.AppendLine("activeAmdColorProfile=" + EncodeToken(ActiveAmdColorProfile));
            foreach (KeyValuePair<string, int> color in NvidiaColorProfiles)
            {
                string[] parts = color.Key.Split('\t');
                if (parts.Length == 2) b.AppendLine("nvidiaColor." + EncodeToken(parts[0]) + "." + EncodeToken(parts[1]) + "=" + color.Value.ToString(CultureInfo.InvariantCulture));
            }
            foreach (KeyValuePair<string, string> color in NvidiaColorAdjustments)
            {
                string[] parts = color.Key.Split('\t');
                if (parts.Length == 2) b.AppendLine("nvidiaColorExtra." + EncodeToken(parts[0]) + "." + EncodeToken(parts[1]) + "=" + CleanSettingValue(color.Value));
            }
            foreach (KeyValuePair<string, string> game in NvidiaGameProfiles)
                b.AppendLine("nvidiaGame." + CleanSettingValue(game.Key) + "=" + EncodeToken(game.Value));
            foreach (KeyValuePair<string, int> color in AmdColorProfiles)
            {
                string[] parts = color.Key.Split('\t');
                if (parts.Length == 2) b.AppendLine("amdColor." + EncodeToken(parts[0]) + "." + EncodeToken(parts[1]) + "=" + color.Value.ToString(CultureInfo.InvariantCulture));
            }
            foreach (KeyValuePair<string, string> color in AmdColorAdjustments)
            {
                string[] parts = color.Key.Split('\t');
                if (parts.Length == 2) b.AppendLine("amdColorExtra." + EncodeToken(parts[0]) + "." + EncodeToken(parts[1]) + "=" + CleanSettingValue(color.Value));
            }
            foreach (KeyValuePair<string, string> game in AmdGameProfiles)
                b.AppendLine("amdGame." + CleanSettingValue(game.Key) + "=" + EncodeToken(game.Value));
            foreach (KeyValuePair<string, string> game in GameProfiles)
                b.AppendLine("game." + game.Key.Replace("=", "") + "=" + game.Value.Replace("=", ""));
            foreach (KeyValuePair<string, string> game in GameLaunchPaths)
                b.AppendLine("gameLaunch." + game.Key.Replace("=", "").Replace("\r", "").Replace("\n", "") + "=" + (game.Value ?? "").Replace("=", "").Replace("\r", "").Replace("\n", ""));
            foreach (KeyValuePair<string, string> game in GameStretchProfiles)
                b.AppendLine("gameStretch." + game.Key.Replace("=", "").Replace("\r", "").Replace("\n", "") + "=" + EncodeToken(game.Value));
            foreach (KeyValuePair<string, string> mode in StretchOriginalModes)
                b.AppendLine("stretchOriginal." + mode.Key.Replace("=", "").Replace("\r", "").Replace("\n", "") + "=" + mode.Value);
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, b.ToString(), Encoding.UTF8);
        }

        private static string CleanSettingValue(string value) { return (value ?? "").Replace("=", "").Replace("\r", "").Replace("\n", ""); }
        private static string EncodeToken(string value)
        { return Convert.ToBase64String(Encoding.UTF8.GetBytes(value ?? "")).TrimEnd('=').Replace('+', '-').Replace('/', '_'); }
        private static bool TryDecodeToken(string token, out string value)
        {
            value = "";
            try
            {
                string base64 = (token ?? "").Replace('-', '+').Replace('_', '/');
                while (base64.Length % 4 != 0) base64 += "=";
                value = Encoding.UTF8.GetString(Convert.FromBase64String(base64)); return true;
            }
            catch { return false; }
        }
    }

    internal sealed class NvidiaDisplayInfo
    {
        public string DeviceName;
        public string DisplayLabel;
        public int CurrentLevel, MinimumLevel, MaximumLevel, DefaultLevel;
        public IntPtr Handle;
        public override string ToString() { return DisplayLabel ?? DeviceName ?? "NVIDIA display"; }
    }

    internal static class DisplayLabels
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct DisplayDevice
        {
            public int Size;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceString;
            public int StateFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceId;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceKey;
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern bool EnumDisplayDevices(string device, uint deviceNumber, ref DisplayDevice displayDevice, uint flags);

        private static readonly object NameCacheSync = new object();
        private static Dictionary<string, string> _monitorNames;

        private static Dictionary<string, string> GetMonitorNames()
        {
            lock (NameCacheSync)
            {
                if (_monitorNames != null) return _monitorNames;
                Dictionary<string, string> names = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                try
                {
                    using (ManagementObjectSearcher search = new ManagementObjectSearcher(new ManagementScope(@"\\.\root\WMI"),
                        new ObjectQuery("SELECT InstanceName, UserFriendlyName FROM WmiMonitorID"),
                        new EnumerationOptions { Timeout = TimeSpan.FromSeconds(2) }))
                    using (ManagementObjectCollection results = search.Get())
                    {
                        foreach (ManagementObject item in results)
                        {
                            string instance = Convert.ToString(item["InstanceName"]);
                            string[] parts = (instance ?? "").Split('\\');
                            if (parts.Length < 2) continue;
                            ushort[] chars = item["UserFriendlyName"] as ushort[];
                            string friendly = chars == null ? "" : new string(chars.Where(x => x != 0).Select(x => (char)x).ToArray()).Trim();
                            if (friendly.Length > 0 && !names.ContainsKey(parts[1])) names[parts[1]] = friendly;
                        }
                    }
                }
                catch { }
                _monitorNames = names;
                return _monitorNames;
            }
        }

        public static string ForDevice(string deviceName)
        {
            Screen screen = Screen.AllScreens.FirstOrDefault(x => String.Equals(x.DeviceName, deviceName, StringComparison.OrdinalIgnoreCase));
            return screen == null ? Localizer.T("display.monitor") + " · " + Localizer.T("display.secondary") + " · " + deviceName : ForScreen(screen);
        }

        public static string ForScreen(Screen screen)
        {
            if (screen == null) return Localizer.T("display.secondary");
            string model = "";
            string monitorId = "";
            try
            {
                DisplayDevice device = new DisplayDevice(); device.Size = Marshal.SizeOf(typeof(DisplayDevice));
                if (EnumDisplayDevices(screen.DeviceName, 0, ref device, 0)) { model = (device.DeviceString ?? "").Trim(); monitorId = device.DeviceId ?? ""; }
            }
            catch { }
            string[] idParts = monitorId.Split('\\');
            if (idParts.Length > 1)
            {
                string friendly;
                if (GetMonitorNames().TryGetValue(idParts[1], out friendly) && !String.IsNullOrWhiteSpace(friendly)) model = friendly;
            }
            if (String.IsNullOrWhiteSpace(model) || model.IndexOf("generic pnp", StringComparison.OrdinalIgnoreCase) >= 0 || model.IndexOf("standardmonitor", StringComparison.OrdinalIgnoreCase) >= 0)
                model = Localizer.T("display.monitor");

            string role = Localizer.T(screen.Primary ? "display.primary" : "display.secondary");
            if (!screen.Primary)
            {
                Screen primary = Screen.AllScreens.FirstOrDefault(x => x.Primary);
                if (primary != null)
                {
                    int dx = screen.Bounds.Left - primary.Bounds.Left, dy = screen.Bounds.Top - primary.Bounds.Top;
                    string position = Math.Abs(dx) >= Math.Abs(dy) ? Localizer.T(dx < 0 ? "display.left" : "display.right") : Localizer.T(dy < 0 ? "display.above" : "display.below");
                    role += " · " + position;
                }
            }
            return model + " · " + role + " · " + screen.Bounds.Width.ToString(CultureInfo.InvariantCulture) + "×" + screen.Bounds.Height.ToString(CultureInfo.InvariantCulture);
        }
    }

    // Digital Vibrance uses NVIDIA's private NVAPI DVC interface. It is loaded only when the
    // NVIDIA driver exposes it; every call checks the driver status and uses its reported limits.
    internal static class NvidiaColorApi
    {
        private const uint InitializeId = 0x0150E828;
        private const uint EnumDisplayId = 0x9ABDD40D;
        private const uint DisplayNameId = 0x22A78B05;
        private const uint GetDvcInfoExId = 0x0E45002D;
        private const uint SetDvcLevelExId = 0x4A82C2B1;
        private const int EndEnumeration = -7;
        private static readonly object Sync = new object();
        private static IntPtr _module;
        private static QueryInterfaceDelegate _query;
        private static InitializeDelegate _initialize;
        private static EnumDisplayDelegate _enumDisplay;
        private static GetDisplayNameDelegate _getDisplayName;
        private static GetDvcInfoExDelegate _getDvcInfo;
        private static SetDvcLevelExDelegate _setDvcLevel;
        private static bool _initialized;
        private static string _initializationError = "";

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate IntPtr QueryInterfaceDelegate(uint id);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int InitializeDelegate();
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int EnumDisplayDelegate(uint index, out IntPtr displayHandle);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int GetDisplayNameDelegate(IntPtr displayHandle, [Out] byte[] name);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int GetDvcInfoExDelegate(IntPtr displayHandle, uint outputId, ref DvcInfoEx info);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int SetDvcLevelExDelegate(IntPtr displayHandle, uint outputId, ref DvcInfoEx info);

        [StructLayout(LayoutKind.Sequential)] private struct DvcInfoEx
        {
            public uint Version;
            public int CurrentLevel;
            public int MinimumLevel;
            public int MaximumLevel;
            public int DefaultLevel;
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern IntPtr LoadLibrary(string fileName);
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)] private static extern IntPtr GetProcAddress(IntPtr module, string name);

        public static IList<NvidiaDisplayInfo> GetDisplays()
        {
            lock (Sync)
            {
                EnsureInitialized();
                List<NvidiaDisplayInfo> result = new List<NvidiaDisplayInfo>();
                for (uint index = 0; index < 32; index++)
                {
                    IntPtr handle; int status = _enumDisplay(index, out handle);
                    if (status == EndEnumeration) break;
                    CheckStatus(status, "Could not enumerate NVIDIA displays");
                    byte[] nameBuffer = new byte[64]; CheckStatus(_getDisplayName(handle, nameBuffer), "Could not read NVIDIA display name");
                    int length = Array.IndexOf<byte>(nameBuffer, 0); if (length < 0) length = nameBuffer.Length;
                    string deviceName = Encoding.ASCII.GetString(nameBuffer, 0, length);
                    DvcInfoEx info = CreateVersionedInfo(); CheckStatus(_getDvcInfo(handle, 0, ref info), "NVIDIA Digital Vibrance is not available for this display");
                    if (String.IsNullOrWhiteSpace(deviceName) || info.MinimumLevel > info.MaximumLevel) continue;
                    Screen screen = Screen.AllScreens.FirstOrDefault(x => String.Equals(x.DeviceName, deviceName, StringComparison.OrdinalIgnoreCase));
                    string label = DisplayLabels.ForDevice(deviceName);
                    result.Add(new NvidiaDisplayInfo { DeviceName = deviceName, DisplayLabel = label, Handle = handle,
                        CurrentLevel = info.CurrentLevel, MinimumLevel = info.MinimumLevel, MaximumLevel = info.MaximumLevel, DefaultLevel = info.DefaultLevel });
                }
                return result;
            }
        }

        public static void SetLevel(string deviceName, int level)
        {
            lock (Sync)
            {
                EnsureInitialized(); NvidiaDisplayInfo display = GetDisplaysUnlocked(deviceName);
                if (display == null) throw new InvalidOperationException("The selected NVIDIA display is no longer available.");
                if (level < display.MinimumLevel || level > display.MaximumLevel) throw new ArgumentOutOfRangeException("level", "The selected Digital Vibrance value is outside the driver-reported range.");
                DvcInfoEx info = new DvcInfoEx { Version = (uint)(20 | 0x10000), CurrentLevel = level,
                    MinimumLevel = display.MinimumLevel, MaximumLevel = display.MaximumLevel, DefaultLevel = display.DefaultLevel };
                CheckStatus(_setDvcLevel(display.Handle, 0, ref info), "The NVIDIA driver rejected the Digital Vibrance profile");
            }
        }

        private static NvidiaDisplayInfo GetDisplaysUnlocked(string deviceName)
        {
            for (uint index = 0; index < 32; index++)
            {
                IntPtr handle; int status = _enumDisplay(index, out handle);
                if (status == EndEnumeration) return null;
                CheckStatus(status, "Could not enumerate NVIDIA displays");
                byte[] nameBuffer = new byte[64]; CheckStatus(_getDisplayName(handle, nameBuffer), "Could not read NVIDIA display name");
                int length = Array.IndexOf<byte>(nameBuffer, 0); if (length < 0) length = nameBuffer.Length;
                string name = Encoding.ASCII.GetString(nameBuffer, 0, length);
                if (!String.Equals(name, deviceName, StringComparison.OrdinalIgnoreCase)) continue;
                DvcInfoEx info = CreateVersionedInfo(); CheckStatus(_getDvcInfo(handle, 0, ref info), "NVIDIA Digital Vibrance is not available for this display");
                return new NvidiaDisplayInfo { DeviceName = name, Handle = handle, CurrentLevel = info.CurrentLevel,
                    MinimumLevel = info.MinimumLevel, MaximumLevel = info.MaximumLevel, DefaultLevel = info.DefaultLevel };
            }
            return null;
        }

        private static DvcInfoEx CreateVersionedInfo() { return new DvcInfoEx { Version = (uint)(20 | 0x10000) }; }
        private static void EnsureInitialized()
        {
            if (_initialized) return;
            if (!String.IsNullOrEmpty(_initializationError)) throw new NotSupportedException(_initializationError);
            try
            {
                string library = Environment.Is64BitProcess ? "nvapi64.dll" : "nvapi.dll";
                _module = LoadLibrary(library);
                if (_module == IntPtr.Zero) throw new NotSupportedException("NVIDIA NVAPI was not found. Install or repair the NVIDIA display driver.");
                IntPtr queryPointer = GetProcAddress(_module, "nvapi_QueryInterface");
                if (queryPointer == IntPtr.Zero) throw new NotSupportedException("The installed NVIDIA driver does not expose NVAPI.");
                _query = (QueryInterfaceDelegate)Marshal.GetDelegateForFunctionPointer(queryPointer, typeof(QueryInterfaceDelegate));
                _initialize = Resolve<InitializeDelegate>(InitializeId);
                _enumDisplay = Resolve<EnumDisplayDelegate>(EnumDisplayId);
                _getDisplayName = Resolve<GetDisplayNameDelegate>(DisplayNameId);
                _getDvcInfo = Resolve<GetDvcInfoExDelegate>(GetDvcInfoExId);
                _setDvcLevel = Resolve<SetDvcLevelExDelegate>(SetDvcLevelExId);
                CheckStatus(_initialize(), "NVIDIA NVAPI initialization failed"); _initialized = true;
            }
            catch (Exception ex) { _initializationError = ex.Message; throw; }
        }

        private static T Resolve<T>(uint id) where T : class
        {
            IntPtr pointer = _query(id); if (pointer == IntPtr.Zero) throw new NotSupportedException("The installed driver does not support the NVIDIA Digital Vibrance interface.");
            return Marshal.GetDelegateForFunctionPointer(pointer, typeof(T)) as T;
        }
        private static void CheckStatus(int status, string message)
        { if (status != 0) throw new InvalidOperationException(message + " (NVAPI " + status.ToString(CultureInfo.InvariantCulture) + ")."); }
    }

    internal sealed class ColorDisplayInfo
    {
        public string DeviceKey, DisplayLabel;
        public bool IsNvidia;
        public int CurrentLevel, MinimumLevel, MaximumLevel, DefaultLevel, AdapterIndex, DisplayIndex;
        public readonly Dictionary<string, ColorAdjustmentRange> Adjustments = new Dictionary<string, ColorAdjustmentRange>(StringComparer.OrdinalIgnoreCase);
        public override string ToString() { return DisplayLabel ?? DeviceKey ?? "Display"; }
    }

    internal sealed class ColorAdjustmentRange
    {
        public int Current, Default, Minimum, Maximum, Step;
    }

    // Uses the documented AMD Display Library color saturation calls if the installed driver
    // exposes ADL. The driver defaults are queried from ADL and used for every reset.
    internal static class AmdColorApi
    {
        private const int AmdVendorId = 0x1002;
        private const int BrightnessColorType = 1 << 0;
        private const int ContrastColorType = 1 << 1;
        private const int SaturationColorType = 1 << 2;
        private const int HueColorType = 1 << 3;
        private static readonly object Sync = new object();
        private static IntPtr _module;
        private static AllocDelegate _allocator;
        private static CreateDelegate _create;
        private static NumberOfAdaptersDelegate _numberOfAdapters;
        private static AdapterInfoGetDelegate _adapterInfoGet;
        private static DisplayInfoGetDelegate _displayInfoGet;
        private static ColorGetDelegate _colorGet;
        private static ColorSetDelegate _colorSet;
        private static bool _initialized;
        private static string _initializationError = "";

        [UnmanagedFunctionPointer(CallingConvention.StdCall)] private delegate IntPtr AllocDelegate(int size);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] private delegate int CreateDelegate(AllocDelegate allocator, int enumConnectedAdapters);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] private delegate int NumberOfAdaptersDelegate(out int count);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] private delegate int AdapterInfoGetDelegate(IntPtr adapterInfo, int inputSize);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] private delegate int DisplayInfoGetDelegate(int adapterIndex, out int count, out IntPtr displayInfo, int forceDetect);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] private delegate int ColorGetDelegate(int adapterIndex, int displayIndex, int colorType, out int current, out int defaultValue, out int minimum, out int maximum, out int step);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] private delegate int ColorSetDelegate(int adapterIndex, int displayIndex, int colorType, int current);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)] private struct AdapterInfo
        {
            public int Size, AdapterIndex;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string Udid;
            public int Bus, Device, Function, VendorId;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string AdapterName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string DisplayName;
            public int Present, Exists;
        }
        [StructLayout(LayoutKind.Sequential)] private struct DisplayId
        { public int LogicalIndex, PhysicalIndex, LogicalAdapterIndex, PhysicalAdapterIndex; }
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)] private struct DisplayInfo
        {
            public DisplayId Id;
            public int ControllerIndex;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string DisplayName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string Manufacturer;
            public int DisplayType, OutputType, Connector, InfoMask, InfoValue;
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern IntPtr LoadLibrary(string fileName);
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)] private static extern IntPtr GetProcAddress(IntPtr module, string name);

        public static IList<ColorDisplayInfo> GetDisplays()
        {
            lock (Sync)
            {
                EnsureInitialized();
                int adapterCount; Check(_numberOfAdapters(out adapterCount), "AMD adapter enumeration failed");
                if (adapterCount < 1 || adapterCount > 64) throw new NotSupportedException("No AMD display adapter is available through ADL.");
                int adapterSize = Marshal.SizeOf(typeof(AdapterInfo)); IntPtr adapterBuffer = Marshal.AllocHGlobal(adapterSize * adapterCount);
                List<AdapterInfo> adapters = new List<AdapterInfo>();
                try
                {
                    AdapterInfo blank = new AdapterInfo { Size = adapterSize, Udid = "", AdapterName = "", DisplayName = "" };
                    for (int i = 0; i < adapterCount; i++) Marshal.StructureToPtr(blank, IntPtr.Add(adapterBuffer, i * adapterSize), false);
                    Check(_adapterInfoGet(adapterBuffer, adapterSize * adapterCount), "AMD adapter information could not be read");
                    for (int i = 0; i < adapterCount; i++)
                    {
                        AdapterInfo adapter = (AdapterInfo)Marshal.PtrToStructure(IntPtr.Add(adapterBuffer, i * adapterSize), typeof(AdapterInfo));
                        if (adapter.VendorId == AmdVendorId && adapter.Present != 0 && adapter.Exists != 0) adapters.Add(adapter);
                    }
                }
                finally { Marshal.FreeHGlobal(adapterBuffer); }

                List<ColorDisplayInfo> result = new List<ColorDisplayInfo>();
                foreach (AdapterInfo adapter in adapters)
                {
                    int displayCount; IntPtr displayBuffer;
                    Check(_displayInfoGet(adapter.AdapterIndex, out displayCount, out displayBuffer, 0), "AMD display information could not be read");
                    if (displayBuffer == IntPtr.Zero || displayCount < 0 || displayCount > 64) continue;
                    try
                    {
                        int displaySize = Marshal.SizeOf(typeof(DisplayInfo));
                        for (int i = 0; i < displayCount; i++)
                        {
                            DisplayInfo display = (DisplayInfo)Marshal.PtrToStructure(IntPtr.Add(displayBuffer, i * displaySize), typeof(DisplayInfo));
                            int current, defaultValue, minimum, maximum, step;
                            if (_colorGet(adapter.AdapterIndex, display.Id.LogicalIndex, SaturationColorType, out current, out defaultValue, out minimum, out maximum, out step) != 0 || minimum > maximum) continue;
                            string name = String.IsNullOrWhiteSpace(display.DisplayName) ? "AMD display " + (display.Id.LogicalIndex + 1).ToString(CultureInfo.InvariantCulture) : display.DisplayName.Trim();
                            string adapterName = String.IsNullOrWhiteSpace(adapter.AdapterName) ? "AMD Radeon" : adapter.AdapterName.Trim();
                            ColorDisplayInfo colorDisplay = new ColorDisplayInfo { DeviceKey = adapter.AdapterIndex.ToString(CultureInfo.InvariantCulture) + ":" + display.Id.LogicalIndex.ToString(CultureInfo.InvariantCulture),
                                DisplayLabel = adapterName + " · " + name, AdapterIndex = adapter.AdapterIndex, DisplayIndex = display.Id.LogicalIndex,
                                CurrentLevel = current, DefaultLevel = defaultValue, MinimumLevel = minimum, MaximumLevel = maximum, IsNvidia = false };
                            colorDisplay.Adjustments["saturation"] = new ColorAdjustmentRange { Current = current, Default = defaultValue, Minimum = minimum, Maximum = maximum, Step = Math.Max(1, step) };
                            AddAdjustment(colorDisplay, adapter.AdapterIndex, display.Id.LogicalIndex, "brightness", BrightnessColorType);
                            AddAdjustment(colorDisplay, adapter.AdapterIndex, display.Id.LogicalIndex, "contrast", ContrastColorType);
                            AddAdjustment(colorDisplay, adapter.AdapterIndex, display.Id.LogicalIndex, "hue", HueColorType);
                            result.Add(colorDisplay);
                        }
                    }
                    finally { if (displayBuffer != IntPtr.Zero) Marshal.FreeHGlobal(displayBuffer); }
                }
                if (result.Count == 0) throw new NotSupportedException("AMD display color controls are not available. Check the AMD driver and AMD Software installation.");
                return result;
            }
        }

        public static void SetLevel(string deviceKey, int level)
        { SetAdjustment(deviceKey, "saturation", level); }

        public static void SetAdjustment(string deviceKey, string adjustment, int level)
        {
            lock (Sync)
            {
                ColorDisplayInfo display = GetDisplays().FirstOrDefault(x => String.Equals(x.DeviceKey, deviceKey, StringComparison.OrdinalIgnoreCase));
                if (display == null) throw new InvalidOperationException("The selected AMD display is no longer available.");
                ColorAdjustmentRange range;
                if (!display.Adjustments.TryGetValue(adjustment, out range)) throw new NotSupportedException("This color adjustment is not exposed by the AMD driver for this display.");
                if (level < range.Minimum || level > range.Maximum) throw new ArgumentOutOfRangeException("level", "Value outside the AMD driver range.");
                int colorType = adjustment == "brightness" ? BrightnessColorType : adjustment == "contrast" ? ContrastColorType : adjustment == "hue" ? HueColorType : SaturationColorType;
                Check(_colorSet(display.AdapterIndex, display.DisplayIndex, colorType, level), "The AMD driver rejected the color profile");
            }
        }

        private static void AddAdjustment(ColorDisplayInfo display, int adapterIndex, int displayIndex, string key, int colorType)
        {
            int current, defaultValue, minimum, maximum, step;
            if (_colorGet(adapterIndex, displayIndex, colorType, out current, out defaultValue, out minimum, out maximum, out step) == 0 && minimum <= maximum)
                display.Adjustments[key] = new ColorAdjustmentRange { Current = current, Default = defaultValue, Minimum = minimum, Maximum = maximum, Step = Math.Max(1, step) };
        }

        private static void EnsureInitialized()
        {
            if (_initialized) return;
            if (_initializationError.Length > 0) throw new NotSupportedException(_initializationError);
            try
            {
                string[] candidates = { Path.Combine(Environment.SystemDirectory, "atiadlxx.dll"), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "AMD", "CNext", "CNext", "atiadlxx.dll") };
                foreach (string candidate in candidates) if (File.Exists(candidate)) { _module = LoadLibrary(candidate); if (_module != IntPtr.Zero) break; }
                if (_module == IntPtr.Zero) throw new NotSupportedException("AMD ADL color controls are unavailable. Install AMD Software: Adrenalin Edition.");
                _allocator = delegate(int size) { return Marshal.AllocHGlobal(Math.Max(1, size)); };
                _create = Resolve<CreateDelegate>("ADL_Main_Control_Create");
                _numberOfAdapters = Resolve<NumberOfAdaptersDelegate>("ADL_Adapter_NumberOfAdapters_Get");
                _adapterInfoGet = Resolve<AdapterInfoGetDelegate>("ADL_Adapter_AdapterInfo_Get");
                _displayInfoGet = Resolve<DisplayInfoGetDelegate>("ADL_Display_DisplayInfo_Get");
                _colorGet = Resolve<ColorGetDelegate>("ADL_Display_Color_Get");
                _colorSet = Resolve<ColorSetDelegate>("ADL_Display_Color_Set");
                Check(_create(_allocator, 1), "AMD ADL initialization failed"); _initialized = true;
            }
            catch (Exception ex) { _initializationError = ex.Message; throw; }
        }
        private static T Resolve<T>(string name) where T : class
        {
            IntPtr pointer = GetProcAddress(_module, name); if (pointer == IntPtr.Zero) throw new NotSupportedException("AMD driver API missing: " + name);
            return Marshal.GetDelegateForFunctionPointer(pointer, typeof(T)) as T;
        }
        private static void Check(int status, string message) { if (status != 0) throw new InvalidOperationException(message + " (ADL " + status.ToString(CultureInfo.InvariantCulture) + ")."); }
    }

    internal static class Palette
    {
        public static readonly Dictionary<string, Color> Accents = new Dictionary<string, Color>
        {
            { "orange", Color.FromArgb(255, 145, 50) }, { "cyan", Color.FromArgb(39, 194, 224) },
            { "violet", Color.FromArgb(157, 115, 246) }, { "lime", Color.FromArgb(133, 214, 93) },
            { "pink", Color.FromArgb(238, 92, 156) }
        };
        public static Color Background = Color.FromArgb(8, 11, 16);
        public static Color Sidebar = Color.FromArgb(13, 17, 24);
        public static Color Surface = Color.FromArgb(20, 26, 35);
        public static Color Surface2 = Color.FromArgb(28, 36, 47);
        public static Color Border = Color.FromArgb(43, 54, 68);
        public static Color Text = Color.FromArgb(243, 246, 250);
        public static Color Muted = Color.FromArgb(157, 171, 187);
        public static Color Accent = Accents["orange"];
        public static Color AccentHover = Color.FromArgb(255, 174, 93);
        public static Color Green = Color.FromArgb(92, 213, 158);
        public static Color Red = Color.FromArgb(255, 105, 116);

        public static void Select(string key)
        {
            if (!Accents.ContainsKey(key)) key = "orange";
            Accent = Accents[key];
            AccentHover = Color.FromArgb(Math.Min(255, Accent.R + 28), Math.Min(255, Accent.G + 28), Math.Min(255, Accent.B + 28));
        }
    }

    internal static class Localizer
    {
        public static readonly Dictionary<string, string> Languages = new Dictionary<string, string>
        {
            { "de", "Deutsch" }, { "en", "English" }, { "fr", "Français" },
            { "es", "Español" }, { "tr", "Türkçe" }, { "pl", "Polski" }
        };
        private static readonly Dictionary<string, Dictionary<string, string>> Texts = Build();
        private static readonly Dictionary<string, Dictionary<string, string>> ExtraTexts = BuildExtras();
        public static string Current = "de";

        public static string T(string key)
        {
            string value;
            if (ExtraTexts.ContainsKey(Current) && ExtraTexts[Current].TryGetValue(key, out value)) return value;
            if (Texts.ContainsKey(Current) && Texts[Current].TryGetValue(key, out value)) return value;
            if (ExtraTexts.ContainsKey("en") && ExtraTexts["en"].TryGetValue(key, out value)) return value;
            if (Texts["en"].TryGetValue(key, out value)) return value;
            return key;
        }
        public static string OptimizationText(string itemKey, bool description, string fallback)
        {
            string key = "optitem." + itemKey + (description ? ".desc" : ".title");
            string value = T(key);
            return value == key ? fallback : value;
        }

        private static Dictionary<string, Dictionary<string, string>> BuildExtras()
        {
            string[] codes = { "de", "en", "fr", "es", "tr", "pl" };
            Dictionary<string, Dictionary<string, string>> result = new Dictionary<string, Dictionary<string, string>>();
            foreach (string code in codes) result[code] = new Dictionary<string, string>();
            Action<string, string[]> add = delegate(string key, string[] values)
            {
                for (int i = 0; i < codes.Length && i < values.Length; i++) result[codes[i]][key] = values[i];
            };
            add("state.on", new[] { "AN", "ON", "ACTIVÉ", "ACTIVADO", "AÇIK", "WŁ." });
            add("state.off", new[] { "AUS", "OFF", "DÉSACTIVÉ", "DESACTIVADO", "KAPALI", "WYŁ." });
            add("window.maximize", new[] { "Maximieren", "Maximize", "Agrandir", "Maximizar", "Büyüt", "Maksymalizuj" });
            add("window.restore", new[] { "Wiederherstellen", "Restore", "Restaurer", "Restaurar", "Geri yükle", "Przywróć" });
            add("header.exit", new[] { "Beenden", "Exit", "Quitter", "Salir", "Çıkış", "Zakończ" });
            add("nav.colorProfiles", new[] { "Farb-Profile", "Color profiles", "Profils couleur", "Perfiles de color", "Renk profilleri", "Profile kolorów" });
            add("nav.performance", new[] { "Leistung", "Performance", "Performances", "Rendimiento", "Performans", "Wydajność" });
            add("nav.potatoGraphics", new[] { "Potato Graphics", "Potato graphics", "Graphismes Potato", "Gráficos Potato", "Potato grafikleri", "Grafika Potato" });
            add("potato.title", new[] { "Potato Graphics", "Potato graphics", "Graphismes Potato", "Gráficos Potato", "Potato grafikleri", "Grafika Potato" });
            add("potato.subtitle", new[] { "Fortnite-Qualität mit gesicherter Originaldatei absenken und jederzeit zurücksetzen.", "Lower Fortnite quality with a backed-up original file and restore it any time.", "Réduisez la qualité de Fortnite avec sauvegarde du fichier d’origine et restauration à tout moment.", "Reduce la calidad de Fortnite con copia del archivo original y restáurala cuando quieras.", "Yedeklenen özgün dosyayla Fortnite kalitesini düşürün ve istediğiniz zaman geri yükleyin.", "Obniż jakość Fortnite z kopią pliku oryginalnego i przywróć ją w dowolnym momencie." });
            add("potato.detecting", new[] { "NVIDIA-Grafikkarte wird geprüft …", "Checking for an NVIDIA graphics card …", "Vérification d’une carte graphique NVIDIA…", "Buscando una tarjeta gráfica NVIDIA…", "NVIDIA ekran kartı denetleniyor…", "Sprawdzanie karty graficznej NVIDIA…" });
            add("potato.nvidiaReady", new[] { "NVIDIA-Grafikkarte erkannt: {0}", "NVIDIA graphics card detected: {0}", "Carte NVIDIA détectée : {0}", "Tarjeta NVIDIA detectada: {0}", "NVIDIA ekran kartı algılandı: {0}", "Wykryto kartę NVIDIA: {0}" });
            add("potato.unsupported", new[] { "AMD- und Intel-Grafikkarten werden hier noch nicht unterstützt. Die Potato-Profile sind deshalb deaktiviert.", "AMD and Intel graphics cards are not supported here yet. Potato profiles are disabled.", "Les cartes AMD et Intel ne sont pas encore prises en charge ici. Les profils Potato sont désactivés.", "Las gráficas AMD e Intel aún no son compatibles. Los perfiles Potato están desactivados.", "AMD ve Intel ekran kartları henüz desteklenmiyor. Potato profilleri devre dışı.", "Karty AMD i Intel nie są jeszcze obsługiwane. Profile Potato są wyłączone." });
            add("potato.noFile", new[] { "GameUserSettings.ini wurde im lokalen Fortnite-Konfigurationsordner nicht gefunden.", "GameUserSettings.ini was not found in the local Fortnite configuration folder.", "GameUserSettings.ini est introuvable dans le dossier de configuration local de Fortnite.", "No se encontró GameUserSettings.ini en la carpeta local de configuración de Fortnite.", "GameUserSettings.ini yerel Fortnite yapılandırma klasöründe bulunamadı.", "Nie znaleziono GameUserSettings.ini w lokalnym folderze konfiguracji Fortnite." });
            add("potato.path", new[] { "Fortnite-Datei", "Fortnite file", "Fichier Fortnite", "Archivo de Fortnite", "Fortnite dosyası", "Plik Fortnite" });
            add("potato.normal", new[] { "Normal", "Normal", "Normal", "Normal", "Normal", "Normalny" });
            add("potato.light", new[] { "Leichtes Potato", "Light potato", "Potato léger", "Potato ligero", "Hafif Potato", "Lekki Potato" });
            add("potato.extreme", new[] { "Extremes Potato", "Extreme potato", "Potato extrême", "Potato extremo", "Aşırı Potato", "Ekstremalny Potato" });
            add("potato.normalDesc", new[] { "Stellt die gesicherten Originalwerte wieder her und entfernt den Schreibschutz.", "Restores the backed-up original values and removes read-only protection.", "Restaure les valeurs d’origine sauvegardées et retire la lecture seule.", "Restaura los valores originales guardados y quita la protección de solo lectura.", "Yedeklenen özgün değerleri geri yükler ve salt okunur korumasını kaldırır.", "Przywraca zapisane oryginalne wartości i usuwa atrybut tylko do odczytu." });
            add("potato.lightDesc", new[] { "Setzt Sichtweite, Schatten und Texturen auf niedrige Qualität (1). Die Datei wird schreibgeschützt.", "Sets view distance, shadows and textures to low quality (1). The file becomes read-only.", "Règle la distance, les ombres et les textures sur une qualité faible (1). Le fichier devient en lecture seule.", "Pone distancia, sombras y texturas en calidad baja (1). El archivo queda de solo lectura.", "Görüş mesafesi, gölgeler ve dokuları düşük kaliteye (1) ayarlar. Dosya salt okunur olur.", "Ustawia zasięg widzenia, cienie i tekstury na niską jakość (1). Plik będzie tylko do odczytu." });
            add("potato.extremeDesc", new[] { "Setzt Sichtweite, Schatten und Texturen auf 0 und importiert danach ein ausgewähltes NVIDIA-.nip-Profil.", "Sets view distance, shadows and textures to 0, then imports a selected NVIDIA .nip profile.", "Règle la distance, les ombres et les textures sur 0, puis importe un profil NVIDIA .nip choisi.", "Pone distancia, sombras y texturas en 0 y después importa un perfil NVIDIA .nip seleccionado.", "Görüş mesafesi, gölgeler ve dokuları 0 yapar, ardından seçilen NVIDIA .nip profilini içe aktarır.", "Ustawia zasięg widzenia, cienie i tekstury na 0, a następnie importuje wybrany profil NVIDIA .nip." });
            add("potato.apply", new[] { "Anwenden", "Apply", "Appliquer", "Aplicar", "Uygula", "Zastosuj" });
            add("potato.reset", new[] { "Originalzustand wiederherstellen", "Restore original settings", "Restaurer les paramètres d’origine", "Restaurar valores originales", "Özgün ayarları geri yükle", "Przywróć ustawienia oryginalne" });
            add("potato.readOnly", new[] { "Hinweis: Potato-Profile setzen GameUserSettings.ini auf schreibgeschützt. Fortnite kann dadurch Änderungen an dieser Datei nicht speichern. Normal/Zurücksetzen stellt die gesicherte Datei wieder her und entfernt den Schreibschutz.", "Note: Potato profiles make GameUserSettings.ini read-only. Fortnite may then be unable to save changes to this file. Normal/Reset restores the backup and removes read-only protection.", "Remarque : les profils Potato rendent GameUserSettings.ini en lecture seule. Fortnite pourrait ne plus pouvoir enregistrer ce fichier. Normal/Réinitialiser restaure la sauvegarde et retire la lecture seule.", "Nota: los perfiles Potato hacen que GameUserSettings.ini sea de solo lectura. Fortnite quizá no pueda guardar cambios allí. Normal/Restablecer restaura la copia y quita la protección.", "Not: Potato profilleri GameUserSettings.ini dosyasını salt okunur yapar. Fortnite bu dosyaya değişiklik kaydedemeyebilir. Normal/Sıfırla yedeği geri yükleyip korumayı kaldırır.", "Uwaga: profile Potato ustawiają GameUserSettings.ini jako tylko do odczytu. Fortnite może nie zapisywać zmian w tym pliku. Normal/Reset przywraca kopię i usuwa blokadę zapisu." });
            add("potato.driverNote", new[] { "NVIDIA-Treiberprofile stammen aus einer von dir gewählten .nip-Datei und erfordern eine Administratorbestätigung. Freezer kann diese externe Treiberänderung nicht selbst zurücksetzen; sichere oder exportiere das Profil zuvor in NVIDIA Profile Inspector.", "NVIDIA driver profiles come from a .nip file you choose and require administrator approval. Freezer cannot undo this external driver change; back up or export the profile in NVIDIA Profile Inspector first.", "Les profils de pilote NVIDIA proviennent d’un fichier .nip choisi et nécessitent une validation administrateur. Freezer ne peut pas annuler seul ce changement externe ; sauvegardez ou exportez le profil dans NVIDIA Profile Inspector.", "Los perfiles del controlador NVIDIA proceden de un .nip elegido y requieren aprobación de administrador. Freezer no puede revertir este cambio externo; guarda o exporta antes el perfil en NVIDIA Profile Inspector.", "NVIDIA sürücü profilleri seçtiğin .nip dosyasından gelir ve yönetici onayı gerektirir. Freezer bu harici sürücü değişikliğini geri alamaz; önce NVIDIA Profile Inspector'da yedekle veya dışa aktar.", "Profile sterownika NVIDIA pochodzą z wybranego pliku .nip i wymagają zgody administratora. Freezer nie cofnie tej zewnętrznej zmiany; najpierw wykonaj kopię lub eksport w NVIDIA Profile Inspector." });
            add("potato.confirm", new[] { "Die Fortnite-Datei wird vorher gesichert. Vorhandene Qualitätswerte werden geändert und die Datei anschließend schreibgeschützt.", "The Fortnite file will be backed up first. Existing quality values will be changed and the file will then be made read-only.", "Le fichier Fortnite sera sauvegardé. Les valeurs existantes seront modifiées puis le fichier passera en lecture seule.", "Primero se guardará el archivo de Fortnite. Se cambiarán los valores de calidad y después quedará de solo lectura.", "Fortnite dosyası önce yedeklenecek. Kalite değerleri değiştirilecek ve ardından dosya salt okunur yapılacak.", "Plik Fortnite zostanie najpierw skopiowany. Istniejące wartości jakości zostaną zmienione, a plik będzie tylko do odczytu." });
            add("potato.nipPrompt", new[] { "Wähle das NVIDIA-Profil (.nip), das für den extremen Look importiert werden soll.", "Choose the NVIDIA profile (.nip) to import for the extreme look.", "Choisissez le profil NVIDIA (.nip) à importer pour l’aspect extrême.", "Elige el perfil NVIDIA (.nip) que se importará para el aspecto extremo.", "Aşırı görünüm için içe aktarılacak NVIDIA profilini (.nip) seç.", "Wybierz profil NVIDIA (.nip) do importu dla ekstremalnego wyglądu." });
            add("potato.npiPrompt", new[] { "NVIDIA Profile Inspector wurde nicht gefunden. Wähle die Datei nvidiaProfileInspector.exe aus.", "NVIDIA Profile Inspector was not found. Select nvidiaProfileInspector.exe.", "NVIDIA Profile Inspector est introuvable. Sélectionnez nvidiaProfileInspector.exe.", "No se encontró NVIDIA Profile Inspector. Selecciona nvidiaProfileInspector.exe.", "NVIDIA Profile Inspector bulunamadı. nvidiaProfileInspector.exe dosyasını seç.", "Nie znaleziono NVIDIA Profile Inspector. Wybierz nvidiaProfileInspector.exe." });
            add("potato.importFailed", new[] { "Das NVIDIA-Profil konnte nicht gestartet oder importiert werden. Die Fortnite-Datei wurde nicht verändert.", "The NVIDIA profile could not be started or imported. The Fortnite file was not changed.", "Le profil NVIDIA n’a pas pu être démarré ou importé. Le fichier Fortnite n’a pas été modifié.", "No se pudo iniciar o importar el perfil NVIDIA. El archivo de Fortnite no se modificó.", "NVIDIA profili başlatılamadı veya içe aktarılamadı. Fortnite dosyası değiştirilmedi.", "Nie udało się uruchomić lub zaimportować profilu NVIDIA. Plik Fortnite nie został zmieniony." });
            add("potato.configFailedAfterDriver", new[] { "Der NVIDIA-Import wurde gestartet, aber die Fortnite-Datei konnte nicht sicher aktualisiert werden. Stelle ein importiertes Treiberprofil bei Bedarf separat im Profile Inspector wieder her.", "The NVIDIA import was started, but the Fortnite file could not be updated safely. Restore the imported driver profile separately in Profile Inspector if needed.", "L’import NVIDIA a été démarré, mais le fichier Fortnite n’a pas pu être modifié sans risque. Restaurez séparément le profil dans Profile Inspector si nécessaire.", "Se inició la importación NVIDIA, pero no se pudo actualizar el archivo Fortnite de forma segura. Si hace falta, restaura el perfil en Profile Inspector.", "NVIDIA içe aktarma başlatıldı ancak Fortnite dosyası güvenli biçimde güncellenemedi. Gerekirse sürücü profilini Profile Inspector'dan geri yükle.", "Import NVIDIA został uruchomiony, ale nie można było bezpiecznie zmienić pliku Fortnite. W razie potrzeby przywróć profil osobno w Profile Inspector." });
            add("potato.importCancelled", new[] { "Die Administratorabfrage wurde abgebrochen. Es wurden keine Änderungen vorgenommen.", "The administrator prompt was cancelled. No changes were made.", "La demande d’autorisation administrateur a été annulée. Aucune modification n’a été effectuée.", "Se canceló la solicitud de administrador. No se realizaron cambios.", "Yönetici isteği iptal edildi. Hiçbir değişiklik yapılmadı.", "Anulowano prośbę o uprawnienia administratora. Nie wprowadzono zmian." });
            add("potato.importStarted", new[] { "Der Importauftrag wurde an NVIDIA Profile Inspector übergeben. Prüfe dortige Fehlermeldungen. Fortnite-Einstellungen wurden aktualisiert und die Datei schreibgeschützt.", "The import was handed to NVIDIA Profile Inspector. Check it for errors. Fortnite settings were updated and the file is now read-only.", "L’import a été transmis à NVIDIA Profile Inspector. Vérifiez les erreurs éventuelles. Les paramètres Fortnite ont été modifiés et le fichier est en lecture seule.", "La importación se envió a NVIDIA Profile Inspector. Comprueba los errores allí. Se actualizaron los ajustes de Fortnite y el archivo es de solo lectura.", "İçe aktarma NVIDIA Profile Inspector'a gönderildi. Hataları orada kontrol et. Fortnite ayarları güncellendi ve dosya salt okunur yapıldı.", "Przekazano import do NVIDIA Profile Inspector. Sprawdź ewentualne błędy. Ustawienia Fortnite zostały zmienione, a plik jest tylko do odczytu." });
            add("potato.lightDone", new[] { "Leichtes Potato-Profil angewendet. Die Originaldatei ist gesichert.", "Light potato profile applied. The original file is backed up.", "Profil Potato léger appliqué. Le fichier d’origine est sauvegardé.", "Perfil Potato ligero aplicado. El archivo original está guardado.", "Hafif Potato profili uygulandı. Özgün dosya yedeklendi.", "Zastosowano lekki profil Potato. Oryginalny plik jest w kopii." });
            add("potato.noBackup", new[] { "Es gibt keine Freezer-Sicherung zum Wiederherstellen.", "There is no Freezer backup to restore.", "Aucune sauvegarde Freezer à restaurer.", "No hay una copia de Freezer para restaurar.", "Geri yüklenecek Freezer yedeği yok.", "Brak kopii Freezer do przywrócenia." });
            add("potato.keysMissing", new[] { "Die drei Fortnite-Werte für Sichtweite, Schatten und Textur wurden nicht alle gefunden. Die Datei blieb unverändert.", "The Fortnite values for view distance, shadows and textures were not all found. The file was left unchanged.", "Les trois valeurs Fortnite de distance, ombres et textures n’ont pas toutes été trouvées. Le fichier est inchangé.", "No se encontraron los tres valores de distancia, sombras y texturas. El archivo no se modificó.", "Görüş mesafesi, gölge ve doku için üç Fortnite değeri de bulunamadı. Dosya değiştirilmedi.", "Nie znaleziono wszystkich trzech wartości Fortnite: zasięgu, cieni i tekstur. Plik pozostał bez zmian." });
            add("potato.running", new[] { "Beende Fortnite vollständig, bevor du dieses Profil anwendest oder zurücksetzt.", "Close Fortnite completely before applying or restoring this profile.", "Fermez complètement Fortnite avant d’appliquer ou de restaurer ce profil.", "Cierra Fortnite por completo antes de aplicar o restaurar este perfil.", "Bu profili uygulamadan veya geri yüklemeden önce Fortnite'ı tamamen kapat.", "Zamknij Fortnite przed zastosowaniem lub przywróceniem profilu." });
            add("potato.restoreConfirm", new[] { "Die gespeicherte GameUserSettings.ini wird wiederhergestellt und der Schreibschutz entfernt. Die Sicherung bleibt für weitere Wiederherstellungen erhalten.", "The backed-up GameUserSettings.ini will be restored and read-only protection removed. The backup will be kept for future restores.", "Le GameUserSettings.ini sauvegardé sera restauré et la lecture seule retirée. La sauvegarde sera conservée pour les restaurations futures.", "Se restaurará la copia de GameUserSettings.ini y se quitará la protección de solo lectura. La copia se conservará.", "Yedeklenen GameUserSettings.ini geri yüklenecek ve salt okunur koruması kaldırılacak. Yedek sonraki geri yüklemeler için tutulacak.", "Zostanie przywrócony zapisany GameUserSettings.ini, a blokada zapisu usunięta. Kopia pozostanie na przyszłość." });
            add("benchmark.title", new[] { "Leistung messen", "Measure performance", "Mesurer les performances", "Medir rendimiento", "Performansı ölç", "Pomiar wydajności" });
            add("benchmark.subtitle", new[] { "Wiederholbare Spielsitzungen vergleichen. Freezer wendet dabei keine Optimierungen automatisch an.", "Compare repeatable gaming sessions. Freezer does not apply optimizations automatically.", "Comparez des sessions reproductibles. Freezer n’applique aucune optimisation automatiquement.", "Compara sesiones repetibles. Freezer no aplica optimizaciones automáticamente.", "Tekrarlanabilir oyun oturumlarını karşılaştırın. Freezer optimizasyonları otomatik uygulamaz.", "Porównuj powtarzalne sesje. Freezer nie stosuje optymalizacji automatycznie." });
            add("benchmark.runTitle", new[] { "Messlauf", "Benchmark run", "Mesure", "Medición", "Ölçüm", "Pomiar" });
            add("benchmark.game", new[] { "Laufendes Spiel", "Running game", "Jeu en cours", "Juego activo", "Çalışan oyun", "Uruchomiona gra" });
            add("benchmark.profile", new[] { "Profil-Kennzeichnung", "Profile label", "Étiquette du profil", "Etiqueta del perfil", "Profil etiketi", "Etykieta profilu" });
            add("benchmark.duration", new[] { "Dauer", "Duration", "Durée", "Duración", "Süre", "Czas" });
            add("benchmark.refresh", new[] { "Spiele aktualisieren", "Refresh games", "Actualiser les jeux", "Actualizar juegos", "Oyunları yenile", "Odśwież gry" });
            add("benchmark.start", new[] { "Messung starten", "Start measurement", "Démarrer la mesure", "Iniciar medición", "Ölçümü başlat", "Rozpocznij pomiar" });
            add("benchmark.stop", new[] { "Messung beenden", "Stop measurement", "Arrêter la mesure", "Detener medición", "Ölçümü durdur", "Zatrzymaj pomiar" });
            add("benchmark.idle", new[] { "Bereit. Bitte dieselbe Szene und Route für Vergleichsläufe verwenden.", "Ready. Use the same scene and route for comparable runs.", "Prêt. Utilisez la même scène et le même parcours pour comparer.", "Listo. Usa la misma escena y recorrido para comparar.", "Hazır. Karşılaştırmalar için aynı sahne ve rotayı kullanın.", "Gotowe. Do porównań użyj tej samej sceny i trasy." });
            add("benchmark.running", new[] { "Messung läuft …", "Measurement running …", "Mesure en cours…", "Medición en curso…", "Ölçüm sürüyor…", "Pomiar trwa…" });
            add("benchmark.cancelled", new[] { "Messung abgebrochen, weil die Ansicht verlassen wurde.", "Measurement cancelled because the page was left.", "Mesure annulée car la page a été quittée.", "Medición cancelada al salir de la página.", "Sayfadan ayrıldığınız için ölçüm iptal edildi.", "Pomiar anulowany po opuszczeniu strony." });
            add("benchmark.results", new[] { "Ergebnis des letzten Laufs", "Last run results", "Résultats du dernier test", "Resultados de la última prueba", "Son ölçüm sonuçları", "Wyniki ostatniego pomiaru" });
            add("benchmark.noResults", new[] { "Noch kein abgeschlossener Messlauf. 1%-Werte hängen von Dauer und Anzahl der erfassten Frames ab.", "No completed run yet. 1% metrics depend on run duration and captured frame count.", "Aucune mesure terminée. Les métriques à 1 % dépendent de la durée et du nombre d’images.", "Aún no hay mediciones. Las métricas del 1 % dependen de la duración y los fotogramas capturados.", "Henüz tamamlanmış ölçüm yok. %1 değerleri süreye ve kare sayısına bağlıdır.", "Brak ukończonego pomiaru. Wartości 1% zależą od czasu i liczby klatek." });
            add("benchmark.sampleThreshold", new[] { "Für 1%-Low sind mindestens 1.000 Frames, für 0,1%-Low mindestens 10.000 Frames nötig; darunter wird — angezeigt.", "1% low needs at least 1,000 frames and 0.1% low 10,000; otherwise the value is shown as unavailable.", "Le 1 % faible nécessite 1 000 images et le 0,1 % faible 10 000 ; sinon la valeur est indisponible.", "El 1 % bajo necesita 1.000 fotogramas y el 0,1 % 10.000; de lo contrario se indica como no disponible.", "%1 düşük için 1.000, %0,1 düşük için 10.000 kare gerekir; aksi halde kullanılamaz gösterilir.", "1% low wymaga 1 000 klatek, a 0,1% low 10 000; w przeciwnym razie wartość jest niedostępna." });
            add("benchmark.avgFps", new[] { "Durchschnitt FPS", "Average FPS", "FPS moyen", "FPS promedio", "Ortalama FPS", "Średnie FPS" });
            add("benchmark.oneLow", new[] { "1%-Low", "1% low", "1 % faible", "1 % bajo", "%1 düşük", "1% low" });
            add("benchmark.pointOneLow", new[] { "0,1%-Low", "0.1% low", "0,1 % faible", "0,1 % bajo", "%0,1 düşük", "0,1% low" });
            add("benchmark.frameTime", new[] { "Framezeit Mittel / p95", "Frame time mean / p95", "Temps d’image moy. / p95", "Tiempo de fotograma med. / p95", "Kare süresi ort. / p95", "Czas klatki śr. / p95" });
            add("benchmark.frameCount", new[] { "Erfasste Frames", "Captured frames", "Images capturées", "Fotogramas capturados", "Yakalanan kare", "Zarejestrowane klatki" });
            add("benchmark.compareTitle", new[] { "Messläufe vergleichen", "Compare runs", "Comparer les mesures", "Comparar mediciones", "Ölçümleri karşılaştır", "Porównaj pomiary" });
            add("benchmark.baseline", new[] { "Referenzlauf", "Baseline run", "Mesure de référence", "Medición de referencia", "Referans ölçüm", "Pomiar bazowy" });
            add("benchmark.comparisonRun", new[] { "Vergleichslauf", "Comparison run", "Mesure comparée", "Medición comparada", "Karşılaştırma ölçümü", "Pomiar porównawczy" });
            add("benchmark.compare", new[] { "Vergleich anzeigen", "Show comparison", "Afficher la comparaison", "Mostrar comparación", "Karşılaştırmayı göster", "Pokaż porównanie" });
            add("benchmark.exportCsv", new[] { "CSV exportieren", "Export CSV", "Exporter CSV", "Exportar CSV", "CSV dışa aktar", "Eksportuj CSV" });
            add("benchmark.comparison", new[] { "Ø FPS {0} → {1} ({2}); 1%-Low {3} → {4} ({5}); Framezeit p95 {6} → {7} ms.", "Avg FPS {0} → {1} ({2}); 1% low {3} → {4} ({5}); p95 frame time {6} → {7} ms.", "FPS moy. {0} → {1} ({2}) ; 1 % faible {3} → {4} ({5}) ; temps p95 {6} → {7} ms.", "FPS prom. {0} → {1} ({2}); 1 % bajo {3} → {4} ({5}); tiempo p95 {6} → {7} ms.", "Ort. FPS {0} → {1} ({2}); %1 düşük {3} → {4} ({5}); p95 kare süresi {6} → {7} ms.", "Śr. FPS {0} → {1} ({2}); 1% low {3} → {4} ({5}); czas p95 {6} → {7} ms." });
            add("benchmark.diagnosis", new[] { "Messhinweise", "Measurement notes", "Notes de mesure", "Notas de medición", "Ölçüm notları", "Uwagi pomiarowe" });
            add("benchmark.diagnosisUnknown", new[] { "Für einen Engpasshinweis werden ausreichend Messwerte benötigt. Sensorlücken werden nicht geschätzt.", "More samples are needed for a bottleneck hint. Missing sensor values are not estimated.", "Il faut davantage de mesures pour indiquer un goulot. Les valeurs manquantes ne sont pas estimées.", "Se necesitan más muestras para indicar un cuello de botella. No se estiman valores ausentes.", "Darboğaz ipucu için daha fazla örnek gerekir. Eksik değerler tahmin edilmez.", "Do wskazania ograniczenia potrzeba więcej próbek. Brakujące wartości nie są szacowane." });
            add("benchmark.hardware", new[] { "System und Hinweise", "System and guidance", "Système et conseils", "Sistema y orientación", "Sistem ve öneriler", "System i wskazówki" });
            add("benchmark.hardwareUnknown", new[] { "Nicht verfügbare Daten werden ausdrücklich so angezeigt. Keine automatische Treiber- oder Feature-Installation.", "Unavailable data is identified as such. No drivers or features are installed automatically.", "Les données indisponibles sont signalées. Aucun pilote ni fonctionnalité n’est installé automatiquement.", "Los datos no disponibles se indican como tales. No se instalan controladores ni funciones automáticamente.", "Kullanılamayan veriler belirtilir. Sürücü veya özellik otomatik yüklenmez.", "Brakujące dane są oznaczane. Sterowniki ani funkcje nie są instalowane automatycznie." });
            add("benchmark.diagnosisClear", new[] { "In diesen Daten zeigt sich kein eindeutiges Auslastungslimit. Das schließt andere Engpässe nicht aus.", "These samples show no clear utilization limit. This does not rule out other bottlenecks.", "Ces mesures ne montrent pas de limite claire. D’autres goulots restent possibles.", "Estas muestras no muestran un límite claro. No se descartan otros cuellos de botella.", "Bu örneklerde belirgin bir kullanım sınırı yok. Diğer darboğazlar hariç tutulmaz.", "Te próbki nie wskazują wyraźnego limitu. Inne ograniczenia są możliwe." });
            add("benchmark.gpuPressure", new[] { "GPU-Auslastung lag im Mittel bei {0}%: ein GPU-Limit ist möglich.", "Average GPU utilization was {0}%: a GPU limit is possible.", "L’utilisation moyenne du GPU était de {0} % : une limite GPU est possible.", "El uso medio de GPU fue {0}%: es posible un límite de GPU.", "Ortalama GPU kullanımı %{0}: GPU sınırı olabilir.", "Średnie użycie GPU wyniosło {0}%: możliwe ograniczenie GPU." });
            add("benchmark.cpuPressure", new[] { "Ein logischer CPU-Kern erreichte {0}% bei niedrigerer GPU-Last: eine CPU-seitige Begrenzung ist möglich.", "A logical CPU core reached {0}% while GPU utilization was lower: a CPU-side limit is possible.", "Un cœur logique a atteint {0} % avec une utilisation GPU inférieure : une limite CPU est possible.", "Un núcleo lógico llegó a {0}% con menor uso de GPU: es posible un límite de CPU.", "GPU kullanımı daha düşükken bir mantıksal CPU çekirdeği %{0} seviyesine ulaştı: CPU sınırı olabilir.", "Jeden logiczny rdzeń osiągnął {0}% przy niższym użyciu GPU: możliwe ograniczenie CPU." });
            add("benchmark.ramPressure", new[] { "RAM-Auslastung erreichte {0}%: Speicherdruck ist möglich.", "RAM utilization reached {0}%: memory pressure is possible.", "L’utilisation de la RAM a atteint {0} % : une pression mémoire est possible.", "El uso de RAM llegó a {0}%: puede haber presión de memoria.", "RAM kullanımı %{0} seviyesine ulaştı: bellek baskısı olabilir.", "Użycie RAM osiągnęło {0}%: możliwa presja pamięci." });
            add("benchmark.heuristic", new[] { "Das sind Hinweise aus Sensoren, keine eindeutige Engpassdiagnose.", "These are sensor-based hints, not a definitive bottleneck diagnosis.", "Ces indications issues des capteurs ne constituent pas un diagnostic définitif.", "Son indicios de sensores, no un diagnóstico definitivo.", "Bunlar sensör ipuçlarıdır, kesin darboğaz teşhisi değildir.", "To wskazówki z czujników, nie ostateczna diagnoza." });
            add("benchmark.incomparableGames", new[] { "Hinweis: unterschiedliche Spiele; Vergleich nur eingeschränkt aussagekräftig.", "Note: different games; the comparison has limited meaning.", "Note : jeux différents ; comparaison limitée.", "Aviso: juegos distintos; la comparación es limitada.", "Not: farklı oyunlar; karşılaştırma sınırlı anlam taşır.", "Uwaga: różne gry; porównanie ma ograniczoną wartość." });
            add("benchmark.csvSaved", new[] { "CSV-Datei exportiert.", "CSV exported.", "CSV exporté.", "CSV exportado.", "CSV dışa aktarıldı.", "Wyeksportowano CSV." });
            add("diagnostic.export", new[] { "Diagnose prüfen / exportieren", "Review / export diagnostics", "Vérifier / exporter le diagnostic", "Revisar / exportar diagnóstico", "Tanılamayı incele / dışa aktar", "Przejrzyj / eksportuj diagnostykę" });
            add("diagnostic.previewTitle", new[] { "Diagnosebericht prüfen", "Review diagnostic report", "Vérifier le rapport de diagnostic", "Revisar informe de diagnóstico", "Tanılama raporunu incele", "Przejrzyj raport diagnostyczny" });
            add("diagnostic.previewHint", new[] { "Der folgende Bericht wird nur gespeichert, wenn du ausdrücklich exportierst. Er enthält keine Benutzerpfade, Prozess-IDs oder Seriennummern.", "The report below is saved only if you explicitly export it. It excludes user paths, process IDs, and serial numbers.", "Le rapport n’est enregistré que si vous l’exportez. Il exclut les chemins utilisateur, PID et numéros de série.", "El informe solo se guarda si lo exportas. Excluye rutas de usuario, PID y números de serie.", "Aşağıdaki rapor yalnızca dışa aktarırsanız kaydedilir. Kullanıcı yolları, işlem kimlikleri ve seri numaraları içermez.", "Raport zostanie zapisany tylko po eksporcie. Nie zawiera ścieżek użytkownika, PID ani numerów seryjnych." });
            add("diagnostic.exportNow", new[] { "Bericht speichern …", "Save report …", "Enregistrer le rapport…", "Guardar informe…", "Raporu kaydet…", "Zapisz raport…" });
            add("diagnostic.exported", new[] { "Diagnosebericht exportiert.", "Diagnostic report exported.", "Rapport de diagnostic exporté.", "Informe de diagnóstico exportado.", "Tanılama raporu dışa aktarıldı.", "Wyeksportowano raport diagnostyczny." });
            add("benchmark.resources", new[] { "Sensor-Durchschnitt CPU / GPU / RAM", "Sensor average CPU / GPU / RAM", "Moyenne capteurs CPU / GPU / RAM", "Promedio sensores CPU / GPU / RAM", "CPU / GPU / RAM sensör ortalaması", "Średnia czujników CPU / GPU / RAM" });
            add("benchmark.noGame", new[] { "Kein unterstützter Spielprozess gefunden. Starte das Spiel und aktualisiere die Liste.", "No supported game process found. Start the game and refresh the list.", "Aucun jeu pris en charge trouvé. Lancez le jeu et actualisez la liste.", "No se encontró un juego compatible. Inicia el juego y actualiza la lista.", "Desteklenen oyun süreci bulunamadı. Oyunu başlatıp listeyi yenileyin.", "Nie znaleziono obsługiwanego procesu gry. Uruchom grę i odśwież listę." });
            add("benchmark.presentMonMissing", new[] { "PresentMon ist nicht bereit. Warte kurz, bis die eingebettete Komponente vorbereitet wurde.", "PresentMon is not ready. Wait briefly for the embedded component to be prepared.", "PresentMon n’est pas prêt. Patientez pendant la préparation du composant intégré.", "PresentMon no está listo. Espera mientras se prepara el componente integrado.", "PresentMon hazır değil. Yerleşik bileşenin hazırlanmasını bekleyin.", "PresentMon nie jest gotowy. Poczekaj na przygotowanie składnika." });
            add("benchmark.saved", new[] { "Messlauf gespeichert.", "Run saved.", "Mesure enregistrée.", "Medición guardada.", "Ölçüm kaydedildi.", "Zapisano pomiar." });
            add("benchmark.profileBalanced", new[] { "Ausgewogen", "Balanced", "Équilibré", "Equilibrado", "Dengeli", "Zrównoważony" });
            add("benchmark.profileMax", new[] { "Max FPS", "Max FPS", "FPS max", "FPS máx.", "Maks. FPS", "Maks. FPS" });
            add("benchmark.profileStreamer", new[] { "Streamer", "Streamer", "Streaming", "Streaming", "Yayın", "Streaming" });
            add("benchmark.profileCustom", new[] { "Benutzerdefiniert", "Custom", "Personnalisé", "Personalizado", "Özel", "Niestandardowy" });
            add("benchmark.openDisplay", new[] { "Anzeige-Einstellungen", "Display settings", "Paramètres d’affichage", "Configuración de pantalla", "Ekran ayarları", "Ustawienia ekranu" });
            add("benchmark.openStartup", new[] { "Autostart prüfen", "Review startup apps", "Vérifier le démarrage", "Revisar inicio", "Başlangıç uygulamalarını incele", "Aplikacje startowe" });
            add("benchmark.openDrivers", new[] { "Offizielle Treiberhilfe", "Official driver help", "Aide officielle des pilotes", "Ayuda oficial de controladores", "Resmî sürücü yardımı", "Oficjalna pomoc sterowników" });
            add("benchmark.taskManager", new[] { "Task-Manager öffnen", "Open Task Manager", "Ouvrir le Gestionnaire des tâches", "Abrir Administrador de tareas", "Görev Yöneticisi'ni aç", "Otwórz Menedżera zadań" });
            add("benchmark.activityTitle", new[] { "Hintergrund- und Autostart-Überblick", "Background and startup overview", "Vue d’ensemble arrière-plan et démarrage", "Resumen de segundo plano e inicio", "Arka plan ve başlangıç özeti", "Przegląd procesów w tle i autostartu" });
            add("benchmark.refreshActivity", new[] { "Aktivität aktualisieren", "Refresh activity", "Actualiser l’activité", "Actualizar actividad", "Etkinliği yenile", "Odśwież aktywność" });
            add("benchmark.activityLoading", new[] { "Prozess- und Autostartinformationen werden gelesen …", "Reading process and startup information …", "Lecture des processus et du démarrage…", "Leyendo procesos e inicio…", "Süreç ve başlangıç bilgileri okunuyor…", "Odczytywanie procesów i autostartu…" });
            add("benchmark.topProcesses", new[] { "Top-Prozesse nach Arbeitsspeicher (Momentaufnahme): {0}", "Top processes by memory (snapshot): {0}", "Principaux processus par mémoire (instantané) : {0}", "Procesos principales por memoria (instantánea): {0}", "Belleğe göre en yüksek süreçler (anlık): {0}", "Najwięcej pamięci używają (migawka): {0}" });
            add("benchmark.startupCount", new[] { "Autostart-Einträge: {0}. Windows-Einstellungen öffnen, um sie selbst zu prüfen; Freezer deaktiviert nichts automatisch.", "Startup entries: {0}. Review them in Windows Settings; Freezer does not disable anything automatically.", "Entrées au démarrage : {0}. Vérifiez-les dans Windows ; Freezer ne désactive rien automatiquement.", "Entradas de inicio: {0}. Revísalas en Configuración; Freezer no desactiva nada automáticamente.", "Başlangıç girdisi: {0}. Windows Ayarları'ndan inceleyin; Freezer otomatik kapatmaz.", "Elementy autostartu: {0}. Sprawdź je w Ustawieniach; Freezer niczego nie wyłącza automatycznie." });
            add("benchmark.noDriverVendor", new[] { "Hersteller nicht eindeutig erkannt. Öffne die Herstellerseite manuell.", "Vendor not identified with confidence. Choose the manufacturer site manually.", "Fabricant non identifié avec certitude. Choisissez le site du fabricant manuellement.", "No se identificó el fabricante con certeza. Elige manualmente su sitio.", "Üretici kesin belirlenemedi. Üretici sayfasını kendiniz seçin.", "Nie rozpoznano pewnie producenta. Wybierz witrynę producenta ręcznie." });
            add("nav.crosshair", new[] { "Fadenkreuz", "Crosshair", "Réticule", "Punto de mira", "Nişangâh", "Celownik" });
            add("nav.stretch", new[] { "Stretch", "Stretch", "Résolution étirée", "Resolución estirada", "Genişletme", "Rozdzielczość rozciągnięta" });
            add("colors.title", new[] { "Farb-Profile", "Color profiles", "Profils couleur", "Perfiles de color", "Renk profilleri", "Profile kolorów" });
            add("colors.subtitle", new[] { "Eigene Farbwerte pro Spiel speichern und während der Spielsitzung automatisch anwenden.", "Save custom color values per game and apply them automatically during play.", "Enregistrez des couleurs par jeu et appliquez-les automatiquement pendant la partie.", "Guarda colores por juego y aplícalos automáticamente mientras juegas.", "Oyuna özel renk değerlerini kaydedin ve oyun sırasında otomatik uygulayın.", "Zapisuj kolory dla gier i stosuj je automatycznie podczas gry." });
            add("colors.nvidia", new[] { "NVIDIA", "NVIDIA", "NVIDIA", "NVIDIA", "NVIDIA", "NVIDIA" });
            add("colors.amd", new[] { "AMD", "AMD", "AMD", "AMD", "AMD", "AMD" });
            add("colors.noNvidia", new[] { "Keine NVIDIA-Grafikkarte erkannt. Dieser Bereich ist gesperrt.", "No NVIDIA graphics card detected. This section is locked.", "Aucune carte graphique NVIDIA détectée. Section verrouillée.", "No se detectó una tarjeta NVIDIA. Sección bloqueada.", "NVIDIA ekran kartı algılanmadı. Bu bölüm kilitli.", "Nie wykryto karty NVIDIA. Ta sekcja jest zablokowana." });
            add("colors.noAmd", new[] { "Keine AMD-Grafikkarte erkannt. Dieser Bereich ist gesperrt.", "No AMD graphics card detected. This section is locked.", "Aucune carte graphique AMD détectée. Section verrouillée.", "No se detectó una tarjeta AMD. Sección bloqueada.", "AMD ekran kartı algılanmadı. Bu bölüm kilitli.", "Nie wykryto karty AMD. Ta sekcja jest zablokowana." });
            add("colors.detecting", new[] { "Grafikkarten und Treiber werden erkannt …", "Detecting graphics cards and drivers …", "Détection des cartes graphiques et pilotes…", "Detectando tarjetas gráficas y controladores…", "Ekran kartları ve sürücüler algılanıyor…", "Wykrywanie kart graficznych i sterowników…" });
            add("colors.driverUnavailable", new[] { "Karte erkannt, aber die Farbsteuerung des Treibers ist nicht verfügbar. Bitte NVIDIA-Treiber bzw. AMD Software installieren oder aktualisieren.", "Card detected, but driver color controls are unavailable. Install or update the NVIDIA driver or AMD Software.", "Carte détectée, mais les contrôles couleur du pilote sont indisponibles. Installez ou mettez à jour le pilote NVIDIA ou AMD Software.", "Tarjeta detectada, pero los controles de color del controlador no están disponibles. Instala o actualiza el controlador NVIDIA o AMD Software.", "Kart algılandı ancak sürücü renk kontrolleri kullanılamıyor. NVIDIA sürücüsünü veya AMD Software'i kurup güncelleyin.", "Wykryto kartę, ale sterownik nie udostępnia kontroli kolorów. Zainstaluj lub zaktualizuj sterownik NVIDIA albo AMD Software." });
            add("colors.device", new[] { "Monitor / Ausgang", "Display / output", "Écran / sortie", "Pantalla / salida", "Ekran / çıkış", "Ekran / wyjście" });
            add("colors.saturation", new[] { "Farbsättigung", "Color saturation", "Saturation", "Saturación", "Renk doygunluğu", "Nasycenie" });
            add("colors.digitalVibrance", new[] { "Digitale Farbanpassung / Digital Vibrance", "Digital Vibrance", "Digital Vibrance", "Digital Vibrance", "Digital Vibrance", "Digital Vibrance" });
            add("colors.standard", new[] { "Standard (Treiber-Standardwerte)", "Standard (driver defaults)", "Standard (valeurs par défaut du pilote)", "Estándar (valores predeterminados del controlador)", "Standart (sürücü varsayılanları)", "Standard (domyślne sterownika)" });
            add("colors.noProfile", new[] { "Keine automatische Änderung", "No automatic change", "Aucun changement automatique", "Sin cambios automáticos", "Otomatik değişiklik yok", "Bez zmian automatycznych" });
            add("colors.profile", new[] { "Profil", "Profile", "Profil", "Perfil", "Profil", "Profil" });
            add("colors.savedProfiles", new[] { "Gespeicherte Profile", "Saved profiles", "Profils enregistrés", "Perfiles guardados", "Kayıtlı profiller", "Zapisane profile" });
            add("colors.noSavedProfiles", new[] { "Noch keine eigenen Profile gespeichert", "No custom profiles saved yet", "Aucun profil personnalisé enregistré", "Aún no hay perfiles personalizados", "Henüz özel profil kaydedilmedi", "Nie zapisano profili niestandardowych" });
            add("colors.profileName", new[] { "Profilname", "Profile name", "Nom du profil", "Nombre del perfil", "Profil adı", "Nazwa profilu" });
            add("colors.save", new[] { "Profil speichern", "Save profile", "Enregistrer le profil", "Guardar perfil", "Profili kaydet", "Zapisz profil" });
            add("colors.apply", new[] { "Profil anwenden", "Apply profile", "Appliquer le profil", "Aplicar perfil", "Profili uygula", "Zastosuj profil" });
            add("colors.reset", new[] { "Treiber-Standard", "Driver default", "Défaut du pilote", "Predeterminado del controlador", "Sürücü varsayılanı", "Domyślne sterownika" });
            add("colors.game", new[] { "Spiel", "Game", "Jeu", "Juego", "Oyun", "Gra" });
            add("colors.assign", new[] { "Spielprofil zuweisen", "Assign game profile", "Associer un profil au jeu", "Asignar perfil al juego", "Oyuna profil ata", "Przypisz profil do gry" });
            add("colors.saveAssignment", new[] { "Zuweisung speichern", "Save assignment", "Enregistrer l’association", "Guardar asignación", "Atamayı kaydet", "Zapisz przypisanie" });
            add("colors.monitoring", new[] { "Automatik: Zugewiesenes Profil beim Spielstart anwenden und nach Spielende auf Treiber-Standardwerte zurücksetzen.", "Automation: apply the assigned profile when a game starts and restore driver defaults when it exits.", "Automatique : appliquer le profil au lancement du jeu et restaurer les valeurs par défaut à sa fermeture.", "Automático: aplicar el perfil al iniciar el juego y restaurar los valores predeterminados al cerrarlo.", "Otomatik: oyun başlayınca atanmış profili uygula, kapanınca sürücü varsayılanlarına dön.", "Automatycznie: zastosuj przypisany profil po uruchomieniu gry i przywróć ustawienia domyślne po jej zamknięciu." });
            add("colors.globalNote", new[] { "Hinweis: Treiber-Farbwerte wirken auf den gewählten Bildschirmausgang global, nicht ausschließlich innerhalb des Spiels.", "Note: driver color values affect the selected display output globally, not only inside the game.", "Note : les couleurs du pilote s’appliquent globalement à la sortie choisie, pas uniquement au jeu.", "Aviso: los valores del controlador afectan globalmente a la pantalla seleccionada, no solo al juego.", "Not: sürücü renk değerleri yalnız oyunda değil seçilen ekran çıkışında genel olarak uygulanır.", "Uwaga: ustawienia sterownika wpływają globalnie na wyjście ekranu, nie tylko na grę." });
            add("colors.displayHint", new[] { "Wähle den Bildschirm anhand von Modell, Hauptmonitor/Position und Auflösung. Manuelles Anwenden und Zurücksetzen betreffen nur diese Auswahl.", "Identify a screen by model, primary/position and resolution. Manual apply and reset affect only this selection.", "Identifiez l’écran par son modèle, son rôle/sa position et sa résolution. L’application et la réinitialisation manuelles ne concernent que cet écran.", "Identifica la pantalla por modelo, posición y resolución. Aplicar y restablecer manualmente solo afecta a esta pantalla.", "Ekranı model, ana/konum bilgisi ve çözünürlüğe göre seçin. Elle uygulama ve sıfırlama yalnız bu ekranı etkiler.", "Wybierz ekran po modelu, roli/położeniu i rozdzielczości. Ręczne zastosowanie i reset dotyczą tylko tego ekranu." });
            add("colors.profileNotForDisplay", new[] { "Für diesen Monitor ist dieses Profil noch nicht gespeichert. Wähle einen gespeicherten Wert oder speichere das Profil für diesen Monitor.", "This profile has not been saved for this monitor. Choose a saved value or save the profile for this monitor.", "Ce profil n’a pas encore été enregistré pour cet écran. Choisissez une valeur enregistrée ou enregistrez le profil pour cet écran.", "Este perfil aún no se ha guardado para esta pantalla. Elige un valor guardado o guarda el perfil para esta pantalla.", "Bu profil bu monitör için kaydedilmedi. Kayıtlı bir değer seçin veya profili bu monitör için kaydedin.", "Ten profil nie został zapisany dla tego monitora. Wybierz zapisaną wartość lub zapisz profil dla tego monitora." });
            add("colors.deviceUnavailable", new[] { "Der gewählte Monitorausgang ist nicht mehr verfügbar. Bitte wähle ihn erneut aus.", "The selected display output is no longer available. Select it again.", "La sortie écran sélectionnée n’est plus disponible. Sélectionnez-la à nouveau.", "La salida de pantalla seleccionada ya no está disponible. Selecciónala de nuevo.", "Seçilen ekran çıkışı artık kullanılamıyor. Yeniden seçin.", "Wybrane wyjście ekranu jest niedostępne. Wybierz je ponownie." });
            add("colors.saved", new[] { "Farbprofil gespeichert.", "Color profile saved.", "Profil couleur enregistré.", "Perfil de color guardado.", "Renk profili kaydedildi.", "Zapisano profil kolorów." });
            add("colors.applied", new[] { "Farbprofil angewendet.", "Color profile applied.", "Profil couleur appliqué.", "Perfil de color aplicado.", "Renk profili uygulandı.", "Zastosowano profil kolorów." });
            add("colors.restored", new[] { "Treiber-Standardwerte wiederhergestellt.", "Driver defaults restored.", "Valeurs par défaut du pilote restaurées.", "Se restauraron los valores predeterminados.", "Sürücü varsayılanları geri yüklendi.", "Przywrócono ustawienia domyślne sterownika." });
            add("colors.assignmentSaved", new[] { "Spielzuweisung gespeichert.", "Game assignment saved.", "Association de jeu enregistrée.", "Asignación de juego guardada.", "Oyun ataması kaydedildi.", "Zapisano przypisanie gry." });
            add("colors.badName", new[] { "Bitte einen Profilnamen mit 1 bis 32 Zeichen eingeben.", "Enter a profile name with 1 to 32 characters.", "Saisissez un nom de profil de 1 à 32 caractères.", "Introduce un nombre de perfil de 1 a 32 caracteres.", "1–32 karakterli bir profil adı girin.", "Wpisz nazwę profilu o długości 1–32 znaków." });
            add("colors.sectionStatus", new[] { "Treiberstatus wird geprüft …", "Checking driver status …", "Vérification du pilote…", "Comprobando el controlador…", "Sürücü durumu denetleniyor…", "Sprawdzanie sterownika…" });
            add("fps.preparing", new[] { "FPS-Messung wird vorbereitet …", "Preparing FPS capture …", "Préparation de la mesure FPS…", "Preparando la medición de FPS…", "FPS ölçümü hazırlanıyor…", "Przygotowywanie pomiaru FPS…" });
            add("gaming.mode", new[] { "Gaming-Modus", "Gaming Mode", "Mode jeu", "Modo de juego", "Oyun modu", "Tryb gry" });
            add("gaming.streamerMode", new[] { "Streamer", "Streamer", "Streamer", "Streamer", "Yayın", "Streamer" });
            add("gaming.modeHint", new[] { "Game Mode und temporärer Sitzungs-Boost für erkannte Spiele.", "Game Mode and a temporary session boost for recognized games.", "Mode Jeu et boost temporaire des jeux reconnus.", "Modo Juego y refuerzo temporal para juegos reconocidos.", "Oyun Modu ve tanınan oyunlar için geçici oturum desteği.", "Tryb gry i tymczasowe wzmocnienie rozpoznanych gier." });
            add("gaming.streamerHint", new[] { "Spiel und OBS erhalten während der Sitzung eine ausgewogene Priorität.", "Balances game and OBS process priority for the session.", "Équilibre la priorité du jeu et d’OBS pendant la session.", "Equilibra la prioridad del juego y OBS durante la sesión.", "Oturumda oyun ve OBS işlem önceliğini dengeler.", "Równoważy priorytet gry i OBS podczas sesji." });
            add("updates.autoCheck", new[] { "Beim Start automatisch nach Updates suchen", "Automatically check for updates at startup", "Rechercher automatiquement les mises à jour au démarrage", "Buscar actualizaciones al iniciar", "Başlangıçta güncellemeleri otomatik denetle", "Automatycznie sprawdzaj aktualizacje przy uruchomieniu" });
            add("updates.autoCheckHint", new[] { "Standardmäßig aus. Manuelle Update-Suche bleibt jederzeit verfügbar.", "Off by default. Manual update checks remain available at any time.", "Désactivé par défaut. La recherche manuelle reste disponible.", "Desactivado por defecto. La búsqueda manual sigue disponible.", "Varsayılan olarak kapalıdır. Elle denetim her zaman kullanılabilir.", "Domyślnie wyłączone. Ręczne sprawdzanie jest zawsze dostępne." });
            add("restore.keptExternal", new[] { "Die Mauswerte wurden zwischenzeitlich geändert; Freezer hat diese Änderungen beibehalten.", "Mouse settings changed externally; Freezer kept those newer values.", "Les paramètres de la souris ont été modifiés depuis ; Freezer a conservé ces valeurs.", "La configuración del ratón cambió externamente; Freezer conservó esos valores.", "Fare ayarları dışarıdan değişti; Freezer yeni değerleri korudu.", "Ustawienia myszy zmieniono poza aplikacją; Freezer zachował te nowsze wartości." });
            add("gaming.boostWarning", new[] {
                "Freezer setzt erkannte Spiele vorübergehend auf Hohe Priorität und fordert eine 1-ms-Timerauflösung an. Für die Spielsitzung wird ein eigener Höchstleistungsplan-Klon aktiviert: Core Parking aus und minimale/maximale CPU-Leistung auf 100 % am Netzbetrieb. Das kann Temperatur, Lüfter und Stromverbrauch erhöhen; die Hardware behält ihre Schutzlimits. Dienste und RAM werden nicht pauschal verändert. Mehr FPS sind nicht garantiert.",
                "Freezer temporarily sets recognized games to High priority and requests 1 ms timer resolution. For the session it activates a private high-performance plan clone: core parking off and minimum/maximum CPU performance at 100% on AC power. Heat, fan noise, and power use can rise; hardware thermal protections remain active. Services and RAM are not changed indiscriminately. FPS gains are not guaranteed.",
                "Freezer attribue temporairement une priorité élevée aux jeux reconnus et demande un minuteur de 1 ms. Pour la session, il active une copie privée d’un plan haute performance : stationnement des cœurs désactivé et performances CPU min./max. à 100 % sur secteur. La chaleur, le bruit et la consommation peuvent augmenter; les protections thermiques restent actives. Les services et la RAM ne sont pas modifiés globalement. Aucun gain FPS n’est garanti.",
                "Freezer asigna temporalmente prioridad alta a los juegos reconocidos y solicita un temporizador de 1 ms. Durante la sesión activa una copia privada de un plan de alto rendimiento: estacionamiento de núcleos desactivado y rendimiento mínimo/máximo de CPU al 100 % con corriente. Pueden aumentar calor, ruido y consumo; se mantienen las protecciones térmicas. No modifica servicios ni RAM indiscriminadamente. No se garantizan más FPS.",
                "Freezer tanınan oyunlara geçici Yüksek öncelik verir ve 1 ms zamanlayıcı ister. Oturum için özel bir yüksek performans planı kopyası açar: çekirdek park etme kapalı, prize takılıyken minimum/maksimum CPU performansı %100. Isı, fan sesi ve güç tüketimi artabilir; donanımın termal korumaları devam eder. Hizmetleri veya RAM'i gelişigüzel değiştirmez. FPS artışı garanti edilmez.",
                "Freezer tymczasowo nadaje rozpoznanym grom wysoki priorytet i żąda timera 1 ms. Na czas sesji aktywuje prywatną kopię planu wysokiej wydajności: parkowanie rdzeni wyłączone, minimalna/maksymalna wydajność CPU 100% przy zasilaniu sieciowym. Temperatura, hałas i pobór mocy mogą wzrosnąć; zabezpieczenia termiczne pozostają aktywne. Usługi i RAM nie są zmieniane bez rozpoznania. Wzrost FPS nie jest gwarantowany." });
            add("gaming.boostDetails", new[] {
                "Gaming-Sitzung: Erkannte Spiele erhalten vorübergehend Hohe Priorität und eine 1-ms-Timerauflösung. Freezer erstellt bei Bedarf eine eigene Kopie des Ultimate-Performance-Plans (Fallback: Höchstleistung) und deaktiviert darin Core Parking sowie setzt CPU-Min/Max am Netzbetrieb auf 100 %. Priorität und Energieplan werden beim Spielende, Ausschalten oder nächsten Start wiederhergestellt.",
                "Gaming session: recognized games temporarily receive High priority and 1 ms timer resolution. Freezer creates a private Ultimate Performance plan clone when available (High performance fallback), disables core parking, and sets AC CPU min/max performance to 100%. Priority and plan are restored when the game ends, Gaming Mode is disabled, or Freezer next starts.",
                "Session de jeu : priorité élevée temporaire et minuteur de 1 ms. Freezer crée une copie privée du plan Ultimate Performance (sinon Haute performance), désactive le stationnement des cœurs et règle les performances CPU min./max. à 100 % sur secteur. La priorité et le plan sont restaurés à la fin du jeu, à la désactivation ou au prochain démarrage.",
                "Sesión de juego: prioridad alta temporal y temporizador de 1 ms. Freezer crea una copia privada del plan Ultimate Performance (o Alto rendimiento como alternativa), desactiva el estacionamiento de núcleos y fija el rendimiento mínimo/máximo de CPU al 100 % con corriente. Restaura prioridad y plan al terminar el juego, desactivar el modo o iniciar Freezer de nuevo.",
                "Oyun oturumu: tanınan oyunlara geçici Yüksek öncelik ve 1 ms zamanlayıcı verilir. Freezer, varsa Ultimate Performance planının özel bir kopyasını (yedek: Yüksek performans) oluşturur, çekirdek park etmeyi kapatır ve prize takılıyken CPU minimum/maksimum performansını %100 yapar. Oyun bitince, mod kapanınca veya Freezer yeniden açılınca geri yükler.",
                "Sesja gry: gry otrzymują tymczasowo wysoki priorytet i timer 1 ms. Freezer tworzy prywatną kopię planu Ultimate Performance (awaryjnie High performance), wyłącza parkowanie rdzeni i ustawia min./maks. wydajność CPU na 100% przy zasilaniu sieciowym. Przywraca priorytet i plan po grze, wyłączeniu trybu lub ponownym uruchomieniu Freezer." });
            add("gaming.boostOff", new[] { "Gaming-Modus ausschalten und gespeicherte Spielprioritäten wiederherstellen?", "Turn Gaming Mode off and restore saved game process priorities?", "Désactiver le mode Jeu et restaurer les priorités enregistrées ?", "¿Desactivar el modo de juego y restaurar las prioridades guardadas?", "Oyun Modu kapatılıp kaydedilen işlem öncelikleri geri yüklensin mi?", "Wyłączyć Tryb Gry i przywrócić zapisane priorytety procesów?" });
            add("gaming.streamerConfirmOn", new[] {
                "Streamer-Modus einschalten? Freezer passt die Spiel- und OBS-Prozesspriorität vorübergehend an. OBS-Einstellungen und Windows-Dienste werden nicht verändert. Der Effekt hängt vom PC ab; ein Leistungsgewinn ist nicht garantiert. Beim Ausschalten werden Freezer-Änderungen zurückgenommen.",
                "Turn Streamer Mode on? Freezer temporarily adjusts game and OBS process priority. It does not change OBS settings or Windows services. Results depend on the PC; performance gains are not guaranteed. Freezer's changes are reverted when turned off.",
                "Activer le mode Streamer ? Freezer ajuste temporairement la priorité du jeu et d’OBS. Les réglages OBS et les services Windows ne sont pas modifiés. Le résultat dépend du PC et aucun gain n’est garanti. Les changements de Freezer sont annulés à la désactivation.",
                "¿Activar el modo Streamer? Freezer ajustará temporalmente la prioridad del juego y OBS. No cambia OBS ni los servicios de Windows. El resultado depende del PC y no se garantiza una mejora. Los cambios se revierten al desactivarlo.",
                "Yayıncı Modu açılsın mı? Freezer oyun ve OBS işlem önceliğini geçici olarak ayarlar. OBS ayarları veya Windows hizmetleri değiştirilmez. Sonuç bilgisayara bağlıdır, artış garanti edilmez. Kapatıldığında Freezer değişiklikleri geri alınır.",
                "Włączyć Tryb Streamera? Freezer tymczasowo dostosuje priorytet gry i OBS. Nie zmieni ustawień OBS ani usług Windows. Wynik zależy od komputera i nie gwarantuje wzrostu wydajności. Zmiany Freezer zostaną cofnięte po wyłączeniu." });
            add("gaming.streamerConfirmOff", new[] {
                "Streamer-Modus ausschalten und von Freezer angepasste Prioritäten wiederherstellen?",
                "Turn Streamer Mode off and restore priorities adjusted by Freezer?",
                "Désactiver le mode Streamer et restaurer les priorités ajustées par Freezer ?",
                "¿Desactivar el modo Streamer y restaurar las prioridades ajustadas por Freezer?",
                "Yayıncı Modu kapatılıp Freezer'ın ayarladığı öncelikler geri yüklensin mi?",
                "Wyłączyć Tryb Streamera i przywrócić priorytety zmienione przez Freezer?" });
            add("crosshair.saved", new[] { "Fadenkreuz-Einstellungen gespeichert.", "Crosshair settings saved.", "Réglages du viseur enregistrés.", "Ajustes de la mira guardados.", "Nişangâh ayarları kaydedildi.", "Zapisano ustawienia celownika." });
            add("crosshair.opacity", new[] { "Deckkraft", "Opacity", "Opacité", "Opacidad", "Saydamlık", "Krycie" });
            add("crosshair.outline", new[] { "Kontur", "Outline", "Contour", "Contorno", "Kenarlık", "Kontur" });
            add("crosshair.glow", new[] { "Neon-Leuchten", "Neon glow", "Lueur néon", "Brillo neón", "Neon parıltısı", "Neonowa poświata" });
            add("crosshair.preview", new[] { "Live-Vorschau", "Live preview", "Aperçu en direct", "Vista previa", "Canlı önizleme", "Podgląd na żywo" });
            add("crosshair.presets", new[] { "Gespeicherte Fadenkreuze", "Saved crosshairs", "Viseurs enregistrés", "Miras guardadas", "Kayıtlı nişangâhlar", "Zapisane celowniki" });
            add("crosshair.presetSave", new[] { "Preset speichern", "Save preset", "Enregistrer le preset", "Guardar ajuste", "Profili kaydet", "Zapisz preset" });
            add("crosshair.presetApply", new[] { "Auswählen", "Load", "Charger", "Cargar", "Yükle", "Wczytaj" });
            add("crosshair.presetDelete", new[] { "Löschen", "Delete", "Supprimer", "Eliminar", "Sil", "Usuń" });
            add("crosshair.presetName", new[] { "Name für das Fadenkreuz-Preset:", "Name this crosshair preset:", "Nom du preset de viseur :", "Nombre del ajuste de mira:", "Nişangâh profili adı:", "Nazwa presetu celownika:" });
            add("crosshair.effectHint", new[] { "Das Overlay bleibt ein normales Fenster. Vollbild- und Anti-Cheat-Regeln können es ausblenden.", "The overlay remains a normal window. Fullscreen and anti-cheat rules may hide it.", "La superposition reste une fenêtre normale. Le plein écran ou l’anti-triche peut la masquer.", "La superposición sigue siendo una ventana normal. Pantalla completa o anti-cheat pueden ocultarla.", "Kaplama normal bir pencere olarak kalır. Tam ekran ve anti-cheat onu gizleyebilir.", "Nakładka pozostaje zwykłym oknem. Pełny ekran lub anti-cheat mogą ją ukryć." });
            add("crosshair.presetSaved", new[] { "Fadenkreuz-Preset gespeichert.", "Crosshair preset saved.", "Preset de viseur enregistré.", "Ajuste de mira guardado.", "Nişangâh profili kaydedildi.", "Zapisano preset celownika." });
            add("crosshair.presetRemoved", new[] { "Fadenkreuz-Preset gelöscht.", "Crosshair preset deleted.", "Preset de viseur supprimé.", "Ajuste de mira eliminado.", "Nişangâh profili silindi.", "Usunięto preset celownika." });
            add("crosshair.presetSelect", new[] { "Wähle zuerst ein gespeichertes Preset aus.", "Select a saved preset first.", "Sélectionnez d’abord un preset.", "Selecciona primero un ajuste.", "Önce kayıtlı bir profil seçin.", "Najpierw wybierz zapisany preset." });
            add("crosshair.presetOverwrite", new[] { "Dieses Preset ersetzen?", "Replace this preset?", "Remplacer ce preset ?", "¿Reemplazar este ajuste?", "Bu profil değiştirilsin mi?", "Zastąpić ten preset?" });
            add("crosshair.presetInvalid", new[] { "Das Preset ist beschädigt oder enthält ungültige Werte.", "This preset is damaged or contains invalid values.", "Ce preset est endommagé ou contient des valeurs incorrectes.", "El ajuste está dañado o contiene valores no válidos.", "Profil bozuk veya geçersiz değerler içeriyor.", "Preset jest uszkodzony lub zawiera nieprawidłowe wartości." });
            add("crosshair.presetDeleteConfirm", new[] { "Preset „{0}“ endgültig löschen?", "Delete preset “{0}”?", "Supprimer le preset « {0} » ?", "¿Eliminar el ajuste «{0}»?", "“{0}” profili silinsin mi?", "Usunąć preset „{0}”?" });
            add("crosshair.presetImageMissing", new[] { "Das eigene Fadenkreuz-Bild ist nicht verfügbar. Importiere oder zeichne es zuerst erneut.", "The custom crosshair image is unavailable. Import or draw it again first.", "L’image personnalisée du viseur est indisponible. Importez-la ou redessinez-la.", "La imagen personalizada no está disponible. Impórtala o dibújala otra vez.", "Özel nişangâh resmi yok. Önce yeniden içe aktarın veya çizin.", "Brak własnego obrazu celownika. Najpierw zaimportuj go lub narysuj ponownie." });
            add("tutorial.body", new[] { "Willkommen bei Freezer 2.43.0. Dieses kurze, überspringbare Tutorial erklärt die wichtigsten Bereiche:\r\n\r\n• Wiederherstellung: Unter Reparatur findest du Diagnose, Rücksetzen und Hinweise zu Sicherungen.\r\n• Spielprofile: Unter Spiele kannst du Profile mit Windows-Modus, Farbprofil und Stretch-Anzeige verbinden.\r\n• Stretch-Skalierung: Modi werden beim Treiber geprüft und nach einer zeitlich begrenzten Bestätigung automatisch zurückgesetzt.\r\n• Fadenkreuz: Das Overlay ist ein normales Fenster ohne Spiel-Injektion; exklusives Vollbild oder Anti-Cheat können es blockieren.\r\n\r\nAlle FPS-Vergleiche sind Beispiele. Ergebnisse hängen von Hardware, Spiel und Einstellungen ab.", "Welcome to Freezer 2.43.0. This short, skippable tour covers the main areas:\r\n\r\n• Recovery: Repair contains diagnostics, restore actions and backup guidance.\r\n• Game profiles: Games links a Windows mode, color profile and stretch display per game.\r\n• Stretch scaling: Modes are checked by the display driver and automatically reverted unless confirmed in time.\r\n• Crosshair: The overlay is a normal window with no game injection; exclusive fullscreen or anti-cheat may block it.\r\n\r\nFPS comparisons are illustrations. Results depend on hardware, game and settings.", "Bienvenue dans Freezer 2.43.0. Cette présentation facultative couvre les fonctions principales :\r\n\r\n• Restauration : Réparation contient les diagnostics, les restaurations et les sauvegardes.\r\n• Profils de jeu : Jeux relie un mode Windows, un profil couleur et une résolution étirée.\r\n• Mise à l’échelle : les modes sont vérifiés par le pilote et annulés automatiquement sans confirmation à temps.\r\n• Viseur : la superposition est une fenêtre normale sans injection ; le plein écran exclusif ou l’anti-triche peut la bloquer.\r\n\r\nLes comparaisons FPS sont illustratives.", "Bienvenido a Freezer 2.43.0. Esta guía breve y opcional cubre las áreas principales:\r\n\r\n• Recuperación: Reparación incluye diagnósticos, restauración e información de copias.\r\n• Perfiles de juego: Juegos vincula modo de Windows, perfil de color y resolución estirada.\r\n• Escalado: el controlador comprueba los modos y los revierte automáticamente si no se confirman a tiempo.\r\n• Mira: la superposición es una ventana normal sin inyección; pantalla completa exclusiva o anti-cheat pueden bloquearla.\r\n\r\nLas comparaciones de FPS son ilustrativas.", "Freezer 2.43.0'e hoş geldin. Bu kısa ve isteğe bağlı tur temel bölümleri açıklar:\r\n\r\n• Kurtarma: Onarım bölümünde tanılama, geri yükleme ve yedek bilgileri bulunur.\r\n• Oyun profilleri: Oyunlar, Windows modu, renk profili ve esnetilmiş ekranı oyuna bağlar.\r\n• Ölçekleme: Modlar sürücüde doğrulanır ve zamanında onaylanmazsa geri alınır.\r\n• Nişangâh: Oyun enjeksiyonu kullanmayan normal bir penceredir; özel tam ekran veya anti-cheat engelleyebilir.\r\n\r\nFPS karşılaştırmaları yalnızca örnektir.", "Witamy w Freezer 2.43.0. Ta krótka, opcjonalna prezentacja opisuje główne obszary:\r\n\r\n• Odzyskiwanie: Naprawa zawiera diagnostykę, przywracanie i informacje o kopiach.\r\n• Profile gier: Gry łączą tryb Windows, profil kolorów i rozciągniętą rozdzielczość.\r\n• Skalowanie: sterownik sprawdza tryby i automatycznie je cofa bez potwierdzenia na czas.\r\n• Celownik: nakładka to zwykłe okno bez wstrzykiwania do gry; wyłączny pełny ekran lub anti-cheat może ją blokować.\r\n\r\nPorównania FPS są ilustracją." });
            add("settings.trayTitle", new[] { "Beim Schließen in den Infobereich minimieren", "Minimize to the system tray when closing", "Réduire dans la zone de notification à la fermeture", "Minimizar a la bandeja al cerrar", "Kapatırken sistem tepsisine küçült", "Minimalizuj do zasobnika po zamknięciu" });
            add("settings.trayHint", new[] { "Das X blendet Freezer aus; Rechtsklick auf das Tray-Symbol bietet Öffnen und Vollständig beenden.", "The X hides Freezer; right-click its tray icon to open it or fully exit.", "Le X masque Freezer ; clic droit sur l’icône pour ouvrir ou quitter complètement.", "La X oculta Freezer; haz clic derecho en el icono para abrirlo o salir por completo.", "X, Freezer'ı gizler; açmak veya tamamen kapatmak için tepsi simgesine sağ tıklayın.", "X ukrywa Freezer; kliknij ikonę prawym przyciskiem, aby otworzyć lub zakończyć." });
            add("tray.open", new[] { "Öffnen", "Open", "Ouvrir", "Abrir", "Aç", "Otwórz" });
            add("tray.exit", new[] { "Vollständig beenden", "Exit completely", "Quitter complètement", "Salir por completo", "Tamamen çık", "Zakończ całkowicie" });
            add("tray.tooltip", new[] { "Freezer läuft im Hintergrund", "Freezer is running in the background", "Freezer fonctionne en arrière-plan", "Freezer se está ejecutando en segundo plano", "Freezer arka planda çalışıyor", "Freezer działa w tle" });
            add("network.qosWarning", new[] {
                "Freezer erstellt eine temporäre Windows-QoS-Regel für das laufende Spiel und markiert dessen ausgehende Pakete mit DSCP 46. Dafür sind Administratorrechte nötig. Router und Internetanbieter können die Markierung ignorieren; Ping oder Paketverlust werden dadurch nicht garantiert verbessert. Die Regel ist bis zum Entfernen oder Neustart aktiv.",
                "Freezer creates a temporary Windows QoS policy for the running game and marks its outgoing packets with DSCP 46. Administrator rights are required. Routers and ISPs may ignore the mark; ping and packet loss are not guaranteed to improve. The rule stays active until removed or Windows restarts.",
                "Freezer crée une règle QoS Windows temporaire pour le jeu en cours et marque ses paquets sortants DSCP 46. Des droits administrateur sont requis. Le routeur ou le fournisseur peut ignorer ce marquage ; aucune amélioration du ping ou des pertes n’est garantie. La règle reste active jusqu’à sa suppression ou au redémarrage.",
                "Freezer crea una regla QoS temporal de Windows para el juego activo y marca sus paquetes salientes con DSCP 46. Requiere permisos de administrador. El router o proveedor puede ignorar la marca; no se garantiza una mejora del ping ni de la pérdida de paquetes. La regla permanece hasta quitarla o reiniciar Windows.",
                "Freezer çalışan oyun için geçici bir Windows QoS kuralı oluşturur ve giden paketlerini DSCP 46 ile işaretler. Yönetici izni gerekir. Yönlendirici veya internet sağlayıcısı bu işareti yok sayabilir; ping ya da paket kaybında iyileşme garanti edilmez. Kural kaldırılana veya Windows yeniden başlayana kadar kalır.",
                "Freezer tworzy tymczasową regułę QoS systemu Windows dla uruchomionej gry i oznacza jej pakiety wychodzące DSCP 46. Wymaga uprawnień administratora. Router lub dostawca może zignorować oznaczenie; poprawa pingu ani utraty pakietów nie jest gwarantowana. Reguła działa do usunięcia lub ponownego uruchomienia Windows." });
            add("network.qosEnabled", new[] { "Tymczasige QoS-Regel für {0} aktiviert. Die Netzwerkroute oder den Ping kann Freezer nicht kontrollieren.", "Temporary QoS policy enabled for {0}. Freezer cannot control the network route or ping.", "Règle QoS temporaire activée pour {0}. Freezer ne contrôle ni la route réseau ni le ping.", "Regla QoS temporal activada para {0}. Freezer no controla la ruta ni el ping.", "{0} için geçici QoS kuralı açıldı. Freezer ağ rotasını veya pingi kontrol edemez.", "Włączono tymczasową regułę QoS dla {0}. Freezer nie kontroluje trasy ani pingu." });
            add("network.qosDisabled", new[] { "Die Freezer-QoS-Regel wurde entfernt.", "The Freezer QoS policy was removed.", "La règle QoS Freezer a été supprimée.", "Se eliminó la regla QoS de Freezer.", "Freezer QoS kuralı kaldırıldı.", "Usunięto regułę QoS Freezer." });
            add("network.qosNoGame", new[] { "Starte zuerst ein unterstütztes Spiel und versuche es erneut.", "Start a supported game first, then try again.", "Lancez d’abord un jeu pris en charge, puis réessayez.", "Inicia primero un juego compatible y vuelve a intentarlo.", "Önce desteklenen bir oyunu başlatıp tekrar deneyin.", "Najpierw uruchom obsługiwaną grę i spróbuj ponownie." });
            add("network.qosAdmin", new[] { "Windows hat die Administratorbestätigung abgebrochen oder abgelehnt. Es wurde keine Regeländerung bestätigt.", "Windows cancelled or denied administrator approval. The policy change was not confirmed.", "Windows a annulé ou refusé l’autorisation administrateur. La modification n’a pas été confirmée.", "Windows canceló o denegó el permiso de administrador. No se confirmó el cambio.", "Windows yönetici onayını iptal etti veya reddetti. Kural değişikliği onaylanmadı.", "Windows anulował lub odrzucił zgodę administratora. Zmiana reguły nie została potwierdzona." });
            add("network.qosNeedsAdmin", new[] { "Windows-QoS-Regeln benötigen Administratorrechte. Bestätige die Windows-Abfrage, um fortzufahren.", "Windows QoS policies require administrator rights. Approve the Windows prompt to continue.", "Les règles QoS Windows nécessitent des droits administrateur. Acceptez la demande Windows pour continuer.", "Las reglas QoS de Windows requieren permisos de administrador. Acepta el aviso de Windows para continuar.", "Windows QoS kuralları yönetici izni gerektirir. Devam etmek için Windows istemini onaylayın.", "Reguły QoS Windows wymagają uprawnień administratora. Potwierdź monit Windows, aby kontynuować." });
            add("network.qosRemove", new[] { "QoS-Regel entfernen", "Remove QoS rule", "Supprimer la règle QoS", "Quitar regla QoS", "QoS kuralını kaldır", "Usuń regułę QoS" });
            add("network.qosApply", new[] { "QoS für laufendes Spiel", "QoS for running game", "QoS pour le jeu en cours", "QoS para el juego activo", "Çalışan oyun için QoS", "QoS dla uruchomionej gry" });
            add("optitem.network_qos.title", new[] { "Lokale Spiel-QoS-Regel", "Local game QoS policy", "Règle QoS locale pour le jeu", "Regla QoS local para el juego", "Yerel oyun QoS kuralı", "Lokalna reguła QoS dla gry" });
            add("optitem.network_qos.desc", new[] { "Markiert den Netzwerkverkehr eines laufenden unterstützten Spiels temporär mit DSCP 46. Benötigt Adminbestätigung; Router können die Markierung ignorieren und Ping-Verbesserungen sind nicht garantiert. Entfernen ist möglich; Neustart löscht ActiveStore-Regeln ebenfalls.", "Temporarily marks traffic from a running supported game with DSCP 46. Requires administrator approval; routers may ignore the mark and ping gains are not guaranteed. You can remove it; Windows restart also clears ActiveStore rules.", "Marque temporairement le trafic d’un jeu pris en charge en cours avec DSCP 46. Nécessite une autorisation administrateur ; les routeurs peuvent ignorer le marquage et aucune baisse du ping n’est garantie. La règle peut être supprimée ; un redémarrage efface aussi ActiveStore.", "Marca temporalmente con DSCP 46 el tráfico de un juego compatible en ejecución. Requiere permiso de administrador; los routers pueden ignorar la marca y no se garantiza una mejora del ping. Puedes quitarla; reiniciar Windows también elimina las reglas ActiveStore.", "Çalışan desteklenen oyunun trafiğini geçici olarak DSCP 46 ile işaretler. Yönetici onayı gerekir; yönlendiriciler işareti yok sayabilir ve ping artışı garanti değildir. Kaldırabilir veya Windows'u yeniden başlatarak ActiveStore kuralını silebilirsiniz.", "Tymczasowo oznacza DSCP 46 ruch uruchomionej obsługiwanej gry. Wymaga zgody administratora; routery mogą ignorować oznaczenie i poprawa pingu nie jest gwarantowana. Możesz usunąć regułę; restart Windows usuwa również wpisy ActiveStore." });
            add("updates.localFound", new[] { "Eine neuere lokale Freezer-Version ({0}) wurde gefunden:\r\n{1}\r\n\r\nJetzt starten? Prüfe vor dem Start den Dateipfad und die Quelle.", "A newer local Freezer {0} was found:\r\n{1}\r\n\r\nStart it now? Check the file path and source before launching it.", "Une version locale plus récente de Freezer ({0}) a été trouvée :\r\n{1}\r\n\r\nLa lancer maintenant ? Vérifiez le chemin et la provenance du fichier.", "Se encontró un archivo local de Freezer más reciente ({0}):\r\n{1}\r\n\r\n¿Iniciarlo ahora? Comprueba la ruta y el origen antes de ejecutarlo.", "Daha yeni bir yerel Freezer dosyası bulundu ({0}):\r\n{1}\r\n\r\nŞimdi başlatılsın mı? Açmadan önce dosya yolunu ve kaynağını kontrol et.", "Znaleziono nowszy lokalny plik Freezer {0}:\r\n{1}\r\n\r\nUruchomić go teraz? Przed uruchomieniem sprawdź ścieżkę i źródło pliku." });
            add("updates.localBanner", new[] { "Eine neuere lokale Version ({0}) wurde gefunden. Freezer läuft normal weiter; das Update ist freiwillig.", "A newer local version ({0}) was found. Freezer continues normally; updating is optional.", "Une version locale plus récente ({0}) a été trouvée. Freezer continue normalement ; la mise à jour est facultative.", "Se encontró una versión local más reciente ({0}). Freezer sigue funcionando; la actualización es opcional.", "Daha yeni bir yerel sürüm ({0}) bulundu. Freezer normal çalışmaya devam ediyor; güncelleme isteğe bağlı.", "Znaleziono nowszą lokalną wersję ({0}). Freezer działa dalej; aktualizacja jest dobrowolna." });
            add("updates.localDetails", new[] { "Update-Paket gefunden: Version {0}\r\n{1}\r\nMit „Update installieren“ wird die vollständige EXE nach Bestätigung ausgetauscht.", "Update package found: version {0}\r\n{1}\r\nUse “Install update” to replace the complete EXE after confirmation.", "Paquet de mise à jour trouvé : version {0}\r\n{1}\r\n« Installer la mise à jour » remplacera l’EXE complète après confirmation.", "Paquete de actualización encontrado: versión {0}\r\n{1}\r\n«Instalar actualización» sustituye el EXE completo tras confirmarlo.", "Güncelleme paketi bulundu: sürüm {0}\r\n{1}\r\nOnaydan sonra tüm EXE'yi değiştirmek için “Güncellemeyi yükle”yi seç.", "Znaleziono pakiet aktualizacji: wersja {0}\r\n{1}\r\nWybierz „Zainstaluj aktualizację”, aby po potwierdzeniu zastąpić cały plik EXE." });
            add("updates.localShow", new[] { "Datei im Explorer anzeigen", "Show file in Explorer", "Afficher dans l’Explorateur", "Mostrar archivo en el Explorador", "Dosyayı Explorer'da göster", "Pokaż plik w Eksploratorze" });
            add("diagnostic.ram", new[] { "RAM-Auslastung", "RAM usage", "Utilisation RAM", "Uso de RAM", "RAM kullanımı", "Użycie RAM" });
            add("diagnostic.appResources", new[] {
                "Freezer-Prozess: Arbeitssatz {0} MB, privater Speicher {1} MB, virtueller Speicher {2} MB, Handles {3}, GDI {4}, USER {5}, .NET-Heap {6} MB",
                "Freezer process: working set {0} MB, private memory {1} MB, virtual memory {2} MB, handles {3}, GDI {4}, USER {5}, .NET heap {6} MB",
                "Processus Freezer : mémoire résidente {0} Mo, mémoire privée {1} Mo, mémoire virtuelle {2} Mo, handles {3}, GDI {4}, USER {5}, tas .NET {6} Mo",
                "Proceso Freezer: memoria de trabajo {0} MB, memoria privada {1} MB, memoria virtual {2} MB, identificadores {3}, GDI {4}, USER {5}, heap .NET {6} MB",
                "Freezer işlemi: çalışma kümesi {0} MB, özel bellek {1} MB, sanal bellek {2} MB, tanıtıcılar {3}, GDI {4}, USER {5}, .NET yığını {6} MB",
                "Proces Freezer: zestaw roboczy {0} MB, pamięć prywatna {1} MB, pamięć wirtualna {2} MB, uchwyty {3}, GDI {4}, USER {5}, sterta .NET {6} MB" });
            add("diagnostic.acpiTemp", new[] { "ACPI-Temperatursensoren (nicht zwingend CPU-Paket)", "ACPI temperature sensors (not necessarily CPU package)", "Capteurs thermiques ACPI (pas forcément le processeur)", "Sensores ACPI (no necesariamente el paquete de CPU)", "ACPI sıcaklık sensörleri (CPU paketi olmayabilir)", "Czujniki ACPI (niekoniecznie temperatura CPU)" });
            add("diagnostic.videoDrivers", new[] { "Grafiktreiber-Status", "Graphics driver status", "État du pilote graphique", "Estado del controlador gráfico", "Grafik sürücüsü durumu", "Stan sterownika grafiki" });
            add("diagnostic.notAvailable", new[] { "Nicht verfügbar / vom Treiber nicht bereitgestellt", "Unavailable / not exposed by driver", "Indisponible / non fourni par le pilote", "No disponible / no expuesto por el controlador", "Kullanılamıyor / sürücü sağlamıyor", "Niedostępne / nieudostępnione przez sterownik" });
            add("diagnostic.noGpu", new[] { "Kein Grafikadapter gefunden", "No graphics adapter found", "Aucun adaptateur graphique détecté", "No se encontró adaptador gráfico", "Grafik bağdaştırıcısı bulunamadı", "Nie znaleziono karty graficznej" });
            add("games.previous", new[] { "Zurück", "Previous", "Précédent", "Anterior", "Önceki", "Poprzednie" });
            add("games.next", new[] { "Weiter", "Next", "Suivant", "Siguiente", "Sonraki", "Następne" });
            add("games.apply", new[] { "Profil für Windows anwenden", "Apply profile to Windows", "Appliquer le profil à Windows", "Aplicar perfil a Windows", "Profili Windows'a uygula", "Zastosuj profil w Windows" });
            add("games.applyHint", new[] { "Windows-Spielprofile ändern Windows-Einstellungen. Das Fortnite-Grafikprofil bearbeitet separat vorhandene Qualitätswerte in GameUserSettings.ini, nur nach Sicherung und Bestätigung.", "Windows game profiles change Windows settings. The Fortnite graphics preset separately edits existing quality values in GameUserSettings.ini, only after backup and confirmation.", "Les profils Windows modifient les réglages de Windows. Le profil graphique Fortnite modifie séparément des valeurs existantes de GameUserSettings.ini après sauvegarde et confirmation.", "Los perfiles de Windows cambian ajustes del sistema. El perfil gráfico de Fortnite edita por separado valores existentes de GameUserSettings.ini, tras copia y confirmación.", "Windows oyun profilleri Windows ayarlarını değiştirir. Fortnite grafik profili, yedek ve onay sonrasında GameUserSettings.ini içindeki mevcut değerleri ayrıca düzenler.", "Profile Windows zmieniają ustawienia systemu. Profil grafiki Fortnite osobno edytuje istniejące wartości GameUserSettings.ini po utworzeniu kopii i potwierdzeniu." });
            add("games.profileSaved", new[] { "Profil gespeichert. Zum Anwenden auf Windows bitte den Button verwenden.", "Profile saved. Use the button to apply it to Windows.", "Profil enregistré. Utilisez le bouton pour l’appliquer à Windows.", "Perfil guardado. Usa el botón para aplicarlo a Windows.", "Profil kaydedildi. Windows'a uygulamak için düğmeyi kullanın.", "Profil zapisany. Użyj przycisku, aby zastosować go w Windows." });
            add("games.applied", new[] { "Windows-Gaming-Profil angewendet.", "Windows gaming profile applied.", "Profil de jeu Windows appliqué.", "Perfil de juego de Windows aplicado.", "Windows oyun profili uygulandı.", "Zastosowano profil gier Windows." });
            add("games.liteDetails", new[] { "Lite: Windows-Spielmodus aktivieren.", "Lite: enable Windows Game Mode.", "Lite : activer le Mode Jeu Windows.", "Lite: activar el modo de juego de Windows.", "Lite: Windows Oyun Modu'nu aç.", "Lite: włącz Tryb gry Windows." });
            add("games.balancedDetails", new[] { "Balanced: Spielmodus aktivieren und Hintergrundaufnahmen für diesen Benutzer ausschalten.", "Balanced: enable Game Mode and disable background capture for this user.", "Balanced : activer le Mode Jeu et désactiver la capture en arrière-plan.", "Balanced: activar el modo de juego y desactivar la captura en segundo plano.", "Balanced: Oyun Modu'nu aç ve bu kullanıcı için arka plan kaydını kapat.", "Balanced: włącz Tryb gry i wyłącz nagrywanie w tle dla użytkownika." });
            add("games.powerDetails", new[] { "Power: Balanced plus CPU-Maximum 100 % am Netzbetrieb. Wärme/Stromverbrauch können steigen; möglicherweise sind Adminrechte nötig.", "Power: Balanced plus 100% AC CPU maximum. Heat and power use may rise; administrator rights may be required.", "Power : Balanced et maximum CPU à 100 % sur secteur. Chaleur et consommation peuvent augmenter; droits admin possibles.", "Power: Balanced más CPU al 100 % con corriente. Puede aumentar calor y consumo; quizá se necesiten permisos de administrador.", "Power: Balanced ve prizde CPU üst sınırı %100. Isı/tüketim artabilir; yönetici izni gerekebilir.", "Power: Balanced oraz CPU 100% na zasilaniu. Może wzrosnąć temperatura i pobór; administrator może być wymagany." });
            add("games.lite", new[] { "Leichtes Profil", "Lite profile", "Profil léger", "Perfil ligero", "Hafif profil", "Lekki profil" });
            add("games.balanced", new[] { "Ausgewogen", "Balanced", "Équilibré", "Equilibrado", "Dengeli", "Zrównoważony" });
            add("games.power", new[] { "Ultimative Power-Optimierung", "Ultimate power optimization", "Optimisation de puissance ultime", "Optimización de potencia máxima", "En yüksek performans optimizasyonu", "Maksymalna optymalizacja wydajności" });
            add("games.liteDetails", new[] { "Leichtes Profil: Aktiviert den Windows-Spielmodus. Es ändert keine Spieldateien.", "Lite profile: enables Windows Game Mode. It does not change game files.", "Profil léger : active le Mode Jeu Windows. Aucun fichier du jeu n’est modifié.", "Perfil ligero: activa el modo de juego de Windows. No cambia archivos del juego.", "Hafif profil: Windows Oyun Modu'nu açar. Oyun dosyalarını değiştirmez.", "Lekki profil: włącza Tryb gry Windows. Nie zmienia plików gry." });
            add("games.balancedDetails", new[] { "Ausgewogen: Aktiviert den Spielmodus und schaltet Windows-Hintergrundaufnahmen für diesen Benutzer aus. Aufnahmeclips können dadurch ausfallen.", "Balanced: enables Game Mode and disables Windows background capture for this user. Captured clips may stop working.", "Équilibré : active le Mode Jeu et désactive la capture en arrière-plan pour cet utilisateur. Les clips peuvent ne plus fonctionner.", "Equilibrado: activa el modo de juego y desactiva la captura en segundo plano para este usuario. Los clips podrían dejar de funcionar.", "Dengeli: Oyun Modu'nu açar ve bu kullanıcı için Windows arka plan kaydını kapatır. Kayıt klipleri çalışmayabilir.", "Zrównoważony: włącza Tryb gry i wyłącza nagrywanie w tle Windows dla tego użytkownika. Klipy mogą przestać działać." });
            add("games.powerDetails", new[] { "Ultimative Power-Optimierung: Enthält das ausgewogene Profil und setzt das CPU-Maximum im Netzbetrieb auf 100 %. Wärme, Lüftergeräusch und Stromverbrauch können steigen; Windows kann Administratorrechte verlangen.", "Ultimate power optimization: includes the balanced profile and sets the CPU maximum to 100% on AC power. Heat, fan noise and power use may rise; Windows may require administrator rights.", "Optimisation ultime : inclut le profil équilibré et règle le maximum CPU à 100 % sur secteur. Chaleur, bruit et consommation peuvent augmenter; Windows peut demander l’administration.", "Optimización máxima: incluye el perfil equilibrado y fija el máximo de CPU al 100 % conectado a la corriente. Puede aumentar el calor, el ruido y el consumo; Windows podría pedir permisos de administrador.", "En yüksek performans: Dengeli profili içerir ve prize bağlıyken CPU üst sınırını %100 yapar. Isı, fan sesi ve tüketim artabilir; Windows yönetici izni isteyebilir.", "Maksymalna wydajność: obejmuje profil zrównoważony i ustawia limit CPU na 100% przy zasilaniu sieciowym. Wzrosnąć mogą temperatura, hałas i pobór; Windows może wymagać administratora." });
            add("games.maxFps", new[] { "Max-FPS-Modus", "Max FPS mode", "Mode FPS max", "Modo FPS máximo", "Maksimum FPS modu", "Tryb maks. FPS" });
            add("games.streamer", new[] { "Streamer-Modus", "Streamer mode", "Mode streamer", "Modo streamer", "Yayıncı modu", "Tryb streamera" });
            add("games.maxFpsDetails", new[] { "Max FPS: Spielmodus, Hintergrundaufnahme aus, CPU-Maximum im Netzbetrieb 100 %, erkannte Spiele erhalten vorübergehend Hohe Priorität und 1-ms-Timerauflösung. Windows-Dienste bleiben unangetastet; Wärme und Stromverbrauch können steigen. FPS-Zuwachs ist nicht garantiert.", "Max FPS: enables Game Mode, disables background capture, sets the AC CPU maximum to 100%, and temporarily gives recognized games High priority and a 1 ms timer request. Windows services are left alone; heat and power use may rise. FPS gains are not guaranteed.", "FPS max : active le Mode Jeu, désactive la capture en arrière-plan, règle le CPU à 100 % sur secteur et donne temporairement une priorité élevée aux jeux reconnus avec un timer de 1 ms. Les services restent intacts ; chaleur et consommation peuvent augmenter. Aucun gain n’est garanti.", "FPS máximo: activa el modo de juego, desactiva la captura en segundo plano, fija la CPU al 100 % con corriente y da temporalmente prioridad alta a los juegos reconocidos con un temporizador de 1 ms. No toca servicios; puede subir el calor y el consumo. No garantiza más FPS.", "Maks. FPS: Oyun Modu'nu açar, arka plan kaydını kapatır, prizde CPU üst sınırını %100 yapar ve tanınan oyunlara geçici Yüksek öncelik ile 1 ms zamanlayıcı verir. Windows hizmetlerine dokunmaz; ısı ve tüketim artabilir. FPS artışı garanti değildir.", "Maks. FPS: włącza Tryb gry, wyłącza nagrywanie w tle, ustawia CPU na 100% przy zasilaniu i tymczasowo nadaje rozpoznanym grom wysoki priorytet oraz timer 1 ms. Nie zmienia usług; może wzrosnąć temperatura i pobór. Wzrost FPS nie jest gwarantowany." });
            add("games.streamerDetails", new[] { "Streamer: Spielmodus bleibt aktiv. Spiel und OBS erhalten vorübergehend die Prozesspriorität Oberhalb normal, damit keiner der beiden Prozesse unnötig verdrängt wird. Es werden keine Dienste beendet und keine OBS-Einstellungen geändert. Die GPU muss weiterhin genug Leistung für Spiel und Encoding haben.", "Streamer: keeps Game Mode enabled. The game and OBS temporarily use Above Normal process priority so neither is unnecessarily displaced. No services are stopped and OBS settings are not changed. The GPU still needs enough headroom for the game and encoding.", "Streamer : garde le Mode Jeu actif. Le jeu et OBS utilisent temporairement la priorité Supérieure à la normale afin qu’aucun des deux processus ne soit inutilement évincé. Aucun service ni réglage OBS n’est modifié. Le GPU doit garder assez de marge pour le jeu et l’encodage.", "Streamer: mantiene el modo de juego. El juego y OBS usan temporalmente prioridad Superior a lo normal para evitar que uno desplace innecesariamente al otro. No se detienen servicios ni se cambian ajustes de OBS. La GPU debe conservar margen para el juego y la codificación.", "Yayıncı: Oyun Modu açık kalır. Oyunun ve OBS'nin gereksiz yere birbirini engellememesi için ikisi de geçici olarak Normal Üstü işlem önceliği kullanır. Hizmetler durdurulmaz ve OBS ayarları değiştirilmez. GPU, oyun ve kodlama için yeterli paya sahip olmalıdır.", "Streamer: pozostawia Tryb gry włączony. Gra i OBS tymczasowo używają priorytetu Powyżej normalnego, aby nie wypierać się niepotrzebnie. Usługi nie są zatrzymywane, a ustawienia OBS nie są zmieniane. GPU musi zachować zapas dla gry i kodowania." });
            add("home.hardwareTitle", new[] { "Erkannte Komponenten", "Detected hardware", "Matériel détecté", "Hardware detectado", "Algılanan donanım", "Wykryty sprzęt" });
            add("home.hardwareLoading", new[] { "Wird erkannt", "Detecting", "Détection", "Detectando", "Algılanıyor", "Wykrywanie" });
            add("home.cpu", new[] { "Prozessor", "Processor", "Processeur", "Procesador", "İşlemci", "Procesor" });
            add("home.gpu", new[] { "Grafikkarte", "Graphics card", "Carte graphique", "Tarjeta gráfica", "Ekran kartı", "Karta graficzna" });
            add("home.ram", new[] { "Arbeitsspeicher", "Memory", "Mémoire", "Memoria", "Bellek", "Pamięć" });
            add("home.mainboard", new[] { "Mainboard", "Motherboard", "Carte mère", "Placa base", "Anakart", "Płyta główna" });
            add("home.storage", new[] { "Laufwerk", "Storage", "Stockage", "Almacenamiento", "Depolama", "Dysk" });
            add("home.fpsExampleTitle", new[] { "FPS-Vergleich · Beispiel", "FPS comparison · example", "Comparaison FPS · exemple", "Comparación FPS · ejemplo", "FPS karşılaştırması · örnek", "Porównanie FPS · przykład" });
            add("home.fpsExampleNote", new[] { "60 → 120 FPS ist nur eine Illustration, kein Leistungsversprechen. Ergebnisse hängen von Hardware, Spiel und Einstellungen ab.", "60 → 120 FPS is illustrative only, not a performance promise. Results depend on hardware, game and settings.", "60 → 120 FPS est une illustration, pas une promesse. Le résultat dépend du matériel, du jeu et des réglages.", "60 → 120 FPS es solo una ilustración, no una promesa. Depende del hardware, juego y ajustes.", "60 → 120 FPS yalnızca örnektir, performans garantisi değildir. Sonuç donanım, oyun ve ayarlara bağlıdır.", "60 → 120 FPS to tylko ilustracja, nie obietnica. Wynik zależy od sprzętu, gry i ustawień." });
            add("welcome.title", new[] { "Hallo, schön, dass du Freezer benutzt!", "Hello, glad you’re using Freezer!", "Bonjour, merci d’utiliser Freezer !", "¡Hola, gracias por usar Freezer!", "Merhaba, Freezer kullandığın için teşekkürler!", "Cześć, miło, że używasz Freezer!" });
            add("welcome.body", new[] { "Freezer ist ein kostenloser Optimierer. Danke, dass du das unabhängige Projekt aus Deutschland unterstützt. Made in Germany.\r\n\r\nDie Vorschau 60 → 120 FPS ist ein reines Beispiel und keine Zusage: tatsächliche FPS hängen von deiner Hardware, dem Spiel und den Einstellungen ab. Änderungen bleiben nachvollziehbar und bestätigungspflichtig.", "Freezer is a free optimizer. Thank you for supporting this independent project from Germany. Made in Germany.\r\n\r\nThe 60 → 120 FPS preview is illustrative only, not a promise. Actual FPS depend on your hardware, game and settings. Changes remain reviewable and require confirmation.", "Freezer est un optimiseur gratuit. Merci de soutenir ce projet indépendant d’Allemagne. Made in Germany.\r\n\r\nL’aperçu 60 → 120 FPS est une illustration, pas une promesse. Les FPS réels dépendent du matériel, du jeu et des réglages. Les changements restent visibles et soumis à confirmation.", "Freezer es un optimizador gratuito. Gracias por apoyar este proyecto independiente de Alemania. Made in Germany.\r\n\r\nLa vista 60 → 120 FPS es solo ilustrativa, no una promesa. Los FPS reales dependen del hardware, el juego y los ajustes. Los cambios se muestran y requieren confirmación.", "Freezer ücretsiz bir optimizasyon aracıdır. Almanya'dan yürütülen bu bağımsız projeyi desteklediğin için teşekkürler. Made in Germany.\r\n\r\n60 → 120 FPS önizlemesi yalnızca örnektir, garanti değildir. Gerçek FPS donanımına, oyuna ve ayarlara bağlıdır. Değişiklikler gösterilir ve onay gerektirir.", "Freezer to darmowy optymalizator. Dziękujemy za wsparcie niezależnego projektu z Niemiec. Made in Germany.\r\n\r\nPodgląd 60 → 120 FPS jest tylko ilustracją, nie obietnicą. Rzeczywiste FPS zależą od sprzętu, gry i ustawień. Zmiany są widoczne i wymagają potwierdzenia." });
            add("colors.brightness", new[] { "Helligkeit", "Brightness", "Luminosité", "Brillo", "Parlaklık", "Jasność" });
            add("colors.contrast", new[] { "Kontrast", "Contrast", "Contraste", "Contraste", "Kontrast", "Kontrast" });
            add("colors.hue", new[] { "Farbton", "Hue", "Teinte", "Tono", "Ton", "Odcień" });
            add("colors.nvidiaNote", new[] { "NVIDIA: Freezer steuert hier Digital Vibrance über NVAPI. Helligkeit, Kontrast und Gamma sind über diese Schnittstelle nicht verfügbar.", "NVIDIA: Freezer controls Digital Vibrance through NVAPI here. Brightness, contrast and gamma are not exposed by this interface.", "NVIDIA : Freezer contrôle ici Digital Vibrance via NVAPI. Cette interface n’expose pas la luminosité, le contraste ni le gamma.", "NVIDIA: Freezer controla Digital Vibrance mediante NVAPI. Esta interfaz no expone brillo, contraste ni gamma.", "NVIDIA: Freezer burada NVAPI üzerinden Digital Vibrance ayarlar. Bu arayüz parlaklık, kontrast ve gammayı sunmaz.", "NVIDIA: Freezer steruje tu Digital Vibrance przez NVAPI. Ten interfejs nie udostępnia jasności, kontrastu ani gamma." });
            add("colors.amdGammaNote", new[] { "AMD: Verfügbare Regler werden vom Treiber ausgelesen. Gamma ist über diese ADL-Schnittstelle nicht verfügbar; Standardwerte kommen vom Treiber.", "AMD: Available controls are read from the driver. Gamma is not exposed by this ADL interface; defaults come from the driver.", "AMD : les réglages disponibles viennent du pilote. Le gamma n’est pas exposé par cette interface ADL ; les valeurs par défaut viennent du pilote.", "AMD: los controles disponibles se leen del controlador. Esta interfaz ADL no expone gamma; los valores predeterminados vienen del controlador.", "AMD: kullanılabilir kontroller sürücüden okunur. Bu ADL arayüzü gammayı sunmaz; varsayılanlar sürücüden gelir.", "AMD: dostępne ustawienia są odczytywane ze sterownika. Ten interfejs ADL nie udostępnia gamma; wartości domyślne pochodzą ze sterownika." });
            add("colors.openControlPanel", new[] { "NVIDIA-Systemsteuerung öffnen", "Open NVIDIA Control Panel", "Ouvrir le panneau NVIDIA", "Abrir Panel de NVIDIA", "NVIDIA Denetim Masası'nı aç", "Otwórz Panel NVIDIA" });
            add("colors.panelUnavailable", new[] { "Die NVIDIA-Systemsteuerung konnte nicht geöffnet werden. Prüfe, ob der NVIDIA-Treiber installiert ist.", "Could not open NVIDIA Control Panel. Check whether the NVIDIA driver is installed.", "Impossible d’ouvrir le panneau NVIDIA. Vérifiez que le pilote est installé.", "No se pudo abrir el Panel de NVIDIA. Comprueba que el controlador esté instalado.", "NVIDIA Denetim Masası açılamadı. NVIDIA sürücüsünün yüklü olduğunu kontrol edin.", "Nie można otworzyć Panelu NVIDIA. Sprawdź, czy sterownik NVIDIA jest zainstalowany." });
            add("gaming.obsGuideButton", new[] { "OBS-Streaming-Empfehlung", "OBS streaming guide", "Conseils OBS", "Guía de OBS", "OBS yayın önerisi", "Porady OBS" });
            add("gaming.obsGuideHint", new[] { "Encoder passend zur erkannten Grafikkarte. Die Empfehlungen ändern OBS nicht.", "Encoder advice based on the detected GPU. This guide does not change OBS.", "Conseils d’encodeur selon le GPU détecté. OBS ne sera pas modifié.", "Consejos según la GPU detectada. Esta guía no cambia OBS.", "Algılanan GPU'ya göre kodlayıcı önerisi. OBS ayarları değiştirilmez.", "Dobór enkodera do wykrytego GPU. Porada nie zmienia OBS." });
            add("gaming.obsGuideTitle", new[] { "OBS Streaming-Assistent", "OBS streaming guide", "Guide de streaming OBS", "Guía de streaming de OBS", "OBS yayın yardımcısı", "Asystent streamingu OBS" });
            add("overlay.close", new[] { "Live-Anzeige schließen", "Close live overlay", "Fermer l’overlay", "Cerrar superposición", "Canlı katmanı kapat", "Zamknij nakładkę" });
            add("gaming.obsNvidia", new[] { "Grafikkarte: {0}\r\nFür möglichst breite Unterstützung beim Streamen: NVIDIA NVENC H.264. AV1 oder HEVC nur wählen, wenn OBS und deine Streaming-Plattform das ausdrücklich unterstützen. NVENC entlastet die CPU, nutzt aber weiterhin GPU-Ressourcen.", "GPU: {0}\r\nFor broad streaming compatibility, start with NVIDIA NVENC H.264. Choose AV1 or HEVC only when OBS and your streaming platform explicitly support it. NVENC reduces CPU work but still uses GPU resources.", "GPU : {0}\r\nPour une compatibilité étendue en streaming, commencez avec NVIDIA NVENC H.264. Choisissez AV1 ou HEVC uniquement si OBS et la plateforme le prennent explicitement en charge. NVENC réduit la charge CPU mais utilise le GPU.", "GPU: {0}\r\nPara una compatibilidad amplia, empieza con NVIDIA NVENC H.264. Elige AV1 o HEVC solo si OBS y la plataforma lo admiten expresamente. NVENC reduce el trabajo de CPU, pero sigue usando la GPU.", "GPU: {0}\r\nGeniş yayın uyumluluğu için NVIDIA NVENC H.264 ile başlayın. AV1 veya HEVC'yi yalnızca OBS ve yayın platformunuz açıkça destekliyorsa seçin. NVENC CPU yükünü azaltır, ancak GPU kaynaklarını kullanmaya devam eder.", "GPU: {0}\r\nAby uzyskać szeroką zgodność streamingu, zacznij od NVIDIA NVENC H.264. AV1 lub HEVC wybierz tylko wtedy, gdy OBS i platforma jawnie je obsługują. NVENC odciąża CPU, ale nadal korzysta z GPU." });
            add("gaming.obsAmd", new[] { "Grafikkarte: {0}\r\nNutze in OBS zunächst AMD HW H.264/AVC. HEVC oder AV1 nur, wenn dein Encoder, OBS und deine Plattform sie anbieten und unterstützen.", "GPU: {0}\r\nStart with AMD HW H.264/AVC in OBS. Use HEVC or AV1 only if your encoder, OBS, and platform offer and support them.", "GPU : {0}\r\nCommencez avec AMD HW H.264/AVC dans OBS. Utilisez HEVC ou AV1 uniquement si l’encodeur, OBS et la plateforme les proposent et les prennent en charge.", "GPU: {0}\r\nEmpieza con AMD HW H.264/AVC en OBS. Usa HEVC o AV1 solo si el codificador, OBS y la plataforma los ofrecen y admiten.", "GPU: {0}\r\nOBS'de önce AMD HW H.264/AVC kullanın. HEVC veya AV1'i yalnızca kodlayıcınız, OBS ve platformunuz sunup destekliyorsa seçin.", "GPU: {0}\r\nW OBS zacznij od AMD HW H.264/AVC. HEVC lub AV1 wybierz tylko wtedy, gdy enkoder, OBS i platforma je oferują i obsługują." });
            add("gaming.obsIntel", new[] { "Grafikkarte: {0}\r\nWenn verfügbar, teste in OBS Intel Quick Sync H.264. Bei paralleler integrierter und dedizierter GPU die tatsächlich aktive Encoder-Option prüfen.", "GPU: {0}\r\nIf available, try Intel Quick Sync H.264 in OBS. With both integrated and discrete GPUs, verify which encoder is actually active.", "GPU : {0}\r\nSi disponible, essayez Intel Quick Sync H.264 dans OBS. Avec un GPU intégré et un GPU dédié, vérifiez quel encodeur est actif.", "GPU: {0}\r\nSi está disponible, prueba Intel Quick Sync H.264 en OBS. Si hay GPU integrada y dedicada, comprueba cuál está activa.", "GPU: {0}\r\nVarsa OBS'de Intel Quick Sync H.264'ü deneyin. Dahili ve harici GPU varsa hangi kodlayıcının etkin olduğunu kontrol edin.", "GPU: {0}\r\nJeśli jest dostępny, wypróbuj Intel Quick Sync H.264 w OBS. Przy GPU zintegrowanym i dedykowanym sprawdź, który enkoder jest aktywny." });
            add("gaming.obsUnknown", new[] { "Grafikkarte: {0}\r\nWähle in OBS unter Ausgabe nach Möglichkeit einen verfügbaren Hardware-Encoder. Nutze x264 nur, wenn die CPU dabei genügend Reserven hat.", "GPU: {0}\r\nIn OBS Output, choose an available hardware encoder if possible. Use x264 only when the CPU has enough headroom.", "GPU : {0}\r\nDans Sortie OBS, choisissez si possible un encodeur matériel disponible. Utilisez x264 uniquement si le CPU dispose d’assez de marge.", "GPU: {0}\r\nEn Salida de OBS, elige un codificador de hardware disponible si es posible. Usa x264 solo si la CPU tiene margen suficiente.", "GPU: {0}\r\nOBS Çıkış bölümünde mümkünse kullanılabilir bir donanım kodlayıcı seçin. x264'ü yalnızca CPU'da yeterli pay varsa kullanın.", "GPU: {0}\r\nW ustawieniach wyjścia OBS wybierz dostępny enkoder sprzętowy. x264 stosuj tylko wtedy, gdy CPU ma wystarczający zapas." });
            add("gaming.obsCommon", new[] { "Startwerte: CBR, Schlüsselbildintervall 2 s (falls die Plattform es verlangt) und einen Qualitätspreset wählen. Auflösung/FPS sowie Bitrate nach den aktuellen Empfehlungen der Plattform und dem stabilen Upload einstellen. Kurz testen und verworfene Frames, Rendering-Lag und Encoding-Lag prüfen.", "Starting point: CBR rate control, 2 s keyframe interval (if required by the platform), and a quality preset. Set resolution/FPS and bitrate to the platform's current guidance and your stable upload. Run a short test and check dropped frames, rendering lag, and encoding lag.", "Point de départ : contrôle CBR, intervalle d’image clé de 2 s (si la plateforme le demande) et préréglage qualité. Réglez résolution/FPS et débit selon les recommandations actuelles de la plateforme et votre débit montant stable. Faites un test et vérifiez les images perdues ainsi que les retards de rendu et d’encodage.", "Inicio: control CBR, intervalo de fotograma clave de 2 s (si la plataforma lo requiere) y preajuste de calidad. Ajusta resolución/FPS y bitrate según las recomendaciones actuales de la plataforma y tu subida estable. Haz una prueba y revisa fotogramas perdidos y retrasos de renderizado/codificación.", "Başlangıç ayarı: CBR, platform gerektiriyorsa 2 sn anahtar kare aralığı ve kalite ön ayarı. Çözünürlük/FPS ile bitrate'i platformun güncel önerilerine ve kararlı yükleme hızınıza göre ayarlayın. Kısa test yapıp düşen kareleri, oluşturma ve kodlama gecikmesini kontrol edin.", "Punkt startowy: CBR, klatka kluczowa co 2 s (jeśli wymaga tego platforma) i preset jakości. Rozdzielczość/FPS oraz bitrate ustaw według aktualnych zaleceń platformy i stabilnego uploadu. Wykonaj krótki test i sprawdź utracone klatki oraz opóźnienia renderowania i kodowania." });
            add("gaming.obsNotice", new[] { "Diese Empfehlungen sind ein sicherer Ausgangspunkt, kein Leistungsversprechen. Freezer liest keine OBS-Profile und schreibt keine OBS-Einstellungen. Der Streamer-Modus passt nur die temporäre Prozesspriorität an.", "These recommendations are a starting point, not a performance guarantee. Freezer does not read or modify OBS profiles. Streamer mode only adjusts temporary process priority.", "Ces conseils sont un point de départ, sans garantie de performance. Freezer ne lit ni ne modifie les profils OBS. Le mode Streamer ajuste uniquement temporairement la priorité du processus.", "Estas recomendaciones son un punto de partida, no una garantía de rendimiento. Freezer no lee ni modifica perfiles de OBS. El modo Streamer solo ajusta temporalmente la prioridad del proceso.", "Bu öneriler başlangıç noktasıdır, performans garantisi değildir. Freezer OBS profillerini okumaz veya değiştirmez. Yayıncı modu yalnızca geçici işlem önceliğini ayarlar.", "To zalecenia początkowe, bez gwarancji wydajności. Freezer nie odczytuje ani nie zmienia profili OBS. Tryb streamera zmienia wyłącznie tymczasowy priorytet procesu." });
            add("games.page", new[] { "Spiel {0} von {1}", "Game {0} of {1}", "Jeu {0} sur {1}", "Juego {0} de {1}", "Oyun {0} / {1}", "Gra {0} z {1}" });
            add("x3d.apply", new[] { "X3D-Profil anwenden", "Apply X3D profile", "Appliquer le profil X3D", "Aplicar perfil X3D", "X3D profilini uygula", "Zastosuj profil X3D" });
            add("x3d.detected", new[] { "Erkannte CPU: {0}", "Detected CPU: {0}", "Processeur détecté : {0}", "CPU detectada: {0}", "Algılanan CPU: {0}", "Wykryty procesor: {0}" });
            add("x3d.notDetected", new[] { "Kein AMD-X3D-Prozessor erkannt. Erkannte CPU: {0}. Es wurden keine Änderungen vorgenommen.", "No AMD X3D processor detected. Detected CPU: {0}. No changes were made.", "Aucun processeur AMD X3D détecté. Processeur détecté : {0}. Aucune modification effectuée.", "No se detectó un procesador AMD X3D. CPU detectada: {0}. No se realizaron cambios.", "AMD X3D işlemci algılanmadı. Algılanan CPU: {0}. Hiçbir değişiklik yapılmadı.", "Nie wykryto procesora AMD X3D. Wykryty CPU: {0}. Nie wprowadzono zmian." });
            add("restore.infoTitle", new[] { "Wiederherstellungspunkt als zusätzliche Absicherung", "A restore point is an extra recovery option", "Point de restauration : une protection supplémentaire", "Punto de restauración como protección adicional", "Ek kurtarma seçeneği olarak geri yükleme noktası", "Punkt przywracania jako dodatkowe zabezpieczenie" });
            add("restore.infoBody", new[] { "Vor größeren Windows-Änderungen ist ein Wiederherstellungspunkt eine nützliche zusätzliche Rückkehrmöglichkeit. Er ist keine Garantie und sichert keine persönlichen Dateien.\r\n\r\nSo erstellst du einen: Windows-Suche öffnen → „Wiederherstellungspunkt erstellen“ eingeben → Systemschutz wählen → „Erstellen…“ anklicken und einen Namen vergeben. Falls Systemschutz aus ist, kannst du ihn dort erst konfigurieren.\r\n\r\nFreezer ändert Bildschirm-Timeouts nicht.", "Before larger Windows changes, a restore point is a useful extra way back. It is not a guarantee and does not back up personal files.\r\n\r\nTo create one: open Windows Search → type “Create a restore point” → choose System Protection → click “Create…” and give it a name. If protection is off, configure it there first.\r\n\r\nFreezer does not change display timeouts.", "Avant de modifier Windows, un point de restauration offre une possibilité de retour supplémentaire. Ce n’est pas une garantie et il ne sauvegarde pas les fichiers personnels.\r\n\r\nPour en créer un : ouvrez la recherche Windows → saisissez « Créer un point de restauration » → Protection du système → « Créer… » puis donnez un nom. Si la protection est désactivée, configurez-la d’abord.\r\n\r\nFreezer ne modifie pas le délai d’écran.", "Antes de hacer cambios importantes en Windows, un punto de restauración ofrece una opción adicional para volver atrás. No es una garantía ni copia archivos personales.\r\n\r\nPara crearlo: abre la búsqueda de Windows → escribe «Crear un punto de restauración» → Protección del sistema → «Crear…» y asígnale un nombre. Si está desactivada, configúrala primero.\r\n\r\nFreezer no cambia el tiempo de pantalla.", "Windows'ta büyük değişikliklerden önce geri yükleme noktası ek bir geri dönüş seçeneğidir. Garanti değildir ve kişisel dosyaları yedeklemez.\r\n\r\nOluşturmak için: Windows aramasını aç → “Geri yükleme noktası oluştur” yaz → Sistem Koruması'nı seç → “Oluştur…”a tıkla ve ad ver. Koruma kapalıysa önce oradan yapılandır.\r\n\r\nFreezer ekran zaman aşımını değiştirmez.", "Przed większymi zmianami Windows punkt przywracania daje dodatkową możliwość powrotu. Nie jest gwarancją i nie kopiuje plików osobistych.\r\n\r\nAby go utworzyć: otwórz wyszukiwanie Windows → wpisz „Utwórz punkt przywracania” → Ochrona systemu → kliknij „Utwórz…” i nadaj nazwę. Jeśli ochrona jest wyłączona, najpierw ją skonfiguruj.\r\n\r\nFreezer nie zmienia czasu wygaszania ekranu." });
            add("restore.open", new[] { "Systemschutz öffnen", "Open System Protection", "Ouvrir la protection du système", "Abrir Protección del sistema", "Sistem Koruması'nı aç", "Otwórz Ochronę systemu" });
            add("desktop.scan", new[] { "Hardware prüfen & Vorschläge", "Analyze hardware & suggest", "Analyser le matériel", "Analizar hardware", "Donanımı incele", "Analizuj sprzęt" });
            add("desktop.title", new[] { "Desktop-Optimierung nach Hardware", "Hardware-based desktop suggestions", "Conseils selon le matériel", "Sugerencias según hardware", "Donanıma göre masaüstü önerileri", "Sugestie dla sprzętu" });
            add("desktop.cpu", new[] { "Prozessor", "Processor", "Processeur", "Procesador", "İşlemci", "Procesor" });
            add("desktop.gpu", new[] { "Grafikkarte", "Graphics", "Carte graphique", "Gráfica", "Ekran kartı", "Karta graficzna" });
            add("desktop.ram", new[] { "Arbeitsspeicher", "Memory", "Mémoire", "Memoria", "Bellek", "Pamięć" });
            add("desktop.logicalCores", new[] { "Logische Prozessoren", "Logical processors", "Processeurs logiques", "Procesadores lógicos", "Mantıksal işlemciler", "Procesory logiczne" });
            add("desktop.recommendations", new[] { "Passende, rücksetzbare Vorschläge", "Relevant, reversible suggestions", "Suggestions réversibles", "Sugerencias reversibles", "Geri alınabilir öneriler", "Odwracalne sugestie" });
            add("desktop.body", new[] { "Freezer wählt vorsichtige, reversible Benutzer-Einstellungen anhand deiner erkannten Hardware aus. Du bestätigst vor jeder Änderung. Es werden keine Dienste, Treiber, BIOS- oder Bildschirm-Timeout-Einstellungen verändert.", "Freezer selects cautious, reversible per-user settings based on detected hardware. You confirm before any change. No services, drivers, BIOS, or display-timeout settings are changed.", "Freezer choisit des réglages utilisateur réversibles selon le matériel détecté. Vous confirmez chaque changement. Aucun service, pilote, BIOS ou délai d’écran n’est modifié.", "Freezer elige opciones reversibles según el hardware detectado. Confirmas antes de cambiar. No modifica servicios, controladores, BIOS ni el tiempo de pantalla.", "Freezer donanıma göre dikkatli ve geri alınabilir kullanıcı ayarları önerir. Her değişikliği sen onaylarsın. Hizmetleri, sürücüleri, BIOS'u veya ekran zaman aşımını değiştirmez.", "Freezer dobiera ostrożne, odwracalne ustawienia użytkownika do sprzętu. Każdą zmianę potwierdzasz. Nie zmienia usług, sterowników, BIOS-u ani czasu wygaszania." });
            add("desktop.noGpu", new[] { "Model der Grafikkarte konnte nicht sicher gelesen werden.", "Could not reliably read the graphics model.", "Impossible de lire le modèle graphique.", "No se pudo leer el modelo de gráfica.", "Ekran kartı modeli güvenilir biçimde okunamadı.", "Nie udało się odczytać modelu karty graficznej." });
            add("desktop.suggestMode", new[] { "Windows-Spielmodus aktivieren, falls noch aus.", "Enable Windows Game Mode if it is off.", "Activer le Mode Jeu Windows s’il est désactivé.", "Activar el modo de juego de Windows si está desactivado.", "Kapalıysa Windows Oyun Modu'nu aç.", "Włącz Tryb gry Windows, jeśli jest wyłączony." });
            add("desktop.suggestCapture", new[] { "Hintergrundaufnahmen ausschalten; Spielclips können dann fehlen.", "Disable background capture; game clips may no longer be available.", "Désactiver la capture en arrière-plan ; les clips peuvent ne plus fonctionner.", "Desactivar la captura en segundo plano; los clips podrían dejar de funcionar.", "Arka plan kaydını kapat; oyun klipleri kullanılamayabilir.", "Wyłącz nagrywanie w tle; klipy z gry mogą być niedostępne." });
            add("desktop.suggestVisual", new[] { "Bei höchstens 8 GB RAM: Windows-Animationen reduzieren, um Hintergrundaufwand zu senken.", "At 8 GB RAM or less: reduce Windows effects to lower background overhead.", "Avec 8 Go de RAM ou moins : réduire les effets Windows.", "Con 8 GB de RAM o menos: reducir efectos de Windows.", "8 GB veya daha az RAM'de Windows efektlerini azalt.", "Przy maks. 8 GB RAM ogranicz efekty Windows." });
            add("desktop.suggestX3d", new[] { "X3D-Prozessor erkannt: Das passende Ryzen-X3D-Profil ist zusätzlich unter Gaming & Latenz verfügbar.", "X3D CPU detected: the Ryzen X3D profile is also available under Gaming & Latency.", "CPU X3D détecté : le profil Ryzen X3D est disponible dans Gaming et latence.", "CPU X3D detectada: el perfil Ryzen X3D está en Gaming y latencia.", "X3D CPU algılandı: Ryzen X3D profili Gaming ve Gecikme bölümünde.", "Wykryto CPU X3D: profil Ryzen X3D jest w sekcji Gaming i opóźnienia." });
            add("desktop.apply", new[] { "Diese Vorschläge anwenden?", "Apply these suggestions?", "Appliquer ces suggestions ?", "¿Aplicar estas sugerencias?", "Bu öneriler uygulansın mı?", "Zastosować te sugestie?" });
            add("games.applyShort", new[] { "Windows-Profil", "Windows profile", "Profil Windows", "Perfil de Windows", "Windows profili", "Profil Windows" });
            add("games.fortniteGraphics", new[] { "Grafikprofil", "Graphics preset", "Profil graphique", "Perfil gráfico", "Grafik profili", "Profil grafiki" });
            add("fortnite.title", new[] { "Fortnite-Grafikprofil", "Fortnite graphics preset", "Profil graphique Fortnite", "Perfil gráfico de Fortnite", "Fortnite grafik profili", "Profil grafiki Fortnite" });
            add("fortnite.hint", new[] { "Ändert nur bereits vorhandene sg.*-Qualitätswerte in der lokalen GameUserSettings.ini. Fortnite muss geschlossen sein. Vor dem ersten Wechsel wird eine Originalkopie angelegt; Änderungen können vom Spiel überschrieben werden und garantieren keine zusätzlichen FPS.", "Changes only existing sg.* quality values in the local GameUserSettings.ini. Fortnite must be closed. An original backup is made before the first change; the game may overwrite settings, and FPS gains are not guaranteed.", "Modifie uniquement les valeurs sg.* existantes du fichier GameUserSettings.ini local. Fortnite doit être fermé. Une copie originale est créée avant la première modification ; le jeu peut remplacer ces réglages et aucun gain de FPS n’est garanti.", "Solo cambia los valores sg.* existentes en GameUserSettings.ini. Fortnite debe estar cerrado. Se guarda una copia original antes del primer cambio; el juego puede sobrescribirlos y no se garantizan más FPS.", "Yerel GameUserSettings.ini içindeki mevcut sg.* kalite değerlerini değiştirir. Fortnite kapalı olmalı. İlk değişiklikten önce yedek alınır; oyun ayarları geçersiz kılabilir ve FPS artışı garanti değildir.", "Zmienia tylko istniejące wartości jakości sg.* w lokalnym GameUserSettings.ini. Fortnite musi być zamknięty. Przed pierwszą zmianą powstaje kopia oryginału; gra może nadpisać ustawienia, a wzrost FPS nie jest gwarantowany." });
            add("fortnite.performance", new[] { "Leistung · niedrig", "Performance · low", "Performances · faible", "Rendimiento · bajo", "Performans · düşük", "Wydajność · niska" });
            add("fortnite.potato", new[] { "Minimum · Potato", "Minimum · potato", "Minimum · potato", "Mínimo · potato", "En düşük · potato", "Minimum · potato" });
            add("fortnite.restore", new[] { "Originale Sicherung wiederherstellen", "Restore original backup", "Restaurer la sauvegarde originale", "Restaurar copia original", "Orijinal yedeği geri yükle", "Przywróć oryginalną kopię" });
            add("fortnite.notFound", new[] { "Fortnite-Konfiguration nicht gefunden. Starte Fortnite einmal und öffne dieses Menü danach erneut.", "Fortnite settings file not found. Start Fortnite once, then reopen this menu.", "Fichier Fortnite introuvable. Lancez Fortnite une fois puis rouvrez ce menu.", "No se encontró la configuración. Inicia Fortnite una vez y vuelve a abrir este menú.", "Fortnite ayar dosyası bulunamadı. Oyunu bir kez başlatıp menüyü yeniden aç.", "Nie znaleziono pliku Fortnite. Uruchom grę raz i ponownie otwórz to menu." });
            add("fortnite.running", new[] { "Schließe Fortnite vollständig, bevor du das Grafikprofil änderst.", "Close Fortnite completely before changing the graphics preset.", "Fermez complètement Fortnite avant de modifier le profil.", "Cierra Fortnite por completo antes de cambiar el perfil.", "Grafik profilini değiştirmeden önce Fortnite'ı tamamen kapat.", "Zamknij Fortnite przed zmianą profilu." });
            add("fortnite.confirm", new[] { "Die vorhandene Konfiguration wird vor dem Schreiben gesichert. Nur bereits vorhandene Qualitätswerte werden geändert.", "The current configuration is backed up before writing. Only quality values already present are changed.", "La configuration actuelle sera sauvegardée. Seules les valeurs de qualité existantes seront modifiées.", "Se guardará la configuración actual. Solo se cambian valores de calidad existentes.", "Yazmadan önce mevcut ayarlar yedeklenir. Yalnızca var olan kalite değerleri değiştirilir.", "Przed zapisem powstanie kopia. Zmienią się tylko istniejące wartości jakości." });
            add("fortnite.help", new[] { "Aktuelle Epic-PC-Tipps", "Current Epic PC tips", "Conseils PC Epic à jour", "Consejos actuales de Epic para PC", "Güncel Epic PC önerileri", "Aktualne porady Epic dla PC" });
            add("fortnite.helpError", new[] { "Die offizielle Epic-Hilfeseite konnte nicht geöffnet werden.", "The official Epic support page could not be opened.", "Impossible d’ouvrir la page d’aide officielle d’Epic.", "No se pudo abrir la página oficial de ayuda de Epic.", "Resmî Epic destek sayfası açılamadı.", "Nie można otworzyć oficjalnej strony pomocy Epic." });
            add("fortnite.apply", new[] { "Anwenden", "Apply", "Appliquer", "Aplicar", "Uygula", "Zastosuj" });
            add("fortnite.done", new[] { "Grafikprofil angewendet. Änderungen greifen beim nächsten Fortnite-Start.", "Graphics preset applied. Changes take effect the next time Fortnite starts.", "Profil appliqué. Les changements seront actifs au prochain démarrage.", "Perfil aplicado. Se aplicará al iniciar Fortnite de nuevo.", "Grafik profili uygulandı. Değişiklikler Fortnite yeniden açıldığında geçerli olur.", "Profil zastosowano. Zadziała przy następnym uruchomieniu Fortnite." });
            add("fortnite.noBackup", new[] { "Es wurde noch keine Freezer-Originalsicherung erstellt.", "No Freezer original backup exists yet.", "Aucune sauvegarde originale Freezer n’existe encore.", "Aún no existe una copia original de Freezer.", "Henüz Freezer orijinal yedeği yok.", "Brak oryginalnej kopii Freezer." });
            add("fortnite.potatoButtonOn", new[] { "Potato Graphics einschalten", "Enable potato graphics", "Activer les graphismes minimum", "Activar gráficos mínimos", "En düşük grafikleri aç", "Włącz minimalną grafikę" });
            add("fortnite.potatoButtonOff", new[] { "Potato rückgängig", "Undo potato graphics", "Annuler les graphismes minimum", "Deshacer gráficos mínimos", "En düşük grafikleri geri al", "Cofnij minimalną grafikę" });
            add("fortnite.potatoEnabled", new[] { "Potato-Profil aktiviert. Änderungen greifen beim nächsten Fortnite-Start.", "Potato preset enabled. Changes take effect the next time Fortnite starts.", "Profil minimum activé. Les changements prendront effet au prochain démarrage.", "Perfil mínimo activado. Se aplicará al iniciar Fortnite de nuevo.", "En düşük grafik profili etkin. Değişiklikler Fortnite yeniden açıldığında geçerli olur.", "Minimalny profil włączony. Zadziała przy następnym uruchomieniu Fortnite." });
            add("fortnite.reapplied", new[] { "Gespeichertes Fortnite-Grafikprofil vor dem Spielstart erneut angewendet.", "Saved Fortnite graphics preset reapplied before launch.", "Le profil graphique Fortnite enregistré a été réappliqué avant le lancement.", "El perfil gráfico guardado de Fortnite se volvió a aplicar antes de iniciar.", "Kaydedilen Fortnite grafik profili oyun başlamadan yeniden uygulandı.", "Zapisany profil graficzny Fortnite zastosowano ponownie przed uruchomieniem." });
            add("fortnite.launchProtection", new[] { "Das gespeicherte Fortnite-Grafikprofil konnte vor dem Start nicht sicher angewendet werden. Fortnite wurde deshalb nicht gestartet. Prüfe, ob das Spiel geschlossen ist und die Konfigurationsdatei beschreibbar ist.", "The saved Fortnite graphics preset could not be safely applied before launch, so Fortnite was not started. Make sure the game is closed and its settings file is writable.", "Le profil graphique Fortnite enregistré n’a pas pu être appliqué de manière sûre avant le lancement. Fortnite n’a donc pas démarré. Vérifiez que le jeu est fermé et que le fichier est accessible en écriture.", "No se pudo aplicar de forma segura el perfil gráfico guardado antes de iniciar, así que Fortnite no se abrió. Comprueba que el juego esté cerrado y que el archivo se pueda escribir.", "Kayıtlı Fortnite grafik profili oyun başlamadan güvenle uygulanamadı; bu nedenle Fortnite başlatılmadı. Oyunun kapalı ve ayar dosyasının yazılabilir olduğundan emin olun.", "Nie udało się bezpiecznie zastosować zapisanego profilu grafiki przed uruchomieniem, dlatego Fortnite nie został uruchomiony. Sprawdź, czy gra jest zamknięta i czy plik można zapisać." });
            add("fortnite.potatoRestored", new[] { "Die vor Freezer gespeicherten Fortnite-Grafikeinstellungen wurden wiederhergestellt.", "Fortnite graphics settings saved before Freezer were restored.", "Les paramètres Fortnite enregistrés avant Freezer ont été restaurés.", "Se restauraron los ajustes de Fortnite guardados antes de Freezer.", "Freezer öncesinde kaydedilen Fortnite grafik ayarları geri yüklendi.", "Przywrócono ustawienia Fortnite sprzed zmian Freezer." });
            add("fortnite.tierHigh", new[] { "Hoch · nahezu Standard", "High · near default", "Élevé · proche du défaut", "Alto · casi predeterminado", "Yüksek · varsayılana yakın", "Wysoka · prawie domyślna" });
            add("fortnite.tierMedium", new[] { "Mittel · ausgewogen", "Medium · balanced", "Moyen · équilibré", "Medio · equilibrado", "Orta · dengeli", "Średnia · zrównoważona" });
            add("fortnite.tierLow", new[] { "Niedrig · Potato", "Low · potato", "Faible · minimum", "Bajo · potato", "Düşük · potato", "Niska · potato" });
            add("fortnite.tierExtreme", new[] { "Extrem · minimale Details", "Extreme · minimum detail", "Extrême · détails minimaux", "Extremo · detalle mínimo", "Aşırı · en düşük ayrıntı", "Ekstremalna · minimalne detale" });
            add("fortnite.keysMissing", new[] { "Keine bekannten Qualitätswerte im Abschnitt ScalabilityGroups gefunden. Die Datei blieb unverändert.", "No recognized quality values were found in ScalabilityGroups. The file was left unchanged.", "Aucune valeur connue dans ScalabilityGroups. Le fichier est inchangé.", "No se encontraron valores conocidos en ScalabilityGroups. El archivo no cambió.", "ScalabilityGroups içinde tanınan kalite değeri yok. Dosya değiştirilmedi.", "Nie znaleziono znanych wartości jakości. Plik pozostał bez zmian." });
            add("crosshair.title", new[] { "Fadenkreuz-Overlay", "Crosshair overlay", "Superposition de viseur", "Superposición de mira", "Nişangâh katmanı", "Nakładka celownika" });
            add("crosshair.hint", new[] { "Wird auf der gewählten Anzeige exakt mittig positioniert. Keine Spiel-Injektion. Exklusives Vollbild oder Anti-Cheat können das Overlay verbergen oder blockieren.", "Centered on the selected display. No game injection. Exclusive fullscreen or anti-cheat may hide or block the overlay.", "Centré sur l’écran choisi. Aucune injection. Le plein écran exclusif ou l’anti-triche peut le masquer ou le bloquer.", "Centrada en la pantalla elegida. Sin inyección. El modo exclusivo o el anti-cheat puede ocultarla o bloquearla.", "Seçilen ekranda tam ortalanır. Oyuna enjeksiyon yapmaz. Tam ekran veya anti-cheat katmanı gizleyebilir ya da engelleyebilir.", "Wyśrodkowany na wybranym ekranie. Bez wstrzykiwania do gry. Pełny ekran lub anti-cheat może go ukryć albo zablokować." });
            add("crosshair.monitor", new[] { "Monitor / rozdzielczość", "Display / resolution", "Écran / résolution", "Pantalla / resolución", "Ekran / çözünürlük", "Ekran / rozdzielczość" });
            add("crosshair.shape", new[] { "Form", "Shape", "Forme", "Forma", "Şekil", "Kształt" });
            add("crosshair.color", new[] { "Farbe", "Color", "Couleur", "Color", "Renk", "Kolor" });
            add("crosshair.size", new[] { "Größe", "Size", "Taille", "Tamaño", "Boyut", "Rozmiar" });
            add("crosshair.gap", new[] { "Abstand", "Gap", "Écart", "Separación", "Boşluk", "Odstęp" });
            add("crosshair.thickness", new[] { "Linienstärke", "Line width", "Épaisseur", "Grosor", "Çizgi kalınlığı", "Grubość linii" });
            add("crosshair.start", new[] { "Overlay starten", "Start overlay", "Démarrer", "Iniciar", "Katmanı başlat", "Uruchom nakładkę" });
            add("crosshair.stop", new[] { "Overlay ausschalten", "Stop overlay", "Arrêter", "Detener", "Katmanı kapat", "Wyłącz nakładkę" });
            add("crosshair.reload", new[] { "Neu zentrieren", "Recenter", "Recentrer", "Volver a centrar", "Yeniden ortala", "Wyśrodkuj ponownie" });
            add("crosshair.reloadDone", new[] { "Fadenkreuz an aktuelle Monitorauflösung angepasst.", "Crosshair aligned to current display resolution.", "Viseur recalé sur la résolution actuelle.", "Mira ajustada a la resolución actual.", "Nişangâh geçerli ekran çözünürlüğüne hizalandı.", "Celownik dopasowano do bieżącej rozdzielczości." });
            add("crosshair.customButton", new[] { "Eigenes Fadenkreuz zeichnen", "Draw custom crosshair", "Dessiner un viseur personnalisé", "Dibujar mira personalizada", "Özel nişangâh çiz", "Narysuj własny celownik" });
            add("crosshair.importButton", new[] { "Bild importieren", "Import image", "Importer une image", "Importar imagen", "Görsel içe aktar", "Importuj obraz" });
            add("crosshair.dropHint", new[] { "Bild hier ablegen · PNG mit Transparenz empfohlen", "Drop an image here · transparent PNG recommended", "Déposez une image ici · PNG transparent recommandé", "Suelta una imagen aquí · se recomienda PNG transparente", "Görseli buraya bırak · şeffaf PNG önerilir", "Upuść obraz tutaj · zalecany przezroczysty PNG" });
            add("crosshair.imageSaved", new[] { "Eigenes Fadenkreuz gespeichert und zentriert.", "Custom crosshair saved and centered.", "Viseur personnalisé enregistré et centré.", "Mira personalizada guardada y centrada.", "Özel nişangâh kaydedildi ve ortalandı.", "Zapisano i wyśrodkowano własny celownik." });
            add("crosshair.imageInvalid", new[] { "Das Bild ist ungültig. Verwende eine lesbare PNG-, JPG- oder BMP-Datei bis 8 MB und höchstens 2048 × 2048 Pixel.", "The image is invalid. Use a readable PNG, JPG or BMP up to 8 MB and 2048 × 2048 pixels.", "Image invalide. Utilisez un PNG, JPG ou BMP lisible de 8 Mo maximum et de 2048 × 2048 pixels.", "La imagen no es válida. Usa PNG, JPG o BMP legible de hasta 8 MB y 2048 × 2048 píxeles.", "Görsel geçersiz. 8 MB ve 2048 × 2048 piksele kadar okunabilir PNG, JPG veya BMP kullanın.", "Nieprawidłowy obraz. Użyj czytelnego PNG, JPG lub BMP do 8 MB i 2048 × 2048 pikseli." });
            add("crosshair.editorTitle", new[] { "Fadenkreuz-Editor", "Crosshair editor", "Éditeur de viseur", "Editor de mira", "Nişangâh düzenleyicisi", "Edytor celownika" });
            add("crosshair.editorHint", new[] { "Zeichne mit gedrückter Maustaste. Das Motiv wird transparent gespeichert und im Overlay mittig angezeigt.", "Draw by holding the mouse button. The design is saved with transparency and centered in the overlay.", "Dessinez en maintenant le bouton de la souris. Le motif est enregistré avec transparence et centré dans l’overlay.", "Dibuja manteniendo pulsado el ratón. El diseño se guarda con transparencia y se centra en la superposición.", "Fare tuşunu basılı tutarak çiz. Tasarım şeffaf kaydedilir ve katmanda ortalanır.", "Rysuj, przytrzymując przycisk myszy. Projekt zostanie zapisany z przezroczystością i wyśrodkowany w nakładce." });
            add("crosshair.editorColor", new[] { "Zeichenfarbe", "Drawing color", "Couleur du trait", "Color del trazo", "Çizim rengi", "Kolor rysowania" });
            add("crosshair.editorWidth", new[] { "Linienbreite", "Line width", "Épaisseur", "Grosor", "Çizgi kalınlığı", "Grubość linii" });
            add("crosshair.editorOpacity", new[] { "Bildtransparenz", "Image opacity", "Opacité de l’image", "Opacidad de imagen", "Resim saydamlığı", "Przezroczystość obrazu" });
            add("crosshair.editorMode", new[] { "Zeichenmodus", "Drawing mode", "Mode de dessin", "Modo de dibujo", "Çizim modu", "Tryb rysowania" });
            add("crosshair.editorFreehand", new[] { "Freihand", "Freehand", "Main levée", "A mano alzada", "Serbest çizim", "Odręczny" });
            add("crosshair.editorPixel", new[] { "Pixelraster", "Pixel grid", "Grille de pixels", "Cuadrícula de píxeles", "Piksel ızgarası", "Siatka pikseli" });
            add("crosshair.editorUndo", new[] { "Letzten Strich zurück", "Undo stroke", "Annuler le trait", "Deshacer trazo", "Son çizgiyi geri al", "Cofnij pociągnięcie" });
            add("crosshair.editorClear", new[] { "Leeren", "Clear", "Effacer", "Borrar", "Temizle", "Wyczyść" });
            add("crosshair.editorImage", new[] { "Bild als Vorlage", "Use image as template", "Image comme modèle", "Usar imagen como plantilla", "Görseli şablon yap", "Użyj obrazu jako wzoru" });
            add("crosshair.editorSave", new[] { "Fadenkreuz speichern", "Save crosshair", "Enregistrer le viseur", "Guardar mira", "Nişangâhı kaydet", "Zapisz celownik" });
            add("crosshair.editorCancel", new[] { "Abbrechen", "Cancel", "Annuler", "Cancelar", "İptal", "Anuluj" });
            add("gaming.sessionTitle", new[] { "Gaming-Sitzung", "Gaming session", "Session de jeu", "Sesión de juego", "Oyun oturumu", "Sesja gry" });
            add("gaming.sessionHint", new[] { "Wähle dein Spiel und Profil. „Spiel starten“ wendet das bestätigte Windows-Profil an und öffnet anschließend die ausgewählte Datei.", "Choose a game and profile. “Start game” applies the confirmed Windows profile, then opens the selected file.", "Choisissez un jeu et un profil. « Lancer » applique le profil Windows confirmé, puis ouvre le fichier choisi.", "Elige un juego y perfil. «Iniciar juego» aplica el perfil de Windows confirmado y abre el archivo elegido.", "Bir oyun ve profil seçin. “Oyunu başlat”, onaylanan Windows profilini uygular ve ardından seçilen dosyayı açar.", "Wybierz grę i profil. „Uruchom grę” stosuje potwierdzony profil Windows, a następnie otwiera wybrany plik." });
            add("gaming.sessionGame", new[] { "Spiel", "Game", "Jeu", "Juego", "Oyun", "Gra" });
            add("gaming.sessionProfile", new[] { "Profil", "Profile", "Profil", "Perfil", "Profil", "Profil" });
            add("gaming.colorProfile", new[] { "Farbprofil", "Color profile", "Profil couleur", "Perfil de color", "Renk profili", "Profil kolorów" });
            add("gaming.stretchMonitor", new[] { "Monitor", "Display", "Écran", "Pantalla", "Ekran", "Ekran" });
            add("gaming.stretchResolution", new[] { "Stretch-Auflösung", "Stretch resolution", "Résolution étirée", "Resolución estirada", "Esnetilmiş çözünürlük", "Rozciągnięta rozdzielczość" });
            add("gaming.combinedSaved", new[] { "Spielprofil gespeichert.", "Game profile saved.", "Profil de jeu enregistré.", "Perfil de juego guardado.", "Oyun profili kaydedildi.", "Zapisano profil gry." });
            add("gaming.noColorProfile", new[] { "Keine automatische Änderung", "No automatic change", "Aucun changement automatique", "Sin cambio automático", "Otomatik değişiklik yok", "Bez automatycznej zmiany" });
            add("gaming.nvidiaStandard", new[] { "NVIDIA · Treiberstandard", "NVIDIA · driver default", "NVIDIA · valeur pilote", "NVIDIA · valor predeterminado", "NVIDIA · sürücü varsayılanı", "NVIDIA · domyślne sterownika" });
            add("gaming.amdStandard", new[] { "AMD · Treiberstandard", "AMD · driver default", "AMD · valeur pilote", "AMD · valor predeterminado", "AMD · sürücü varsayılanı", "AMD · domyślne sterownika" });
            add("gaming.nvidiaProfile", new[] { "NVIDIA · {0}", "NVIDIA · {0}", "NVIDIA · {0}", "NVIDIA · {0}", "NVIDIA · {0}", "NVIDIA · {0}" });
            add("gaming.amdProfile", new[] { "AMD · {0}", "AMD · {0}", "AMD · {0}", "AMD · {0}", "AMD · {0}", "AMD · {0}" });
            add("gaming.applySelection", new[] { "Profil anwenden", "Apply profile", "Appliquer le profil", "Aplicar perfil", "Profili uygula", "Zastosuj profil" });
            add("gaming.launchGame", new[] { "Spiel starten", "Start game", "Lancer le jeu", "Iniciar juego", "Oyunu başlat", "Uruchom grę" });
            add("gaming.chooseLaunchFile", new[] { "Spiel- oder Launcher-Datei auswählen", "Select game or launcher file", "Choisir le jeu ou le launcher", "Elegir archivo del juego o launcher", "Oyun veya başlatıcı dosyası seçin", "Wybierz grę lub plik launchera" });
            add("gaming.launchCancelled", new[] { "Kein Startprogramm ausgewählt. Es wurde nichts gestartet.", "No launcher was selected. Nothing was started.", "Aucun lanceur sélectionné. Rien n’a été lancé.", "No se seleccionó un lanzador. No se inició nada.", "Başlatıcı seçilmedi. Hiçbir şey başlatılmadı.", "Nie wybrano launchera. Niczego nie uruchomiono." });
            add("gaming.launchFailed", new[] { "Das ausgewählte Spiel konnte nicht gestartet werden.", "The selected game could not be started.", "Le jeu sélectionné n’a pas pu démarrer.", "No se pudo iniciar el juego seleccionado.", "Seçilen oyun başlatılamadı.", "Nie udało się uruchomić wybranej gry." });
            add("stretch.native", new[] { "Native Auflösung · nicht ändern", "Native resolution · do not change", "Résolution native · ne pas modifier", "Resolución nativa · no cambiar", "Yerel çözünürlük · değiştirme", "Rozdzielczość natywna · bez zmian" });
            add("fortnite.wallpaperTitle", new[] { "Fortnite-Kachel gestalten", "Customize Fortnite tile", "Personnaliser la tuile Fortnite", "Personalizar tarjeta de Fortnite", "Fortnite kutucuğunu özelleştir", "Dostosuj kafelek Fortnite" });
            add("fortnite.wallpaperHint", new[] { "Eigenes Bild hier ablegen oder auswählen. Das Bild ändert nur die Freezer-Kachel, keine Fortnite-Dateien.", "Drop or choose an image. It changes only the Freezer tile, not Fortnite files.", "Déposez ou choisissez une image. Elle modifie uniquement la tuile Freezer, pas les fichiers Fortnite.", "Suelta o elige una imagen. Solo cambia la tarjeta de Freezer, no los archivos de Fortnite.", "Bir görsel bırakın veya seçin. Yalnızca Freezer kutucuğunu değiştirir, Fortnite dosyalarını değiştirmez.", "Upuść lub wybierz obraz. Zmienia tylko kafelek Freezer, nie pliki Fortnite." });
            add("fortnite.wallpaperChoose", new[] { "Bild auswählen", "Choose image", "Choisir une image", "Elegir imagen", "Görsel seç", "Wybierz obraz" });
            add("fortnite.wallpaperReset", new[] { "Standardbild", "Default image", "Image par défaut", "Imagen predeterminada", "Varsayılan görsel", "Obraz domyślny" });
            add("fortnite.wallpaperSaved", new[] { "Fortnite-Kachelbild gespeichert.", "Fortnite tile image saved.", "Image de tuile Fortnite enregistrée.", "Imagen de tarjeta Fortnite guardada.", "Fortnite kutucuk görseli kaydedildi.", "Zapisano obraz kafelka Fortnite." });
            add("fortnite.wallpaperResetDone", new[] { "Standardbild der Fortnite-Kachel wiederhergestellt.", "Fortnite tile default image restored.", "Image par défaut de la tuile restaurée.", "Imagen predeterminada restaurada.", "Fortnite kutucuğunun varsayılan görseli geri yüklendi.", "Przywrócono domyślny obraz kafelka Fortnite." });
            add("fortnite.wallpaperInvalid", new[] { "Bitte wähle eine lesbare PNG-, JPG- oder BMP-Datei unter 20 MB aus.", "Choose a readable PNG, JPG or BMP file under 20 MB.", "Choisissez un fichier PNG, JPG ou BMP lisible de moins de 20 Mo.", "Elige un archivo PNG, JPG o BMP legible de menos de 20 MB.", "20 MB'den küçük, okunabilir PNG, JPG veya BMP dosyası seçin.", "Wybierz czytelny plik PNG, JPG lub BMP o rozmiarze poniżej 20 MB." });
            add("updates.remoteBanner", new[] { "Neue Freezer-Version {0} verfügbar. Details und Download findest du unter Updates.", "Freezer {0} is available. See Updates for details and download.", "Freezer {0} est disponible. Consultez Mises à jour pour les détails et le téléchargement.", "Freezer {0} está disponible. Consulta Actualizaciones para ver los detalles y descargarlo.", "Freezer {0} mevcut. Ayrıntı ve indirme için Güncellemeler'e bakın.", "Freezer {0} jest dostępny. Szczegóły i pobieranie znajdziesz w Aktualizacjach." });
            add("crosshair.confirm", new[] { "Das Fadenkreuz wird als transparentes, klickdurchlässiges Fenster angezeigt. Manche Spiele oder Anti-Cheat-Systeme blockieren externe Overlays. Fortfahren?", "The crosshair is shown in a transparent, click-through window. Some games or anti-cheat systems block external overlays. Continue?", "Le viseur apparaît dans une fenêtre transparente et traversable. Certains jeux ou anti-triches bloquent les overlays externes. Continuer ?", "La mira aparece en una ventana transparente y permeable al clic. Algunos juegos o anti-cheat bloquean overlays externos. ¿Continuar?", "Nişangâh şeffaf ve tıklamayı geçiren bir pencerede gösterilir. Bazı oyunlar veya anti-cheat bunu engelleyebilir. Devam edilsin mi?", "Celownik jest wyświetlany w przezroczystym, przepuszczającym kliknięcia oknie. Niektóre gry lub anti-cheat blokują takie nakładki. Kontynuować?" });
            add("crosshair.plus", new[] { "Plus", "Plus", "Plus", "Cruz", "Artı", "Plus" });
            add("crosshair.x", new[] { "X", "X", "X", "X", "X", "X" });
            add("crosshair.circle", new[] { "Kreis", "Circle", "Cercle", "Círculo", "Daire", "Okrąg" });
            add("crosshair.dot", new[] { "Punkt", "Dot", "Point", "Punto", "Nokta", "Kropka" });
            add("crosshair.square", new[] { "Quadrat", "Square", "Carré", "Cuadrado", "Kare", "Kwadrat" });
            add("crosshair.diamond", new[] { "Raute", "Diamond", "Losange", "Rombo", "Baklava", "Romb" });
            add("crosshair.t", new[] { "T-Form", "T shape", "Forme en T", "Forma de T", "T şekli", "Kształt T" });
            add("crosshair.brackets", new[] { "Eckklammern", "Brackets", "Crochets", "Corchetes", "Köşeli", "Narożniki" });
            add("crosshair.cross", new[] { "Kreuz ohne Abstand", "Solid cross", "Croix pleine", "Cruz continua", "Boşluksuz artı", "Pełny krzyż" });
            add("crosshair.circleCross", new[] { "Kreis mit Plus", "Circle + cross", "Cercle + croix", "Círculo + cruz", "Daire + artı", "Koło + krzyż" });
            add("crosshair.chevron", new[] { "Doppelpfeil", "Double chevron", "Double chevron", "Doble chevrón", "Çift şevron", "Podwójny grot" });
            add("crosshair.star", new[] { "Stern", "Star", "Étoile", "Estrella", "Yıldız", "Gwiazda" });
            add("crosshair.custom", new[] { "Eigenes Bild", "Custom image", "Image personnalisé", "Imagen personalizada", "Özel görsel", "Własny obraz" });
            add("crosshair.white", new[] { "Weiß", "White", "Blanc", "Blanco", "Beyaz", "Biały" });
            add("crosshair.green", new[] { "Grün", "Green", "Vert", "Verde", "Yeşil", "Zielony" });
            add("crosshair.lime", new[] { "Neongrün", "Lime", "Vert citron", "Lima", "Açık yeşil", "Limonkowy" });
            add("crosshair.cyan", new[] { "Cyan", "Cyan", "Cyan", "Cian", "Camgöbeği", "Cyjan" });
            add("crosshair.yellow", new[] { "Gelb", "Yellow", "Jaune", "Amarillo", "Sarı", "Żółty" });
            add("crosshair.red", new[] { "Rot", "Red", "Rouge", "Rojo", "Kırmızı", "Czerwony" });
            add("crosshair.magenta", new[] { "Magenta", "Magenta", "Magenta", "Magenta", "Macenta", "Magenta" });
            add("crosshair.orange", new[] { "Orange", "Orange", "Orange", "Naranja", "Turuncu", "Pomarańczowy" });
            add("crosshair.purple", new[] { "Violett", "Purple", "Violet", "Morado", "Mor", "Fioletowy" });
            add("crosshair.pink", new[] { "Rosa", "Pink", "Rose", "Rosa", "Pembe", "Różowy" });
            add("crosshair.blue", new[] { "Blau", "Blue", "Bleu", "Azul", "Mavi", "Niebieski" });
            add("home.badge", new[] { "Kostenlos · Lokal · Kein Konto", "Free · Local · No account", "Gratuit · Local · Sans compte", "Gratis · Local · Sin cuenta", "Ücretsiz · Yerel · Hesap yok", "Bezpłatnie · Lokalnie · Bez konta" });
            add("nav.updates", new[] { "Updates", "Updates", "Mises à jour", "Actualizaciones", "Güncellemeler", "Aktualizacje" });
            add("updates.title", new[] { "Updates verwalten", "Manage updates", "Gérer les mises à jour", "Administrar actualizaciones", "Güncellemeleri yönet", "Zarządzaj aktualizacjami" });
            add("updates.subtitle", new[] { "Prüfe öffentliche Freezer-Releases und öffne die Release-Seite zum Herunterladen.", "Check public Freezer releases and open the release page to download.", "Vérifiez les versions publiques de Freezer et ouvrez la page des versions pour télécharger.", "Comprueba las versiones públicas de Freezer y abre la página de lanzamientos para descargar.", "Herkese açık Freezer sürümlerini kontrol et ve indirmek için sürüm sayfasını aç.", "Sprawdź publiczne wydania Freezer i otwórz stronę wydań, aby pobrać." });
            add("updates.current", new[] { "Installierte Version: {0}", "Installed version: {0}", "Version installée : {0}", "Versión instalada: {0}", "Yüklü sürüm: {0}", "Zainstalowana wersja: {0}" });
            add("updates.check", new[] { "Nach Updates suchen", "Check for updates", "Rechercher des mises à jour", "Buscar actualizaciones", "Güncellemeleri denetle", "Sprawdź aktualizacje" });
            add("updates.open", new[] { "GitHub-Releases öffnen", "Open GitHub releases", "Ouvrir les versions GitHub", "Abrir lanzamientos de GitHub", "GitHub sürümlerini aç", "Otwórz wydania GitHub" });
            add("updates.checking", new[] { "Suche nach der neuesten Version …", "Checking for the latest version …", "Recherche de la dernière version…", "Buscando la versión más reciente…", "En son sürüm aranıyor…", "Sprawdzanie najnowszej wersji…" });
            add("updates.failed", new[] { "Update-Prüfung fehlgeschlagen. Prüfe die Internetverbindung oder öffne die Release-Seite.", "Update check failed. Check your connection or open the releases page.", "Échec de la vérification. Vérifiez la connexion ou ouvrez la page des versions.", "No se pudo comprobar. Revisa la conexión o abre la página de lanzamientos.", "Güncelleme denetimi başarısız. Bağlantını kontrol et veya sürüm sayfasını aç.", "Nie udało się sprawdzić. Sprawdź połączenie lub otwórz stronę wydań." });
            add("updates.available", new[] { "Neue Version verfügbar: {0}", "New version available: {0}", "Nouvelle version disponible : {0}", "Nueva versión disponible: {0}", "Yeni sürüm mevcut: {0}", "Dostępna nowa wersja: {0}" });
            add("updates.latest", new[] { "Du verwendest bereits die neueste veröffentlichte Version ({0}).", "You already have the latest published version ({0}).", "Vous disposez déjà de la dernière version publiée ({0}).", "Ya tienes la última versión publicada ({0}).", "Yayımlanan en son sürümü kullanıyorsun ({0}).", "Masz już najnowszą opublikowaną wersję ({0})." });
            add("updates.noRelease", new[] { "Auf GitHub wurde noch kein Release gefunden. Die Release-Seite ist unten verlinkt.", "No release was found on GitHub yet. The releases page is linked below.", "Aucune version n’a été trouvée sur GitHub. La page est accessible ci-dessous.", "Aún no se encontró ningún lanzamiento en GitHub. La página está enlazada abajo.", "GitHub'da henüz sürüm bulunamadı. Sürüm sayfası aşağıda.", "Nie znaleziono jeszcze wydania na GitHub. Strona wydań jest poniżej." });
            add("updates.manual", new[] { "Lade ein offizielles Windows-Paket herunter und wähle es hier aus. Nach deiner Bestätigung ersetzt Freezer die laufende EXE; eingebettete Bilder und Programmdateien werden gemeinsam aktualisiert. Vorher wird eine Sicherung angelegt.", "Download an official Windows package and select it here. After confirmation, Freezer replaces the running EXE; bundled artwork and app files update together. A backup is created first.", "Téléchargez un paquet Windows officiel et sélectionnez-le ici. Après confirmation, Freezer remplace l’EXE en cours ; les images et fichiers intégrés sont mis à jour ensemble. Une sauvegarde est créée avant.", "Descarga un paquete oficial de Windows y selecciónalo aquí. Tras confirmarlo, Freezer reemplaza el EXE en ejecución; las imágenes y archivos incluidos se actualizan juntos. Primero se crea una copia de seguridad.", "Resmî bir Windows paketi indirip buradan seç. Onayından sonra Freezer çalışan EXE'yi değiştirir; gömülü görseller ve uygulama dosyaları birlikte güncellenir. Önce yedek alınır.", "Pobierz oficjalny pakiet Windows i wybierz go tutaj. Po potwierdzeniu Freezer zastąpi uruchomiony plik EXE; wbudowane grafiki i pliki aplikacji zostaną zaktualizowane razem. Najpierw powstanie kopia zapasowa." });
            add("updates.scanLocal", new[] { "Downloads durchsuchen", "Scan Downloads", "Analyser les téléchargements", "Buscar en Descargas", "İndirilenleri tara", "Skanuj Pobrane" });
            add("updates.chooseFile", new[] { "Update-Datei auswählen", "Choose update file", "Choisir le fichier de mise à jour", "Elegir archivo de actualización", "Güncelleme dosyası seç", "Wybierz plik aktualizacji" });
            add("updates.install", new[] { "Update installieren", "Install update", "Installer la mise à jour", "Instalar actualización", "Güncellemeyi yükle", "Zainstaluj aktualizację" });
            add("updates.noLocal", new[] { "Keine neuere Freezer-EXE oder ein Windows-ZIP-Paket gefunden. Du kannst die Datei manuell auswählen.", "No newer Freezer EXE or Windows ZIP package was found. You can select a file manually.", "Aucun EXE Freezer ni paquet ZIP Windows plus récent trouvé. Vous pouvez choisir un fichier manuellement.", "No se encontró un EXE de Freezer ni un paquete ZIP de Windows más reciente. Puedes elegirlo manualmente.", "Daha yeni Freezer EXE'si veya Windows ZIP paketi bulunamadı. Dosyayı elle seçebilirsin.", "Nie znaleziono nowszego pliku EXE Freezer ani pakietu ZIP Windows. Możesz wybrać plik ręcznie." });
            add("updates.applyConfirm", new[] { "Version {0} wird installiert. Freezer wird geschlossen und nach dem Austausch neu gestartet. Die komplette EXE wird ersetzt; eine Sicherung der bisherigen Datei bleibt erhalten.\r\n\r\nQuelle: {1}\r\n\r\nFortfahren?", "Version {0} will be installed. Freezer will close and restart after replacement. The complete EXE is replaced; a backup of the previous file is kept.\r\n\r\nSource: {1}\r\n\r\nContinue?", "La version {0} sera installée. Freezer se fermera puis redémarrera après le remplacement. L’EXE complète sera remplacée ; une sauvegarde de l’ancien fichier sera conservée.\r\n\r\nSource : {1}\r\n\r\nContinuer ?", "Se instalará la versión {0}. Freezer se cerrará y reiniciará tras reemplazarla. Se sustituirá el EXE completo y se conservará una copia del anterior.\r\n\r\nOrigen: {1}\r\n\r\n¿Continuar?", "{0} sürümü yüklenecek. Freezer kapanıp dosya değişiminden sonra yeniden başlayacak. EXE'nin tamamı değiştirilir; önceki dosyanın yedeği saklanır.\r\n\r\nKaynak: {1}\r\n\r\nDevam edilsin mi?", "Zostanie zainstalowana wersja {0}. Freezer zamknie się i uruchomi ponownie po podmianie. Cały plik EXE zostanie zastąpiony; kopia poprzedniej wersji pozostanie.\r\n\r\nŹródło: {1}\r\n\r\nKontynuować?" });
            add("updates.invalidFile", new[] { "Die ausgewählte Datei ist keine gültige neuere Freezer-Version.", "The selected file is not a valid newer Freezer version.", "Le fichier sélectionné n’est pas une version Freezer plus récente valide.", "El archivo seleccionado no es una versión válida más reciente de Freezer.", "Seçilen dosya geçerli ve daha yeni bir Freezer sürümü değil.", "Wybrany plik nie jest prawidłową nowszą wersją Freezer." });
            add("updates.installFailed", new[] { "Das Update konnte nicht vorbereitet werden. Freezer bleibt geöffnet. Prüfe die Datei und den freien Speicherplatz.", "The update could not be prepared. Freezer will stay open. Check the file and available disk space.", "La mise à jour n’a pas pu être préparée. Freezer restera ouvert. Vérifiez le fichier et l’espace disque.", "No se pudo preparar la actualización. Freezer seguirá abierto. Comprueba el archivo y el espacio disponible.", "Güncelleme hazırlanamadı. Freezer açık kalacak. Dosyayı ve boş disk alanını kontrol et.", "Nie udało się przygotować aktualizacji. Freezer pozostanie otwarty. Sprawdź plik i wolne miejsce." });
            add("display.monitor", new[] { "Monitor", "Monitor", "Écran", "Monitor", "Monitör", "Monitor" });
            add("display.primary", new[] { "Hauptmonitor", "Primary monitor", "Écran principal", "Monitor principal", "Ana monitör", "Monitor główny" });
            add("display.secondary", new[] { "Zusatzmonitor", "Additional monitor", "Écran secondaire", "Monitor secundario", "İkincil monitör", "Monitor dodatkowy" });
            add("display.left", new[] { "links vom Hauptmonitor", "left of primary monitor", "à gauche de l’écran principal", "a la izquierda del principal", "ana monitörün solunda", "na lewo od głównego monitora" });
            add("display.right", new[] { "rechts vom Hauptmonitor", "right of primary monitor", "à droite de l’écran principal", "a la derecha del principal", "ana monitörün sağında", "na prawo od głównego monitora" });
            add("display.above", new[] { "oberhalb des Hauptmonitors", "above primary monitor", "au-dessus de l’écran principal", "encima del principal", "ana monitörün üstünde", "nad głównym monitorem" });
            add("display.below", new[] { "unterhalb des Hauptmonitors", "below primary monitor", "en dessous de l’écran principal", "debajo del principal", "ana monitörün altında", "pod głównym monitorem" });
            add("stretch.title", new[] { "Stretch-Auflösung", "Stretched resolution", "Résolution étirée", "Resolución estirada", "Genişletilmiş çözünürlük", "Rozciągnięta rozdzielczość" });
            add("stretch.pageSubtitle", new[] { "Auflösung direkt für einen Monitor ändern – unabhängig davon, ob ein Spiel läuft.", "Change a monitor's resolution directly, whether or not a game is running.", "Modifiez directement la résolution d’un écran, avec ou sans jeu en cours.", "Cambia directamente la resolución de una pantalla, haya un juego abierto o no.", "Bir oyunun açık olup olmamasından bağımsız olarak ekran çözünürlüğünü değiştirin.", "Zmień rozdzielczość monitora niezależnie od uruchomionej gry." });
            add("stretch.currentMode", new[] { "Aktuelle Auflösung", "Current resolution", "Résolution actuelle", "Resolución actual", "Geçerli çözünürlük", "Bieżąca rozdzielczość" });
            add("stretch.availableModes", new[] { "Unterstützte Auflösungen", "Supported resolutions", "Résolutions prises en charge", "Resoluciones compatibles", "Desteklenen çözünürlükler", "Obsługiwane rozdzielczości" });
            add("stretch.customSize", new[] { "Eigene Auflösung", "Custom resolution", "Résolution personnalisée", "Resolución personalizada", "Özel çözünürlük", "Własna rozdzielczość" });
            add("stretch.modeApplied", new[] { "Auflösung für den ausgewählten Monitor geändert. Die Änderung ist temporär und kann zurückgesetzt werden.", "Resolution changed for the selected monitor. The change is temporary and can be restored.", "La résolution de l’écran sélectionné a été modifiée. Le changement est temporaire et peut être annulé.", "Se cambió la resolución de la pantalla seleccionada. El cambio es temporal y se puede revertir.", "Seçilen ekranın çözünürlüğü değiştirildi. Değişiklik geçicidir ve geri alınabilir.", "Zmieniono rozdzielczość wybranego monitora. Zmiana jest tymczasowa i można ją cofnąć." });
            add("stretch.noMonitors", new[] { "Es wurde kein verwendbarer Monitor gefunden.", "No usable monitor was found.", "Aucun écran utilisable n’a été trouvé.", "No se encontró ninguna pantalla utilizable.", "Kullanılabilir ekran bulunamadı.", "Nie znaleziono dostępnego monitora." });
            add("stretch.open", new[] { "Stretch-Auflösung einstellen", "Set stretched resolution", "Régler la résolution étirée", "Configurar resolución estirada", "Genişletilmiş çözünürlüğü ayarla", "Ustaw rozciągniętą rozdzielczość" });
            add("stretch.monitor", new[] { "Monitor", "Monitor", "Écran", "Monitor", "Monitör", "Monitor" });
            add("stretch.resolution", new[] { "Auflösung (Breite × Höhe)", "Resolution (width × height)", "Résolution (largeur × hauteur)", "Resolución (ancho × alto)", "Çözünürlük (genişlik × yükseklik)", "Rozdzielczość (szerokość × wysokość)" });
            add("stretch.hint", new[] { "Es werden nur vom Treiber bestätigte Modi angewendet. Die Auflösung gilt nur für den gewählten Monitor und wird nicht dauerhaft gespeichert. Für echtes Vollbild-Stretching kann zusätzlich GPU-Skalierung auf Vollbild im Grafiktreiber nötig sein.", "Only modes accepted by the driver are applied. This changes only the selected monitor and is not saved permanently. True fullscreen stretching may also require GPU scaling set to Fullscreen in your graphics driver.", "Seuls les modes acceptés par le pilote sont appliqués. Seul l’écran choisi change et le réglage n’est pas permanent. L’étirement en plein écran peut aussi nécessiter la mise à l’échelle GPU en plein écran dans le pilote.", "Solo se aplican modos aceptados por el controlador. Solo cambia el monitor elegido y no se guarda permanentemente. El estiramiento a pantalla completa también puede requerir la escala GPU en pantalla completa del controlador.", "Yalnızca sürücünün kabul ettiği modlar uygulanır. Sadece seçilen monitör geçici olarak değişir. Tam ekran genişletme için sürücüde GPU ölçeklendirmesini Tam ekran yapman gerekebilir.", "Stosowane są tylko tryby zaakceptowane przez sterownik. Zmienia się tylko wybrany monitor i ustawienie nie jest trwałe. Pełnoekranowe rozciąganie może wymagać skalowania GPU do pełnego ekranu w sterowniku." });
            add("stretch.preset", new[] { "Profil", "Preset", "Préréglage", "Perfil", "Hazır ayar", "Preset" });
            add("stretch.custom", new[] { "Benutzerdefiniert", "Custom", "Personnalisée", "Personalizada", "Özel", "Niestandardowa" });
            add("stretch.apply", new[] { "Temporär anwenden", "Apply temporarily", "Appliquer temporairement", "Aplicar temporalmente", "Geçici uygula", "Zastosuj tymczasowo" });
            add("stretch.restore", new[] { "Ursprüngliche Auflösung", "Restore original resolution", "Résolution d’origine", "Restaurar resolución original", "Özgün çözünürlüğü geri yükle", "Przywróć oryginalną rozdzielczość" });
            add("stretch.cancel", new[] { "Abbrechen", "Cancel", "Annuler", "Cancelar", "İptal", "Anuluj" });
            add("stretch.unsupported", new[] { "Der Grafiktreiber hat diese Auflösung abgelehnt. Es wurden keine Änderungen vorgenommen.", "The graphics driver rejected this resolution. No changes were made.", "Le pilote graphique a refusé cette résolution. Aucun changement n’a été effectué.", "El controlador gráfico rechazó esta resolución. No se realizaron cambios.", "Grafik sürücüsü bu çözünürlüğü reddetti. Değişiklik yapılmadı.", "Sterownik graficzny odrzucił tę rozdzielczość. Nie wprowadzono zmian." });
            add("stretch.applyFailed", new[] { "Die Auflösung konnte nicht angewendet werden. Der vorherige Modus bleibt aktiv.", "The resolution could not be applied. The previous mode remains active.", "La résolution n’a pas pu être appliquée. Le mode précédent reste actif.", "No se pudo aplicar la resolución. El modo anterior sigue activo.", "Çözünürlük uygulanamadı. Önceki mod etkin kaldı.", "Nie można zastosować rozdzielczości. Poprzedni tryb pozostaje aktywny." });
            add("stretch.confirmTitle", new[] { "Neue Auflösung bestätigen", "Confirm new resolution", "Confirmer la nouvelle résolution", "Confirmar nueva resolución", "Yeni çözünürlüğü onayla", "Potwierdź nową rozdzielczość" });
            add("stretch.confirmBody", new[] { "Ist die Anzeige gut lesbar? Bestätige innerhalb von {0} Sekunden. Sonst wird die vorige Auflösung automatisch wiederhergestellt.", "Is the display readable? Confirm within {0} seconds or the previous resolution is restored automatically.", "L’affichage est-il lisible ? Confirmez dans les {0} secondes, sinon l’ancienne résolution sera restaurée.", "¿Se ve bien la pantalla? Confirma en {0} segundos; de lo contrario, se restaurará la resolución anterior.", "Görüntü okunaklı mı? {0} saniye içinde onayla; yoksa önceki çözünürlük otomatik geri yüklenir.", "Czy obraz jest czytelny? Potwierdź w ciągu {0} sekund, inaczej poprzednia rozdzielczość zostanie przywrócona." });
            add("stretch.confirm", new[] { "Auflösung beibehalten", "Keep this resolution", "Conserver cette résolution", "Mantener esta resolución", "Bu çözünürlüğü koru", "Zachowaj tę rozdzielczość" });
            add("stretch.reverted", new[] { "Vorige Auflösung wiederhergestellt.", "Previous resolution restored.", "Résolution précédente restaurée.", "Se restauró la resolución anterior.", "Önceki çözünürlük geri yüklendi.", "Przywrócono poprzednią rozdzielczość." });
            add("stretch.kept", new[] { "Auflösung ist temporär aktiv; der vorherige Modus wurde gesichert. Über „Ursprüngliche Auflösung“ kannst du ihn wiederherstellen.", "Resolution is active temporarily and the previous mode was saved. Use Restore original resolution to revert.", "La résolution est temporaire et le mode précédent a été sauvegardé. Utilisez Résolution d’origine pour revenir en arrière.", "La resolución es temporal y se guardó el modo anterior. Usa Restaurar resolución original para volver.", "Çözünürlük geçici etkin; önceki mod kaydedildi. Geri dönmek için Özgün çözünürlüğü geri yükle'yi kullan.", "Rozdzielczość jest tymczasowa, a poprzedni tryb zapisano. Użyj Przywróć oryginalną rozdzielczość, aby cofnąć zmianę." });
            add("home.monitorTitle", new[] { "Freezer Live-Monitor", "Freezer live monitor", "Moniteur Freezer", "Monitor en vivo de Freezer", "Freezer canlı izleyici", "Monitor Freezer na żywo" });
            add("home.monitorDesc", new[] { "Echte Messwerte für CPU, GPU, RAM und FPS. Nicht verfügbare Sensoren werden als — angezeigt.", "Real CPU, GPU, RAM and FPS readings. Unavailable sensors are shown as —.", "Mesures réelles CPU, GPU, RAM et FPS. Les capteurs indisponibles affichent —.", "Lecturas reales de CPU, GPU, RAM y FPS. Los sensores no disponibles muestran —.", "Gerçek CPU, GPU, RAM ve FPS ölçümleri. Kullanılamayan sensörler — gösterir.", "Rzeczywiste odczyty CPU, GPU, RAM i FPS. Brakujące czujniki są oznaczone —." });
            add("settings.monitorTitle", new[] { "Live-Monitor", "Live monitor", "Moniteur en direct", "Monitor en vivo", "Canlı izleyici", "Monitor na żywo" });
            add("settings.monitorDesc", new[] { "Aktualisiert einmal pro Sekunde, solange Monitor oder Overlay sichtbar sind. Sonst pausiert die Abfrage.", "Updates once per second while the monitor or overlay is visible. Sampling pauses otherwise.", "Mise à jour chaque seconde si le moniteur ou l’overlay est visible. Sinon, la mesure s’arrête.", "Se actualiza cada segundo mientras el monitor o la superposición están visibles; después se pausa.", "İzleyici veya katman görünürken saniyede bir güncellenir. Diğer zamanlarda duraklar.", "Aktualizuje się co sekundę, gdy monitor lub nakładka są widoczne. W przeciwnym razie pomiary są wstrzymane." });
            add("repair.diagnose", new[] { "Diagnose starten", "Run diagnostics", "Lancer le diagnostic", "Iniciar diagnóstico", "Tanılamayı başlat", "Uruchom diagnostykę" });
            add("repair.stateFolder", new[] { "Freezer-Datenordner", "Freezer data folder", "Dossier de données Freezer", "Carpeta de datos de Freezer", "Freezer veri klasörü", "Folder danych Freezer" });
            add("repair.snapshotCount", new[] { "Aktive rücksetzbare Änderungen", "Active reversible changes", "Modifications réversibles actives", "Cambios reversibles activos", "Etkin geri alınabilir değişiklikler", "Aktywne odwracalne zmiany" });
            add("repair.displaySafe", new[] { "Bildschirm-Timeout wird von Freezer nicht verändert.", "Freezer never changes the display timeout.", "Freezer ne modifie jamais le délai d’écran.", "Freezer nunca cambia el tiempo de pantalla.", "Freezer ekran zaman aşımını değiştirmez.", "Freezer nie zmienia czasu wygaszania ekranu." });
            add("repair.framework", new[] { "Windows-.NET-Laufzeit", "Windows .NET runtime", "Runtime .NET Windows", "Runtime de .NET para Windows", "Windows .NET çalışma zamanı", "Środowisko .NET Windows" });
            add("repair.snapshotClean", new[] { "Alle Freezer-Sicherungen sind lesbar.", "All Freezer snapshots are readable.", "Toutes les sauvegardes Freezer sont lisibles.", "Todas las copias de Freezer se pueden leer.", "Tüm Freezer yedekleri okunabiliyor.", "Wszystkie kopie Freezer są czytelne." });
            add("repair.snapshotDamaged", new[] { "Mindestens eine Freezer-Sicherung ist beschädigt. Sie wurde zur Sicherheit beibehalten.", "At least one Freezer snapshot is damaged. It was preserved for safety.", "Une sauvegarde Freezer est endommagée. Elle a été conservée par sécurité.", "Hay una copia de Freezer dañada. Se conservó por seguridad.", "En az bir Freezer yedeği bozuk. Güvenlik için korundu.", "Co najmniej jedna kopia Freezer jest uszkodzona. Zachowano ją." });
            add("repair.autoDescription", new[] { "Repariert nur Freezer-eigene Dateien und Einstellungen. Windows-Dienste, Treiber und Spiel-Dateien bleiben unangetastet.", "Repairs only Freezer-owned files and settings. Windows services, drivers and game files are not touched.", "Répare uniquement les fichiers et paramètres Freezer. Les services, pilotes et jeux restent intacts.", "Repara solo archivos y ajustes de Freezer. No toca servicios, controladores ni juegos.", "Yalnızca Freezer dosyalarını ve ayarlarını onarır. Windows hizmetlerine, sürücülere ve oyun dosyalarına dokunmaz.", "Naprawia tylko pliki i ustawienia Freezer. Nie zmienia usług Windows, sterowników ani gier." });
            add("repair.complete", new[] { "Prüfung und sichere Reparatur abgeschlossen.", "Checks and safe repair completed.", "Vérifications et réparation sûre terminées.", "Comprobaciones y reparación segura completadas.", "Denetim ve güvenli onarım tamamlandı.", "Kontrola i bezpieczna naprawa zakończone." });
            add("repair.openAsAdmin", new[] { "Freezer muss für diese Änderung mit Administratorrechten gestartet werden. Grund: Windows schützt das systemweite Energieschema. Ohne erhöhte Rechte wird nur diese Änderung abgelehnt.", "Freezer must run as administrator for this change. Windows protects the system-wide power plan. Without elevation, only this change will be denied.", "Freezer doit être lancé comme administrateur pour ce changement. Windows protège le plan d’alimentation global; seule cette action sera refusée sans élévation.", "Freezer debe ejecutarse como administrador para este cambio. Windows protege el plan de energía global; sin elevación solo se rechazará este cambio.", "Bu değişiklik için Freezer yönetici olarak çalışmalı. Windows sistem güç planını korur; yükseltilmiş izin olmadan yalnızca bu işlem reddedilir.", "Freezer musi działać jako administrator. Windows chroni globalny plan zasilania; bez podwyższonych uprawnień odmowa dotyczy tylko tej zmiany." });
            add("restore.none", new[] { "Es sind keine gespeicherten Freezer-Änderungen zurückzusetzen.", "No saved Freezer changes need restoring.", "Aucun changement Freezer enregistré à restaurer.", "No hay cambios guardados de Freezer que restaurar.", "Geri yüklenecek kayıtlı Freezer değişikliği yok.", "Brak zapisanych zmian Freezer do przywrócenia." });
            add("restore.inactive", new[] { "Keine gespeicherte Änderung aktiv.", "No saved change is active.", "Aucun changement enregistré actif.", "No hay ningún cambio guardado activo.", "Etkin kayıtlı değişiklik yok.", "Brak aktywnej zapisanej zmiany." });
            add("restore.registry", new[] { "{0} Registrierungswert(e) wiederhergestellt; {1} extern geänderte Werte beibehalten.", "Restored {0} registry value(s); preserved {1} value(s) changed externally.", "{0} valeur(s) restaurée(s); {1} valeur(s) modifiée(s) ailleurs conservée(s).", "Se restauraron {0} valores; se conservaron {1} cambios externos.", "{0} kayıt değeri geri yüklendi; dışarıdan değiştirilen {1} değer korundu.", "Przywrócono {0} wartości; zachowano {1} zmienionych zewnętrznie." });
            add("restore.cpuInactive", new[] { "Keine gespeicherte CPU-Einstellung aktiv.", "No saved CPU policy is active.", "Aucune politique CPU enregistrée active.", "No hay una política de CPU guardada activa.", "Etkin kayıtlı CPU ilkesi yok.", "Brak aktywnej zapisanej polityki CPU." });
            add("restore.cpuExternal", new[] { "Die CPU-Einstellung wurde außerhalb von Freezer geändert und bleibt unverändert.", "The CPU policy changed outside Freezer and was preserved.", "La politique CPU a été modifiée hors de Freezer et a été conservée.", "La política de CPU cambió fuera de Freezer y se conservó.", "CPU ayarı Freezer dışında değiştirildi ve korundu.", "Polityka CPU została zmieniona poza Freezer i zachowana." });
            add("restore.cpuDone", new[] { "Vorherige CPU-Einstellung wiederhergestellt. Bildschirm-Timeouts blieben unverändert.", "Previous CPU policy restored. Display timeouts were not changed.", "Politique CPU précédente restaurée. Le délai d’écran n’a pas changé.", "Se restauró la política anterior. No se cambió el tiempo de pantalla.", "Önceki CPU ilkesi geri yüklendi. Ekran zaman aşımı değişmedi.", "Przywrócono poprzednią politykę CPU. Czas wygaszania bez zmian." });
            add("repair.reportOk", new[] { "Diagnose abgeschlossen. Es wurden keine beschädigten Freezer-Daten gefunden.", "Diagnostics complete. No damaged Freezer data was found.", "Diagnostic terminé. Aucune donnée Freezer endommagée.", "Diagnóstico terminado. No se encontraron datos dañados de Freezer.", "Tanılama tamamlandı. Bozuk Freezer verisi bulunamadı.", "Diagnostyka zakończona. Nie znaleziono uszkodzonych danych Freezer." });
            add("action.continue", new[] { "Fortfahren?", "Continue?", "Continuer ?", "¿Continuar?", "Devam edilsin mi?", "Kontynuować?" });
            add("files.removed", new[] { "{0} Dateien entfernt ({1:0.0} MB).", "Removed {0} files ({1:0.0} MB).", "{0} fichiers supprimés ({1:0.0} Mo).", "Se eliminaron {0} archivos ({1:0.0} MB).", "{0} dosya silindi ({1:0.0} MB).", "Usunięto {0} plików ({1:0.0} MB)." });
            add("files.preview", new[] { "{0} Dateien · {1:0.0} MB\r\n\r\n{2}", "{0} files · {1:0.0} MB\r\n\r\n{2}", "{0} fichiers · {1:0.0} Mo\r\n\r\n{2}", "{0} archivos · {1:0.0} MB\r\n\r\n{2}", "{0} dosya · {1:0.0} MB\r\n\r\n{2}", "{0} plików · {1:0.0} MB\r\n\r\n{2}" });
            add("metric.logicalCores", new[] { "logische Kerne", "logical cores", "cœurs logiques", "núcleos lógicos", "mantıksal çekirdek", "wątki logiczne" });
            add("metric.cores", new[] { "Kernlast", "Core load", "Charge des cœurs", "Carga por núcleo", "Çekirdek yükü", "Obciążenie rdzeni" });
            add("metric.gpuCounters", new[] { "Windows-GPU-Zähler", "Windows GPU counters", "compteurs GPU Windows", "contadores GPU de Windows", "Windows GPU sayaçları", "liczniki GPU Windows" });
            add("hardware.sensorLimit", new[] { "Temperatur- und Watt-Sensoren benötigen zusätzliche Hersteller-/Sensor-Schnittstellen und werden nicht erfunden.", "Temperature and watt readings require additional vendor/sensor interfaces; Freezer will not invent values.", "Les températures et watts nécessitent des interfaces capteurs supplémentaires; Freezer n’invente pas de valeurs.", "Temperaturas y vatios requieren interfaces de sensor adicionales; Freezer no inventa valores.", "Sıcaklık ve watt için ek üretici/sensör arayüzleri gerekir; Freezer değer uydurmaz.", "Temperatura i waty wymagają dodatkowych interfejsów czujników; Freezer nie zgaduje wartości." });
            add("fps.captureAttached", new[] { "FPS-Aufnahme aktiv: {0} (PID {1})", "FPS capture active: {0} (PID {1})", "Capture FPS actif : {0} (PID {1})", "Captura FPS activa: {0} (PID {1})", "FPS yakalama etkin: {0} (PID {1})", "Pomiar FPS aktywny: {0} (PID {1})" });
            add("status.working", new[] { "Wird ausgeführt …", "Working …", "Exécution…", "En curso…", "Çalışıyor…", "Pracuję…" });
            add("status.noAdmin", new[] { "Adminrechte nötig", "Administrator rights needed", "Droits administrateur nécessaires", "Se requieren permisos de administrador", "Yönetici izni gerekli", "Wymagane uprawnienia administratora" });
            add("settings.overlayTitle", new[] { "Live-Overlay anpassen", "Customize live overlay", "Personnaliser l’overlay", "Personalizar superposición", "Canlı katmanı özelleştir", "Dostosuj nakładkę" });
            add("settings.motionTitle", new[] { "Sidebar-Animation", "Sidebar animation", "Animation de la barre latérale", "Animación de la barra lateral", "Kenar çubuğu animasyonu", "Animacja paska bocznego" });
            add("settings.motionHint", new[] { "Wähle eine schnelle, reduzierte oder ausgeschaltete Bewegung für das Ausklappen.", "Choose fast, reduced or disabled motion for the expanding navigation.", "Choisissez une animation rapide, réduite ou désactivée pour la navigation.", "Elige movimiento rápido, reducido o desactivado para el menú.", "Menünün açılması için hızlı, yavaş veya kapalı animasyonu seçin.", "Wybierz szybką, ograniczoną lub wyłączoną animację menu." });
            add("settings.motionFast", new[] { "Schnell (ca. 0,1 s)", "Fast (about 0.1 s)", "Rapide (env. 0,1 s)", "Rápida (aprox. 0,1 s)", "Hızlı (yaklaşık 0,1 sn)", "Szybka (ok. 0,1 s)" });
            add("settings.motionSlow", new[] { "Reduziert (ca. 0,4 s)", "Reduced (about 0.4 s)", "Réduite (env. 0,4 s)", "Reducida (aprox. 0,4 s)", "Yavaş (yaklaşık 0,4 sn)", "Ograniczona (ok. 0,4 s)" });
            add("settings.motionOff", new[] { "Aus (sofort)", "Off (instant)", "Désactivée (instantanée)", "Desactivada (instantánea)", "Kapalı (anında)", "Wyłączona (natychmiast)" });
            add("settings.overlayHint", new[] { "Größe und Transparenz des beweglichen Live-Overlays einstellen.", "Adjust the movable live overlay size and opacity.", "Réglez la taille et l’opacité de l’overlay déplaçable.", "Ajusta el tamaño y opacidad de la superposición móvil.", "Taşınabilir canlı katmanın boyutunu ve opaklığını ayarlayın.", "Ustaw rozmiar i krycie przesuwanej nakładki." });
            add("settings.screenTimeoutTitle", new[] { "Bildschirmabschaltung deaktivieren", "Disable display timeout", "Désactiver l’extinction de l’écran", "Desactivar el apagado de pantalla", "Ekran kapanma zaman aşımını kapat", "Wyłącz wyłączanie ekranu" });
            add("settings.screenTimeoutHint", new[] { "Optionale Einstellung für den aktuellen Energiesparplan: Bildschirm bei Netz- und Akkubetrieb auf Nie. Der vorherige Wert wird gesichert. Schlafmodus und Bildschirmschoner bleiben unverändert.", "Optional for the current power plan: set display-off timeout to Never on AC and battery. Previous values are backed up. Sleep and screen saver settings stay unchanged.", "Option facultative pour le plan actuel : écran réglé sur Jamais sur secteur et batterie. Les valeurs précédentes sont sauvegardées. Veille et écran de veille restent inchangés.", "Opción para el plan actual: pantalla en Nunca con corriente y batería. Se guardan los valores previos. El modo de suspensión y el protector no cambian.", "Geçerli plan için isteğe bağlı: ekran kapanması priz ve pilde Hiçbir Zaman. Önceki değerler yedeklenir. Uyku ve ekran koruyucu değişmez.", "Opcja dla bieżącego planu: ekran nigdy nie gaśnie na zasilaniu i baterii. Poprzednie wartości są zapisane. Uśpienie i wygaszacz pozostają bez zmian." });
            add("settings.screenTimeoutRestore", new[] { "Vorherige Werte wiederherstellen", "Restore previous values", "Restaurer les valeurs précédentes", "Restaurar valores anteriores", "Önceki değerleri geri yükle", "Przywróć poprzednie wartości" });
            add("settings.screenTimeoutOn", new[] { "Bildschirm schaltet nicht automatisch ab", "Display will not turn off automatically", "L’écran ne s’éteindra pas automatiquement", "La pantalla no se apagará automáticamente", "Ekran otomatik kapanmaz", "Ekran nie wyłączy się automatycznie" });
            add("settings.screenTimeoutOff", new[] { "Windows-Standardwerte aktiv", "Windows timeout values active", "Valeurs Windows actives", "Valores de Windows activos", "Windows zaman aşımı etkin", "Aktywne wartości Windows" });
            add("settings.screenTimeoutSaved", new[] { "Bildschirmabschaltung für den aktuellen Energiesparplan deaktiviert. Vorherige Werte sind gesichert.", "Display timeout disabled for the current power plan. Previous values are backed up.", "Extinction désactivée pour le plan actuel. Les valeurs précédentes sont sauvegardées.", "Apagado desactivado para el plan actual. Los valores anteriores están guardados.", "Geçerli planda ekran kapanması devre dışı. Önceki değerler yedeklendi.", "Wyłączono wygaszanie dla bieżącego planu. Poprzednie wartości zapisano." });
            add("settings.screenTimeoutRestored", new[] { "Vorherige Bildschirm-Timeout-Werte wiederhergestellt.", "Previous display timeout values restored.", "Valeurs précédentes restaurées.", "Se restauraron los valores anteriores.", "Önceki ekran zaman aşımı değerleri geri yüklendi.", "Przywrócono poprzednie wartości wygaszania." });
            add("settings.screenTimeoutFailed", new[] { "Die Bildschirm-Timeout-Einstellung konnte nicht geändert werden. Gesicherte Werte bleiben erhalten.", "Could not change the display timeout. Backed-up values were preserved.", "Impossible de modifier le délai d’écran. Les valeurs sauvegardées sont conservées.", "No se pudo cambiar el tiempo de pantalla. Se conservaron los valores guardados.", "Ekran zaman aşımı değiştirilemedi. Yedek değerler korundu.", "Nie można zmienić czasu wygaszania. Kopia wartości została zachowana." });
            add("overlay.compact", new[] { "Kompakt", "Compact", "Compact", "Compacto", "Kompakt", "Kompaktowy" });
            add("overlay.standard", new[] { "Standard", "Standard", "Standard", "Estándar", "Standart", "Standardowy" });
            add("overlay.large", new[] { "Groß", "Large", "Grand", "Grande", "Büyük", "Duży" });
            add("overlay.opacity", new[] { "Deckkraft", "Opacity", "Opacité", "Opacidad", "Opaklık", "Krycie" });
            add("overlay.showCpu", new[] { "CPU anzeigen", "Show CPU", "Afficher CPU", "Mostrar CPU", "CPU'yu göster", "Pokaż CPU" });
            add("overlay.showGpu", new[] { "GPU anzeigen", "Show GPU", "Afficher GPU", "Mostrar GPU", "GPU'yu göster", "Pokaż GPU" });
            add("overlay.showRam", new[] { "RAM anzeigen", "Show RAM", "Afficher RAM", "Mostrar RAM", "RAM'i göster", "Pokaż RAM" });
            add("overlay.showFps", new[] { "FPS anzeigen", "Show FPS", "Afficher FPS", "Mostrar FPS", "FPS'yi göster", "Pokaż FPS" });
            add("overlay.details", new[] { "Min", "Min", "Min", "Mín", "Min", "Min" });
            add("overlay.average", new[] { "Ø", "Avg", "Moy.", "Prom.", "Ort.", "Śr." });
            add("fps.captureError", new[] { "FPS-Aufnahme konnte nicht gestartet werden. Prüfe, ob das Spiel noch läuft und ob der Prozess lesbar ist.", "FPS capture could not start. Check that the game is running and its process is accessible.", "La capture FPS n’a pas démarré. Vérifiez que le jeu fonctionne et que son processus est accessible.", "No se pudo iniciar la captura FPS. Comprueba que el juego sigue abierto y que el proceso es accesible.", "FPS yakalama başlatılamadı. Oyunun çalıştığını ve sürecine erişilebildiğini kontrol edin.", "Nie można rozpocząć pomiaru FPS. Sprawdź, czy gra działa i jej proces jest dostępny." });
            add("fps.noTarget", new[] { "Wähle zuerst ein laufendes Spiel aus.", "Select a running game first.", "Sélectionnez d’abord un jeu en cours.", "Selecciona primero un juego en ejecución.", "Önce çalışan bir oyun seçin.", "Najpierw wybierz uruchomioną grę." });
            add("game.minecraft", new[] { "Minecraft: Java Edition", "Minecraft: Java Edition", "Minecraft : Java Edition", "Minecraft: Java Edition", "Minecraft: Java Edition", "Minecraft: Java Edition" });
            add("game.minecraftBedrock", new[] { "Minecraft für Windows (Bedrock Edition)", "Minecraft for Windows (Bedrock Edition)", "Minecraft pour Windows (édition Bedrock)", "Minecraft para Windows (Bedrock Edition)", "Windows için Minecraft (Bedrock Edition)", "Minecraft dla Windows (Bedrock Edition)" });
            add("game.fortnite", new[] { "Fortnite", "Fortnite", "Fortnite", "Fortnite", "Fortnite", "Fortnite" });
            add("game.minecraft", new[] { "Minecraft: Java Edition", "Minecraft: Java Edition", "Minecraft : Java Edition", "Minecraft: Java Edition", "Minecraft: Java Edition", "Minecraft: Java Edition" });
            add("game.valorant", new[] { "VALORANT", "VALORANT", "VALORANT", "VALORANT", "VALORANT", "VALORANT" });
            add("game.gta", new[] { "Grand Theft Auto V", "Grand Theft Auto V", "Grand Theft Auto V", "Grand Theft Auto V", "Grand Theft Auto V", "Grand Theft Auto V" });
            add("game.r6", new[] { "Tom Clancy’s Rainbow Six Siege", "Tom Clancy’s Rainbow Six Siege", "Tom Clancy’s Rainbow Six Siege", "Tom Clancy’s Rainbow Six Siege", "Tom Clancy’s Rainbow Six Siege", "Tom Clancy’s Rainbow Six Siege" });
            add("game.farming", new[] { "Landwirtschafts-Simulator 25", "Farming Simulator 25", "Farming Simulator 25", "Farming Simulator 25", "Farming Simulator 25", "Farming Simulator 25" });
            add("game.helldivers", new[] { "HELLDIVERS 2", "HELLDIVERS 2", "HELLDIVERS 2", "HELLDIVERS 2", "HELLDIVERS 2", "HELLDIVERS 2" });
            add("game.league", new[] { "League of Legends", "League of Legends", "League of Legends", "League of Legends", "League of Legends", "League of Legends" });
            add("game.pubg", new[] { "PUBG: BATTLEGROUNDS", "PUBG: BATTLEGROUNDS", "PUBG: BATTLEGROUNDS", "PUBG: BATTLEGROUNDS", "PUBG: BATTLEGROUNDS", "PUBG: BATTLEGROUNDS" });
            add("game.warzone", new[] { "Call of Duty: Warzone", "Call of Duty: Warzone", "Call of Duty: Warzone", "Call of Duty: Warzone", "Call of Duty: Warzone", "Call of Duty: Warzone" });
            add("game.dota", new[] { "Dota 2", "Dota 2", "Dota 2", "Dota 2", "Dota 2", "Dota 2" });
            add("game.roblox", new[] { "Roblox", "Roblox", "Roblox", "Roblox", "Roblox", "Roblox" });
            add("game.fc26", new[] { "EA SPORTS FC 26", "EA SPORTS FC 26", "EA SPORTS FC 26", "EA SPORTS FC 26", "EA SPORTS FC 26", "EA SPORTS FC 26" });
            add("optitem.fortnite_lan.title", new[] { "Fortnite-Ping: LAN-Verbindung", "Fortnite ping: wired LAN", "Ping Fortnite : Ethernet", "Ping de Fortnite: conexión Ethernet", "Fortnite pingi: kablolu LAN", "Ping w Fortnite: przewodowy LAN" });
            add("optitem.fortnite_lan.desc", new[] { "Verbinde den PC direkt per Ethernet mit dem Router. Vermeide WLAN-Repeater, VPN und parallele Downloads. Wähle in Fortnite die nächstgelegene Serverregion. Der Ping hängt auch von Router, Anbieter und Serverroute ab; ein niedrigerer Wert ist nicht garantiert.", "Connect the PC directly to the router with Ethernet. Avoid Wi-Fi repeaters, VPNs and concurrent downloads. Choose the closest Fortnite matchmaking region. Ping also depends on your router, ISP and server route; a lower value is not guaranteed.", "Reliez le PC directement au routeur par Ethernet. Évitez les répéteurs Wi-Fi, VPN et téléchargements simultanés. Choisissez la région Fortnite la plus proche. Le ping dépend aussi du routeur, du fournisseur et du trajet serveur; aucune baisse n’est garantie.", "Conecta el PC directamente al router por Ethernet. Evita repetidores Wi-Fi, VPN y descargas simultáneas. Elige la región más cercana en Fortnite. El ping también depende del router, proveedor y ruta del servidor; no se garantiza una reducción.", "Bilgisayarı Ethernet kablosuyla doğrudan yönlendiriciye bağla. Wi-Fi tekrarlayıcı, VPN ve eşzamanlı indirmelerden kaçın. Fortnite'ta en yakın sunucu bölgesini seç. Ping; yönlendiriciye, sağlayıcıya ve sunucu rotasına da bağlıdır; düşüş garanti edilmez.", "Połącz komputer bezpośrednio z routerem kablem Ethernet. Unikaj wzmacniaczy Wi-Fi, VPN i pobierania w tle. Wybierz najbliższy region Fortnite. Ping zależy też od routera, dostawcy i trasy do serwera; spadek nie jest gwarantowany." });
            add("optitem.route_latency.title", new[] { "Ping-Spitzen und Verbindung prüfen", "Check ping spikes and connection", "Vérifier les pics de ping", "Revisar picos de ping", "Ping sıçramalarını incele", "Sprawdź skoki pingu" });
            add("optitem.route_latency.desc", new[] { "Teste während des Spiels Paketverlust und Ping-Schwankungen. Pausiere Cloud-Synchronisierung und große Downloads. Ändere DNS oder TCP-Registrywerte nicht pauschal: Das verbessert den Spiel-Ping normalerweise nicht zuverlässig.", "Check packet loss and ping variation while playing. Pause cloud sync and large downloads. Avoid blanket DNS or TCP registry tweaks: they do not reliably improve game ping.", "Vérifiez pertes de paquets et variations de ping en jeu. Mettez en pause synchronisation cloud et gros téléchargements. Évitez les changements DNS/TCP génériques, qui n’améliorent pas fiablement le ping.", "Comprueba pérdida de paquetes y variación del ping en partida. Pausa la sincronización en la nube y descargas grandes. Evita cambios generales de DNS o TCP: no mejoran el ping de forma fiable.", "Oyunda paket kaybını ve ping değişimini kontrol et. Bulut eşitleme ve büyük indirmeleri duraklat. Genel DNS/TCP kayıt defteri değişikliklerinden kaçın; oyun pingini güvenilir biçimde düşürmezler.", "Sprawdź utratę pakietów i wahania pingu w grze. Wstrzymaj synchronizację w chmurze i duże pobieranie. Unikaj ogólnych zmian DNS/TCP — nie poprawiają niezawodnie pingu." });
            add("optitem.input_latency.title", new[] { "Eingabelatenz im Spiel reduzieren", "Reduce in-game input latency", "Réduire la latence d’entrée", "Reducir latencia de entrada", "Girdi gecikmesini azalt", "Zmniejsz opóźnienie wejścia" });
            add("optitem.input_latency.desc", new[] { "Prüfe im jeweiligen Spiel NVIDIA Reflex, AMD Anti-Lag oder eine vergleichbare Option und aktiviere nur eine passende Funktion. V-Sync, Treiber und Bildwiederholrate können das Ergebnis verändern; vergleiche mit derselben Szene.", "Check the game's NVIDIA Reflex, AMD Anti-Lag or equivalent option and use only the supported setting that fits your setup. V-Sync, drivers and refresh rate affect results; compare in the same scene.", "Vérifiez NVIDIA Reflex, AMD Anti-Lag ou l’option équivalente du jeu et n’activez que le réglage adapté. V-Sync, pilotes et fréquence de rafraîchissement changent le résultat; comparez dans la même scène.", "Revisa NVIDIA Reflex, AMD Anti-Lag o una opción equivalente del juego y activa solo la adecuada. V-Sync, controladores y frecuencia afectan el resultado; compara en la misma escena.", "Oyundaki NVIDIA Reflex, AMD Anti-Lag veya benzer seçeneği kontrol et; sistemine uygun olanı kullan. V-Sync, sürücüler ve yenileme hızı sonucu etkiler; aynı sahnede karşılaştır.", "Sprawdź NVIDIA Reflex, AMD Anti-Lag lub podobną opcję w grze i wybierz właściwą dla zestawu. V-Sync, sterowniki i odświeżanie wpływają na wynik; porównuj tę samą scenę." });
            add("optitem.network_queue.title", new[] { "Hintergrundnetzwerk entlasten", "Reduce background network load", "Réduire le trafic réseau en arrière-plan", "Reducir tráfico de red en segundo plano", "Arka plan ağ trafiğini azalt", "Ogranicz ruch sieciowy w tle" });
            add("optitem.network_queue.desc", new[] { "Pausiere während Online-Spielen große Downloads, Cloud-Backups und Updates. Ein LAN-Kabel senkt WLAN-Störungen, kann aber die Strecke zum Internetanbieter nicht verkürzen.", "Pause large downloads, cloud backups and updates during online play. Ethernet avoids Wi-Fi interference but cannot shorten the route to your ISP or game server.", "Mettez en pause téléchargements, sauvegardes cloud et mises à jour pendant le jeu. Ethernet évite les interférences Wi-Fi mais ne raccourcit pas la route vers le fournisseur ou le serveur.", "Pausa descargas grandes, copias en la nube y actualizaciones durante el juego. Ethernet evita interferencias Wi-Fi, pero no acorta la ruta al proveedor o servidor.", "Çevrimiçi oynarken büyük indirmeleri, bulut yedeklerini ve güncellemeleri duraklat. Ethernet Wi-Fi parazitini önler ama sağlayıcıya veya oyun sunucusuna giden yolu kısaltmaz.", "Wstrzymaj duże pobieranie, kopie w chmurze i aktualizacje podczas gry online. Ethernet eliminuje zakłócenia Wi-Fi, ale nie skraca trasy do dostawcy ani serwera." });
            add("diagnostic.admin", new[] { "Freezer läuft ohne Administratorrechte.", "Freezer is running without administrator rights.", "Freezer fonctionne sans droits administrateur.", "Freezer se está ejecutando sin permisos de administrador.", "Freezer yönetici izni olmadan çalışıyor.", "Freezer działa bez uprawnień administratora." });
            add("diagnostic.elevated", new[] { "Freezer läuft mit Administratorrechten.", "Freezer is running with administrator rights.", "Freezer fonctionne avec les droits administrateur.", "Freezer se está ejecutando con permisos de administrador.", "Freezer yönetici izniyle çalışıyor.", "Freezer działa z uprawnieniami administratora." });
            add("startup.title", new[] { "Freezer konnte nicht gestartet werden", "Freezer could not start", "Freezer n’a pas pu démarrer", "No se pudo iniciar Freezer", "Freezer başlatılamadı", "Nie udało się uruchomić Freezer" });
            add("startup.details", new[] { "Ein Fehlerbericht wurde gespeichert unter:", "A diagnostic report was saved to:", "Un rapport de diagnostic a été enregistré dans :", "Se guardó un informe de diagnóstico en:", "Tanılama raporu şuraya kaydedildi:", "Raport diagnostyczny zapisano w:" });
            add("repair.settingsMissing", new[] { "Einstellungsdatei fehlt; Standardwerte werden verwendet.", "Settings file is absent; defaults are in use.", "Fichier de paramètres absent; valeurs par défaut utilisées.", "No existe el archivo de ajustes; se usan valores predeterminados.", "Ayar dosyası yok; varsayılanlar kullanılıyor.", "Brak pliku ustawień; używane są wartości domyślne." });
            add("repair.presentmonMissing", new[] { "PresentMon fehlt. Auto-Reparatur versucht, die eingebettete Datei wiederherzustellen.", "PresentMon is missing. Auto repair will try to restore the bundled file.", "PresentMon manque. La réparation tentera de restaurer le fichier intégré.", "Falta PresentMon. La reparación intentará restaurar el archivo incluido.", "PresentMon eksik. Otomatik onarım gömülü dosyayı geri yüklemeyi dener.", "Brak PresentMon. Naprawa spróbuje odtworzyć dołączony plik." });
            add("repair.backupMade", new[] { "Beschädigte Einstellungen gesichert unter:", "Damaged settings backed up to:", "Paramètres endommagés sauvegardés dans :", "Ajustes dañados guardados en:", "Bozuk ayarlar şuraya yedeklendi:", "Uszkodzone ustawienia zapisano w:" });
            add("repair.auto", new[] { "Auto-Reparatur", "Auto repair", "Réparation auto", "Reparación automática", "Otomatik onarım", "Automatyczna naprawa" });
            add("repair.diagnosing", new[] { "Diagnose läuft …", "Diagnosing …", "Diagnostic en cours…", "Diagnóstico en curso…", "Tanılama çalışıyor…", "Trwa diagnostyka…" });
            add("repair.reportTitle", new[] { "Diagnosebericht", "Diagnostic report", "Rapport de diagnostic", "Informe de diagnóstico", "Tanılama raporu", "Raport diagnostyczny" });
            add("repair.repaired", new[] { "Sichere Freezer-Reparaturen abgeschlossen.", "Safe Freezer repairs completed.", "Réparations Freezer sans risque terminées.", "Reparaciones seguras de Freezer completadas.", "Güvenli Freezer onarımı tamamlandı.", "Bezpieczne naprawy Freezer zakończone." });
            add("repair.noChanges", new[] { "Es gab keine beschädigten Freezer-Dateien zu reparieren.", "No damaged Freezer files needed repair.", "Aucun fichier Freezer endommagé à réparer.", "No había archivos de Freezer dañados que reparar.", "Onarılması gereken bozuk Freezer dosyası yok.", "Nie znaleziono uszkodzonych plików Freezer." });
            add("repair.backupCorrupt", new[] { "Beschädigte Einstellungsdatei wurde gesichert und auf Standard zurückgesetzt.", "Damaged settings were backed up and reset to defaults.", "Les paramètres endommagés ont été sauvegardés puis réinitialisés.", "La configuración dañada se guardó y se restableció.", "Bozuk ayarlar yedeklendi ve varsayılana döndürüldü.", "Uszkodzone ustawienia zapisano i przywrócono domyślne." });
            add("repair.settingsOk", new[] { "Einstellungsdatei lesbar", "Settings file readable", "Fichier de paramètres lisible", "Archivo de ajustes legible", "Ayar dosyası okunabiliyor", "Plik ustawień czytelny" });
            add("repair.settingsBad", new[] { "Einstellungsdatei fehlt oder ist beschädigt", "Settings file missing or damaged", "Fichier de paramètres absent ou endommagé", "Falta el archivo de ajustes o está dañado", "Ayar dosyası yok veya bozuk", "Brak pliku ustawień lub jest uszkodzony" });
            add("repair.presentmonOk", new[] { "FPS-Komponente vorhanden", "FPS component present", "Composant FPS disponible", "Componente FPS disponible", "FPS bileşeni mevcut", "Komponent FPS dostępny" });
            add("repair.presentmonBad", new[] { "FPS-Komponente fehlt", "FPS component missing", "Composant FPS manquant", "Falta el componente FPS", "FPS bileşeni eksik", "Brak komponentu FPS" });
            add("repair.snapshotOk", new[] { "Sicherungen lesbar", "Snapshots readable", "Sauvegardes lisibles", "Copias legibles", "Yedekler okunabiliyor", "Kopie zapasowe czytelne" });
            add("repair.snapshotBad", new[] { "Mindestens eine Sicherung ist beschädigt; sie wurde nicht gelöscht", "At least one snapshot is damaged; it was preserved", "Une sauvegarde est endommagée; elle a été conservée", "Hay una copia dañada; se conservó", "En az bir yedek bozuk; silinmedi", "Co najmniej jedna kopia jest uszkodzona; zachowano ją" });
            add("repair.timeout", new[] { "Bildschirm-Timeout unverändert", "Display timeout unchanged", "Délai d’écran inchangé", "Tiempo de pantalla sin cambios", "Ekran zaman aşımı değiştirilmedi", "Czas wygaszania ekranu bez zmian" });
            add("repair.userRights", new[] { "Für diese Benutzer-Einstellungen sind keine Administratorrechte nötig.", "These per-user settings do not require administrator rights.", "Ces paramètres utilisateur ne nécessitent pas de droits administrateur.", "Estos ajustes de usuario no requieren permisos de administrador.", "Bu kullanıcı ayarları yönetici izni gerektirmez.", "Te ustawienia użytkownika nie wymagają uprawnień administratora." });
            add("repair.adminWhy", new[] { "Die Änderung des aktiven Windows-Energieschemas betrifft Systemrichtlinien. Windows kann dafür Administratorrechte verlangen. Freezer ändert dabei keine Bildschirm-Timeouts.", "Changing the active Windows power plan affects system policy. Windows may require administrator rights. Freezer does not change display timeouts.", "Modifier le profil d’alimentation actif touche une stratégie système. Windows peut demander des droits administrateur. Freezer ne change pas le délai d’écran.", "Cambiar el plan de energía activo afecta a la directiva del sistema. Windows puede pedir permisos de administrador. Freezer no cambia el tiempo de pantalla.", "Etkin güç planını değiştirmek sistem ilkesini etkiler. Windows yönetici izni isteyebilir. Freezer ekran zaman aşımını değiştirmez.", "Zmiana aktywnego planu zasilania dotyczy ustawień systemowych. Windows może wymagać administratora. Freezer nie zmienia wygaszania ekranu." });
            add("repair.elevation", new[] { "Administratorrechte erforderlich", "Administrator rights required", "Droits administrateur requis", "Se requieren permisos de administrador", "Yönetici izni gerekli", "Wymagane uprawnienia administratora" });
            add("error.optimization", new[] { "Optimierungsfehler", "Optimization error", "Erreur d’optimisation", "Error de optimización", "Optimizasyon hatası", "Błąd optymalizacji" });
            add("error.action", new[] { "Aktion fehlgeschlagen", "Action failed", "Échec de l’action", "La acción falló", "İşlem başarısız", "Niepowodzenie działania" });
            add("error.adminHint", new[] { "Windows hat den Zugriff verweigert. Diese Änderung betrifft eine systemweite Energieplaneinstellung und kann Administratorrechte benötigen. Starte Freezer erhöht oder verwende eine Benutzer-Einstellung.", "Windows denied access. This change affects a system-wide power-plan setting and may require administrator rights. Restart Freezer as administrator or use a per-user setting.", "Windows a refusé l’accès. Ce réglage concerne le plan d’alimentation système et peut nécessiter l’administration. Relancez Freezer en administrateur ou utilisez un réglage utilisateur.", "Windows denegó el acceso. Este cambio afecta al plan de energía del sistema y puede requerir permisos de administrador. Reinicia Freezer como administrador o usa un ajuste de usuario.", "Windows erişimi reddetti. Bu değişiklik sistem genelindeki güç planını etkiler ve yönetici izni gerektirebilir. Freezer'ı yönetici olarak başlatın veya kullanıcı ayarını kullanın.", "Windows odmówił dostępu. Ta zmiana dotyczy systemowego planu zasilania i może wymagać administratora. Uruchom Freezer jako administrator lub użyj ustawienia użytkownika." });
            add("error.operation", new[] { "Die Aktion konnte nicht abgeschlossen werden. Technische Details:", "The action could not be completed. Technical details:", "L’action n’a pas pu aboutir. Détails techniques :", "No se pudo completar la acción. Detalles técnicos:", "İşlem tamamlanamadı. Teknik ayrıntılar:", "Nie udało się wykonać działania. Szczegóły techniczne:" });

            string[] codesForItems = codes;
            Action<string, string[]> item = delegate(string key, string[] values)
            {
                for (int i = 0; i < codesForItems.Length && (i * 2 + 1) < values.Length; i++)
                { result[codesForItems[i]]["optitem." + key + ".title"] = values[i * 2]; result[codesForItems[i]]["optitem." + key + ".desc"] = values[i * 2 + 1]; }
            };
            item("game_mode", new[] { "Gaming-Modus mit niedriger Latenz", "Aktiviert Windows Game Mode. Erkannte Spiele erhalten während der Sitzung vorübergehend Hohe Prozesspriorität und eine 1-ms-Timerauflösung. Dienste werden nicht abgeschaltet; höherer Stromverbrauch ist möglich. Änderungen werden zurückgesetzt.", "Low-latency Gaming Mode", "Enables Windows Game Mode. Recognized games temporarily receive High process priority and 1 ms timer resolution while active. Services are not disabled; power use may rise. Changes are reverted.", "Mode jeu à faible latence", "Active le Mode Jeu Windows. Les jeux reconnus reçoivent temporairement une priorité élevée et un timer de 1 ms. Aucun service n’est désactivé; la consommation peut augmenter. Les changements sont rétablis.", "Modo de juego de baja latencia", "Activa el modo de juego de Windows. Los juegos reconocidos reciben temporalmente prioridad alta y temporizador de 1 ms. No se desactivan servicios; puede aumentar el consumo. Se revierte al apagarlo.", "Düşük gecikmeli Oyun Modu", "Windows Oyun Modu'nu açar. Tanınan oyunlara geçici Yüksek öncelik ve 1 ms zamanlayıcı verir. Hizmetler kapatılmaz; güç tüketimi artabilir. Değişiklikler geri alınır.", "Tryb gry o niskim opóźnieniu", "Włącza Tryb Gry Windows. Rozpoznane gry otrzymują tymczasowo wysoki priorytet i timer 1 ms. Usługi nie są wyłączane; zużycie energii może wzrosnąć. Zmiany są cofane." });
            item("mouse_accel", new[] { "Mausbeschleunigung für gleichmäßiges Zielen ausschalten", "Deaktiviert die Windows-Mausbeschleunigung für diesen Benutzer. Die vorherigen Schwellen werden gesichert und beim Ausschalten exakt wiederhergestellt.", "Disable mouse acceleration for consistent aim", "Disables Windows mouse acceleration for this user. Previous thresholds are saved and restored when turned off.", "Désactiver l’accélération de la souris", "Désactive l’accélération Windows pour cet utilisateur. Les seuils précédents sont sauvegardés et restaurés à l’arrêt.", "Desactivar aceleración del ratón", "Desactiva la aceleración de Windows para este usuario. Guarda y restaura los valores anteriores.", "Fare hızlandırmasını kapat", "Bu kullanıcı için Windows fare hızlandırmasını kapatır ve önceki değerleri geri yükler.", "Wyłącz akcelerację myszy", "Wyłącza akcelerację Windows dla tego użytkownika; poprzednie wartości są zapisywane i przywracane." });
            item("visual_effects", new[] { "Windows-Animationen reduzieren", "Reduziert visuelle Effekte für diesen Windows-Benutzer; jederzeit rücksetzbar.", "Reduce Windows animations", "Reduces visual effects for this Windows user; reversible.", "Réduire les animations Windows", "Réduit les effets visuels pour cet utilisateur Windows; réversible.", "Reducir animaciones de Windows", "Reduce efectos visuales para este usuario; reversible.", "Windows animasyonlarını azalt", "Bu kullanıcı için görsel efektleri azaltır; geri alınabilir.", "Ogranicz animacje Windows", "Ogranicza efekty wizualne dla tego użytkownika; można cofnąć." });
            item("game_dvr", new[] { "Hintergrund-Spielaufnahme deaktivieren", "Deaktiviert Xbox/Game-DVR-Aufnahme für diesen Benutzer; Clips können ausfallen.", "Disable background game recording", "Disables Xbox/Game DVR capture for this user; clips may stop working.", "Désactiver l’enregistrement en arrière-plan", "Désactive Xbox/Game DVR pour cet utilisateur; les clips peuvent être indisponibles.", "Desactivar grabación en segundo plano", "Desactiva Xbox/Game DVR para este usuario; los clips pueden dejar de funcionar.", "Arka plan oyun kaydını kapat", "Bu kullanıcı için Xbox/Game DVR'ı kapatır; klipler çalışmayabilir.", "Wyłącz nagrywanie w tle", "Wyłącza Xbox/Game DVR dla tego użytkownika; klipy mogą nie działać." });
            item("menu_delay", new[] { "Menü gecikmesini azalt", "Reduziert das Öffnen von Windows-Menüs auf 100 ms; der alte Wert wird gesichert.", "Reduce menu delay", "Sets Windows menu delay to 100 ms and saves the previous value.", "Réduire le délai des menus", "Règle le délai à 100 ms et sauvegarde l’ancienne valeur.", "Reducir retraso del menú", "Ajusta el retraso del menú a 100 ms y guarda el valor anterior.", "Menü gecikmesini azalt", "Windows menü gecikmesini 100 ms yapar ve eski değeri kaydeder.", "Zmniejsz opóźnienie menu", "Ustawia opóźnienie menu na 100 ms i zapisuje poprzednią wartość." });
            item("cpu_policy", new[] { "CPU-Leistung am Netzbetrieb", "Setzt das CPU-Maximum des aktiven Energieplans auf Netzbetrieb auf 100 %. Mehr Wärme möglich.", "AC CPU performance policy", "Sets the active plan's AC CPU maximum to 100%; heat and power may increase.", "Politique CPU sur secteur", "Règle le maximum CPU sur secteur à 100 %; chaleur et consommation peuvent augmenter.", "Rendimiento de CPU conectado", "Fija el máximo de CPU al 100 % con corriente; puede aumentar calor y consumo.", "Prize takılı CPU performansı", "Etkin güç planında prize takılı CPU sınırını %100 yapar; ısı artabilir.", "Wydajność CPU na zasilaniu sieciowym", "Ustawia maksimum CPU na 100% przy zasilaniu; temperatura i pobór mogą wzrosnąć." });
            item("open_graphics", new[] { "Windows-Grafikeinstellungen", "Öffnet Windows, damit du pro Spiel die bevorzugte GPU auswählst.", "Windows graphics preferences", "Open Windows to choose a preferred GPU per game.", "Préférences graphiques Windows", "Ouvre Windows pour choisir un GPU par jeu.", "Preferencias gráficas de Windows", "Abre Windows para elegir una GPU por juego.", "Windows grafik tercihleri", "Her oyun için GPU seçmek üzere Windows ayarlarını açar.", "Preferencje grafiki Windows", "Otwiera Windows, aby wybrać GPU dla każdej gry." });
            item("core_unpark", new[] { "CPU-Kern-Parking: Hinweise", "Kern-Parking hängt von CPU und Firmware ab. Versteckte Werte werden nicht erzwungen.", "CPU core parking guidance", "Core parking varies by CPU and firmware. Hidden values are not forced.", "Conseils sur le parking des cœurs", "Dépend du processeur et du firmware; aucune valeur cachée n’est imposée.", "Consejos de estacionamiento de núcleos", "Depende de CPU y firmware; no se fuerzan valores ocultos.", "CPU çekirdek parkı bilgisi", "İşlemci ve yazılıma bağlıdır; gizli değerler zorlanmaz.", "Informacje o parkowaniu rdzeni", "Zależy od CPU i firmware; ukryte wartości nie są wymuszane." });
            item("gpu_latency", new[] { "NVIDIA-Latenzmodus: Hinweise", "Den Niedriglatenzmodus pro Spiel im NVIDIA-Control-Panel einstellen.", "NVIDIA low-latency guidance", "Set Low Latency Mode per game in NVIDIA Control Panel.", "Conseils de latence NVIDIA", "Réglez le mode faible latence par jeu dans le panneau NVIDIA.", "Consejos de baja latencia NVIDIA", "Configura el modo de baja latencia por juego en el panel NVIDIA.", "NVIDIA düşük gecikme bilgisi", "Düşük Gecikme Modunu NVIDIA Denetim Masası'nda oyun başına ayarlayın.", "Wskazówki niskiego opóźnienia NVIDIA", "Ustaw tryb niskiego opóźnienia dla gry w Panelu NVIDIA." });
            item("fps_cap", new[] { "Stabile FPS-Begrenzung", "Ein dauerhaft haltbares FPS-Limit kann gleichmäßigere Framezeiten bringen; im Spiel messen.", "Stable FPS cap", "A sustainable FPS cap may improve frame pacing; measure in-game.", "Limite FPS stable", "Une limite durable peut lisser les images; mesurez dans le jeu.", "Límite de FPS estable", "Un límite sostenible puede suavizar los fotogramas; mídelo en el juego.", "Kararlı FPS sınırı", "Sürdürülebilir FPS sınırı kare sürelerini iyileştirebilir; oyunda ölçün.", "Stabilny limit FPS", "Utrzymywalny limit może poprawić płynność; zmierz w grze." });
            item("game_overlays", new[] { "Overlays prüfen", "Schließe nur Aufnahme-, Chat- oder Launcher-Overlays, die du nicht nutzt.", "Review game overlays", "Close only capture, chat or launcher overlays you do not use.", "Vérifier les overlays", "Fermez uniquement les overlays de capture, chat ou launcher inutilisés.", "Revisar superposiciones", "Cierra solo overlays de captura, chat o launcher que no uses.", "Oyun katmanlarını gözden geçir", "Yalnızca kullanmadığınız kayıt, sohbet veya başlatıcı katmanlarını kapatın.", "Sprawdź nakładki", "Zamknij tylko nieużywane nakładki nagrywania, czatu lub launchera." });
            item("game_power", new[] { "Leistung und Temperaturen", "Mehr Leistung kann Stromverbrauch, Wärme und Lüftergeräusch erhöhen.", "Power and temperature", "Higher performance can increase power use, heat and fan noise.", "Puissance et température", "Une performance accrue peut augmenter consommation, chaleur et bruit.", "Potencia y temperatura", "Más rendimiento puede aumentar consumo, calor y ruido.", "Güç ve sıcaklık", "Yüksek performans güç tüketimini, ısıyı ve fan sesini artırabilir.", "Moc i temperatura", "Wyższa wydajność może zwiększyć pobór, temperaturę i hałas." });
            item("x3d_profile", new[] { "AMD Ryzen X3D-Spielprofil", "Erkennt Ryzen-X3D-CPUs (AM4/AM5) und aktiviert rücksetzbare Windows-Spieloptionen: Spielmodus an, Hintergrundaufnahme aus. Keine Änderungen an CCD-, CPPC- oder BIOS-Werten.", "AMD Ryzen X3D gaming profile", "Detects Ryzen X3D CPUs (AM4/AM5) and enables reversible Windows gaming options: Game Mode on, background capture off. Does not change CCD, CPPC or BIOS values.", "Profil de jeu AMD Ryzen X3D", "Détecte les processeurs Ryzen X3D (AM4/AM5) et active des options Windows réversibles : Mode Jeu et désactivation de la capture en arrière-plan. Aucun réglage CCD, CPPC ou BIOS.", "Perfil de juego AMD Ryzen X3D", "Detecta CPU Ryzen X3D (AM4/AM5) y activa opciones reversibles de Windows: modo de juego y captura en segundo plano desactivada. No cambia CCD, CPPC ni BIOS.", "AMD Ryzen X3D oyun profili", "Ryzen X3D işlemcileri (AM4/AM5) algılar ve geri alınabilir Windows oyun seçeneklerini açar: Oyun Modu açık, arka plan kaydı kapalı. CCD, CPPC veya BIOS ayarlarını değiştirmez.", "Profil gier AMD Ryzen X3D", "Wykrywa procesory Ryzen X3D (AM4/AM5) i włącza odwracalne opcje Windows: Tryb gry oraz wyłączenie nagrywania w tle. Nie zmienia ustawień CCD, CPPC ani BIOS." });
            item("desktop_assistant", new[] { "Desktop-Optimierung", "Liest CPU, Grafikkarte und RAM aus und schlägt passende, rücksetzbare Windows-Einstellungen vor.", "Desktop optimizer", "Reads CPU, graphics and memory and suggests matching, reversible Windows settings.", "Optimisation du bureau", "Lit le processeur, la carte graphique et la mémoire pour proposer des réglages Windows réversibles.", "Optimización del escritorio", "Lee CPU, gráfica y memoria y sugiere ajustes reversibles de Windows.", "Masaüstü optimizasyonu", "CPU, ekran kartı ve belleği okuyup uygun, geri alınabilir Windows ayarları önerir.", "Optymalizacja pulpitu", "Odczytuje CPU, grafikę i pamięć, a następnie proponuje odwracalne ustawienia Windows." });
            item("network_diagnostic", new[] { "Netzwerkadapter-Diagnose", "Zeigt verbundene Adapter und Verbindungsstatus. Keine pauschalen TCP-Änderungen.", "Network adapter diagnosis", "Lists connected adapters and link state. No blanket TCP changes.", "Diagnostic réseau", "Affiche les adaptateurs connectés; aucune modification TCP générique.", "Diagnóstico de red", "Lista adaptadores conectados; no aplica cambios TCP genéricos.", "Ağ bağdaştırıcısı tanılaması", "Bağlı adaptörleri listeler; genel TCP değişikliği yapmaz.", "Diagnostyka sieci", "Wyświetla adaptery; nie wprowadza ogólnych zmian TCP." });
            item("dns_flush", new[] { "DNS-Cache leeren", "Leert den lokalen DNS-Resolver. Das garantiert keinen niedrigeren Ping.", "Flush DNS cache", "Clears the local DNS resolver. This does not guarantee lower ping.", "Vider le cache DNS", "Vide le résolveur local; cela ne garantit pas un ping plus faible.", "Vaciar caché DNS", "Limpia el resolvedor local; no garantiza menor ping.", "DNS önbelleğini temizle", "Yerel DNS çözümleyicisini temizler; daha düşük ping garanti etmez.", "Wyczyść pamięć DNS", "Czyści lokalny resolver; nie gwarantuje niższego pingu." });
            item("nagle", new[] { "TCP/Nagle: Hinweise", "Nagle-Änderungen können Latenz verbessern oder verschlechtern; Adapterwerte bleiben unverändert.", "TCP/Nagle guidance", "Nagle changes can help or hurt latency; adapter settings remain unchanged.", "Conseils TCP/Nagle", "Nagle peut améliorer ou dégrader la latence; les paramètres restent inchangés.", "Consejos TCP/Nagle", "Nagle puede mejorar o empeorar la latencia; no se cambia el adaptador.", "TCP/Nagle bilgisi", "Nagle gecikmeyi artırabilir veya azaltabilir; adaptör ayarları değişmez.", "Wskazówki TCP/Nagle", "Nagle może poprawić lub pogorszyć opóźnienia; ustawienia pozostają bez zmian." });
            item("wifi", new[] { "WLAN-Stabilität", "Ethernet ist meist stabiler. Bei WLAN auf ein freies 5-/6-GHz-Band achten.", "Wi-Fi stability", "Ethernet is usually steadier. Prefer a clear 5/6 GHz Wi-Fi band.", "Stabilité Wi-Fi", "Ethernet est souvent plus stable; privilégiez une bande 5/6 GHz dégagée.", "Estabilidad Wi-Fi", "Ethernet suele ser más estable; usa una banda 5/6 GHz despejada.", "Wi-Fi kararlılığı", "Ethernet genellikle daha kararlıdır; temiz 5/6 GHz bandı kullanın.", "Stabilność Wi-Fi", "Ethernet jest zwykle stabilniejszy; wybierz wolne pasmo 5/6 GHz." });
            item("temp_clean", new[] { "Alte Temporärdateien", "Zeigt private temporäre Dateien älter als 7 Tage vor dem Löschen.", "Old temporary files", "Previews private temporary files older than 7 days before deletion.", "Anciens fichiers temporaires", "Aperçu des fichiers temporaires privés de plus de 7 jours.", "Archivos temporales antiguos", "Previsualiza temporales privados de más de 7 días.", "Eski geçici dosyalar", "Silmeden önce 7 günden eski özel geçici dosyaları gösterir.", "Stare pliki tymczasowe", "Podgląda prywatne pliki tymczasowe starsze niż 7 dni." });
            item("shader_clean", new[] { "DirectX-/GPU-Shader-Cache", "Zeigt bekannte GPU-Shader-Caches älter als 14 Tage. Spiele bauen sie bei Bedarf neu.", "DirectX/GPU shader cache", "Previews known shader-cache files older than 14 days. Games may rebuild them.", "Cache shaders DirectX/GPU", "Aperçu des caches shaders de plus de 14 jours; les jeux peuvent les recréer.", "Caché de sombreadores", "Previsualiza cachés antiguos; los juegos pueden reconstruirlos.", "DirectX/GPU gölgelendirici önbelleği", "14 günden eski bilinen önbelleği gösterir; oyunlar yeniden oluşturabilir.", "Pamięć shaderów DirectX/GPU", "Podgląd starych cache shaderów; gry mogą je odbudować." });
            item("discord_clean", new[] { "Discord-Cache", "Zeigt alte Discord-Cache-Dateien. Discord vorher schließen.", "Discord cache", "Previews old Discord cache files. Close Discord first.", "Cache Discord", "Aperçu des anciens fichiers; fermez Discord avant le nettoyage.", "Caché de Discord", "Previsualiza archivos antiguos; cierra Discord antes.", "Discord önbelleği", "Eski önbelleği gösterir; önce Discord'u kapatın.", "Cache Discord", "Podgląd starych plików; zamknij Discord przed czyszczeniem." });
            item("ram_flush", new[] { "RAM-Verwaltung", "Windows verwaltet den Arbeitsspeicher. Erzwingen eines Flushes kann Spiele verlangsamen.", "Memory management", "Windows manages RAM. Forcing a flush can slow down games.", "Gestion mémoire", "Windows gère la RAM; forcer un vidage peut ralentir les jeux.", "Gestión de memoria", "Windows gestiona la RAM; forzar un vaciado puede ralentizar juegos.", "Bellek yönetimi", "RAM'i Windows yönetir; zorla temizleme oyunları yavaşlatabilir.", "Zarządzanie pamięcią", "Windows zarządza RAM; wymuszone czyszczenie może spowolnić gry." });
            item("storage_settings", new[] { "Windows-Speicherverwaltung", "Öffnet die Windows-Speichereinstellungen zur kontrollierten Bereinigung.", "Windows storage settings", "Open Windows storage settings for controlled cleanup.", "Paramètres de stockage", "Ouvre les paramètres Windows pour un nettoyage contrôlé.", "Almacenamiento de Windows", "Abre los ajustes de almacenamiento de Windows.", "Windows depolama ayarları", "Kontrollü temizlik için Windows depolama ayarlarını açar.", "Ustawienia pamięci Windows", "Otwiera ustawienia pamięci Windows." });
            item("windows_update", new[] { "Windows Update", "Updates nicht deaktivieren; außerhalb einer Spielsitzung nach Updates suchen.", "Windows Update", "Keep updates enabled; check for updates outside a gaming session.", "Windows Update", "Gardez les mises à jour actives; vérifiez-les hors session de jeu.", "Windows Update", "Mantén las actualizaciones activas; revísalas fuera de la sesión.", "Windows Update", "Güncellemeleri açık tutun; oyun dışında kontrol edin.", "Windows Update", "Pozostaw aktualizacje włączone; sprawdzaj je poza grą." });
            item("startup_apps", new[] { "Autostart-Apps prüfen", "Öffnet die Windows-Autostartliste. Deaktiviere nur bekannte Apps.", "Review startup apps", "Open Windows startup apps. Disable only apps you recognize.", "Vérifier les applications au démarrage", "Ouvre la liste; désactivez uniquement les applications connues.", "Revisar aplicaciones de inicio", "Abre la lista; desactiva solo aplicaciones conocidas.", "Başlangıç uygulamalarını incele", "Windows listesini açar; yalnızca tanıdığınız uygulamaları kapatın.", "Sprawdź aplikacje startowe", "Otwiera listę Windows; wyłączaj tylko znane aplikacje." });
            item("background_apps", new[] { "Hintergrund-Apps prüfen", "Schließe nur Apps, die du kennst und während des Spielens nicht brauchst.", "Review background apps", "Close only apps you know and do not need while gaming.", "Vérifier les applications en arrière-plan", "Fermez uniquement les applications connues et inutiles en jeu.", "Revisar aplicaciones en segundo plano", "Cierra solo aplicaciones conocidas que no necesites al jugar.", "Arka plan uygulamalarını incele", "Oyun sırasında gerekmeyen ve tanıdığınız uygulamaları kapatın.", "Sprawdź aplikacje w tle", "Zamykaj tylko znane aplikacje niepotrzebne podczas gry." });
            item("game_mode_settings", new[] { "Windows-Spielmodus-Einstellungen", "Öffnet die Windows-Seite für den Spielmodus.", "Windows Game Mode settings", "Open the Windows Game Mode settings page.", "Paramètres du Mode Jeu Windows", "Ouvre la page Mode Jeu de Windows.", "Ajustes del modo de juego", "Abre la página del modo de juego de Windows.", "Windows Oyun Modu ayarları", "Windows Oyun Modu sayfasını açar.", "Ustawienia trybu gry Windows", "Otwiera stronę trybu gry Windows." });
            item("no_timeout", new[] { "Bildschirm-Timeout schützen", "Freezer ändert bei Optimierungen weder Bildschirm-Timeout noch Energiesparzeit.", "Protect display timeout", "Freezer never changes display or sleep timers during optimization.", "Protéger le délai d’écran", "Freezer ne modifie jamais les délais d’écran ou de veille.", "Proteger tiempo de pantalla", "Freezer nunca cambia los tiempos de pantalla o suspensión.", "Ekran zaman aşımını koru", "Freezer optimizasyon sırasında ekran veya uyku sürelerini değiştirmez.", "Ochrona czasu wygaszania", "Freezer nie zmienia czasu wygaszania ani uśpienia." });
            item("background_apps_toggle", new[] { "UWP-Hintergrund-Apps begrenzen", "Blockiert Hintergrundaktivität unterstützter Windows-Apps für diesen Benutzer. Benachrichtigungen oder Synchronisierung können ausbleiben; jederzeit rücksetzbar.", "Limit UWP background apps", "Blocks background activity for supported Windows apps for this user. Notifications or sync may stop; reversible.", "Limiter les applications en arrière-plan", "Bloque l’activité en arrière-plan des applications Windows prises en charge. Les notifications ou la synchronisation peuvent cesser; réversible.", "Limitar aplicaciones en segundo plano", "Bloquea actividad en segundo plano de apps compatibles. Las notificaciones o la sincronización pueden detenerse; reversible.", "UWP arka plan uygulamalarını sınırla", "Desteklenen Windows uygulamalarının arka plan etkinliğini kapatır. Bildirimler veya eşitleme durabilir; geri alınabilir.", "Ogranicz aplikacje w tle", "Blokuje działanie obsługiwanych aplikacji Windows w tle. Powiadomienia lub synchronizacja mogą ustać; można cofnąć." });
            item("transparency", new[] { "Windows-Transparenzeffekte reduzieren", "Schaltet Transparenzeffekte für diesen Benutzer aus. Ändert nur die Darstellung und verspricht keinen FPS-Zuwachs; rücksetzbar.", "Reduce Windows transparency effects", "Disables transparency for this user. Visual change only; no FPS gain is promised. Reversible.", "Réduire la transparence Windows", "Désactive la transparence pour cet utilisateur. Changement visuel uniquement, sans gain FPS promis; réversible.", "Reducir transparencia de Windows", "Desactiva la transparencia para este usuario. Solo cambia la apariencia; no promete más FPS. Reversible.", "Windows şeffaflık efektlerini azalt", "Bu kullanıcı için şeffaflığı kapatır. Yalnızca görünümü değiştirir; FPS artışı vaat etmez. Geri alınabilir.", "Ogranicz przezroczystość Windows", "Wyłącza przezroczystość dla tego użytkownika. Zmienia tylko wygląd i nie obiecuje FPS; można cofnąć." });
            return result;
        }

        private static Dictionary<string, Dictionary<string, string>> Build()
        {
            string[] keys = new string[] {
                "nav.home", "nav.optimizations", "nav.games", "nav.hardware", "nav.settings", "nav.repair",
                "header.tag", "home.title", "home.subtitle", "home.ready", "home.overlay", "home.openMonitor",
                "opt.title", "opt.subtitle", "opt.activate", "opt.restore", "opt.info", "opt.run", "opt.gaming",
                "opt.network", "opt.storage", "opt.system", "games.title", "games.subtitle", "games.profile",
                "games.lite", "games.balanced", "games.power", "hardware.title", "hardware.subtitle", "hardware.attach",
                "hardware.detach", "hardware.refresh", "hardware.overlay", "hardware.target", "hardware.noTarget",
                "settings.title", "settings.subtitle", "settings.language", "settings.accent", "settings.reduceMotion",
                "settings.reduceHint", "settings.animationOn", "settings.animationOff", "repair.title", "repair.subtitle",
                "repair.run", "repair.openFolder", "repair.restoreTweaks", "dialog.confirm", "dialog.cancel", "dialog.ok",
                "dialog.warning", "status.ready", "status.measuring", "status.saved", "status.running", "overlay.title",
                "metric.cpu", "metric.gpu", "metric.ram", "metric.fps", "metric.fpsMin", "metric.fpsAvg", "metric.app",
                "game.fortnite", "game.minecraft", "game.valorant", "game.gta", "game.cyberpunk", "game.rocket",
                "game.overwatch", "game.r6", "game.apex", "game.helldivers", "game.farming", "game.counterstrike",
                "theme.orange", "theme.cyan", "theme.violet", "theme.lime", "theme.pink", "clean.preview",
                "clean.confirm", "clean.done", "network.result", "optimization.confirm", "optimization.done",
                "power.warning", "overlay.hint", "monitor.unavailable"
            };
            string[][] rows = new string[][] {
                new string[] { "Start", "Optimierungen", "Spiele", "Hardware", "Einstellungen", "Reparatur",
                    "PERFORMANCE  /  CONTROL", "Dein PC im Überblick", "Freezer holt mehr aus deiner vorhandenen Hardware heraus. Ergebnisse hängen von System und Spiel ab.",
                    "Bereit für deine Gaming-Sitzung.", "Live-Overlay anzeigen", "Hardware-Monitor öffnen",
                    "Optimierungen", "Sichere, nachvollziehbare Optionen. Änderungen werden vor dem Anwenden bestätigt.", "Aktivieren", "Zurücksetzen", "Hinweis", "Ausführen", "Gaming & Latenz",
                    "Netzwerk", "Speicher & Cache", "Windows & Komfort", "Game Hub", "Profile pro Spiel speichern. Keine Spieldateien werden geändert.", "Profil",
                    "Lite Preset", "Balanced", "Power Preset", "Hardware-Monitor", "Live-Werte werden nur angezeigt, solange Home oder Monitor geöffnet ist.", "FPS messen",
                    "FPS-Messung stoppen", "Aktualisieren", "Overlay anzeigen", "Spielprozess", "Kein Spielprozess ausgewählt",
                    "Einstellungen", "Sprache, Akzentfarbe und Bewegung einstellen.", "Sprache", "Akzentfarbe", "Animationen reduzieren",
                    "Wenn aktiviert, klappt die Navigation sofort ohne Animation auf und zu.", "Schnelle Animation", "Animation aus", "Fehlerbehebung",
                    "Prüft Freezer-eigene Dateien und kann gespeicherte Freezer-Änderungen rückgängig machen.", "Diagnose starten", "Datenordner öffnen", "Freezer-Änderungen zurücksetzen",
                    "Bestätigen", "Abbrechen", "OK", "Hinweis", "Bereit", "Messwerte werden aktualisiert …", "Einstellungen gespeichert.", "Wird ausgeführt …", "Freezer Live-Overlay",
                    "CPU", "GPU", "RAM", "FPS", "Min", "Avg", "Freezer-RAM",
                    "Fortnite", "Minecraft Java", "Valorant", "GTA V", "Cyberpunk 2077", "Rocket League", "Overwatch 2", "Rainbow Six Siege", "Apex Legends", "Helldivers 2", "Landwirtschafts-Simulator", "Counter-Strike 2",
                    "Orange", "Cyan", "Violett", "Limette", "Pink", "Vorschau anzeigen",
                    "Diese alten Cache-Dateien werden nach Bestätigung entfernt. Spiele können Shader-Dateien anschließend neu erstellen.", "Cache-Dateien jetzt löschen?",
                    "Bereinigung abgeschlossen.", "Netzwerkdiagnose", "Diese Änderung ist reversibel. Freezer speichert vorherige Werte und verändert keine Bildschirm-Timeouts. Fortfahren?",
                    "Optimierung angewendet.", "Kann mehr Strom verbrauchen und Wärme erzeugen. Bildschirm-Timeouts werden nicht verändert.", "FPS benötigt ein laufendes Spiel und PresentMon.",
                    "Für diese Hardware ist kein verlässlicher GPU-Wert verfügbar."
                },
                new string[] { "Home", "Optimizations", "Games", "Hardware", "Settings", "Repair",
                    "PERFORMANCE  /  CONTROL", "System overview", "Freezer gets more from your existing hardware. Results depend on your system and game.",
                    "Ready for your gaming session.", "Show live overlay", "Open hardware monitor",
                    "Optimizations", "Safe, transparent options. Changes are confirmed before application.", "Enable", "Restore", "Info", "Run", "Gaming & latency",
                    "Network", "Storage & cache", "Windows & quality of life", "Game Hub", "Save per-game profiles. Game files are never changed.", "Profile",
                    "Lite preset", "Balanced", "Power preset", "Hardware monitor", "Live readings run only while Home or Monitor is open.", "Measure FPS",
                    "Stop FPS capture", "Refresh", "Show overlay", "Game process", "No game process selected",
                    "Settings", "Choose language, accent color and motion.", "Language", "Accent color", "Reduce animations",
                    "When enabled, navigation opens and closes instantly with no animation.", "Fast animation", "No animation", "Repair",
                    "Checks Freezer-owned files and can roll back saved Freezer changes.", "Run diagnostics", "Open data folder", "Restore Freezer changes",
                    "Confirm", "Cancel", "OK", "Notice", "Ready", "Updating readings …", "Settings saved.", "Working …", "Freezer live overlay",
                    "CPU", "GPU", "RAM", "FPS", "Min", "Avg", "Freezer memory",
                    "Fortnite", "Minecraft Java", "Valorant", "GTA V", "Cyberpunk 2077", "Rocket League", "Overwatch 2", "Rainbow Six Siege", "Apex Legends", "Helldivers 2", "Farming Simulator", "Counter-Strike 2",
                    "Orange", "Cyan", "Violet", "Lime", "Pink", "Preview",
                    "These old cache files will be removed after confirmation. Games may rebuild shader files afterwards.", "Delete these cache files now?",
                    "Cleanup finished.", "Network diagnosis", "This change is reversible. Freezer saves previous values and does not change display timeouts. Continue?",
                    "Optimization applied.", "May increase power use and heat. Display timeouts are not changed.", "FPS capture requires a running game and PresentMon.",
                    "No reliable GPU reading is available for this hardware."
                },
                new string[] { "Accueil", "Optimisations", "Jeux", "Matériel", "Paramètres", "Réparation",
                    "PERFORMANCE  /  CONTROL", "Vue d’ensemble", "Freezer tire davantage parti de votre matériel. Les résultats dépendent du système et du jeu.",
                    "Prêt pour votre session de jeu.", "Afficher la superposition", "Ouvrir le moniteur matériel",
                    "Optimisations", "Options sûres et explicites. Les changements sont confirmés avant application.", "Activer", "Restaurer", "Info", "Exécuter", "Jeux et latence",
                    "Réseau", "Stockage et cache", "Windows et confort", "Hub de jeux", "Enregistrer des profils par jeu. Les fichiers du jeu ne sont pas modifiés.", "Profil",
                    "Profil léger", "Équilibré", "Profil puissant", "Moniteur matériel", "Les mesures sont actives uniquement sur Accueil ou Matériel.", "Mesurer les FPS",
                    "Arrêter la mesure FPS", "Actualiser", "Afficher la superposition", "Processus du jeu", "Aucun processus sélectionné",
                    "Paramètres", "Choisissez la langue, la couleur et les animations.", "Langue", "Couleur d’accent", "Réduire les animations",
                    "Activée, la navigation s’ouvre et se ferme instantanément.", "Animation rapide", "Sans animation", "Réparation",
                    "Vérifie les fichiers Freezer et peut annuler les changements enregistrés.", "Lancer le diagnostic", "Ouvrir le dossier", "Restaurer les changements Freezer",
                    "Confirmer", "Annuler", "OK", "Information", "Prêt", "Mise à jour des mesures…", "Paramètres enregistrés.", "Exécution…", "Superposition Freezer",
                    "CPU", "GPU", "RAM", "FPS", "Min", "Moy.", "Mémoire Freezer",
                    "Fortnite", "Minecraft Java", "Valorant", "GTA V", "Cyberpunk 2077", "Rocket League", "Overwatch 2", "Rainbow Six Siege", "Apex Legends", "Helldivers 2", "Farming Simulator", "Counter-Strike 2",
                    "Orange", "Cyan", "Violet", "Citron vert", "Rose", "Aperçu",
                    "Ces anciens fichiers cache seront supprimés après confirmation. Les jeux peuvent recréer leurs shaders ensuite.", "Supprimer ces fichiers cache ?",
                    "Nettoyage terminé.", "Diagnostic réseau", "Ce changement est réversible. Les valeurs précédentes sont enregistrées; les délais d’écran ne changent pas. Continuer ?",
                    "Optimisation appliquée.", "Peut augmenter la consommation et la chaleur. Les délais d’écran restent inchangés.", "La capture FPS nécessite un jeu en cours et PresentMon.",
                    "Aucune mesure GPU fiable n’est disponible pour ce matériel."
                },
                new string[] { "Inicio", "Optimizaciones", "Juegos", "Hardware", "Ajustes", "Reparar",
                    "PERFORMANCE  /  CONTROL", "Resumen del sistema", "Freezer aprovecha mejor tu hardware. Los resultados dependen del sistema y del juego.",
                    "Listo para jugar.", "Mostrar superposición", "Abrir monitor de hardware",
                    "Optimizaciones", "Opciones seguras y claras. Confirma los cambios antes de aplicarlos.", "Activar", "Restaurar", "Info", "Ejecutar", "Juego y latencia",
                    "Red", "Almacenamiento y caché", "Windows y comodidad", "Biblioteca de juegos", "Guarda perfiles por juego. No se modifican archivos del juego.", "Perfil",
                    "Perfil ligero", "Equilibrado", "Perfil potente", "Monitor de hardware", "Las lecturas se actualizan solo en Inicio o Hardware.", "Medir FPS",
                    "Detener medición FPS", "Actualizar", "Mostrar superposición", "Proceso del juego", "No hay proceso seleccionado",
                    "Ajustes", "Elige idioma, color y movimiento.", "Idioma", "Color de acento", "Reducir animaciones",
                    "Al activarlo, el menú se abre y cierra al instante, sin animación.", "Animación rápida", "Sin animación", "Reparación",
                    "Comprueba archivos de Freezer y puede revertir cambios guardados.", "Ejecutar diagnóstico", "Abrir carpeta", "Restaurar cambios de Freezer",
                    "Confirmar", "Cancelar", "Aceptar", "Aviso", "Listo", "Actualizando lecturas…", "Ajustes guardados.", "Procesando…", "Superposición Freezer",
                    "CPU", "GPU", "RAM", "FPS", "Mín", "Prom.", "Memoria Freezer",
                    "Fortnite", "Minecraft Java", "Valorant", "GTA V", "Cyberpunk 2077", "Rocket League", "Overwatch 2", "Rainbow Six Siege", "Apex Legends", "Helldivers 2", "Farming Simulator", "Counter-Strike 2",
                    "Naranja", "Cian", "Violeta", "Lima", "Rosa", "Vista previa",
                    "Estos archivos de caché antiguos se eliminarán tras confirmar. Los juegos podrían reconstruir los shaders.", "¿Eliminar estos archivos de caché?",
                    "Limpieza terminada.", "Diagnóstico de red", "Este cambio se puede revertir. Freezer guarda los valores anteriores y no cambia los tiempos de pantalla. ¿Continuar?",
                    "Optimización aplicada.", "Puede aumentar el consumo y el calor. No se cambian los tiempos de pantalla.", "FPS requiere un juego en ejecución y PresentMon.",
                    "No hay una lectura GPU fiable disponible para este hardware."
                },
                new string[] { "Ana sayfa", "Optimizasyonlar", "Oyunlar", "Donanım", "Ayarlar", "Onarım",
                    "PERFORMANCE  /  CONTROL", "Sisteme genel bakış", "Freezer mevcut donanımınızdan daha fazla yararlanır. Sonuçlar sisteme ve oyuna göre değişir.",
                    "Oyun oturumu için hazır.", "Canlı katmanı göster", "Donanım izleyicisini aç",
                    "Optimizasyonlar", "Güvenli ve açık seçenekler. Değişiklikler uygulanmadan önce onaylanır.", "Etkinleştir", "Geri yükle", "Bilgi", "Çalıştır", "Oyun ve gecikme",
                    "Ağ", "Depolama ve önbellek", "Windows ve kullanım", "Oyun Merkezi", "Oyuna özel profilleri kaydet. Oyun dosyaları değiştirilmez.", "Profil",
                    "Hafif profil", "Dengeli", "Güç profili", "Donanım izleyicisi", "Canlı ölçümler yalnızca Ana Sayfa veya Donanım açıkken çalışır.", "FPS ölç",
                    "FPS ölçümünü durdur", "Yenile", "Katmanı göster", "Oyun işlemi", "Oyun işlemi seçilmedi",
                    "Ayarlar", "Dil, vurgu rengi ve hareketi seçin.", "Dil", "Vurgu rengi", "Animasyonları azalt",
                    "Etkin olduğunda menü animasyonsuz, anında açılıp kapanır.", "Hızlı animasyon", "Animasyon yok", "Onarım",
                    "Freezer dosyalarını denetler ve kaydedilmiş Freezer değişikliklerini geri alabilir.", "Tanılamayı çalıştır", "Veri klasörünü aç", "Freezer değişikliklerini geri al",
                    "Onayla", "İptal", "Tamam", "Bilgi", "Hazır", "Ölçümler güncelleniyor…", "Ayarlar kaydedildi.", "Çalışıyor…", "Freezer canlı katmanı",
                    "CPU", "GPU", "RAM", "FPS", "Min", "Ort.", "Freezer belleği",
                    "Fortnite", "Minecraft Java", "Valorant", "GTA V", "Cyberpunk 2077", "Rocket League", "Overwatch 2", "Rainbow Six Siege", "Apex Legends", "Helldivers 2", "Farming Simulator", "Counter-Strike 2",
                    "Turuncu", "Camgöbeği", "Mor", "Lime", "Pembe", "Önizleme",
                    "Bu eski önbellek dosyaları onaydan sonra silinir. Oyunlar gölgelendirici dosyalarını yeniden oluşturabilir.", "Bu önbellek dosyaları silinsin mi?",
                    "Temizlik tamamlandı.", "Ağ tanılaması", "Bu değişiklik geri alınabilir. Önceki değerler kaydedilir; ekran zaman aşımı değişmez. Devam edilsin mi?",
                    "Optimizasyon uygulandı.", "Güç kullanımı ve ısı artabilir. Ekran zaman aşımı değiştirilmez.", "FPS için çalışan oyun ve PresentMon gerekir.",
                    "Bu donanımda güvenilir GPU değeri yok."
                },
                new string[] { "Start", "Optymalizacje", "Gry", "Sprzęt", "Ustawienia", "Naprawa",
                    "PERFORMANCE  /  CONTROL", "Przegląd systemu", "Freezer lepiej wykorzystuje sprzęt. Wyniki zależą od komputera i gry.",
                    "Gotowy do gry.", "Pokaż nakładkę", "Otwórz monitor sprzętu",
                    "Optymalizacje", "Bezpieczne i jasne opcje. Zmiany są potwierdzane przed zastosowaniem.", "Włącz", "Przywróć", "Informacja", "Uruchom", "Gry i opóźnienia",
                    "Sieć", "Pamięć i cache", "Windows i wygoda", "Biblioteka gier", "Zapisuj profile dla gier. Pliki gry nie są zmieniane.", "Profil",
                    "Lekki profil", "Zrównoważony", "Wydajny profil", "Monitor sprzętu", "Odczyty działają tylko na stronie Start lub Sprzęt.", "Mierz FPS",
                    "Zatrzymaj pomiar FPS", "Odśwież", "Pokaż nakładkę", "Proces gry", "Nie wybrano procesu gry",
                    "Ustawienia", "Wybierz język, kolor i ruch.", "Język", "Kolor akcentu", "Ogranicz animacje",
                    "Po włączeniu menu otwiera się i zamyka natychmiast, bez animacji.", "Szybka animacja", "Bez animacji", "Naprawa",
                    "Sprawdza pliki Freezer i może cofnąć zapisane zmiany Freezer.", "Uruchom diagnostykę", "Otwórz folder danych", "Cofnij zmiany Freezer",
                    "Potwierdź", "Anuluj", "OK", "Informacja", "Gotowy", "Aktualizowanie odczytów…", "Ustawienia zapisane.", "Pracuję…", "Nakładka Freezer",
                    "CPU", "GPU", "RAM", "FPS", "Min", "Śr.", "Pamięć Freezer",
                    "Fortnite", "Minecraft Java", "Valorant", "GTA V", "Cyberpunk 2077", "Rocket League", "Overwatch 2", "Rainbow Six Siege", "Apex Legends", "Helldivers 2", "Farming Simulator", "Counter-Strike 2",
                    "Pomarańczowy", "Cyjan", "Fioletowy", "Limonka", "Różowy", "Podgląd",
                    "Stare pliki cache zostaną usunięte po potwierdzeniu. Gry mogą ponownie utworzyć shadery.", "Usunąć te pliki cache?",
                    "Czyszczenie ukończone.", "Diagnostyka sieci", "Zmianę można cofnąć. Poprzednie wartości są zapisywane; czas wygaszania ekranu nie jest zmieniany. Kontynuować?",
                    "Optymalizacja zastosowana.", "Może zwiększyć pobór energii i temperaturę. Wygaszanie ekranu pozostaje bez zmian.", "Pomiar FPS wymaga uruchomionej gry i PresentMon.",
                    "Brak wiarygodnego odczytu GPU dla tego sprzętu."
                }
            };
            Dictionary<string, Dictionary<string, string>> result = new Dictionary<string, Dictionary<string, string>>();
            string[] codes = new string[] { "de", "en", "fr", "es", "tr", "pl" };
            for (int r = 0; r < rows.Length; r++)
            {
                Dictionary<string, string> map = new Dictionary<string, string>();
                for (int i = 0; i < keys.Length && i < rows[r].Length; i++) map[keys[i]] = rows[r][i];
                result[codes[r]] = map;
            }
            return result;
        }
    }

    internal sealed class Reading
    {
        public double Cpu = -1;
        public double Gpu = -1;
        public double Ram = -1;
        public double RamUsedMb;
        public double RamTotalMb;
        public double AppMb;
        public int Cores;
        public double[] CoreUsage = new double[0];
    }

    internal sealed class HardwareSampler : IDisposable
    {
        [StructLayout(LayoutKind.Sequential)] private struct FileTime { public uint Low; public uint High; public ulong Value { get { return ((ulong)High << 32) | Low; } } }
        [DllImport("kernel32.dll", SetLastError = true)] private static extern bool GetSystemTimes(out FileTime idle, out FileTime kernel, out FileTime user);
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)] private class MemoryStatus
        {
            public uint Length = (uint)Marshal.SizeOf(typeof(MemoryStatus));
            public uint MemoryLoad; public ulong TotalPhys; public ulong AvailPhys; public ulong TotalPageFile;
            public ulong AvailPageFile; public ulong TotalVirtual; public ulong AvailVirtual; public ulong AvailExtendedVirtual;
        }
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)] private static extern bool GlobalMemoryStatusEx([In, Out] MemoryStatus status);
        private readonly object _counterLock = new object();
        private readonly Dictionary<string, PerformanceCounter> _gpuCounters = new Dictionary<string, PerformanceCounter>();
        private readonly List<PerformanceCounter> _coreCounters = new List<PerformanceCounter>();
        private bool _gpuCountersReady;
        private bool _coreCountersReady;
        private ulong _lastIdle, _lastKernel, _lastUser;

        public Reading Sample()
        {
            Reading r = new Reading();
            r.Cores = Environment.ProcessorCount;
            try
            {
                using (Process current = Process.GetCurrentProcess())
                    r.AppMb = current.WorkingSet64 / 1048576.0;
            }
            catch { }
            FileTime idle, kernel, user;
            try
            {
                if (GetSystemTimes(out idle, out kernel, out user))
                {
                    ulong i = idle.Value, k = kernel.Value, u = user.Value;
                    if (_lastKernel != 0)
                    {
                        ulong total = (k - _lastKernel) + (u - _lastUser);
                        ulong busy = total > i - _lastIdle ? total - (i - _lastIdle) : 0;
                        if (total > 0) r.Cpu = Math.Max(0, Math.Min(100, busy * 100.0 / total));
                    }
                    _lastIdle = i; _lastKernel = k; _lastUser = u;
                }
            }
            catch { }
            try
            {
                MemoryStatus memory = new MemoryStatus();
                if (GlobalMemoryStatusEx(memory) && memory.TotalPhys > 0)
                {
                    r.Ram = memory.MemoryLoad;
                    r.RamTotalMb = memory.TotalPhys / 1048576.0;
                    r.RamUsedMb = (memory.TotalPhys - memory.AvailPhys) / 1048576.0;
                }
            }
            catch { }
            r.CoreUsage = ReadCoreUsage();
            r.Gpu = ReadGpu();
            return r;
        }

        private double[] ReadCoreUsage()
        {
            lock (_counterLock)
            {
                if (!_coreCountersReady)
                {
                    _coreCountersReady = true;
                    try
                    {
                        PerformanceCounterCategory category = new PerformanceCounterCategory("Processor");
                        foreach (string instance in category.GetInstanceNames().Where(x => x != "_Total").OrderBy(x => { int n; return Int32.TryParse(x, out n) ? n : Int32.MaxValue; }))
                        {
                            int index; if (!Int32.TryParse(instance, out index)) continue;
                            try { PerformanceCounter counter = new PerformanceCounter("Processor", "% Processor Time", instance, true); counter.NextValue(); _coreCounters.Add(counter); }
                            catch { }
                        }
                    }
                    catch { }
                }
                List<double> values = new List<double>();
                foreach (PerformanceCounter counter in _coreCounters)
                    try { values.Add(Math.Max(0, Math.Min(100, counter.NextValue()))); } catch { values.Add(-1); }
                return values.ToArray();
            }
        }

        private double ReadGpu()
        {
            lock (_counterLock)
            {
                if (!_gpuCountersReady)
                {
                    _gpuCountersReady = true;
                    try
                    {
                        PerformanceCounterCategory category = new PerformanceCounterCategory("GPU Engine");
                        foreach (string instance in category.GetInstanceNames())
                        {
                            if (instance.IndexOf("engtype_3D", StringComparison.OrdinalIgnoreCase) < 0) continue;
                            try
                            {
                                PerformanceCounter counter = new PerformanceCounter("GPU Engine", "Utilization Percentage", instance, true);
                                counter.NextValue();
                                _gpuCounters[instance] = counter;
                            }
                            catch { }
                        }
                    }
                    catch { }
                }
                if (_gpuCounters.Count == 0) return -1;
                Dictionary<string, double> byAdapter = new Dictionary<string, double>();
                foreach (KeyValuePair<string, PerformanceCounter> pair in _gpuCounters)
                {
                    try
                    {
                        string name = pair.Key;
                        Match m = Regex.Match(name, "luid_([0-9a-f]+)_phys_(\\d+)", RegexOptions.IgnoreCase);
                        string key = m.Success ? m.Groups[1].Value + "_" + m.Groups[2].Value : "gpu";
                        float value = pair.Value.NextValue();
                        if (!byAdapter.ContainsKey(key)) byAdapter[key] = 0;
                        byAdapter[key] += Math.Max(0, value);
                    }
                    catch { }
                }
                if (byAdapter.Count == 0) return -1;
                return Math.Max(0, Math.Min(100, byAdapter.Values.Max()));
            }
        }

        public void Dispose()
        {
            lock (_counterLock)
            {
                foreach (PerformanceCounter counter in _gpuCounters.Values) try { counter.Dispose(); } catch { }
                foreach (PerformanceCounter counter in _coreCounters) try { counter.Dispose(); } catch { }
                _gpuCounters.Clear();
                _coreCounters.Clear();
            }
        }
    }

    internal sealed class FrameStats
    {
        public double Current = -1;
        public double Minimum = -1;
        public double Average = -1;
        public double AverageFrameTimeMs = -1;
        public double P95FrameTimeMs = -1;
        public double OnePercentLow = -1;
        public double PointOnePercentLow = -1;
        public long FrameCount;
    }

    internal sealed class BenchmarkRecord
    {
        public DateTime Utc;
        public string Game = "";
        public string Profile = "";
        public int DurationSeconds;
        public long Frames;
        public double AverageFps = -1, MinimumFps = -1, OnePercentLow = -1, PointOnePercentLow = -1;
        public double AverageFrameTimeMs = -1, P95FrameTimeMs = -1;
        public double CpuAverage = -1, CpuPeak = -1, GpuAverage = -1, GpuPeak = -1, RamAverage = -1, RamPeak = -1;
        public override string ToString()
        {
            return Utc.ToLocalTime().ToString("yyyy-MM-dd HH:mm", CultureInfo.CurrentCulture) + " · " + Game + " · " + Profile + " · " + OnePercentLow.ToString("0", CultureInfo.InvariantCulture) + " 1% low";
        }
    }

    internal sealed class BenchmarkRunChoice
    {
        public int Index;
        public BenchmarkRecord Record;
        public override string ToString() { return (Index + 1).ToString(CultureInfo.InvariantCulture) + ". " + Record.ToString(); }
    }

    internal sealed class BenchmarkHistory
    {
        private const int MaxRecords = 40;
        private readonly string _path;
        public BenchmarkHistory(string path) { _path = path; }
        public List<BenchmarkRecord> Load()
        {
            List<BenchmarkRecord> records = new List<BenchmarkRecord>();
            try
            {
                if (!File.Exists(_path)) return records;
                FileInfo historyFile = new FileInfo(_path);
                if (historyFile.Length > 65536) { FreezerLog.Write("Benchmark history exceeded its safety limit", null); return records; }
                foreach (string line in File.ReadAllLines(_path, Encoding.UTF8))
                {
                    try
                    {
                        if (line.Length > 4096) continue;
                        string[] f = line.Split('\t'); if (f.Length != 17) continue;
                        BenchmarkRecord r = new BenchmarkRecord();
                        r.Utc = DateTime.Parse(f[0], CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind);
                        r.Game = Decode(f[1]); r.Profile = Decode(f[2]); r.DurationSeconds = Int32.Parse(f[3], CultureInfo.InvariantCulture); r.Frames = Int64.Parse(f[4], CultureInfo.InvariantCulture);
                        r.AverageFps = ReadNumber(f[5]); r.MinimumFps = ReadNumber(f[6]); r.OnePercentLow = ReadNumber(f[7]); r.PointOnePercentLow = ReadNumber(f[8]);
                        r.AverageFrameTimeMs = ReadNumber(f[9]); r.P95FrameTimeMs = ReadNumber(f[10]);
                        r.CpuAverage = ReadNumber(f[11]); r.CpuPeak = ReadNumber(f[12]); r.GpuAverage = ReadNumber(f[13]); r.GpuPeak = ReadNumber(f[14]); r.RamAverage = ReadNumber(f[15]); r.RamPeak = ReadNumber(f[16]);
                        records.Add(r);
                    }
                    catch { }
                }
            }
            catch (Exception ex) { FreezerLog.Write("Could not read benchmark history", ex); }
            return records.OrderBy(x => x.Utc).TakeLastCompat(MaxRecords).ToList();
        }
        public void Save(IEnumerable<BenchmarkRecord> input)
        {
            List<BenchmarkRecord> records = input.OrderBy(x => x.Utc).TakeLastCompat(MaxRecords).ToList();
            List<string> lines = new List<string>();
            foreach (BenchmarkRecord r in records)
                lines.Add(String.Join("\t", new[] { r.Utc.ToUniversalTime().ToString("o", CultureInfo.InvariantCulture), Encode(r.Game), Encode(r.Profile),
                    r.DurationSeconds.ToString(CultureInfo.InvariantCulture), r.Frames.ToString(CultureInfo.InvariantCulture), Number(r.AverageFps), Number(r.MinimumFps), Number(r.OnePercentLow), Number(r.PointOnePercentLow),
                    Number(r.AverageFrameTimeMs), Number(r.P95FrameTimeMs), Number(r.CpuAverage), Number(r.CpuPeak), Number(r.GpuAverage), Number(r.GpuPeak), Number(r.RamAverage), Number(r.RamPeak) }));
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(_path));
                string temp = _path + ".tmp"; File.WriteAllLines(temp, lines.ToArray(), new UTF8Encoding(false));
                if (File.Exists(_path)) File.Replace(temp, _path, null); else File.Move(temp, _path);
            }
            catch (Exception ex) { FreezerLog.Write("Could not save benchmark history", ex); throw; }
        }
        private static string Encode(string value) { return Convert.ToBase64String(Encoding.UTF8.GetBytes(value ?? String.Empty)); }
        private static string Decode(string value) { return Encoding.UTF8.GetString(Convert.FromBase64String(value)); }
        private static string Number(double value) { return value.ToString("R", CultureInfo.InvariantCulture); }
        private static double ReadNumber(string value) { return Double.Parse(value, NumberStyles.Float, CultureInfo.InvariantCulture); }
    }

    internal static class EnumerableCompatibility
    {
        public static IEnumerable<T> TakeLastCompat<T>(this IEnumerable<T> source, int count)
        {
            Queue<T> queue = new Queue<T>();
            foreach (T item in source) { queue.Enqueue(item); while (queue.Count > count) queue.Dequeue(); }
            return queue;
        }
    }

    internal sealed class PresentMonCapture : IDisposable
    {
        private readonly object _gate = new object();
        private Process _process;
        private int _msIndex = -1;
        private readonly Queue<double> _recent = new Queue<double>();
        private readonly Queue<double> _frameTimes = new Queue<double>();
        private double _recentMs, _totalMs;
        private long _frames;
        private double _current = -1, _minimum = -1, _average = -1;
        private DateTime _lastFrame = DateTime.MinValue;
        public bool Running { get { lock (_gate) { try { return _process != null && !_process.HasExited; } catch { return false; } } } }
        public int ProcessId { get { lock (_gate) { try { return _process != null && !_process.HasExited ? _process.Id : -1; } catch { return -1; } } } }

        public bool Start(string exe, int pid)
        {
            Stop();
            if (!File.Exists(exe) || pid <= 0) return false;
            Process p = new Process();
            p.StartInfo = new ProcessStartInfo(exe, "--process_id " + pid + " --output_stdout --no_console_stats --v1_metrics");
            p.StartInfo.UseShellExecute = false; p.StartInfo.CreateNoWindow = true; p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            p.StartInfo.RedirectStandardOutput = true; p.StartInfo.RedirectStandardError = true;
            p.EnableRaisingEvents = true;
            p.OutputDataReceived += OnOutput;
            p.ErrorDataReceived += delegate { };
            lock (_gate)
            {
                _msIndex = -1; _recent.Clear(); _frameTimes.Clear(); _recentMs = 0; _totalMs = 0; _frames = 0;
                _current = -1; _minimum = -1; _average = -1; _lastFrame = DateTime.MinValue; _process = p;
            }
            try { p.Start(); p.BeginOutputReadLine(); p.BeginErrorReadLine(); return true; }
            catch { lock (_gate) { if (Object.ReferenceEquals(_process, p)) _process = null; } try { p.Dispose(); } catch { } return false; }
        }

        private void OnOutput(object sender, DataReceivedEventArgs e)
        {
            if (String.IsNullOrWhiteSpace(e.Data)) return;
            lock (_gate)
            {
                if (!Object.ReferenceEquals(sender is Process ? sender : null, _process)) return;
                string[] cells = Csv(e.Data);
                if (_msIndex < 0)
                {
                    for (int i = 0; i < cells.Length; i++) if (String.Equals(cells[i].Trim(), "MsBetweenPresents", StringComparison.OrdinalIgnoreCase)) { _msIndex = i; break; }
                    return;
                }
                if (_msIndex >= cells.Length) return;
                double ms;
                if (!Double.TryParse(cells[_msIndex], NumberStyles.Float, CultureInfo.InvariantCulture, out ms) || ms <= 0 || ms > 10000) return;
                _recent.Enqueue(ms); _recentMs += ms; _totalMs += ms; _frames++; _lastFrame = DateTime.UtcNow;
                _frameTimes.Enqueue(ms);
                while (_frameTimes.Count > 180000) _frameTimes.Dequeue();
                while (_recent.Count > 1 && _recentMs - _recent.Peek() >= 1000) _recentMs -= _recent.Dequeue();
                if (_recentMs >= 850)
                {
                    _current = 1000.0 * _recent.Count / _recentMs;
                    if (_minimum < 0 || _current < _minimum) _minimum = _current;
                }
                _average = _totalMs > 0 ? 1000.0 * _frames / _totalMs : -1;
            }
        }

        private static string[] Csv(string line)
        {
            List<string> values = new List<string>(); StringBuilder value = new StringBuilder(); bool quoted = false;
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '"')
                {
                    if (quoted && i + 1 < line.Length && line[i + 1] == '"') { value.Append('"'); i++; }
                    else quoted = !quoted;
                }
                else if (c == ',' && !quoted) { values.Add(value.ToString()); value.Length = 0; }
                else value.Append(c);
            }
            values.Add(value.ToString()); return values.ToArray();
        }

        public FrameStats Get()
        {
            lock (_gate)
            {
                if (DateTime.UtcNow - _lastFrame > TimeSpan.FromSeconds(3)) return new FrameStats();
                return new FrameStats { Current = _current, Minimum = _minimum, Average = _average, FrameCount = _frames };
            }
        }

        public FrameStats GetBenchmarkStats()
        {
            lock (_gate)
            {
                double[] frames = _frameTimes.ToArray();
                if (frames.Length == 0) return new FrameStats();
                Array.Sort(frames);
                double sum = 0;
                for (int i = 0; i < frames.Length; i++) sum += frames[i];
                int slowOne = Math.Max(1, (int)Math.Ceiling(frames.Length * 0.01));
                int slowPointOne = Math.Max(1, (int)Math.Ceiling(frames.Length * 0.001));
                double slowOneSum = 0, slowPointOneSum = 0;
                for (int i = frames.Length - slowOne; i < frames.Length; i++) slowOneSum += frames[i];
                for (int i = frames.Length - slowPointOne; i < frames.Length; i++) slowPointOneSum += frames[i];
                int p95Index = Math.Min(frames.Length - 1, Math.Max(0, (int)Math.Ceiling(frames.Length * 0.95) - 1));
                return new FrameStats
                {
                    FrameCount = frames.Length,
                    AverageFrameTimeMs = sum / frames.Length,
                    P95FrameTimeMs = frames[p95Index],
                    OnePercentLow = frames.Length >= 1000 && slowOneSum > 0 ? 1000.0 * slowOne / slowOneSum : -1,
                    PointOnePercentLow = frames.Length >= 10000 && slowPointOneSum > 0 ? 1000.0 * slowPointOne / slowPointOneSum : -1,
                    Current = _current,
                    Minimum = _minimum,
                    Average = _average
                };
            }
        }

        public void Stop()
        {
            Process p;
            lock (_gate) { p = _process; _process = null; _msIndex = -1; _recent.Clear(); _frameTimes.Clear(); _recentMs = 0; _totalMs = 0; _frames = 0; _current = -1; _minimum = -1; _average = -1; _lastFrame = DateTime.MinValue; }
            if (p != null)
            {
                try { if (!p.HasExited) { p.Kill(); p.WaitForExit(800); } } catch { }
                try { p.Dispose(); } catch { }
            }
        }
        public void Dispose() { Stop(); }
    }

    internal sealed class RegistryEdit
    {
        public string Path;
        public string Name;
        public int NewValue;
        public bool Exists;
        public int OldKind;
        public string OldValue;
    }

    internal sealed class TweakStore
    {
        private readonly string _root;
        private readonly string _backupDir;
        public TweakStore(string root) { _root = root; _backupDir = Path.Combine(root, "snapshots"); Directory.CreateDirectory(_backupDir); }
        public bool IsActive(string key)
        {
            return key == "cpu_policy" ? File.Exists(Path.Combine(_root, "cpu-policy.txt")) : File.Exists(SnapshotPath(key));
        }
        private string SnapshotPath(string key) { return Path.Combine(_backupDir, key + ".xml"); }

        public void Apply(string key, IList<RegistryEdit> edits)
        {
            string file = SnapshotPath(key);
            if (File.Exists(file)) throw new InvalidOperationException("This change is already active. Restore it first.");
            XDocument doc = new XDocument(new XElement("Snapshot", new XAttribute("key", key)));
            foreach (RegistryEdit edit in edits)
            {
                RegistryKey reg = null;
                try
                {
                    reg = Registry.CurrentUser.OpenSubKey(edit.Path, false);
                    object existing = reg == null ? null : reg.GetValue(edit.Name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
                    edit.Exists = existing != null;
                    if (edit.Exists)
                    {
                        edit.OldKind = (int)reg.GetValueKind(edit.Name);
                        if (existing is byte[]) edit.OldValue = Convert.ToBase64String((byte[])existing);
                        else if (existing is string[]) edit.OldValue = String.Join("\u001f", (string[])existing);
                        else edit.OldValue = Convert.ToString(existing, CultureInfo.InvariantCulture);
                    }
                }
                finally { if (reg != null) reg.Dispose(); }
                doc.Root.Add(new XElement("Entry", new XAttribute("path", edit.Path), new XAttribute("name", edit.Name),
                    new XAttribute("exists", edit.Exists), new XAttribute("oldKind", edit.OldKind),
                    new XAttribute("old", edit.OldValue ?? ""), new XAttribute("new", edit.NewValue)));
            }
            Directory.CreateDirectory(_backupDir);
            doc.Save(file); // durable snapshot precedes every registry write
            try
            {
                foreach (RegistryEdit edit in edits)
                {
                    using (RegistryKey keyHandle = Registry.CurrentUser.CreateSubKey(edit.Path))
                        keyHandle.SetValue(edit.Name, edit.NewValue, RegistryValueKind.DWord);
                    using (RegistryKey verify = Registry.CurrentUser.OpenSubKey(edit.Path, false))
                        if (verify == null || Convert.ToInt32(verify.GetValue(edit.Name, -1), CultureInfo.InvariantCulture) != edit.NewValue)
                            throw new IOException("Windows did not confirm the registry value " + edit.Name + ".");
                }
            }
            catch { try { Restore(key); } catch { } throw; }
        }

        public string Restore(string key)
        {
            string file = SnapshotPath(key);
            if (!File.Exists(file)) return Localizer.T("restore.inactive");
            XDocument doc = XDocument.Load(file);
            int restoredCount = 0, keptCount = 0;
            foreach (XElement entry in doc.Root.Elements("Entry"))
            {
                string path = (string)entry.Attribute("path"); string name = (string)entry.Attribute("name");
                bool existed = (bool)entry.Attribute("exists"); int oldKind = (int)entry.Attribute("oldKind"); string oldValue = (string)entry.Attribute("old");
                int newValue = (int)entry.Attribute("new");
                object current = null;
                using (RegistryKey read = Registry.CurrentUser.OpenSubKey(path, false))
                    if (read != null) current = read.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
                bool stillOurs = false;
                try { stillOurs = current != null && Convert.ToInt32(current, CultureInfo.InvariantCulture) == newValue; } catch { }
                if (!stillOurs)
                { keptCount++; continue; }
                using (RegistryKey handle = Registry.CurrentUser.CreateSubKey(path))
                {
                    if (existed)
                    {
                        RegistryValueKind kind = (RegistryValueKind)oldKind; object value;
                        if (kind == RegistryValueKind.DWord) value = Int32.Parse(oldValue, CultureInfo.InvariantCulture);
                        else if (kind == RegistryValueKind.QWord) value = Int64.Parse(oldValue, CultureInfo.InvariantCulture);
                        else if (kind == RegistryValueKind.Binary) value = Convert.FromBase64String(oldValue);
                        else if (kind == RegistryValueKind.MultiString) value = oldValue.Length == 0 ? new string[0] : oldValue.Split(new[] { '\u001f' });
                        else value = oldValue;
                        handle.SetValue(name, value, kind);
                    }
                    else try { handle.DeleteValue(name, false); } catch { }
                }
                restoredCount++;
            }
            File.Delete(file);
            return String.Format(CultureInfo.CurrentCulture, Localizer.T("restore.registry"), restoredCount, keptCount);
        }

        public IList<string> ActiveKeys()
        {
            List<string> result = new List<string>();
            try { foreach (string p in Directory.GetFiles(_backupDir, "*.xml")) result.Add(Path.GetFileNameWithoutExtension(p)); } catch { }
            return result;
        }
    }

    internal sealed class Optimization
    {
        public string Key, Title, Description, Group;
        public string Kind; // toggle, action, info, cleaner, network, cpu
        public IList<RegistryEdit> Edits;
        public string Action;
        public Optimization(string key, string title, string description, string group, string kind)
        { Key = key; Title = title; Description = description; Group = group; Kind = kind; }
        public Optimization WithEdits(IList<RegistryEdit> edits) { Edits = edits; return this; }
    }

    internal sealed class ProcessChoice
    {
        public int Pid; public string Name; public string DisplayName;
        public override string ToString() { return (DisplayName ?? Name) + "  ·  PID " + Pid; }
    }

    internal sealed class ColorProfileSection
    {
        public bool IsNvidia, HardwarePresent, ApiReady;
        public string Vendor;
        public IList<ColorDisplayInfo> Devices = new List<ColorDisplayInfo>();
        public RoundPanel Card;
        public RoundPanel Editor;
        public Label Status, ValueLabel, SavedProfilesLabel, BrightnessValue, ContrastValue, HueValue, DriverHelp, SaturationLabel;
        public Label BrightnessLabel, ContrastLabel, HueLabel;
        public ComboBox DevicePicker, ProfilePicker, GamePicker, GameProfilePicker;
        public ModernSlider Saturation, Brightness, Contrast, Hue;
        public FlowLayoutPanel SavedProfileChips;
        public TextBox ProfileName;
        public Button SaveButton, ApplyButton, ResetButton, AssignButton, DriverPanelButton;
    }

    internal sealed class FreezerForm : Form
    {
        private const string AppVersion = "2.43.0";
        private const string GitHubReleasesUrl = "https://github.com/wannabe494639-beep/Zayno/releases";
        private const string GitHubLatestReleaseApi = "https://api.github.com/repos/wannabe494639-beep/Zayno/releases/latest";
        private readonly string _stateRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Freezer");
        private readonly string _settingsFile;
        private readonly Preferences _prefs;
        private readonly TweakStore _tweaks;
        private readonly HardwareSampler _sampler = new HardwareSampler();
        private readonly PresentMonCapture _fps = new PresentMonCapture();
        private BenchmarkHistory _benchmarkHistory;
        private List<BenchmarkRecord> _benchmarkRecords = new List<BenchmarkRecord>();
        private readonly List<Reading> _benchmarkSamples = new List<Reading>();
        private ComboBox _benchmarkGamePicker, _benchmarkProfilePicker, _benchmarkDurationPicker, _benchmarkBaselinePicker, _benchmarkComparePicker;
        private Label _benchmarkStatusLabel, _benchmarkResultsLabel, _benchmarkDiagnosisLabel;
        private Label _performanceHardwareLabel, _performanceActivityLabel;
        private Button _benchmarkStartButton, _benchmarkStopButton;
        private volatile bool _benchmarkRunning;
        private int _benchmarkDurationSeconds;
        private DateTime _benchmarkStartedUtc;
        private readonly System.Windows.Forms.Timer _sidebarTimer = new System.Windows.Forms.Timer();
        private readonly System.Windows.Forms.Timer _sampleTimer = new System.Windows.Forms.Timer();
        private readonly System.Windows.Forms.Timer _fpsUiTimer = new System.Windows.Forms.Timer();
        private readonly System.Windows.Forms.Timer _gamingBoostTimer = new System.Windows.Forms.Timer();
        private readonly System.Windows.Forms.Timer _colorProfileTimer = new System.Windows.Forms.Timer();
        private readonly System.Windows.Forms.Timer _displayRefreshTimer = new System.Windows.Forms.Timer();
        private System.Windows.Forms.Timer _welcomeTimer;
        private readonly object _gamingBoostLock = new object();
        private readonly object _presentMonExtractLock = new object();
        private readonly object _colorProfileLock = new object();
        private readonly object _gameStretchSessionLock = new object();
        private readonly Dictionary<int, Tuple<long, ProcessPriorityClass>> _boostedGamePriorities = new Dictionary<int, Tuple<long, ProcessPriorityClass>>();
        private readonly Dictionary<int, ProcessPriorityClass> _appliedGamePriorities = new Dictionary<int, ProcessPriorityClass>();
        private readonly FlowLayoutPanel _content;
        private readonly TableLayoutPanel _body;
        private readonly Panel _sidebar;
        private readonly Panel _header;
        private readonly Panel _footer;
        private readonly Label _status;
        private readonly Dictionary<string, GaugeControl> _gauges = new Dictionary<string, GaugeControl>();
        private readonly Dictionary<string, Label> _valueLabels = new Dictionary<string, Label>();
        private readonly Dictionary<string, SidebarNavigationButton> _navButtons = new Dictionary<string, SidebarNavigationButton>();
        private IList<Optimization> _optimizations;
        private string _page = "home";
        private int _sidebarWidth = 70, _sidebarTarget = 70;
        private bool _sidebarPinned, _sampleBusy;
        private bool _hardwareSampleErrorLogged;
        private bool _potatoGpuChecked, _potatoNvidiaAvailable;
        private volatile bool _closing;
        private volatile bool _startupRestoreComplete;
        private volatile bool _presentMonReady;
        private int _startupRestoreQueued, _presentMonExtractionQueued;
        private bool _timerResolutionHeld, _localUpdateCheckQueued;
        private int _gameBoostScanBusy, _gameBoostScanPending;
        private bool _gamingPowerPlanApplied;
        private int _colorProfileScanBusy;
        private int _colorHardwareRefreshBusy;
        private ColorProfileSection _nvidiaColorSection, _amdColorSection;
        private readonly Dictionary<string, string> _activeColorGames = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, string> _activeColorProfiles = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        private ComboBox _processPicker;
        private OverlayForm _overlay;
        private Reading _latest = new Reading();
        private readonly string _presentMonPath;
        private Label _hardwareStatus;
        private Button _gamingModeButton;
        private Button _streamerModeButton;
        private Button _maximizeButton;
        private Label _headerFpsLabel;
        private Label _homeBoardName, _homeStorageName;
        private string _cpuModelName = "", _gpuModelName = "", _boardModelName = "", _storageModelName = "";
        private string _ramTypeName = "";
        private bool _streamerModeActive, _streamerEnabledGameMode;
        private string _gameStretchSessionGameKey = "", _gameStretchSessionDevice = "", _gameStretchSessionOriginal = "";
        private DateTime _gameStretchSessionStartedUtc;
        private bool _gameStretchSessionSawGame;
        private int _gameStretchMonitorBusy;
        private string MouseAccelerationBackupPath { get { return Path.Combine(_stateRoot, "mouse-acceleration.txt"); } }
        private string DisplayTimeoutBackupPath { get { return Path.Combine(_stateRoot, "display-timeout.backup"); } }
        private string GameStretchSessionBackupPath { get { return Path.Combine(_stateRoot, "game-stretch-session.txt"); } }
        private int _hardwareIdentityQueued;
        private ComboBox _sessionGamePicker, _sessionProfilePicker;
        private ComboBox _sessionColorProfilePicker, _sessionStretchDisplayPicker, _sessionStretchResolutionPicker;
        private bool _loadingCombinedProfile;
        private volatile bool _fpsAutoCapture = true;
        private int _fpsPinnedProcessId = -1;
        private WebClient _updateClient;
        private NotifyIcon _trayIcon;
        private ToolStripMenuItem _trayOpenItem, _trayExitItem;
        private bool _exitRequested;
        private bool _networkQosBusy;
        private LocalUpdateCandidate _localUpdateCandidate;
        private string _remoteUpdateTag = "";
        private Version _remoteUpdateVersion;
        private bool _remoteUpdateCheckQueued;
        private static readonly string[] GameProcessNames = { "FortniteClient-Win64-Shipping", "javaw", "Minecraft.Windows", "VALORANT-Win64-Shipping", "GTA5", "Cyberpunk2077", "RocketLeague", "Overwatch", "RainbowSix", "r5apex", "helldivers2", "FarmingSimulator2022Game", "FarmingSimulator2025Game", "cs2", "League of Legends", "TslGame", "cod", "dota2", "RobloxPlayerBeta", "FC26" };
        private int _gamePage;
        private Panel _gameNavigation;
        private Button _gamePrevious, _gameNext;
        private Label _gamePageLabel;
        private Panel _gameViewport;
        private FlowLayoutPanel _gameTiles;
        private FlowLayoutPanel _gameIncomingTiles;
        private string[] _gameKeys;
        private int _gamePageTarget, _gameSlideDirection;
        private double _gameSlideProgress;
        private readonly System.Windows.Forms.Timer _gameSlideTimer = new System.Windows.Forms.Timer();
        private CrosshairForm _crosshair;

        private sealed class LocalUpdateCandidate
        {
            public string Path;
            public string SourcePath;
            public Version Version;
        }

        public FreezerForm()
        {
            Directory.CreateDirectory(_stateRoot);
            _settingsFile = Path.Combine(_stateRoot, "settings.ini");
            _benchmarkHistory = new BenchmarkHistory(Path.Combine(_stateRoot, "benchmark-history.tsv"));
            _benchmarkRecords = _benchmarkHistory.Load();
            _prefs = Preferences.Load(_settingsFile);
            if (!String.IsNullOrWhiteSpace(_prefs.ActiveNvidiaColorGame)) _activeColorGames["nvidia"] = _prefs.ActiveNvidiaColorGame;
            if (!String.IsNullOrWhiteSpace(_prefs.ActiveAmdColorGame)) _activeColorGames["amd"] = _prefs.ActiveAmdColorGame;
            if (!String.IsNullOrWhiteSpace(_prefs.ActiveNvidiaColorProfile)) _activeColorProfiles["nvidia"] = _prefs.ActiveNvidiaColorProfile;
            if (!String.IsNullOrWhiteSpace(_prefs.ActiveAmdColorProfile)) _activeColorProfiles["amd"] = _prefs.ActiveAmdColorProfile;
            if (_prefs.CrosshairEnabled) { _prefs.CrosshairEnabled = false; _prefs.Save(_settingsFile); }
            Localizer.Current = _prefs.Language;
            Palette.Select(_prefs.Accent);
            _tweaks = new TweakStore(_stateRoot);
            _optimizations = BuildOptimizations();
            _presentMonPath = Path.Combine(_stateRoot, "PresentMon.exe");
            Text = "Freezer " + AppVersion; Icon = LoadIcon(); ShowInTaskbar = true;
            StartPosition = FormStartPosition.CenterScreen; FormBorderStyle = FormBorderStyle.None;
            MinimumSize = new Size(960, 640); Size = new Size(1180, 780); BackColor = Palette.Background;
            Font = UiFontCache.Get("Segoe UI", 9F, FontStyle.Regular); DoubleBuffered = true;
            _sidebarTimer.Interval = 10; _sidebarTimer.Tick += AnimateSidebar;
            _sampleTimer.Interval = 1000; _sampleTimer.Tick += SampleTick;
            _fpsUiTimer.Interval = 250; _fpsUiTimer.Tick += UpdateFpsTick;
            _gamingBoostTimer.Interval = 2000; _gamingBoostTimer.Tick += delegate { QueueGamingSessionBoost(); QueueGameStretchSessionMonitor(); };
            _colorProfileTimer.Interval = 2000; _colorProfileTimer.Tick += delegate { QueueColorProfileMonitor(); };
            _displayRefreshTimer.Interval = 220; _displayRefreshTimer.Tick += delegate { _displayRefreshTimer.Stop(); RecenterActiveCrosshair(); };
            _gameSlideTimer.Interval = 16; _gameSlideTimer.Tick += AnimateGameSlide;
            SystemEvents.DisplaySettingsChanged += HandleDisplaySettingsChanged;

            TableLayoutPanel root = new TableLayoutPanel(); root.Dock = DockStyle.Fill; root.Margin = Padding.Empty; root.Padding = Padding.Empty; root.BackColor = Palette.Background;
            root.ColumnCount = 1; root.RowCount = 3; root.RowStyles.Add(new RowStyle(SizeType.Absolute, 64));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); root.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
            _header = BuildHeader(); root.Controls.Add(_header, 0, 0);
            _body = new TableLayoutPanel(); _body.Dock = DockStyle.Fill; _body.Margin = Padding.Empty; _body.Padding = Padding.Empty;
            _body.ColumnCount = 2; _body.RowCount = 1; _body.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, _sidebarWidth));
            _body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            _sidebar = BuildSidebar(); _body.Controls.Add(_sidebar, 0, 0);
            _content = new FlowLayoutPanel(); _content.Dock = DockStyle.Fill; _content.AutoScroll = true; _content.HorizontalScroll.Enabled = false; _content.HorizontalScroll.Visible = false; _content.WrapContents = false;
            _content.FlowDirection = FlowDirection.TopDown; _content.BackColor = Palette.Background; _content.Padding = new Padding(22, 18, 20, 24);
            _content.SizeChanged += delegate { ResizeContentCards(); };
            _body.Controls.Add(_content, 1, 0); root.Controls.Add(_body, 0, 1);
            _footer = new Panel(); _footer.Dock = DockStyle.Fill; _footer.BackColor = Palette.Sidebar;
            _status = MakeLabel(Localizer.T("status.ready"), 9, Palette.Muted, false); _status.Dock = DockStyle.Fill; _status.TextAlign = ContentAlignment.MiddleLeft; _status.Padding = new Padding(18, 0, 0, 0);
            _footer.Controls.Add(_status); root.Controls.Add(_footer, 0, 2); Controls.Add(root);
            ShowPage("home"); UpdateSampleTimer(); CreateTrayIcon();
            FormClosing += OnClosing;
            VisibleChanged += delegate { UpdateSampleTimer(); };
            Resize += delegate { UpdateSampleTimer(); };
            Shown += delegate
            {
                UpdateSampleTimer();
                RestoreStaleGameStretchSession();
                QueueStartupRestore();
                QueuePresentMonExtraction();
                if (_prefs.AutoUpdateCheck) { QueueLocalUpdateCheck(); QueueRemoteUpdateCheck(); }
                QueueHardwareIdentityRead();
                _colorProfileTimer.Start();
                if (!_prefs.IntroTutorialCompleted || !_prefs.RestorePointNoticeShown)
                {
                    _prefs.RestorePointNoticeShown = true; _prefs.IntroTutorialCompleted = true; SavePreferences();
                    _welcomeTimer = new System.Windows.Forms.Timer(); _welcomeTimer.Interval = 650;
                    _welcomeTimer.Tick += delegate
                    {
                        System.Windows.Forms.Timer timer = _welcomeTimer; _welcomeTimer = null;
                        if (timer != null) { timer.Stop(); timer.Dispose(); }
                        if (!_closing) ShowWelcomeDialog();
                    };
                    _welcomeTimer.Start();
                }
            };
            Resize += delegate { if (root != null && !root.IsDisposed) root.Padding = Padding.Empty; UpdateMaximizeButtonState(); };
        }

        private void CreateTrayIcon()
        {
            try
            {
                _trayIcon = new NotifyIcon(); _trayIcon.Icon = LoadIcon(); _trayIcon.Text = Localizer.T("tray.tooltip");
                ContextMenuStrip menu = new ContextMenuStrip();
                _trayOpenItem = new ToolStripMenuItem(Localizer.T("tray.open"));
                _trayExitItem = new ToolStripMenuItem(Localizer.T("tray.exit"));
                _trayOpenItem.Click += delegate { RestoreFromTray(); };
                _trayExitItem.Click += delegate { _exitRequested = true; if (_trayIcon != null) _trayIcon.Visible = false; Close(); };
                menu.Items.Add(_trayOpenItem); menu.Items.Add(new ToolStripSeparator()); menu.Items.Add(_trayExitItem);
                _trayIcon.ContextMenuStrip = menu;
                _trayIcon.MouseDoubleClick += delegate(object sender, MouseEventArgs e) { if (e.Button == MouseButtons.Left) RestoreFromTray(); };
                _trayIcon.DoubleClick += delegate { RestoreFromTray(); };
                _trayIcon.Visible = _prefs.MinimizeToTray;
            }
            catch { if (_trayIcon != null) { try { _trayIcon.Visible = false; _trayIcon.Dispose(); } catch { } _trayIcon = null; } }
        }

        private void RefreshTrayMenuText()
        {
            if (_trayOpenItem != null) _trayOpenItem.Text = Localizer.T("tray.open");
            if (_trayExitItem != null) _trayExitItem.Text = Localizer.T("tray.exit");
            if (_trayIcon != null) _trayIcon.Text = Localizer.T("tray.tooltip");
        }

        private void RestoreFromTray()
        {
            if (IsDisposed) return;
            try
            {
                if (InvokeRequired) { BeginInvoke((MethodInvoker)RestoreFromTray); return; }
                ShowInTaskbar = true;
                if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
                if (!Visible) Show();
                Activate(); BringToFront();
                if (_trayIcon != null) _trayIcon.Visible = _prefs.MinimizeToTray;
            }
            catch { }
        }

        [DllImport("dwmapi.dll", EntryPoint = "DwmSetWindowAttribute")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int valueSize);

        [StructLayout(LayoutKind.Sequential)]
        private struct NativePoint { public int X, Y; }
        [StructLayout(LayoutKind.Sequential)]
        private struct NativeRect { public int Left, Top, Right, Bottom; }
        [StructLayout(LayoutKind.Sequential)]
        private struct NativeMinMaxInfo
        {
            public NativePoint Reserved, MaxSize, MaxPosition, MinTrackSize, MaxTrackSize;
        }
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct NativeMonitorInfo
        {
            public int Size;
            public NativeRect Monitor, Work;
            public int Flags;
        }

        [DllImport("user32.dll")]
        private static extern IntPtr MonitorFromWindow(IntPtr hwnd, uint flags);
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern bool GetMonitorInfo(IntPtr monitor, ref NativeMonitorInfo info);

        private void ApplyMonitorWorkArea(IntPtr lParam)
        {
            try
            {
                IntPtr monitor = MonitorFromWindow(Handle, 2); // nearest monitor, including during a cross-monitor move
                if (monitor == IntPtr.Zero) return;
                NativeMonitorInfo info = new NativeMonitorInfo(); info.Size = Marshal.SizeOf(typeof(NativeMonitorInfo));
                if (!GetMonitorInfo(monitor, ref info)) return;
                NativeMinMaxInfo limits = (NativeMinMaxInfo)Marshal.PtrToStructure(lParam, typeof(NativeMinMaxInfo));
                limits.MaxPosition = new NativePoint { X = info.Work.Left - info.Monitor.Left, Y = info.Work.Top - info.Monitor.Top };
                limits.MaxSize = new NativePoint { X = info.Work.Right - info.Work.Left, Y = info.Work.Bottom - info.Work.Top };
                Marshal.StructureToPtr(limits, lParam, false);
            }
            catch { }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try { int roundedCorners = 2; DwmSetWindowAttribute(Handle, 33, ref roundedCorners, sizeof(int)); } catch { }
            // Blend the native resizable frame into the dark custom chrome while retaining
            // the standard frame styles used for resizing and Windows Snap Layouts.
            try { int borderColor = ColorTranslator.ToWin32(Palette.Background); DwmSetWindowAttribute(Handle, 34, ref borderColor, sizeof(int)); } catch { }
            try { int captionColor = ColorTranslator.ToWin32(Palette.Sidebar); DwmSetWindowAttribute(Handle, 35, ref captionColor, sizeof(int)); } catch { }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                // Keep the custom chrome but expose standard resize/maximize styles so Windows can
                // provide native edge resizing and Snap assist when the header is dragged.
                cp.Style |= 0x00040000 | 0x00020000 | 0x00010000 | 0x00080000; // THICKFRAME, MIN/MAXBOX, SYSMENU
                return cp;
            }
        }

        protected override void WndProc(ref Message m)
        {
            const int WmNcHitTest = 0x0084;
            const int WmDisplayChange = 0x007E;
            const int WmDpiChanged = 0x02E0;
            const int WmGetMinMaxInfo = 0x0024;
            const int HtClient = 1, HtLeft = 10, HtRight = 11, HtTop = 12, HtTopLeft = 13, HtTopRight = 14, HtBottom = 15, HtBottomLeft = 16, HtBottomRight = 17;
            if (m.Msg == WmGetMinMaxInfo)
            {
                base.WndProc(ref m);
                ApplyMonitorWorkArea(m.LParam);
                return;
            }
            base.WndProc(ref m);
            if (m.Msg == WmDisplayChange || m.Msg == WmDpiChanged)
            {
                ScheduleCrosshairRecenter();
                return;
            }
            if (m.Msg != WmNcHitTest || WindowState == FormWindowState.Maximized || m.Result.ToInt32() != HtClient) return;
            long packed = m.LParam.ToInt64();
            int screenX = unchecked((short)(packed & 0xffff));
            int screenY = unchecked((short)((packed >> 16) & 0xffff));
            Point point = PointToClient(new Point(screenX, screenY));
            const int grip = 7;
            bool left = point.X < grip, right = point.X >= ClientSize.Width - grip;
            bool top = point.Y < grip, bottom = point.Y >= ClientSize.Height - grip;
            if (top && left) m.Result = (IntPtr)HtTopLeft;
            else if (top && right) m.Result = (IntPtr)HtTopRight;
            else if (bottom && left) m.Result = (IntPtr)HtBottomLeft;
            else if (bottom && right) m.Result = (IntPtr)HtBottomRight;
            else if (left) m.Result = (IntPtr)HtLeft;
            else if (right) m.Result = (IntPtr)HtRight;
            else if (top) m.Result = (IntPtr)HtTop;
            else if (bottom) m.Result = (IntPtr)HtBottom;
        }

        private static Icon LoadIcon()
        {
            try { using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("Freezer.ico")) return s == null ? SystemIcons.Application : new Icon(s); }
            catch { return SystemIcons.Application; }
        }

        private static Bitmap LoadLogoBitmap()
        {
            try
            {
                using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("FreezerLogo.png"))
                {
                    if (s == null) return SystemIcons.Application.ToBitmap();
                    using (Bitmap source = new Bitmap(s)) return new Bitmap(source);
                }
            }
            catch { return SystemIcons.Application.ToBitmap(); }
        }

        private static PictureBox CreateLogoPictureBox(Point location, Size size)
        {
            PictureBox logo = new PictureBox(); logo.Location = location; logo.Size = size; logo.SizeMode = PictureBoxSizeMode.Zoom;
            logo.BackColor = Color.Transparent; logo.Image = LoadLogoBitmap();
            logo.Disposed += delegate { Image image = logo.Image; logo.Image = null; if (image != null) image.Dispose(); };
            return logo;
        }

        private void QueueLocalUpdateCheck()
        {
            if (_localUpdateCheckQueued) return;
            _localUpdateCheckQueued = true;
            try
            {
                if (!ThreadPool.QueueUserWorkItem(delegate
                {
                    LocalUpdateCandidate candidate = null;
                    try { candidate = FindLocalUpdateCandidate(); } catch { return; }
                    if (candidate == null || IsDisposed || Disposing) return;
                    try
                    {
                        BeginInvoke((MethodInvoker)delegate
                        {
                            if (IsDisposed || Disposing) return;
                            _localUpdateCandidate = candidate;
                            if (_page == "home") ShowPage("home");
                        });
                    }
                    catch { }
                })) _localUpdateCheckQueued = false;
            }
            catch { _localUpdateCheckQueued = false; }
        }

        private void QueueRemoteUpdateCheck()
        {
            if (_remoteUpdateCheckQueued) return;
            _remoteUpdateCheckQueued = true;
            try
            {
                if (!ThreadPool.QueueUserWorkItem(delegate
                {
                    string tag = ""; Version remote = null, installed;
                    try
                    {
                        if (!Version.TryParse(AppVersion, out installed)) return;
                        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(GitHubLatestReleaseApi);
                        request.Method = "GET"; request.UserAgent = "Freezer-PC-Optimizer/" + AppVersion;
                        request.Accept = "application/vnd.github+json"; request.Timeout = 4500; request.ReadWriteTimeout = 4500;
                        using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                        using (Stream stream = response.GetResponseStream())
                        using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                        {
                            string json = reader.ReadToEnd();
                            Match tagMatch = Regex.Match(json, "\"tag_name\"\\s*:\\s*\"([^\"]+)\"");
                            if (!tagMatch.Success) return;
                            tag = tagMatch.Groups[1].Value;
                            string digits = Regex.Match(tag, "\\d+(?:\\.\\d+){1,3}").Value;
                            if (!Version.TryParse(digits, out remote)) return;
                        }
                        if (remote <= installed || IsDisposed || Disposing) return;
                        BeginInvoke((MethodInvoker)delegate
                        {
                            if (IsDisposed || Disposing) return;
                            _remoteUpdateTag = tag; _remoteUpdateVersion = remote;
                            if (_page == "home") ShowPage("home");
                            else if (_page == "updates") ShowPage("updates");
                        });
                    }
                    catch { /* An unavailable network must never affect app startup. */ }
                })) _remoteUpdateCheckQueued = false;
            }
            catch { _remoteUpdateCheckQueued = false; }
        }

        private LocalUpdateCandidate FindLocalUpdateCandidate()
        {
            Version installed;
            if (!Version.TryParse(AppVersion, out installed)) return null;
            LocalUpdateCandidate best = null;
            string current = String.Empty;
            try { current = Path.GetFullPath(Application.ExecutablePath); } catch { }
            string profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string downloads = Path.Combine(profile, "Downloads");
            string appFolder = AppDomain.CurrentDomain.BaseDirectory;
            HashSet<string> paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string folder in new[] { downloads, appFolder })
            {
                try
                {
                    if (!Directory.Exists(folder)) continue;
                    foreach (string path in Directory.GetFiles(folder, "Freezer*.exe", SearchOption.TopDirectoryOnly))
                    {
                        try
                        {
                            string full = Path.GetFullPath(path);
                            if (String.Equals(full, current, StringComparison.OrdinalIgnoreCase) || !paths.Add(full)) continue;
                            Version candidateVersion;
                            if (!TryGetFreezerVersion(full, out candidateVersion) || candidateVersion <= installed) continue;
                            LocalUpdateCandidate candidate = new LocalUpdateCandidate { Path = full, SourcePath = full, Version = candidateVersion };
                            if (best == null || candidate.Version > best.Version) best = candidate;
                        }
                        catch { }
                    }
                    foreach (string archive in Directory.GetFiles(folder, "Freezer*.zip", SearchOption.TopDirectoryOnly))
                    {
                        try
                        {
                            string fullArchive = Path.GetFullPath(archive);
                            if (!paths.Add(fullArchive)) continue;
                            LocalUpdateCandidate candidate = ExtractUpdatePackage(fullArchive, installed);
                            if (candidate != null && (best == null || candidate.Version > best.Version)) best = candidate;
                        }
                        catch { }
                    }
                }
                catch { }
            }
            return best;
        }

        private static bool TryGetFreezerVersion(string path, out Version version)
        {
            version = null;
            try
            {
                Assembly candidate = Assembly.ReflectionOnlyLoadFrom(Path.GetFullPath(path));
                CustomAttributeData product = candidate.GetCustomAttributesData().FirstOrDefault(x => x.AttributeType.FullName == "System.Reflection.AssemblyProductAttribute");
                if (product == null || product.ConstructorArguments.Count == 0
                    || !String.Equals(Convert.ToString(product.ConstructorArguments[0].Value, CultureInfo.InvariantCulture), "Freezer", StringComparison.OrdinalIgnoreCase)) return false;
                Version raw = AssemblyName.GetAssemblyName(path).Version;
                if (raw == null || raw.Major < 0 || raw.Minor < 0 || raw.Build < 0) return false;
                version = new Version(raw.Major, raw.Minor, raw.Build);
                return true;
            }
            catch { return false; }
        }

        private LocalUpdateCandidate ExtractUpdatePackage(string archivePath, Version installed)
        {
            try
            {
                FileInfo archiveInfo = new FileInfo(archivePath);
                if (!archiveInfo.Exists || archiveInfo.Length < 1 || archiveInfo.Length > 250L * 1024L * 1024L) return null;
                string updateFolder = Path.Combine(_stateRoot, "updates"); Directory.CreateDirectory(updateFolder);
                LocalUpdateCandidate best = null;
                using (FileStream file = File.Open(archivePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (ZipArchive zip = new ZipArchive(file, ZipArchiveMode.Read, false))
                {
                    int index = 0;
                    foreach (ZipArchiveEntry entry in zip.Entries)
                    {
                        index++;
                        string name = Path.GetFileName(entry.FullName ?? String.Empty);
                        if (!Regex.IsMatch(name, "^Freezer(?:-[0-9]+(?:\\.[0-9]+){1,3})?\\.exe$", RegexOptions.IgnoreCase)) continue;
                        if (entry.Length < 256L * 1024L || entry.Length > 100L * 1024L * 1024L) continue;
                        string safeArchive = Regex.Replace(Path.GetFileNameWithoutExtension(archivePath), "[^A-Za-z0-9._-]", "_");
                        string destination = Path.Combine(updateFolder, safeArchive + "-" + index.ToString(CultureInfo.InvariantCulture) + ".exe");
                        string temporary = destination + ".tmp";
                        try
                        {
                            using (Stream input = entry.Open())
                            using (FileStream output = new FileStream(temporary, FileMode.Create, FileAccess.Write, FileShare.None))
                            {
                                byte[] buffer = new byte[81920]; long copied = 0; int read;
                                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                                {
                                    copied += read; if (copied > 100L * 1024L * 1024L) throw new InvalidDataException("Update archive entry is too large.");
                                    output.Write(buffer, 0, read);
                                }
                            }
                            if (File.Exists(destination)) File.Delete(destination);
                            File.Move(temporary, destination);
                            Version candidateVersion;
                            if (!TryGetFreezerVersion(destination, out candidateVersion) || candidateVersion <= installed)
                            { File.Delete(destination); continue; }
                            LocalUpdateCandidate candidate = new LocalUpdateCandidate { Path = destination, SourcePath = archivePath, Version = candidateVersion };
                            if (best == null || candidate.Version > best.Version) best = candidate;
                            else File.Delete(destination);
                        }
                        finally { try { if (File.Exists(temporary)) File.Delete(temporary); } catch { } }
                    }
                }
                return best;
            }
            catch { return null; }
        }

        [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod", SetLastError = true)]
        private static extern uint TimeBeginPeriod(uint period);
        [DllImport("winmm.dll", EntryPoint = "timeEndPeriod", SetLastError = true)]
        private static extern uint TimeEndPeriod(uint period);
        [DllImport("user32.dll", EntryPoint = "SystemParametersInfo", SetLastError = true)]
        private static extern bool SystemParametersInfoMouse(uint action, uint parameter, [In, Out] int[] values, uint flags);

        private string GamePriorityBackupPath { get { return Path.Combine(_stateRoot, "gaming-priorities.txt"); } }
        private string GamingPowerPlanBackupPath { get { return Path.Combine(_stateRoot, "gaming-power-plan.txt"); } }

        private static string PowerCfgPath
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "powercfg.exe"); }
        }

        private static string ReadActivePowerScheme(string powercfg)
        {
            string output = RunProcess(powercfg, "/getactivescheme", 5000);
            Match match = Regex.Match(output, "[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}", RegexOptions.IgnoreCase);
            if (!match.Success) throw new IOException("Could not read the active power scheme.");
            return match.Value.ToLowerInvariant();
        }

        private static string DuplicatePowerScheme(string powercfg, string templateGuid)
        {
            string output = RunProcess(powercfg, "/duplicatescheme " + templateGuid, 8000);
            Match match = Regex.Match(output, "[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}", RegexOptions.IgnoreCase);
            if (!match.Success) throw new IOException("Windows did not return the new power-scheme identifier.");
            return match.Value.ToLowerInvariant();
        }

        private void TryEnableGamingPowerPlanLocked()
        {
            if (_gamingPowerPlanApplied || File.Exists(GamingPowerPlanBackupPath)) return;
            string backup = GamingPowerPlanBackupPath, temporary = backup + ".tmp";
            string original = null, target = null;
            try
            {
                string powercfg = PowerCfgPath;
                original = ReadActivePowerScheme(powercfg);
                string[] templates = {
                    "e9a42b02-d5df-448d-aa00-03f14749eb61", // Ultimate Performance
                    "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"  // High performance fallback
                };
                foreach (string template in templates)
                {
                    try { target = DuplicatePowerScheme(powercfg, template); break; }
                    catch { }
                }
                if (String.IsNullOrEmpty(target)) return;

                // Persist recovery information before editing or activating our private clone.
                File.WriteAllText(temporary, original + "|" + target + "|1", Encoding.UTF8);
                if (File.Exists(backup)) File.Delete(backup);
                File.Move(temporary, backup);
                try
                {
                    // These values affect only the temporary clone and AC power. 100% minimum
                    // core parking disables parking; 100% minimum processor state requests
                    // maximum performance. Firmware and thermal limits still remain in control.
                    RunProcess(powercfg, "/setacvalueindex " + target + " SUB_PROCESSOR CPMINCORES 100", 8000);
                    RunProcess(powercfg, "/setacvalueindex " + target + " SUB_PROCESSOR PROCTHROTTLEMIN 100", 8000);
                    RunProcess(powercfg, "/setacvalueindex " + target + " SUB_PROCESSOR PROCTHROTTLEMAX 100", 8000);
                    RunProcess(powercfg, "/setactive " + target, 8000);
                    if (!String.Equals(ReadActivePowerScheme(powercfg), target, StringComparison.OrdinalIgnoreCase))
                        throw new IOException("Windows did not confirm the temporary gaming power scheme.");
                    _gamingPowerPlanApplied = true;
                }
                catch
                {
                    RestoreGamingPowerPlan();
                }
            }
            catch
            {
                // If persisting the snapshot failed, remove the unowned clone. If a
                // snapshot exists, use the normal recovery path instead.
                if (!String.IsNullOrEmpty(target))
                {
                    if (File.Exists(backup)) RestoreGamingPowerPlan();
                    else try { RunProcess(PowerCfgPath, "/delete " + target, 8000); } catch { }
                }
            }
            finally { try { if (File.Exists(temporary)) File.Delete(temporary); } catch { } }
        }

        private bool RestoreGamingPowerPlan()
        {
            string backup = GamingPowerPlanBackupPath;
            if (!File.Exists(backup)) { _gamingPowerPlanApplied = false; return true; }
            try
            {
                string[] parts = File.ReadAllText(backup, Encoding.UTF8).Trim().Split('|');
                // Two-field snapshots were created by Freezer 2.32.28 and refer to an
                // existing scheme that must never be deleted.
                if ((parts.Length != 2 && parts.Length != 3) ||
                    !Regex.IsMatch(parts[0], "^[0-9a-f-]{36}$", RegexOptions.IgnoreCase) ||
                    !Regex.IsMatch(parts[1], "^[0-9a-f-]{36}$", RegexOptions.IgnoreCase) ||
                    (parts.Length == 3 && parts[2] != "1")) return false;
                bool createdByFreezer = parts.Length == 3;
                string powercfg = PowerCfgPath;
                string active = ReadActivePowerScheme(powercfg);
                // If the user picked a different plan during play, keep that selection.
                if (String.Equals(active, parts[1], StringComparison.OrdinalIgnoreCase))
                {
                    RunProcess(powercfg, "/setactive " + parts[0], 8000);
                    if (!String.Equals(ReadActivePowerScheme(powercfg), parts[0], StringComparison.OrdinalIgnoreCase)) return false;
                }
                if (createdByFreezer)
                {
                    string schemes = RunProcess(powercfg, "/list", 5000).ToLowerInvariant();
                    if (schemes.Contains(parts[1])) RunProcess(powercfg, "/delete " + parts[1], 8000);
                }
                File.Delete(backup);
                _gamingPowerPlanApplied = false;
                return true;
            }
            catch { return false; }
        }

        private void QueueGamingSessionBoost()
        {
            if (_closing) return;
            if (Interlocked.CompareExchange(ref _gameBoostScanBusy, 1, 0) != 0)
            { Interlocked.Exchange(ref _gameBoostScanPending, 1); return; }
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    do
                    {
                        Interlocked.Exchange(ref _gameBoostScanPending, 0);
                        try { UpdateGamingSessionBoost(); } catch { }
                    }
                    while (!_closing && Interlocked.Exchange(ref _gameBoostScanPending, 0) != 0);
                }
                finally
                {
                    Interlocked.Exchange(ref _gameBoostScanBusy, 0);
                    if (!_closing && Interlocked.Exchange(ref _gameBoostScanPending, 0) != 0) QueueGamingSessionBoost();
                }
            });
        }

        private void RestoreStaleGamingPowerPlan()
        {
            // Recovery after a crash: restore only if Freezer's plan is still active.
            lock (_gamingBoostLock) RestoreGamingPowerPlan();
        }

        private void UpdateGamingSessionBoost()
        {
            if (!_startupRestoreComplete && !_closing) return;
            bool enabled = !_closing && _tweaks != null && _tweaks.IsActive("game_mode");
            lock (_gamingBoostLock)
            {
                if (_closing) { RestoreGamePrioritiesLocked(); ReleaseTimerResolutionLocked(); RestoreGamingPowerPlan(); return; }
                if (!enabled)
                {
                    RestoreGamePrioritiesLocked();
                    ReleaseTimerResolutionLocked();
                    RestoreGamingPowerPlan();
                    return;
                }

                HashSet<int> seen = new HashSet<int>(); bool streamerGameRunning = false, gameRunning = false;
                foreach (string name in GameProcessNames)
                {
                    Process[] processes = null;
                    try { processes = Process.GetProcessesByName(name); } catch { }
                    if (processes == null) continue;
                    foreach (Process process in processes)
                    {
                        try
                        {
                            if (process.HasExited) continue;
                            gameRunning = true;
                            ProcessPriorityClass desired = GetGamePriority(name);
                            if (desired == ProcessPriorityClass.AboveNormal) streamerGameRunning = true;
                            ApplyTrackedPriorityLocked(process, desired, seen);
                        }
                        catch { }
                        finally { try { process.Dispose(); } catch { } }
                    }
                }

                if (streamerGameRunning)
                {
                    Process[] captureProcesses = null;
                    try { captureProcesses = Process.GetProcessesByName("obs64"); } catch { }
                    if (captureProcesses != null)
                        foreach (Process process in captureProcesses)
                        {
                            try { if (!process.HasExited) ApplyTrackedPriorityLocked(process, ProcessPriorityClass.AboveNormal, seen); }
                            catch { }
                            finally { try { process.Dispose(); } catch { } }
                        }
                }

                List<int> ended = new List<int>();
                foreach (KeyValuePair<int, Tuple<long, ProcessPriorityClass>> item in _boostedGamePriorities)
                {
                    if (seen.Contains(item.Key)) continue;
                    try
                    {
                        using (Process process = Process.GetProcessById(item.Key))
                            if (!process.HasExited && process.StartTime.ToBinary() == item.Value.Item1) continue;
                    }
                    catch { }
                    ended.Add(item.Key);
                }
                foreach (int pid in ended) _boostedGamePriorities.Remove(pid);
                foreach (int pid in ended) _appliedGamePriorities.Remove(pid);
                if (ended.Count > 0) PersistGamePrioritiesLocked();

                if (seen.Count > 0 && !_timerResolutionHeld)
                {
                    try { _timerResolutionHeld = TimeBeginPeriod(1) == 0; } catch { _timerResolutionHeld = false; }
                }
                else if (seen.Count == 0) ReleaseTimerResolutionLocked();

                if (gameRunning) TryEnableGamingPowerPlanLocked();
                else RestoreGamingPowerPlan();
            }
        }

        private ProcessPriorityClass GetGamePriority(string processName)
        {
            if (_streamerModeActive) return ProcessPriorityClass.AboveNormal;
            string key = ProfileKeyForProcess(processName); string profile;
            return key != null && _prefs.GameProfiles.TryGetValue(key, out profile) && profile == "Streamer"
                ? ProcessPriorityClass.AboveNormal : ProcessPriorityClass.High;
        }

        private static string ProfileKeyForProcess(string processName)
        {
            if (String.Equals(processName, "FortniteClient-Win64-Shipping", StringComparison.OrdinalIgnoreCase)) return "game.fortnite";
            if (String.Equals(processName, "javaw", StringComparison.OrdinalIgnoreCase)) return "game.minecraft";
            if (String.Equals(processName, "Minecraft.Windows", StringComparison.OrdinalIgnoreCase)) return "game.minecraftBedrock";
            if (String.Equals(processName, "VALORANT-Win64-Shipping", StringComparison.OrdinalIgnoreCase)) return "game.valorant";
            if (String.Equals(processName, "GTA5", StringComparison.OrdinalIgnoreCase)) return "game.gta";
            if (String.Equals(processName, "Cyberpunk2077", StringComparison.OrdinalIgnoreCase)) return "game.cyberpunk";
            if (String.Equals(processName, "RocketLeague", StringComparison.OrdinalIgnoreCase)) return "game.rocket";
            if (String.Equals(processName, "Overwatch", StringComparison.OrdinalIgnoreCase)) return "game.overwatch";
            if (String.Equals(processName, "RainbowSix", StringComparison.OrdinalIgnoreCase)) return "game.r6";
            if (String.Equals(processName, "r5apex", StringComparison.OrdinalIgnoreCase)) return "game.apex";
            if (String.Equals(processName, "helldivers2", StringComparison.OrdinalIgnoreCase)) return "game.helldivers";
            if (processName.StartsWith("FarmingSimulator", StringComparison.OrdinalIgnoreCase)) return "game.farming";
            if (String.Equals(processName, "cs2", StringComparison.OrdinalIgnoreCase)) return "game.counterstrike";
            if (String.Equals(processName, "League of Legends", StringComparison.OrdinalIgnoreCase)) return "game.league";
            if (String.Equals(processName, "TslGame", StringComparison.OrdinalIgnoreCase)) return "game.pubg";
            if (String.Equals(processName, "cod", StringComparison.OrdinalIgnoreCase)) return "game.warzone";
            if (String.Equals(processName, "dota2", StringComparison.OrdinalIgnoreCase)) return "game.dota";
            if (String.Equals(processName, "RobloxPlayerBeta", StringComparison.OrdinalIgnoreCase)) return "game.roblox";
            if (String.Equals(processName, "FC26", StringComparison.OrdinalIgnoreCase)) return "game.fc26";
            return null;
        }

        private void ApplyTrackedPriorityLocked(Process process, ProcessPriorityClass desired, HashSet<int> seen)
        {
            seen.Add(process.Id); long started = process.StartTime.ToBinary();
            Tuple<long, ProcessPriorityClass> snapshot;
            if (_boostedGamePriorities.TryGetValue(process.Id, out snapshot) && snapshot.Item1 != started)
            {
                _boostedGamePriorities.Remove(process.Id); _appliedGamePriorities.Remove(process.Id); snapshot = null;
            }
            if (snapshot == null)
            {
                ProcessPriorityClass previous = process.PriorityClass;
                _boostedGamePriorities[process.Id] = Tuple.Create(started, previous);
                _appliedGamePriorities[process.Id] = desired;
                try { if (previous != desired && previous != ProcessPriorityClass.RealTime) process.PriorityClass = desired; }
                catch { _boostedGamePriorities.Remove(process.Id); _appliedGamePriorities.Remove(process.Id); throw; }
                PersistGamePrioritiesLocked(); return;
            }
            ProcessPriorityClass applied;
            if (!_appliedGamePriorities.TryGetValue(process.Id, out applied)) applied = ProcessPriorityClass.High;
            if (applied != desired && process.PriorityClass == applied)
            {
                process.PriorityClass = desired; _appliedGamePriorities[process.Id] = desired; PersistGamePrioritiesLocked();
            }
        }

        private void RestoreGamePrioritiesLocked()
        {
            foreach (KeyValuePair<int, Tuple<long, ProcessPriorityClass>> item in _boostedGamePriorities.ToArray())
            {
                bool retry = false;
                try
                {
                    using (Process process = Process.GetProcessById(item.Key))
                    {
                        ProcessPriorityClass applied; if (!_appliedGamePriorities.TryGetValue(item.Key, out applied)) applied = ProcessPriorityClass.High;
                        if (!process.HasExited && process.StartTime.ToBinary() == item.Value.Item1 && process.PriorityClass == applied)
                        {
                            try { process.PriorityClass = item.Value.Item2; }
                            catch { retry = true; }
                        }
                    }
                }
                catch (ArgumentException) { }
                catch { retry = true; }
                if (!retry) { _boostedGamePriorities.Remove(item.Key); _appliedGamePriorities.Remove(item.Key); }
            }
            PersistGamePrioritiesLocked();
        }

        private void ReleaseTimerResolutionLocked()
        {
            if (!_timerResolutionHeld) return;
            try { TimeEndPeriod(1); } catch { }
            _timerResolutionHeld = false;
        }

        private void PersistGamePrioritiesLocked()
        {
            string path = GamePriorityBackupPath, temporary = path + ".tmp";
            try
            {
                if (_boostedGamePriorities.Count == 0)
                {
                    if (File.Exists(path)) File.Delete(path);
                    if (File.Exists(temporary)) File.Delete(temporary);
                    return;
                }
                string[] lines = _boostedGamePriorities.Select(x =>
                {
                    ProcessPriorityClass applied; if (!_appliedGamePriorities.TryGetValue(x.Key, out applied)) applied = ProcessPriorityClass.High;
                    return x.Key.ToString(CultureInfo.InvariantCulture) + "|" + x.Value.Item1.ToString(CultureInfo.InvariantCulture) + "|" + x.Value.Item2.ToString() + "|" + applied.ToString();
                }).ToArray();
                File.WriteAllLines(temporary, lines, Encoding.UTF8);
                if (File.Exists(path)) File.Replace(temporary, path, null); else File.Move(temporary, path);
            }
            catch { try { if (File.Exists(temporary)) File.Delete(temporary); } catch { } }
        }

        private void RestoreSavedGamePriorities()
        {
            string path = Path.Combine(_stateRoot, "gaming-priorities.txt");
            if (!File.Exists(path)) return;
            List<string> pending = new List<string>();
            try
            {
                foreach (string line in File.ReadAllLines(path, Encoding.UTF8))
                {
                    string[] parts = line.Split('|'); int pid; long started; ProcessPriorityClass priority, applied = ProcessPriorityClass.High;
                    if ((parts.Length != 3 && parts.Length != 4) || !Int32.TryParse(parts[0], out pid) || !Int64.TryParse(parts[1], out started) || !Enum.TryParse(parts[2], out priority) || (parts.Length == 4 && !Enum.TryParse(parts[3], out applied))) continue;
                    try
                    {
                        using (Process process = Process.GetProcessById(pid))
                        {
                            if (process.HasExited || process.StartTime.ToBinary() != started) continue;
                            if (process.PriorityClass == applied) process.PriorityClass = priority;
                        }
                    }
                    catch { pending.Add(line); }
                }
                if (pending.Count == 0) File.Delete(path); else File.WriteAllLines(path, pending.ToArray(), Encoding.UTF8);
            }
            catch { }
        }

        private void QueueStartupRestore()
        {
            if (Interlocked.Exchange(ref _startupRestoreQueued, 1) != 0) return;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try { RestoreSavedGamePriorities(); }
                catch { }
                try { RestoreStaleGamingPowerPlan(); }
                catch { }
                finally
                {
                    _startupRestoreComplete = true;
                    if (!_closing && _tweaks != null && _tweaks.IsActive("game_mode"))
                    {
                        QueueGamingSessionBoost();
                    }
                }
            });
        }

        private void QueuePresentMonExtraction()
        {
            if (_presentMonReady || Interlocked.Exchange(ref _presentMonExtractionQueued, 1) != 0) return;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    ExtractPresentMon();
                    using (Stream resource = Assembly.GetExecutingAssembly().GetManifestResourceStream("PresentMon.exe"))
                        _presentMonReady = resource != null && PresentMonMatchesResource(_presentMonPath, resource);
                }
                catch { }
                finally { Interlocked.Exchange(ref _presentMonExtractionQueued, 0); }
            });
        }

        private string ExtractPresentMon()
        {
            string file = Path.Combine(_stateRoot, "PresentMon.exe");
            lock (_presentMonExtractLock)
            {
                try
                {
                    using (Stream input = Assembly.GetExecutingAssembly().GetManifestResourceStream("PresentMon.exe"))
                    {
                        if (input != null && !PresentMonMatchesResource(file, input))
                        {
                            Directory.CreateDirectory(_stateRoot); input.Position = 0;
                            string temporary = file + ".repair-tmp";
                            using (FileStream output = File.Create(temporary)) input.CopyTo(output);
                            if (File.Exists(file)) File.Delete(file);
                            File.Move(temporary, file);
                        }
                    }
                }
                catch { }
            }
            return file;
        }

        private static bool PresentMonMatchesResource(string file, Stream resource)
        {
            try
            {
                if (!File.Exists(file)) return false;
                using (SHA256 sha = SHA256.Create())
                using (FileStream current = File.OpenRead(file))
                {
                    byte[] currentHash = sha.ComputeHash(current); resource.Position = 0;
                    byte[] resourceHash = sha.ComputeHash(resource); resource.Position = 0;
                    return currentHash.SequenceEqual(resourceHash);
                }
            }
            catch { return false; }
        }

        private Panel BuildHeader()
        {
            Panel p = new Panel(); p.Dock = DockStyle.Fill; p.BackColor = Palette.Sidebar; p.MouseDown += DragWindow;
            PictureBox logo = CreateLogoPictureBox(new Point(16, 13), new Size(38, 38)); logo.MouseDown += DragWindow; p.Controls.Add(logo);
            Label title = MakeLabel("FREEZER", 16, Palette.Text, true); title.Location = new Point(64, 10); title.Size = new Size(250, 27); title.MouseDown += DragWindow; title.DoubleClick += delegate { ToggleMaximize(); }; p.Controls.Add(title);
            Label subtitle = MakeLabel(Localizer.T("header.tag"), 8, Palette.Accent, true); subtitle.Location = new Point(66, 36); subtitle.Size = new Size(250, 17); subtitle.MouseDown += DragWindow; subtitle.DoubleClick += delegate { ToggleMaximize(); }; p.Controls.Add(subtitle);
            Button menu = MakeButton("☰", Palette.Surface2, 42); menu.Font = UiFontCache.Get("Segoe UI Symbol", 12F, FontStyle.Regular); menu.Width = 46; menu.Location = new Point(330, 13); menu.Click += delegate { _sidebarPinned = !_sidebarPinned; SetSidebarExpanded(_sidebarPinned); }; menu.MouseEnter += SidebarHoverEnter; menu.MouseLeave += SidebarHoverLeave; p.Controls.Add(menu);
            _gamingModeButton = MakeButton("", Palette.Surface2, 42); _gamingModeButton.Location = new Point(384, 13); _gamingModeButton.Width = 160; _gamingModeButton.AccessibleDescription = Localizer.T("gaming.modeHint"); _gamingModeButton.Click += delegate { ToggleGamingMode(); }; p.Controls.Add(_gamingModeButton);
            _streamerModeButton = MakeButton("", Palette.Surface2, 42); _streamerModeButton.Location = new Point(552, 13); _streamerModeButton.Width = 132; _streamerModeButton.AccessibleDescription = Localizer.T("gaming.streamerHint"); _streamerModeButton.Click += delegate { ToggleStreamerMode(); }; p.Controls.Add(_streamerModeButton);
            _headerFpsLabel = MakeLabel("FPS  —", 9, Palette.Green, true); _headerFpsLabel.Location = new Point(692, 17); _headerFpsLabel.Size = new Size(150, 30); _headerFpsLabel.TextAlign = ContentAlignment.MiddleLeft; _headerFpsLabel.AccessibleName = Localizer.T("metric.fps"); p.Controls.Add(_headerFpsLabel); RefreshGamingModeButton();
            Button exit = MakeButton(Localizer.T("header.exit"), Palette.Surface2, 42); exit.Font = UiFontCache.Get("Segoe UI Semibold", 8.5F, FontStyle.Bold); exit.Width = 88; exit.Anchor = AnchorStyles.Top | AnchorStyles.Right; exit.Location = new Point(p.Width - 246, 13); exit.AccessibleName = Localizer.T("header.exit"); exit.Click += delegate { _exitRequested = true; Close(); }; p.Controls.Add(exit);
            Button minimize = MakeButton("—", Palette.Surface2, 42); minimize.Font = UiFontCache.Get("Segoe UI", 12F, FontStyle.Regular); minimize.Width = 42; minimize.Anchor = AnchorStyles.Top | AnchorStyles.Right; minimize.Location = new Point(p.Width - 148, 13); minimize.Click += delegate { WindowState = FormWindowState.Minimized; }; p.Controls.Add(minimize);
            _maximizeButton = MakeButton("□", Palette.Surface2, 42); _maximizeButton.Font = UiFontCache.Get("Segoe UI Symbol", 10F, FontStyle.Regular); _maximizeButton.Width = 42; _maximizeButton.Anchor = AnchorStyles.Top | AnchorStyles.Right; _maximizeButton.Location = new Point(p.Width - 98, 13); _maximizeButton.AccessibleName = Localizer.T("window.maximize"); _maximizeButton.Click += delegate { ToggleMaximize(); }; p.Controls.Add(_maximizeButton);
            Button close = MakeButton("×", Palette.Surface2, 42); close.Font = UiFontCache.Get("Segoe UI", 13F, FontStyle.Regular); close.Width = 42; close.Anchor = AnchorStyles.Top | AnchorStyles.Right; close.Location = new Point(p.Width - 48, 13); close.Click += delegate { Close(); }; p.Controls.Add(close);
            Action layoutHeader = delegate
            {
                exit.Location = new Point(p.Width - 246, 13); minimize.Location = new Point(p.Width - 148, 13); _maximizeButton.Location = new Point(p.Width - 98, 13); close.Location = new Point(p.Width - 48, 13);
                if (_headerFpsLabel != null)
                {
                    bool enoughRoom = p.Width >= 1180;
                    _headerFpsLabel.Visible = enoughRoom;
                    _streamerModeButton.Location = new Point(552, 13);
                    if (enoughRoom) _headerFpsLabel.Width = Math.Max(80, exit.Left - _headerFpsLabel.Left - 10);
                }
            };
            p.Resize += delegate { layoutHeader(); };
            layoutHeader();
            p.MouseDoubleClick += delegate { ToggleMaximize(); };
            p.MouseLeave += SidebarHoverLeave;
            return p;
        }

        private void ToggleMaximize()
        {
            if (WindowState == FormWindowState.Maximized) WindowState = FormWindowState.Normal;
            else { MaximizedBounds = Rectangle.Empty; WindowState = FormWindowState.Maximized; }
            UpdateMaximizeButtonState();
        }

        private Screen FindCurrentCrosshairScreen(string deviceName)
        {
            Screen[] screens = Screen.AllScreens;
            Screen match = screens.FirstOrDefault(x => String.Equals(x.DeviceName, deviceName, StringComparison.OrdinalIgnoreCase));
            if (match != null) return match;
            return screens.FirstOrDefault(x => x.Primary) ?? Screen.PrimaryScreen;
        }

        private void HandleDisplaySettingsChanged(object sender, EventArgs e)
        {
            ScheduleCrosshairRecenter();
        }

        private void ScheduleCrosshairRecenter()
        {
            if (_closing || _crosshair == null || _crosshair.IsDisposed) return;
            try
            {
                if (InvokeRequired) { BeginInvoke((MethodInvoker)ScheduleCrosshairRecenter); return; }
                _displayRefreshTimer.Stop(); _displayRefreshTimer.Start();
            }
            catch { }
        }

        private void RecenterActiveCrosshair()
        {
            if (_crosshair == null || _crosshair.IsDisposed) return;
            Screen screen = FindCurrentCrosshairScreen(_prefs.CrosshairScreen);
            if (screen == null) return;
            if (!String.Equals(_prefs.CrosshairScreen, screen.DeviceName, StringComparison.OrdinalIgnoreCase))
            { _prefs.CrosshairScreen = screen.DeviceName; SavePreferences(); }
            _crosshair.ApplyStyle(screen.Bounds, _prefs.CrosshairShape, _prefs.CrosshairColor, _prefs.CrosshairSize, _prefs.CrosshairGap, _prefs.CrosshairThickness, _prefs.CrosshairOpacity, _prefs.CrosshairOutline, _prefs.CrosshairGlow, CrosshairCustomImagePath());
        }

        private string CrosshairCustomImagePath()
        {
            return Path.Combine(_stateRoot, "crosshair-custom.png");
        }

        private string CrosshairPresetImagePath(string presetName)
        {
            byte[] hash;
            using (SHA256 sha = SHA256.Create()) hash = sha.ComputeHash(Encoding.UTF8.GetBytes((presetName ?? "").ToUpperInvariant()));
            string fileName = BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant() + ".png";
            return Path.Combine(_stateRoot, "crosshair-presets", fileName);
        }

        private bool ImportCrosshairImage(string sourcePath)
        {
            string extension = Path.GetExtension(sourcePath ?? "").ToLowerInvariant();
            if (!File.Exists(sourcePath) || !new[] { ".png", ".jpg", ".jpeg", ".bmp" }.Contains(extension))
            {
                ThemedDialog.Show(this, Localizer.T("crosshair.title"), Localizer.T("crosshair.imageInvalid"), false);
                return false;
            }

            string target = CrosshairCustomImagePath();
            string temporary = target + ".new";
            try
            {
                FileInfo info = new FileInfo(sourcePath);
                if (info.Length <= 0 || info.Length > 8L * 1024L * 1024L) throw new InvalidDataException();
                using (Image loaded = Image.FromFile(sourcePath))
                {
                    if (loaded.Width < 8 || loaded.Height < 8 || loaded.Width > 2048 || loaded.Height > 2048) throw new InvalidDataException();
                    using (Bitmap normalized = new Bitmap(512, 512, PixelFormat.Format32bppArgb))
                    using (Graphics g = Graphics.FromImage(normalized))
                    {
                        g.Clear(Color.Transparent);
                        g.CompositingMode = CompositingMode.SourceOver;
                        g.CompositingQuality = CompositingQuality.HighQuality;
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.SmoothingMode = SmoothingMode.HighQuality;
                        double scale = Math.Min(460.0 / loaded.Width, 460.0 / loaded.Height);
                        int width = Math.Max(1, (int)Math.Round(loaded.Width * scale));
                        int height = Math.Max(1, (int)Math.Round(loaded.Height * scale));
                        g.DrawImage(loaded, new Rectangle((512 - width) / 2, (512 - height) / 2, width, height));
                        normalized.Save(temporary, ImageFormat.Png);
                    }
                }
                if (File.Exists(target)) File.Replace(temporary, target, null);
                else File.Move(temporary, target);
                _prefs.CrosshairShape = "custom";
                SavePreferences();
                if (_crosshair != null && !_crosshair.IsDisposed) { _crosshair.ReloadCustomImage(); RecenterActiveCrosshair(); }
                SetStatus(Localizer.T("crosshair.imageSaved"));
                return true;
            }
            catch
            {
                try { if (File.Exists(temporary)) File.Delete(temporary); } catch { }
                ThemedDialog.Show(this, Localizer.T("crosshair.title"), Localizer.T("crosshair.imageInvalid"), false);
                return false;
            }
        }

        private void ChooseCrosshairImage()
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = Localizer.T("crosshair.importButton");
                dialog.Filter = "Images (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp";
                if (dialog.ShowDialog(this) == DialogResult.OK && ImportCrosshairImage(dialog.FileName)) ShowPage("crosshair");
            }
        }

        private void SetCrosshairDropTarget(Control target, Action<string> onImage)
        {
            target.AllowDrop = true;
            target.DragEnter += delegate(object sender, DragEventArgs e)
            {
                string[] files = e.Data == null ? null : e.Data.GetData(DataFormats.FileDrop) as string[];
                string extension = files != null && files.Length > 0 ? Path.GetExtension(files[0]).ToLowerInvariant() : "";
                e.Effect = files != null && files.Length == 1 && new[] { ".png", ".jpg", ".jpeg", ".bmp" }.Contains(extension) ? DragDropEffects.Copy : DragDropEffects.None;
            };
            target.DragDrop += delegate(object sender, DragEventArgs e)
            {
                string[] files = e.Data == null ? null : e.Data.GetData(DataFormats.FileDrop) as string[];
                if (files != null && files.Length == 1) onImage(files[0]);
            };
        }

        private void UpdateMaximizeButtonState()
        {
            if (_maximizeButton != null)
            {
                bool maximized = WindowState == FormWindowState.Maximized;
                _maximizeButton.Text = maximized ? "❐" : "□";
                _maximizeButton.AccessibleName = Localizer.T(maximized ? "window.restore" : "window.maximize");
            }
        }

        private void RefreshGamingModeButton()
        {
            if (_gamingModeButton == null || _gamingModeButton.IsDisposed) return;
            bool enabled = _tweaks.IsActive("game_mode");
            if (_gamingBoostTimer != null && !_closing)
            {
                if (enabled && !_gamingBoostTimer.Enabled) _gamingBoostTimer.Start();
                else if (!enabled && _gamingBoostTimer.Enabled) _gamingBoostTimer.Stop();
            }
            _gamingModeButton.Text = Localizer.T("gaming.mode") + "  ·  " + Localizer.T(enabled ? "state.on" : "state.off");
            _gamingModeButton.BackColor = enabled ? Color.FromArgb(45, Palette.Accent.R, Palette.Accent.G, Palette.Accent.B) : Palette.Surface2;
            _gamingModeButton.Invalidate(true); _gamingModeButton.Refresh();
            if (_streamerModeButton != null && !_streamerModeButton.IsDisposed)
            {
                _streamerModeButton.Text = Localizer.T("gaming.streamerMode") + "  ·  " + Localizer.T(_streamerModeActive ? "state.on" : "state.off");
                _streamerModeButton.BackColor = _streamerModeActive ? Color.FromArgb(45, Palette.Accent.R, Palette.Accent.G, Palette.Accent.B) : Palette.Surface2;
                _streamerModeButton.Invalidate(true); _streamerModeButton.Refresh();
            }
            if (_header != null && !_header.IsDisposed) { _header.Invalidate(true); _header.Update(); }
        }

        private void ToggleGamingMode()
        {
            Optimization item = _optimizations.FirstOrDefault(x => x.Key == "game_mode");
            if (item == null) return;
            bool enabled = _tweaks.IsActive("game_mode");
            string prompt = enabled ? Localizer.T("gaming.boostOff") : Localizer.T("gaming.boostWarning");
            if (!ThemedDialog.Confirm(this, Localizer.T("gaming.mode"), prompt)) return;
            try
            {
                if (enabled) { SetStatus(_tweaks.Restore("game_mode")); _streamerModeActive = false; _streamerEnabledGameMode = false; }
                else { _tweaks.Apply("game_mode", item.Edits); SetStatus(Localizer.T("optimization.done") + " · " + Localizer.T("gaming.boostDetails")); }
                QueueGamingSessionBoost();
            }
            catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("error.optimization"), DescribeSystemError(ex), false); }
            RefreshGamingModeButton();
            if (_page == "optimizations") ShowPage(_page);
        }

        private void ToggleStreamerMode()
        {
            string prompt = _streamerModeActive ? Localizer.T("gaming.streamerConfirmOff") : Localizer.T("gaming.streamerConfirmOn");
            if (!ThemedDialog.Confirm(this, Localizer.T("gaming.streamerMode"), prompt)) return;
            try
            {
                if (!_streamerModeActive)
                {
                    if (!_tweaks.IsActive("game_mode"))
                    {
                        Optimization gameMode = _optimizations.First(x => x.Key == "game_mode");
                        _tweaks.Apply("game_mode", gameMode.Edits);
                        _streamerEnabledGameMode = true;
                    }
                    _streamerModeActive = true;
                    SetStatus(Localizer.T("gaming.streamerHint"));
                }
                else
                {
                    _streamerModeActive = false;
                    if (_streamerEnabledGameMode) { _tweaks.Restore("game_mode"); _streamerEnabledGameMode = false; }
                    SetStatus(Localizer.T("gaming.streamerMode") + " · " + Localizer.T("state.off"));
                }
                QueueGamingSessionBoost();
            }
            catch (Exception ex) { _streamerModeActive = false; _streamerEnabledGameMode = false; ThemedDialog.Show(this, Localizer.T("gaming.streamerMode"), DescribeSystemError(ex), false); }
            RefreshGamingModeButton();
        }

        private Panel BuildSidebar()
        {
            Panel p = new Panel(); p.Dock = DockStyle.Fill; p.BackColor = Palette.Sidebar; p.Padding = new Padding(7, 12, 7, 8);
            string[,] items = { { "home", "⌂", "nav.home" }, { "optimizations", "◈", "nav.optimizations" },
                { "games", "▦", "nav.games" }, { "potatoGraphics", "▧", "nav.potatoGraphics" }, { "hardware", "▥", "nav.hardware" }, { "performance", "◌", "nav.performance" },
                { "crosshair", "⊕", "nav.crosshair" },
                { "colorProfiles", "◉", "nav.colorProfiles" }, { "stretch", "▭", "nav.stretch" }, { "updates", "↻", "nav.updates" },
                { "settings", "⚙", "nav.settings" }, { "repair", "✚", "nav.repair" } };
            for (int i = 0; i < items.GetLength(0); i++)
            {
                string key = items[i, 0], icon = items[i, 1], text = items[i, 2];
                SidebarNavigationButton b = new SidebarNavigationButton(icon, Localizer.T(text)); b.Tag = text;
                b.Dock = DockStyle.Top; b.Height = 48; b.Margin = new Padding(0, 0, 0, 5); b.Click += delegate { ShowPage(key); };
                p.Controls.Add(b); p.Controls.SetChildIndex(b, 0); _navButtons[key] = b;
                b.MouseEnter += delegate { b.SetHoverTarget(true, _prefs.Motion == "off" || _prefs.ReduceMotion); if (!(_prefs.Motion == "off" || _prefs.ReduceMotion)) _sidebarTimer.Start(); SidebarHoverEnter(b, EventArgs.Empty); };
                b.MouseLeave += delegate { b.SetHoverTarget(false, _prefs.Motion == "off" || _prefs.ReduceMotion); if (!(_prefs.Motion == "off" || _prefs.ReduceMotion)) _sidebarTimer.Start(); SidebarHoverLeave(b, EventArgs.Empty); };
            }
            p.MouseEnter += SidebarHoverEnter; p.MouseLeave += SidebarHoverLeave;
            return p;
        }

        private static Label MakeLabel(string text, float size, Color color, bool bold)
        {
            Label l = new Label(); l.Text = text; l.ForeColor = color; l.BackColor = Color.Transparent;
            l.Font = UiFontCache.Get("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular); l.AutoEllipsis = true; return l;
        }

        private Button MakeButton(string text, Color color, int height)
        {
            Button b = new RoundedActionButton(); b.Text = text; b.Height = height; b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0; b.BackColor = color; b.ForeColor = Palette.Text; b.Font = UiFontCache.Get("Segoe UI Semibold", 9F, FontStyle.Bold);
            b.Cursor = Cursors.Hand; b.UseVisualStyleBackColor = false; b.TextAlign = ContentAlignment.MiddleCenter;
            b.MouseEnter += delegate { if (b.Enabled && b.BackColor == Palette.Surface2) b.BackColor = Palette.Border; };
            b.MouseLeave += delegate { if (b.Enabled && b.BackColor == Palette.Border) b.BackColor = Palette.Surface2; };
            return b;
        }

        private void DragWindow(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            ReleaseCapture(); SendMessage(Handle, 0xA1, new IntPtr(2), IntPtr.Zero);
        }
        [DllImport("user32.dll")] private static extern bool ReleaseCapture();
        [DllImport("user32.dll")] private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

        private void SidebarHoverEnter(object sender, EventArgs e)
        { if (!_sidebarPinned) SetSidebarExpanded(true); }
        private void SidebarHoverLeave(object sender, EventArgs e)
        {
            if (_sidebarPinned) return;
            Point pos = PointToClient(Cursor.Position);
            if (pos.Y < _header.Height) return; // moving from the menu icon down into the sidebar
            Rectangle expanded = new Rectangle(0, _header.Height, _sidebar.Width + 10, _body.Height);
            if (!expanded.Contains(pos)) SetSidebarExpanded(false);
        }
        private void SetSidebarExpanded(bool expanded)
        {
            _sidebarTarget = expanded ? 244 : 70;
            if (_prefs.Motion == "off" || _prefs.ReduceMotion) { _sidebarWidth = _sidebarTarget; ApplySidebarWidth(); SnapSidebarVisuals(); _sidebarTimer.Stop(); return; }
            _sidebarTimer.Interval = _prefs.Motion == "slow" ? 16 : 10;
            _sidebarTimer.Start();
        }
        private void AnimateSidebar(object sender, EventArgs e)
        {
            int delta = _sidebarTarget - _sidebarWidth;
            int step = _prefs.Motion == "slow" ? 8 : 24;
            if (Math.Abs(delta) <= step) _sidebarWidth = _sidebarTarget;
            else _sidebarWidth += delta > 0 ? step : -step;
            ApplySidebarWidth();
            bool animating = _sidebarWidth != _sidebarTarget;
            double visualStep = _prefs.Motion == "slow" ? 0.10 : 0.30;
            foreach (SidebarNavigationButton button in _navButtons.Values) if (button.AdvanceVisual(visualStep)) animating = true;
            if (!animating) _sidebarTimer.Stop();
        }
        private void ApplySidebarWidth()
        {
            _body.ColumnStyles[0].Width = _sidebarWidth;
            foreach (KeyValuePair<string, SidebarNavigationButton> pair in _navButtons)
            {
                string titleKey = Convert.ToString(pair.Value.Tag);
                pair.Value.SetCaption(Localizer.T(titleKey)); pair.Value.Expanded = _sidebarWidth >= 100;
            }
        }

        private void SnapSidebarVisuals()
        {
            foreach (KeyValuePair<string, SidebarNavigationButton> pair in _navButtons)
                pair.Value.SnapVisuals();
        }

        private void StartSidebarVisualAnimation()
        {
            if (_prefs.Motion == "off" || _prefs.ReduceMotion) { SnapSidebarVisuals(); return; }
            _sidebarTimer.Interval = _prefs.Motion == "slow" ? 16 : 10; _sidebarTimer.Start();
        }

        private void ShowPage(string page)
        {
            if (_benchmarkRunning && _page == "performance" && page != "performance") CancelBenchmark(Localizer.T("benchmark.cancelled"));
            _optimizations = BuildOptimizations();
            StopGameSlide();
            _page = page; _content.SuspendLayout();
            while (_content.Controls.Count > 0)
            {
                Control old = _content.Controls[_content.Controls.Count - 1];
                _content.Controls.RemoveAt(_content.Controls.Count - 1); old.Dispose();
            }
            _gameNavigation = null; _gameViewport = null; _gameTiles = null; _gameIncomingTiles = null;
            _gamePrevious = null; _gameNext = null; _gamePageLabel = null;
            _gauges.Clear(); _valueLabels.Clear();
            foreach (KeyValuePair<string, SidebarNavigationButton> pair in _navButtons) pair.Value.SetActiveTarget(pair.Key == page, _prefs.Motion == "off" || _prefs.ReduceMotion);
            StartSidebarVisualAnimation();
            if (page == "home") RenderHome();
            else if (page == "optimizations") RenderOptimizations();
            else if (page == "games") RenderGames();
            else if (page == "potatoGraphics") RenderPotatoGraphics();
            else if (page == "hardware") RenderHardware();
            else if (page == "performance") RenderPerformance();
            else if (page == "crosshair") RenderCrosshair();
            else if (page == "colorProfiles") RenderColorProfiles();
            else if (page == "stretch") RenderStretchResolutionPage();
            else if (page == "updates") RenderUpdates();
            else if (page == "settings") RenderSettings();
            else RenderRepair();
            _content.ResumeLayout(); UpdateSampleTimer();
        }

        private void AddPageHeading(string title, string subtitle)
        {
            Label h = MakeLabel(title, 24, Palette.Text, true); h.AutoSize = false; h.Height = 38; h.Margin = new Padding(0, 0, 0, 2); h.Width = ContentCardWidth(); _content.Controls.Add(h);
            Label sub = MakeLabel(subtitle, 10, Palette.Muted, false); sub.Height = 38; sub.Width = h.Width; sub.Margin = new Padding(1, 0, 0, 12); _content.Controls.Add(sub);
        }

        private int ContentCardWidth()
        {
            // Leave room for the panel padding, card margin, and the vertical scrollbar.
            return Math.Max(500, _content.ClientSize.Width - _content.Padding.Horizontal - SystemInformation.VerticalScrollBarWidth - 12);
        }

        private RoundPanel Card(int height)
        {
            RoundPanel p = new RoundPanel(); p.BackColor = Palette.Surface; p.ForeColor = Palette.Text; p.Height = height;
            p.Width = ContentCardWidth(); p.Margin = new Padding(0, 0, 0, 11); p.Padding = new Padding(16); return p;
        }
        private void ResizeContentCards()
        {
            int width = ContentCardWidth();
            foreach (Control c in _content.Controls) if (c is RoundPanel || c is Label || c is FlowLayoutPanel || c is Panel) c.Width = width;
            if (_page == "games" && _gameNavigation != null && !_gameNavigation.IsDisposed)
            {
                _gameNavigation.Width = width; _gameNext.Location = new Point(width - _gameNext.Width, 3);
                _gamePageLabel.Location = new Point(_gamePrevious.Width + 12, 6); _gamePageLabel.Width = Math.Max(100, width - _gamePrevious.Width - _gameNext.Width - 24);
                if (_gameViewport != null && !_gameViewport.IsDisposed)
                {
                    _gameViewport.Width = width;
                    ResizeGamePage(_gameTiles, width); ResizeGamePage(_gameIncomingTiles, width);
                    if (_gameSlideTimer.Enabled) PositionGameSlide();
                }
            }
        }

        private void RenderHome()
        {
            AddPageHeading(Localizer.T("home.title"), Localizer.T("home.subtitle"));
            RoundPanel status = Card(70); PictureBox logo = CreateLogoPictureBox(new Point(16, 10), new Size(48, 48)); status.Controls.Add(logo);
            Label ready = MakeLabel(Localizer.T("home.ready"), 16, Palette.Text, true); ready.Location = new Point(75, 13); ready.Size = new Size(status.Width - 94, 28); status.Controls.Add(ready);
            Label free = MakeLabel(Localizer.T("home.badge"), 9, Palette.Accent, true); free.Location = new Point(77, 42); free.Size = new Size(status.Width - 100, 17); status.Controls.Add(free); _content.Controls.Add(status);
            if (_localUpdateCandidate != null)
            {
                RoundPanel update = Card(58); update.Cursor = Cursors.Hand;
                Label updateText = MakeLabel(String.Format(CultureInfo.CurrentCulture, Localizer.T("updates.localBanner"), _localUpdateCandidate.Version), 9, Palette.Text, true);
                updateText.Location = new Point(15, 8); updateText.Size = new Size(update.Width - 30, 42); updateText.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
                update.Controls.Add(updateText); update.Click += delegate { ShowPage("updates"); }; updateText.Click += delegate { ShowPage("updates"); };
                _content.Controls.Add(update);
            }
            else if (_remoteUpdateVersion != null)
            {
                RoundPanel update = Card(58); update.Cursor = Cursors.Hand;
                Label updateText = MakeLabel(String.Format(CultureInfo.CurrentCulture, Localizer.T("updates.remoteBanner"), _remoteUpdateTag), 9, Palette.Text, true);
                updateText.Location = new Point(15, 8); updateText.Size = new Size(update.Width - 30, 42); updateText.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
                update.Controls.Add(updateText); update.Click += delegate { ShowPage("updates"); }; updateText.Click += delegate { ShowPage("updates"); };
                _content.Controls.Add(update);
            }
            FlowLayoutPanel metrics = new FlowLayoutPanel(); metrics.Width = status.Width; metrics.Height = 174; metrics.WrapContents = false; metrics.Margin = new Padding(0, 0, 0, 12); metrics.BackColor = Palette.Background;
            AddGauge(metrics, "cpu", Localizer.T("metric.cpu")); AddGauge(metrics, "gpu", Localizer.T("metric.gpu")); AddGauge(metrics, "ram", Localizer.T("metric.ram"));
            RoundPanel fps = Card(144); fps.Width = 220; Label fpsTitle = MakeLabel(Localizer.T("metric.fps"), 11, Palette.Muted, true); fpsTitle.Location = new Point(15, 14); fpsTitle.Size = new Size(180, 22); fps.Controls.Add(fpsTitle);
            AddValue(fps, "fps", "—", 28, Palette.Text, new Point(15, 45), new Size(190, 42)); AddValue(fps, "fps_detail", Localizer.T("overlay.details") + " —   " + Localizer.T("overlay.average") + " —", 9, Palette.Muted, new Point(16, 93), new Size(205, 24)); metrics.Controls.Add(fps); _content.Controls.Add(metrics);
            RoundPanel action = Card(86); Label at = MakeLabel(Localizer.T("home.monitorTitle"), 13, Palette.Text, true); at.Location = new Point(16, 13); at.Size = new Size(450, 24); action.Controls.Add(at);
            Label desc = MakeLabel(Localizer.T("home.monitorDesc"), 9, Palette.Muted, false); desc.Location = new Point(16, 40); desc.Size = new Size(action.Width - 205, 32); action.Controls.Add(desc);
            Button overlay = MakeButton(Localizer.T("home.overlay"), Palette.Accent, 38); overlay.Width = 158; overlay.Location = new Point(action.Width - 180, 24); overlay.Click += delegate { ToggleOverlay(); }; action.Controls.Add(overlay);
            RoundPanel hardware = Card(84);
            Label hardwareTitle = MakeLabel(Localizer.T("home.hardwareTitle"), 11, Palette.Text, true); hardwareTitle.Location = new Point(16, 8); hardwareTitle.Size = new Size(420, 22); hardware.Controls.Add(hardwareTitle);
            _homeBoardName = MakeHardwareLine("home.mainboard", 34, hardware);
            _homeStorageName = MakeHardwareLine("home.storage", 57, hardware);
            _content.Controls.Add(hardware); UpdateHomeHardwareSummary(_latest);
            _content.Controls.Add(action);
            RoundPanel fpsExample = Card(94);
            Label fpsExampleTitle = MakeLabel(Localizer.T("home.fpsExampleTitle"), 11, Palette.Text, true); fpsExampleTitle.Location = new Point(15, 8); fpsExampleTitle.Size = new Size(340, 20); fpsExample.Controls.Add(fpsExampleTitle);
            Label fpsBefore = MakeLabel("60 FPS", 13, Palette.Muted, true); fpsBefore.Location = new Point(18, 32); fpsBefore.Size = new Size(82, 24); fpsExample.Controls.Add(fpsBefore);
            Label fpsArrow = MakeLabel("→", 15, Palette.Accent, true); fpsArrow.Location = new Point(102, 31); fpsArrow.Size = new Size(28, 24); fpsExample.Controls.Add(fpsArrow);
            Label fpsAfter = MakeLabel("120 FPS", 13, Palette.Green, true); fpsAfter.Location = new Point(134, 32); fpsAfter.Size = new Size(105, 24); fpsExample.Controls.Add(fpsAfter);
            Label fpsNote = MakeLabel(Localizer.T("home.fpsExampleNote"), 8, Palette.Muted, false); fpsNote.Location = new Point(15, 61); fpsNote.Size = new Size(fpsExample.Width - 30, 25); fpsNote.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; fpsExample.Controls.Add(fpsNote);
            _content.Controls.Add(fpsExample);
            UpdateReadings(_latest, _fps.Get());
        }

        private Label MakeHardwareLine(string key, int y, Control parent)
        {
            Label label = MakeLabel("• " + Localizer.T(key) + " — " + Localizer.T("home.hardwareLoading"), 9, Palette.Text, false);
            label.Location = new Point(17, y); label.Size = new Size(parent.Width - 34, 19); label.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            parent.Controls.Add(label); return label;
        }

        private void AddGauge(FlowLayoutPanel parent, string key, string label)
        {
            GaugeControl g = new GaugeControl(); g.Caption = label; g.Width = Math.Max(138, Math.Min(190, (parent.Width - 270) / 3)); g.Height = 168; g.Margin = new Padding(0, 0, 7, 0); parent.Controls.Add(g); _gauges[key] = g;
        }
        private void AddValue(Control parent, string key, string text, float size, Color color, Point location, Size sizeBox)
        {
            Label l = MakeLabel(text, size, color, true); l.Location = location; l.Size = sizeBox; parent.Controls.Add(l); _valueLabels[key] = l;
        }

        private void RenderOptimizations()
        {
            AddPageHeading(Localizer.T("opt.title"), Localizer.T("opt.subtitle"));
            string[] groups = { "opt.gaming", "opt.network", "opt.storage", "opt.system" };
            foreach (string group in groups)
            {
                Label title = MakeLabel(Localizer.T(group), 13, Palette.Accent, true); title.Height = 27; title.Width = Math.Max(500, _content.ClientSize.Width - 56); title.Margin = new Padding(0, 9, 0, 4); _content.Controls.Add(title);
                foreach (Optimization item in _optimizations.Where(x => x.Group == group)) RenderOptimizationCard(item);
            }
        }

        private void RenderOptimizationCard(Optimization item)
        {
            RoundPanel card = Card(112); Label title = MakeLabel(item.Title, 12, Palette.Text, true); title.Location = new Point(16, 12); title.Size = new Size(card.Width - 220, 24); card.Controls.Add(title);
            Label desc = MakeLabel(item.Description, 9, Palette.Muted, false); desc.Location = new Point(16, 39); desc.Size = new Size(card.Width - 220, 54); desc.AutoEllipsis = true; card.Controls.Add(desc);
            if (item.Kind == "toggle" || item.Kind == "cpu" || item.Kind == "mouse")
            {
                bool active = item.Key == "mouse_accel" ? File.Exists(MouseAccelerationBackupPath) : _tweaks.IsActive(item.Key);
                ToggleSwitch toggle = new ToggleSwitch(); toggle.Location = new Point(card.Width - 165, 32); toggle.Checked = active; toggle.CheckedChanged += delegate { ToggleOptimization(item, toggle); }; card.Controls.Add(toggle);
                Label state = MakeLabel(toggle.Checked ? Localizer.T("state.on") : Localizer.T("state.off"), 8, toggle.Checked ? Palette.Green : Palette.Muted, true); state.Location = new Point(card.Width - 116, 39); state.Size = new Size(70, 20); card.Controls.Add(state);
                Button undo = MakeButton(Localizer.T("opt.restore"), Palette.Surface2, 34); undo.Width = 96; undo.Location = new Point(card.Width - 278, 34); undo.Visible = toggle.Checked; undo.Click += delegate { toggle.SetCheckedSilently(false); ToggleOptimization(item, toggle); undo.Visible = toggle.Checked; desc.Width = card.Width - (toggle.Checked ? 310 : 220); }; card.Controls.Add(undo);
                if (toggle.Checked) desc.Width = card.Width - 310;
                toggle.CheckedChanged += delegate { state.Text = toggle.Checked ? Localizer.T("state.on") : Localizer.T("state.off"); state.ForeColor = toggle.Checked ? Palette.Green : Palette.Muted; undo.Visible = toggle.Checked; desc.Width = card.Width - (toggle.Checked ? 310 : 220); };
            }
            else
            {
                string buttonText = item.Kind == "x3d" ? Localizer.T("x3d.apply") : item.Kind == "desktop" ? Localizer.T("desktop.scan") : item.Key == "network_qos" && !String.IsNullOrEmpty(_prefs.NetworkQosPolicyName) ? Localizer.T("network.qosRemove") : Localizer.T(item.Kind == "info" ? "opt.info" : item.Kind == "network" || item.Kind == "qos" ? "opt.run" : Localizer.T("clean.preview"));
                Button button = MakeButton(buttonText, Palette.Accent, 36);
                button.Width = 150; button.Location = new Point(card.Width - 177, 35); button.Click += delegate { RunOptimization(item); }; card.Controls.Add(button);
            }
            _content.Controls.Add(card);
        }

        private IList<Optimization> BuildOptimizations()
        {
            string gamebar = @"Software\Microsoft\GameBar";
            string gameDvr = @"Software\Microsoft\Windows\CurrentVersion\GameDVR";
            string gameConfig = @"System\GameConfigStore";
            string visual = @"Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects";
            string desktop = @"Control Panel\Desktop";
            string backgroundApps = @"Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications";
            string themes = @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize";
            List<Optimization> a = new List<Optimization>();
            a.Add(NewToggle("game_mode", "Windows Game Mode", "Prioritizes games using the current user's Windows Game Mode settings.", "opt.gaming",
                Edit(gamebar, "AllowAutoGameMode", 1), Edit(gamebar, "AutoGameModeEnabled", 1)));
            a.Add(NewToggle("visual_effects", "Reduce Windows visual effects", "Sets the per-user VisualFXSetting to best performance. Previous value is saved and can be restored.", "opt.gaming", Edit(visual, "VisualFXSetting", 2)));
            a.Add(NewToggle("transparency", "Reduce Windows transparency effects", "Disables transparency for this user. Visual change only; no FPS gain is promised. Reversible.", "opt.gaming", Edit(themes, "EnableTransparency", 0)));
            a.Add(NewToggle("game_dvr", "Disable background game recording", "Stops Xbox/Game DVR background capture for this user. Reversible; game clips may be unavailable while enabled.", "opt.gaming",
                Edit(gameConfig, "GameDVR_Enabled", 0), Edit(gameDvr, "AppCaptureEnabled", 0)));
            a.Add(NewToggle("menu_delay", "Reduce Windows menu delay", "Changes the current user's menu animation delay to 100 ms. Restores the exact previous value.", "opt.gaming", Edit(desktop, "MenuShowDelay", 100)));
            a.Add(NewItem("mouse_accel", "Disable mouse acceleration", "Turn off Windows pointer acceleration for consistent mouse movement. Previous values are backed up and restored when disabled.", "opt.gaming", "mouse"));
            Optimization power = NewItem("cpu_policy", "High-performance CPU policy", "Temporarily sets the active plan's AC maximum CPU policy to 100%. Screen timeout settings are not touched.", "opt.gaming", "cpu"); a.Add(power);
            a.Add(NewAction("open_graphics", "Windows graphics preferences", "Open Windows Graphics settings to choose a per-game GPU preference.", "opt.gaming", "ms-settings:display-advancedgraphics"));
            a.Add(NewInfo("core_unpark", "CPU core parking guidance", "Core parking varies by processor, firmware and Windows plan. Freezer does not force hidden core-parking values.", "opt.gaming"));
            a.Add(NewInfo("gpu_latency", "NVIDIA low-latency guidance", "Set Low Latency Mode per game in NVIDIA Control Panel. Driver controls and supported modes vary by GPU and game.", "opt.gaming"));
            a.Add(NewInfo("fps_cap", "Stable FPS cap", "A cap near a frame rate your PC can hold steadily often improves frame pacing. Measure in-game before choosing a value.", "opt.gaming"));
            a.Add(NewInfo("game_overlays", "Overlay checklist", "Close capture, chat and launcher overlays you do not use. Freezer does not terminate background apps automatically.", "opt.gaming"));
            a.Add(NewInfo("game_power", "Power and temperature", "Power presets may increase heat, fan noise and energy use. Monitor temperatures with your hardware vendor's tool.", "opt.gaming"));
            a.Add(NewInfo("fortnite_lan", "Fortnite ping: wired LAN", "Connect directly to your router, avoid background downloads and choose the closest Fortnite region. Ping depends on your ISP and route; no reduction is guaranteed.", "opt.network"));
            a.Add(NewInfo("route_latency", "Check ping spikes and connection", "Review packet loss and ping variation. Pause large downloads and cloud sync; generic DNS or TCP registry edits do not reliably lower game ping.", "opt.network"));
            a.Add(NewInfo("network_queue", "Reduce background network load", "Pause large downloads, cloud backups and updates during online play. Ethernet avoids Wi-Fi interference but cannot shorten the route to your ISP or game server.", "opt.network"));
            a.Add(NewInfo("input_latency", "Reduce in-game input latency", "Check the game's NVIDIA Reflex, AMD Anti-Lag or equivalent supported option. Compare the same scene because V-Sync and refresh rate affect results.", "opt.gaming"));
            a.Add(NewItem("x3d_profile", "AMD Ryzen X3D gaming profile", "Detects Ryzen X3D CPUs across AM4 and AM5. Applies reversible Windows Game Mode and background-capture settings; it does not alter hidden CCD/CPPC or BIOS controls.", "opt.gaming", "x3d"));
            a.Add(NewItem("desktop_assistant", "Hardware-based desktop suggestions", "Detects CPU, graphics and memory, then offers matching reversible Windows settings for confirmation.", "opt.system", "desktop"));
            a.Add(NewItem("network_diagnostic", "Network adapter diagnosis", "Lists connected adapters and current link state. No universal TCP or Nagle changes are applied.", "opt.network", "network"));
            a.Add(NewItem("network_qos", "Local game QoS policy", "Temporarily marks a running game's traffic with DSCP 46. Requires administrator approval; routers may ignore the mark and ping improvement is not guaranteed. Reversible; ActiveStore clears on reboot.", "opt.network", "qos"));
            a.Add(NewItemWithAction("dns_flush", "Flush DNS cache", "Clears the local DNS resolver cache. This is not a guaranteed ping improvement; initial name lookups may need to be resolved again.", "opt.network", "action", "dns"));
            a.Add(NewInfo("nagle", "TCP / Nagle advice", "Nagle changes can improve or worsen latency depending on the game and adapter. Freezer leaves adapter registry settings unchanged.", "opt.network"));
            a.Add(NewInfo("wifi", "Wi-Fi stability", "For competitive play, use Ethernet when possible; otherwise prefer a clear 5/6 GHz signal and avoid downloads during matches.", "opt.network"));
            a.Add(NewItemWithAction("temp_clean", "Old temporary files", "Preview private user temp files older than 7 days. Shared folders and recent files are skipped.", "opt.storage", "cleaner", "temp"));
            a.Add(NewItemWithAction("shader_clean", "DirectX / GPU shader cache", "Preview known NVIDIA, AMD and DirectX shader-cache files older than 14 days. Games may rebuild them.", "opt.storage", "cleaner", "shader"));
            a.Add(NewItemWithAction("discord_clean", "Discord cache", "Preview old Discord cache files. Close Discord first for the cleanest result.", "opt.storage", "cleaner", "discord"));
            a.Add(NewInfo("ram_flush", "Memory management", "Windows manages RAM cache automatically. Forcing a cache flush usually makes games reload data and is not applied.", "opt.storage"));
            a.Add(NewAction("storage_settings", "Windows storage settings", "Open Storage settings to review temporary files before Windows removes them.", "opt.storage", "ms-settings:storagesense"));
            a.Add(NewInfo("windows_update", "Windows Update", "Freezer does not disable Windows Update or telemetry services. Check updates outside a gaming session instead.", "opt.system"));
            a.Add(NewAction("startup_apps", "Startup apps", "Review which apps start with Windows and disable only those you recognize and do not need.", "opt.system", "ms-settings:startupapps"));
            a.Add(NewInfo("background_apps", "Background applications", "Close only apps you recognize and do not need during play. Freezer will not stop unknown processes.", "opt.system"));
            a.Add(NewAction("game_mode_settings", "Game Mode settings", "Open Windows Game Mode settings.", "opt.system", "ms-settings:gaming-gamemode"));
            a.Add(NewInfo("no_timeout", "Display timeout protection", "Freezer does not change the Windows display timeout or sleep timer during any optimization.", "opt.system"));
            a.Add(NewToggle("background_apps_toggle", "Limit UWP background apps", "Blocks background activity for supported Windows apps for this user. Notifications or sync may stop; reversible.", "opt.system", Edit(backgroundApps, "GlobalUserDisabled", 1)));
            return a;
        }

        private static RegistryEdit Edit(string path, string name, int value) { return new RegistryEdit { Path = path, Name = name, NewValue = value }; }
        private static Optimization NewItem(string key, string title, string description, string group, string kind)
        { return new Optimization(key, Localizer.OptimizationText(key, false, title), Localizer.OptimizationText(key, true, description), group, kind); }
        private static Optimization NewItemWithAction(string key, string title, string description, string group, string kind, string action)
        { Optimization item = NewItem(key, title, description, group, kind); item.Action = action; return item; }
        private static Optimization NewToggle(string key, string title, string description, string group, params RegistryEdit[] edits)
        { return NewItem(key, title, description, group, "toggle").WithEdits(edits); }
        private static Optimization NewInfo(string key, string title, string description, string group)
        { return NewItem(key, title, description, group, "info"); }
        private static Optimization NewAction(string key, string title, string description, string group, string action)
        { return new Optimization(key, Localizer.OptimizationText(key, false, title), Localizer.OptimizationText(key, true, description), group, "action") { Action = action }; }

        private void ToggleOptimization(Optimization item, ToggleSwitch toggle)
        {
            bool target = toggle.Checked;
            string warning = Localizer.T("optimization.confirm") + "\r\n\r\n" + item.Description;
            if (item.Key == "game_mode") warning = target ? item.Description + "\r\n\r\n" + Localizer.T("gaming.boostWarning") : Localizer.T("gaming.boostOff");
            if (item.Key == "cpu_policy") warning += "\r\n\r\n" + Localizer.T("power.warning") + "\r\n\r\n" + Localizer.T("repair.adminWhy");
            if (!ThemedDialog.Confirm(this, item.Title, warning)) { toggle.SetCheckedSilently(!target); return; }
            try
            {
                if (item.Key == "game_mode" && !target) { _streamerModeActive = false; _streamerEnabledGameMode = false; }
                if (target)
                {
                    if (item.Key == "cpu_policy") ApplyCpuPolicy(); else if (item.Key == "mouse_accel") ApplyMouseAcceleration(); else _tweaks.Apply(item.Key, item.Edits);
                    SetStatus(Localizer.T("optimization.done"));
                }
                else
                {
                    string report = item.Key == "cpu_policy" ? RestoreCpuPolicy() : item.Key == "mouse_accel" ? RestoreMouseAcceleration() : _tweaks.Restore(item.Key);
                    SetStatus(item.Key == "game_mode" && !_tweaks.IsActive("game_mode") ? Localizer.T("state.off") + " · " + Localizer.T("gaming.mode") : report);
                }
                if (item.Key == "game_mode") QueueGamingSessionBoost();
                RefreshGamingModeButton();
            }
            catch (Exception ex)
            {
                toggle.SetCheckedSilently(!target);
                RefreshGamingModeButton();
                ThemedDialog.Show(this, Localizer.T("error.optimization"), DescribeSystemError(ex), false);
            }
        }

        private bool ReadMouseParameters(int[] values)
        {
            if (!SystemParametersInfoMouse(0x0003, 0, values, 0))
                throw new InvalidOperationException("Windows could not read mouse acceleration settings (" + Marshal.GetLastWin32Error().ToString(CultureInfo.InvariantCulture) + ").");
            return true;
        }

        private void ApplyMouseAcceleration()
        {
            int[] previous = new int[3]; ReadMouseParameters(previous);
            Directory.CreateDirectory(_stateRoot);
            File.WriteAllText(MouseAccelerationBackupPath, String.Join(",", previous.Select(x => x.ToString(CultureInfo.InvariantCulture))), Encoding.UTF8);
            if (!SystemParametersInfoMouse(0x0004, 0, new[] { 0, 0, 0 }, 0x0001 | 0x0002))
            {
                try { File.Delete(MouseAccelerationBackupPath); } catch { }
                throw new InvalidOperationException("Windows could not change mouse acceleration (" + Marshal.GetLastWin32Error().ToString(CultureInfo.InvariantCulture) + ").");
            }
        }

        private string RestoreMouseAcceleration()
        {
            if (!File.Exists(MouseAccelerationBackupPath)) return Localizer.T("restore.inactive");
            string[] parts = File.ReadAllText(MouseAccelerationBackupPath, Encoding.UTF8).Trim().Split(',');
            int[] previous = new int[3];
            if (parts.Length != 3 || !Int32.TryParse(parts[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out previous[0]) || !Int32.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out previous[1]) || !Int32.TryParse(parts[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out previous[2]))
                throw new InvalidDataException("The mouse acceleration backup is incomplete.");
            int[] current = new int[3]; ReadMouseParameters(current);
            if (!current.SequenceEqual(new[] { 0, 0, 0 }))
            {
                File.Delete(MouseAccelerationBackupPath);
                return Localizer.T("restore.keptExternal");
            }
            if (!SystemParametersInfoMouse(0x0004, 0, previous, 0x0001 | 0x0002))
                throw new InvalidOperationException("Windows could not restore mouse acceleration (" + Marshal.GetLastWin32Error().ToString(CultureInfo.InvariantCulture) + ").");
            File.Delete(MouseAccelerationBackupPath);
            return Localizer.T("optimization.done");
        }

        private void RunOptimization(Optimization item)
        {
            try
            {
                if (item.Kind == "x3d") { ApplyX3dProfile(item); return; }
                if (item.Kind == "desktop") { RunDesktopAssistant(item); return; }
                if (item.Kind == "qos") { ToggleNetworkQosPolicy(); return; }
                if (item.Kind == "info") { ThemedDialog.Show(this, item.Title, item.Description, false); return; }
                if (item.Kind == "action" && item.Action == "dns")
                {
                    if (!ThemedDialog.Confirm(this, item.Title, item.Description + "\r\n\r\n" + Localizer.T("action.continue"))) return;
                    string result = RunProcess("ipconfig.exe", "/flushdns", 8000); ThemedDialog.Show(this, item.Title, result, false); return;
                }
                if (item.Kind == "action") { Process.Start(new ProcessStartInfo(item.Action) { UseShellExecute = true }); return; }
                if (item.Kind == "network")
                {
                    string output = RunProcess("ipconfig.exe", "/all", 6000);
                    string[] lines = output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None).Where(x => x.IndexOf("adapter", StringComparison.OrdinalIgnoreCase) >= 0 || x.IndexOf("Media State", StringComparison.OrdinalIgnoreCase) >= 0 || x.IndexOf("IPv4", StringComparison.OrdinalIgnoreCase) >= 0).Take(24).ToArray();
                    ThemedDialog.Show(this, Localizer.T("network.result"), String.Join(Environment.NewLine, lines), false); return;
                }
                if (item.Kind == "cleaner") CleanCache(item.Action);
            }
            catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("error.action"), DescribeSystemError(ex), false); }
        }

        private void ToggleNetworkQosPolicy()
        {
            if (_networkQosBusy) return;
            bool remove = !String.IsNullOrEmpty(_prefs.NetworkQosPolicyName);
            string policyName = _prefs.NetworkQosPolicyName, appPath = _prefs.NetworkQosApp;
            if (!remove)
            {
                Process running = null;
                foreach (string processName in GameProcessNames)
                {
                    try { Process[] matches = Process.GetProcessesByName(processName); if (matches.Length > 0) { running = matches[0]; for (int i = 1; i < matches.Length; i++) matches[i].Dispose(); break; } }
                    catch { }
                }
                if (running == null) { ThemedDialog.Show(this, Localizer.T("network.qosApply"), Localizer.T("network.qosNoGame"), false); return; }
                try { appPath = running.MainModule.FileName; }
                catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("network.qosApply"), DescribeSystemError(ex), false); return; }
                finally { try { running.Dispose(); } catch { } }
                if (String.IsNullOrWhiteSpace(appPath) || !File.Exists(appPath)) { ThemedDialog.Show(this, Localizer.T("network.qosApply"), Localizer.T("network.qosNoGame"), false); return; }
                policyName = NetworkQosPolicyNameFor(appPath);
                if (!ThemedDialog.Confirm(this, Localizer.T("network.qosApply"), Localizer.T("network.qosWarning") + "\r\n\r\n" + Path.GetFileName(appPath))) return;
            }
            RunNetworkQosPowerShell(policyName, appPath, remove);
        }

        private static string NetworkQosPolicyNameFor(string appPath)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(appPath.ToLowerInvariant()));
                return "FreezerGameQoS_" + BitConverter.ToString(hash, 0, 4).Replace("-", "");
            }
        }

        private static string PowerShellLiteral(string value) { return "'" + (value ?? "").Replace("'", "''") + "'"; }

        private void RunNetworkQosPowerShell(string policyName, string appPath, bool remove)
        {
            if (_networkQosBusy) return;
            _networkQosBusy = true;
            string resultPath = Path.Combine(_stateRoot, "qos-result-" + Guid.NewGuid().ToString("N") + ".txt");
            string policy = PowerShellLiteral(policyName), app = PowerShellLiteral(appPath ?? ""), result = PowerShellLiteral(resultPath);
            string script = "$ErrorActionPreference='Stop'; try { Import-Module NetQos -ErrorAction Stop; $name=" + policy + "; ";
            if (remove)
                script += "$exists=Get-NetQosPolicy -PolicyStore ActiveStore -Name $name -ErrorAction SilentlyContinue; if ($exists) { Remove-NetQosPolicy -PolicyStore ActiveStore -Name $name -Confirm:$false -ErrorAction Stop }; ";
            else
                script += "$exists=Get-NetQosPolicy -PolicyStore ActiveStore -Name $name -ErrorAction SilentlyContinue; if ($exists) { Remove-NetQosPolicy -PolicyStore ActiveStore -Name $name -Confirm:$false -ErrorAction Stop }; New-NetQosPolicy -PolicyStore ActiveStore -Name $name -AppPathNameMatchCondition " + app + " -DSCPAction 46 -ErrorAction Stop | Out-Null; ";
            script += "[IO.File]::WriteAllText(" + result + ",'OK',[Text.Encoding]::UTF8); exit 0 } catch { [IO.File]::WriteAllText(" + result + ",(($_ | Out-String)),[Text.Encoding]::UTF8); exit 1 }";
            string powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
            string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));
            SetStatus(Localizer.T("status.working"));
            try
            {
                ProcessStartInfo start = new ProcessStartInfo(powershell, "-NoProfile -NonInteractive -WindowStyle Hidden -EncodedCommand " + encoded);
                start.UseShellExecute = true; start.Verb = "runas"; start.WindowStyle = ProcessWindowStyle.Hidden;
                Process elevated = Process.Start(start);
                if (elevated == null) throw new IOException("PowerShell did not start.");
                ThreadPool.QueueUserWorkItem(delegate
                {
                    bool finished = false; int exitCode = -1; string output = "";
                    try { finished = elevated.WaitForExit(60000); if (finished) exitCode = elevated.ExitCode; else try { elevated.Kill(); } catch { } }
                    catch { }
                    finally { try { elevated.Dispose(); } catch { } }
                    try { if (File.Exists(resultPath)) output = File.ReadAllText(resultPath, Encoding.UTF8).Trim(); } catch { }
                    try { if (File.Exists(resultPath)) File.Delete(resultPath); } catch { }
                    try
                    {
                        BeginInvoke((MethodInvoker)delegate
                        {
                            if (IsDisposed || _closing) return;
                            _networkQosBusy = false;
                            if (finished && exitCode == 0)
                            {
                                if (remove) { _prefs.NetworkQosPolicyName = ""; _prefs.NetworkQosApp = ""; SetStatus(Localizer.T("network.qosDisabled")); }
                                else { _prefs.NetworkQosPolicyName = policyName; _prefs.NetworkQosApp = appPath; SetStatus(String.Format(CultureInfo.CurrentCulture, Localizer.T("network.qosEnabled"), Path.GetFileName(appPath))); }
                                SavePreferences(); if (_page == "optimizations") ShowPage("optimizations");
                            }
                            else
                            {
                                string message = !finished ? Localizer.T("network.qosNeedsAdmin") : String.IsNullOrWhiteSpace(output) ? Localizer.T("network.qosNeedsAdmin") : Localizer.T("network.qosNeedsAdmin") + "\r\n\r\n" + output;
                                ThemedDialog.Show(this, Localizer.T("network.qosApply"), message, false); SetStatus(Localizer.T("status.ready"));
                            }
                        });
                    }
                    catch { }
                });
            }
            catch (System.ComponentModel.Win32Exception ex)
            {
                _networkQosBusy = false;
                try { if (File.Exists(resultPath)) File.Delete(resultPath); } catch { }
                string message = ex.NativeErrorCode == 1223 ? Localizer.T("network.qosAdmin") : Localizer.T("network.qosNeedsAdmin") + "\r\n\r\n" + DescribeSystemError(ex);
                ThemedDialog.Show(this, Localizer.T("network.qosApply"), message, false); SetStatus(Localizer.T("status.ready"));
            }
            catch (Exception ex)
            {
                _networkQosBusy = false;
                try { if (File.Exists(resultPath)) File.Delete(resultPath); } catch { }
                ThemedDialog.Show(this, Localizer.T("network.qosApply"), DescribeSystemError(ex), false); SetStatus(Localizer.T("status.ready"));
            }
        }

        private static string RunProcess(string file, string args, int timeout)
        {
            using (Process p = new Process())
            {
                p.StartInfo = new ProcessStartInfo(file, args); p.StartInfo.UseShellExecute = false; p.StartInfo.CreateNoWindow = true;
                p.StartInfo.RedirectStandardOutput = true; p.StartInfo.RedirectStandardError = true;
                if (!p.Start()) throw new IOException("The requested Windows utility could not be started.");
                StringBuilder result = new StringBuilder();
                p.OutputDataReceived += delegate(object s, DataReceivedEventArgs e) { if (e.Data != null) lock (result) result.AppendLine(e.Data); };
                p.ErrorDataReceived += delegate(object s, DataReceivedEventArgs e) { if (e.Data != null) lock (result) result.AppendLine(e.Data); };
                p.BeginOutputReadLine(); p.BeginErrorReadLine();
                if (!p.WaitForExit(timeout)) { try { p.Kill(); } catch { } throw new TimeoutException(file + " did not finish in time."); }
                p.WaitForExit(); string text; lock (result) text = result.ToString();
                if (p.ExitCode != 0) throw new IOException(text.Length == 0 ? file + " exited with code " + p.ExitCode : text.Trim());
                return text.Trim();
            }
        }

        private void CleanCache(string target)
        {
            List<string> roots = new List<string>(); string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (target == "temp") roots.Add(Path.Combine(local, "Temp"));
            else if (target == "shader") { roots.Add(Path.Combine(local, "D3DSCache")); roots.Add(Path.Combine(local, "NVIDIA", "DXCache")); roots.Add(Path.Combine(local, "NVIDIA", "GLCache")); roots.Add(Path.Combine(local, "AMD", "DxCache")); }
            else if (target == "discord")
            {
                string app = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                foreach (string client in new[] { "discord", "discordptb", "discordcanary" })
                    foreach (string dir in new[] { "Cache", "Code Cache", "GPUCache" }) roots.Add(Path.Combine(app, client, dir));
            }
            List<string> files = FindOldFiles(roots, target == "temp" ? 7 : 14, 3000);
            long bytes = 0; foreach (string file in files) try { bytes += new FileInfo(file).Length; } catch { }
            string preview = String.Format(CultureInfo.CurrentCulture, Localizer.T("files.preview"), files.Count, bytes / 1048576.0, Localizer.T("clean.confirm"));
            if (!ThemedDialog.Confirm(this, Localizer.T("clean.preview"), preview)) return;
            int removed = 0; long freed = 0;
            foreach (string file in files) try { long length = new FileInfo(file).Length; File.Delete(file); removed++; freed += length; } catch { }
            ThemedDialog.Show(this, Localizer.T("clean.done"), String.Format(CultureInfo.CurrentCulture, Localizer.T("files.removed"), removed, freed / 1048576.0), false);
        }

        private static List<string> FindOldFiles(IList<string> roots, int ageDays, int limit)
        {
            List<string> result = new List<string>(); DateTime cutoff = DateTime.Now.AddDays(-ageDays); int scanned = 0;
            foreach (string root in roots)
            {
                try
                {
                    if (!Directory.Exists(root) || (File.GetAttributes(root) & FileAttributes.ReparsePoint) != 0) continue;
                    string safe = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
                    Stack<Tuple<string, int>> stack = new Stack<Tuple<string, int>>(); stack.Push(Tuple.Create(root, 0));
                    while (stack.Count > 0 && result.Count < limit && scanned < 20000)
                    {
                        Tuple<string, int> node = stack.Pop(); string[] children;
                        try { children = Directory.GetFileSystemEntries(node.Item1); } catch { continue; }
                        foreach (string child in children)
                        {
                            if (result.Count >= limit || scanned++ >= 20000) break;
                            try
                            {
                                string full = Path.GetFullPath(child);
                                if (!full.StartsWith(safe, StringComparison.OrdinalIgnoreCase)) continue;
                                FileAttributes attr = File.GetAttributes(full); if ((attr & FileAttributes.ReparsePoint) != 0) continue;
                                if ((attr & FileAttributes.Directory) != 0) { if (node.Item2 < 3) stack.Push(Tuple.Create(full, node.Item2 + 1)); }
                                else if (File.GetLastWriteTime(full) < cutoff) result.Add(full);
                            }
                            catch { }
                        }
                    }
                }
                catch { }
            }
            return result;
        }

        private void ApplyCpuPolicy()
        {
            string powercfg = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "powercfg.exe");
            string active = RunProcess(powercfg, "/getactivescheme", 5000);
            Match guid = Regex.Match(active, "[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}", RegexOptions.IgnoreCase);
            if (!guid.Success) throw new IOException("Could not read the active power scheme.");
            int original = ReadAcCpuMaximum(powercfg, guid.Value);
            string file = Path.Combine(_stateRoot, "cpu-policy.txt");
            File.WriteAllText(file, guid.Value + "\r\n" + original.ToString(CultureInfo.InvariantCulture), Encoding.UTF8);
            try
            {
                RunProcess(powercfg, "/setacvalueindex " + guid.Value + " SUB_PROCESSOR PROCTHROTTLEMAX 100", 5000);
                RunProcess(powercfg, "/setactive " + guid.Value, 5000);
                if (ReadAcCpuMaximum(powercfg, guid.Value) != 100) throw new IOException("Windows did not confirm the requested AC CPU policy.");
            }
            catch { try { RestoreCpuPolicy(); } catch { } throw; }
        }

        private string RestoreCpuPolicy()
        {
            string file = Path.Combine(_stateRoot, "cpu-policy.txt"); if (!File.Exists(file)) return Localizer.T("restore.cpuInactive");
            string[] lines = File.ReadAllLines(file); if (lines.Length < 2 || !Regex.IsMatch(lines[0], "^[0-9a-f-]{36}$", RegexOptions.IgnoreCase)) throw new IOException("The saved CPU policy backup is invalid; it was kept.");
            int value; if (!Int32.TryParse(lines[1], out value)) throw new IOException("The saved CPU policy backup is invalid; it was kept.");
            string powercfg = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "powercfg.exe");
            if (ReadAcCpuMaximum(powercfg, lines[0]) != 100)
            { File.Delete(file); return Localizer.T("restore.cpuExternal"); }
            RunProcess(powercfg, "/setacvalueindex " + lines[0] + " SUB_PROCESSOR PROCTHROTTLEMAX " + value, 5000);
            RunProcess(powercfg, "/setactive " + lines[0], 5000);
            if (ReadAcCpuMaximum(powercfg, lines[0]) != value) throw new IOException("Windows did not confirm restoration; the saved backup was retained.");
            File.Delete(file);
            return Localizer.T("restore.cpuDone");
        }

        private static int ReadAcCpuMaximum(string powercfg, string scheme)
        {
            string query = RunProcess(powercfg, "/query " + scheme + " SUB_PROCESSOR PROCTHROTTLEMAX", 5000);
            MatchCollection values = Regex.Matches(query, "0x([0-9a-f]{1,8})", RegexOptions.IgnoreCase);
            if (values.Count < 2) throw new IOException("Could not read the AC CPU policy value.");
            return Int32.Parse(values[values.Count - 2].Groups[1].Value, NumberStyles.HexNumber, CultureInfo.InvariantCulture);
        }

        private void RenderGames()
        {
            AddPageHeading(Localizer.T("games.title"), Localizer.T("games.subtitle"));
            _gameKeys = new[] { "game.fortnite", "game.minecraft", "game.minecraftBedrock", "game.valorant", "game.gta", "game.cyberpunk", "game.rocket", "game.overwatch", "game.r6", "game.apex", "game.helldivers", "game.farming", "game.counterstrike", "game.league", "game.pubg", "game.warzone", "game.dota", "game.roblox", "game.fc26" };
            RenderGameSessionCard();
            int pageCount = (_gameKeys.Length + 2) / 3;
            Panel navigation = new Panel(); navigation.Width = Math.Max(500, _content.ClientSize.Width - 56); navigation.Height = 50; navigation.Margin = new Padding(0, 0, 0, 8); navigation.BackColor = Palette.Background;
            Button previous = MakeButton("‹  " + Localizer.T("games.previous"), Palette.Surface2, 38); previous.Width = 138; previous.Location = new Point(0, 3);
            Button next = MakeButton(Localizer.T("games.next") + "  ›", Palette.Surface2, 38); next.Width = 138; next.Location = new Point(navigation.Width - 138, 3);
            Label page = MakeLabel(String.Format(CultureInfo.CurrentCulture, Localizer.T("games.page"), _gamePage + 1, pageCount), 10, Palette.Muted, true); page.TextAlign = ContentAlignment.MiddleCenter; page.Location = new Point(150, 6); page.Size = new Size(navigation.Width - 300, 30);
            _gameNavigation = navigation; _gamePrevious = previous; _gameNext = next; _gamePageLabel = page;
            navigation.Controls.Add(previous); navigation.Controls.Add(next); navigation.Controls.Add(page); _content.Controls.Add(navigation);
            Panel viewport = new Panel(); viewport.Width = navigation.Width; viewport.Height = 288; viewport.Margin = new Padding(0); viewport.Padding = Padding.Empty; viewport.BackColor = Palette.Background; viewport.Name = "game-viewport";
            _gameViewport = viewport; _gameTiles = BuildGamePage(_gamePage, _gameKeys, viewport.Width); viewport.Controls.Add(_gameTiles); _content.Controls.Add(viewport);
            RoundPanel hint = Card(64); Label text = MakeLabel(Localizer.T("games.applyHint"), 9, Palette.Muted, false); text.Location = new Point(16, 12); text.Size = new Size(hint.Width - 32, 42); hint.Controls.Add(text); _content.Controls.Add(hint);
            previous.Enabled = _gamePage > 0; next.Enabled = _gamePage + 1 < pageCount;
            previous.Click += delegate { BeginGameSlide(-1); };
            next.Click += delegate { BeginGameSlide(1); };
        }

        private void RenderGameSessionCard()
        {
            RoundPanel card = Card(226);
            Label title = MakeLabel(Localizer.T("gaming.sessionTitle"), 11, Palette.Text, true); title.Location = new Point(16, 10); title.Size = new Size(260, 22); card.Controls.Add(title);
            Label hint = MakeLabel(Localizer.T("gaming.sessionHint"), 8, Palette.Muted, false); hint.Location = new Point(16, 32); hint.Size = new Size(card.Width - 32, 25); hint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; card.Controls.Add(hint);
            _sessionGamePicker = MakeCombo(_gameKeys.Select(Localizer.T).ToArray()); _sessionGamePicker.Location = new Point(16, 76); _sessionGamePicker.Width = 300; _sessionGamePicker.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            int selected = Array.IndexOf(_gameKeys, _prefs.SelectedGame);
            try { ProcessChoice detected = FindRunningGameTarget(); if (detected != null) { string detectedKey = GameKeyForProcess(detected.Name); int detectedIndex = Array.IndexOf(_gameKeys, detectedKey); if (detectedIndex >= 0) { selected = detectedIndex; _prefs.SelectedGame = detectedKey; SavePreferences(); } } } catch { }
            if (selected < 0) selected = 0; _sessionGamePicker.SelectedIndex = selected; card.Controls.Add(_sessionGamePicker);
            string[] profileKeys = { "Lite", "Balanced", "Power", "MaxFPS", "Streamer" };
            _sessionProfilePicker = MakeCombo(new[] { Localizer.T("games.lite"), Localizer.T("games.balanced"), Localizer.T("games.power"), Localizer.T("games.maxFps"), Localizer.T("games.streamer") });
            _sessionProfilePicker.Location = new Point(326, 76); _sessionProfilePicker.Width = 220; _sessionProfilePicker.Anchor = AnchorStyles.Top | AnchorStyles.Left; card.Controls.Add(_sessionProfilePicker);
            Action loadSavedProfile = delegate
            {
                string gameKey = _sessionGamePicker.SelectedIndex >= 0 ? _gameKeys[_sessionGamePicker.SelectedIndex] : _gameKeys[0];
                string profile; if (!_prefs.GameProfiles.TryGetValue(gameKey, out profile)) profile = "Balanced";
                _sessionProfilePicker.SelectedIndex = Math.Max(0, Array.IndexOf(profileKeys, profile));
            };
            loadSavedProfile();

            Label colorLabel = MakeLabel(Localizer.T("gaming.colorProfile"), 8, Palette.Muted, true); colorLabel.Location = new Point(16, 118); colorLabel.Size = new Size(300, 18); card.Controls.Add(colorLabel);
            Label stretchMonitorLabel = MakeLabel(Localizer.T("gaming.stretchMonitor"), 8, Palette.Muted, true); stretchMonitorLabel.Location = new Point(390, 118); stretchMonitorLabel.Size = new Size(250, 18); card.Controls.Add(stretchMonitorLabel);
            Label stretchResolutionLabel = MakeLabel(Localizer.T("gaming.stretchResolution"), 8, Palette.Muted, true); stretchResolutionLabel.Location = new Point(700, 118); stretchResolutionLabel.Size = new Size(250, 18); card.Controls.Add(stretchResolutionLabel);
            _sessionColorProfilePicker = MakeCombo(new string[0]); _sessionColorProfilePicker.Location = new Point(16, 139); _sessionColorProfilePicker.Width = 360; card.Controls.Add(_sessionColorProfilePicker);
            _sessionStretchDisplayPicker = MakeCombo(new string[0]);
            foreach (Screen screen in Screen.AllScreens) _sessionStretchDisplayPicker.Items.Add(new CrosshairDisplayOption(screen));
            if (_sessionStretchDisplayPicker.Items.Count > 0) _sessionStretchDisplayPicker.SelectedIndex = Array.FindIndex(Screen.AllScreens, s => s.Primary);
            _sessionStretchDisplayPicker.Location = new Point(390, 139); _sessionStretchDisplayPicker.Width = 295; card.Controls.Add(_sessionStretchDisplayPicker);
            _sessionStretchResolutionPicker = MakeCombo(new string[0]); _sessionStretchResolutionPicker.Location = new Point(700, 139); _sessionStretchResolutionPicker.Width = 300; card.Controls.Add(_sessionStretchResolutionPicker);
            RebuildGameColorProfileOptions();
            Action loadCombinedSettings = delegate
            {
                if (_sessionGamePicker.SelectedIndex < 0) return;
                _loadingCombinedProfile = true;
                try
                {
                    string gameKey = _gameKeys[_sessionGamePicker.SelectedIndex];
                    string colorProfile = null;
                    if (_prefs.NvidiaGameProfiles.TryGetValue(gameKey, out colorProfile) && !String.IsNullOrWhiteSpace(colorProfile)) SelectGameColorProfile("nvidia", colorProfile);
                    else if (_prefs.AmdGameProfiles.TryGetValue(gameKey, out colorProfile) && !String.IsNullOrWhiteSpace(colorProfile)) SelectGameColorProfile("amd", colorProfile);
                    else SelectGameColorProfile("", "");
                    string storedStretch; string device = ""; int width = 0, height = 0;
                    if (_prefs.GameStretchProfiles.TryGetValue(gameKey, out storedStretch)) TryParseGameStretchProfile(storedStretch, out device, out width, out height);
                    CrosshairDisplayOption display = _sessionStretchDisplayPicker.Items.Cast<object>().OfType<CrosshairDisplayOption>().FirstOrDefault(x => String.Equals(x.Screen.DeviceName, device, StringComparison.OrdinalIgnoreCase));
                    if (display != null) _sessionStretchDisplayPicker.SelectedItem = display;
                    RefreshGameStretchOptions(gameKey, width, height);
                }
                finally { _loadingCombinedProfile = false; }
            };
            loadCombinedSettings();
            _sessionGamePicker.SelectedIndexChanged += delegate
            {
                if (_sessionGamePicker.SelectedIndex < 0) return;
                _prefs.SelectedGame = _gameKeys[_sessionGamePicker.SelectedIndex]; SavePreferences(); loadSavedProfile(); loadCombinedSettings();
            };
            _sessionProfilePicker.SelectedIndexChanged += delegate
            {
                if (_sessionGamePicker.SelectedIndex < 0 || _sessionProfilePicker.SelectedIndex < 0) return;
                _prefs.GameProfiles[_gameKeys[_sessionGamePicker.SelectedIndex]] = profileKeys[_sessionProfilePicker.SelectedIndex]; SavePreferences();
            };
            _sessionColorProfilePicker.SelectedIndexChanged += delegate { if (!_loadingCombinedProfile) SaveGameColorProfileSelection(); };
            _sessionStretchDisplayPicker.SelectedIndexChanged += delegate
            {
                if (_loadingCombinedProfile || _sessionGamePicker.SelectedIndex < 0) return;
                RefreshGameStretchOptions(_gameKeys[_sessionGamePicker.SelectedIndex], 0, 0);
                SaveGameStretchSelection();
            };
            _sessionStretchResolutionPicker.SelectedIndexChanged += delegate { if (!_loadingCombinedProfile) SaveGameStretchSelection(); };
            Button apply = MakeButton(Localizer.T("gaming.applySelection"), Palette.Surface2, 36); apply.Width = 154; apply.Location = new Point(card.Width - 334, 74); apply.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            apply.Click += delegate { if (_sessionGamePicker.SelectedIndex >= 0) ApplyGameProfile(_gameKeys[_sessionGamePicker.SelectedIndex], _sessionProfilePicker.SelectedIndex); }; card.Controls.Add(apply);
            Button launch = MakeButton(Localizer.T("gaming.launchGame"), Palette.Accent, 36); launch.Width = 160; launch.Location = new Point(card.Width - 170, 74); launch.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            launch.Click += delegate { StartSelectedGame(); }; card.Controls.Add(launch);
            Action layoutSession = delegate
            {
                int actionLeft = card.ClientSize.Width - 334;
                int available = Math.Max(300, actionLeft - 24);
                int gameWidth = Math.Min(300, Math.Max(160, (available - 10) * 3 / 5));
                int profileWidth = Math.Min(220, Math.Max(140, available - gameWidth - 10));
                _sessionGamePicker.Width = gameWidth;
                _sessionProfilePicker.Location = new Point(_sessionGamePicker.Right + 10, 76);
                _sessionProfilePicker.Width = profileWidth;
                apply.Location = new Point(card.ClientSize.Width - 334, 74);
                launch.Location = new Point(card.ClientSize.Width - 170, 74);
                int rowWidth = Math.Max(540, card.ClientSize.Width - 32), gap = 12;
                int col1 = Math.Max(210, (rowWidth - gap * 2) / 3);
                int col2 = Math.Max(200, (rowWidth - col1 - gap * 2) / 2);
                colorLabel.Location = new Point(16, 118); colorLabel.Width = col1;
                stretchMonitorLabel.Location = new Point(16 + col1 + gap, 118); stretchMonitorLabel.Width = col2;
                stretchResolutionLabel.Location = new Point(16 + col1 + gap + col2 + gap, 118); stretchResolutionLabel.Width = Math.Max(150, rowWidth - col1 - col2 - gap * 2);
                _sessionColorProfilePicker.Location = new Point(16, 139); _sessionColorProfilePicker.Width = col1;
                _sessionStretchDisplayPicker.Location = new Point(16 + col1 + gap, 139); _sessionStretchDisplayPicker.Width = col2;
                _sessionStretchResolutionPicker.Location = new Point(16 + col1 + gap + col2 + gap, 139); _sessionStretchResolutionPicker.Width = Math.Max(150, rowWidth - col1 - col2 - gap * 2);
            };
            card.Resize += delegate { layoutSession(); };
            layoutSession();
            Button obsGuide = MakeButton(Localizer.T("gaming.obsGuideButton"), Palette.Surface2, 34); obsGuide.Width = 194; obsGuide.Location = new Point(16, 183);
            obsGuide.Click += delegate { ShowObsStreamingGuide(); }; card.Controls.Add(obsGuide);
            Label obsHint = MakeLabel(Localizer.T("gaming.obsGuideHint"), 8, Palette.Muted, false); obsHint.Location = new Point(220, 183); obsHint.Size = new Size(card.Width - 238, 34); obsHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; card.Controls.Add(obsHint);
            _content.Controls.Add(card);
        }

        private void StartSelectedGame()
        {
            if (_sessionGamePicker == null || _sessionGamePicker.SelectedIndex < 0) return;
            string gameKey = _gameKeys[_sessionGamePicker.SelectedIndex];
            string launchPath; _prefs.GameLaunchPaths.TryGetValue(gameKey, out launchPath);
            if (String.IsNullOrWhiteSpace(launchPath) || !File.Exists(launchPath))
            {
                using (OpenFileDialog dialog = new OpenFileDialog())
                {
                    dialog.Title = Localizer.T("gaming.chooseLaunchFile"); dialog.Filter = "Programme oder Verknüpfungen (*.exe;*.lnk)|*.exe;*.lnk|Alle Dateien (*.*)|*.*";
                    dialog.CheckFileExists = true; dialog.Multiselect = false;
                    if (dialog.ShowDialog(this) != DialogResult.OK) { SetStatus(Localizer.T("gaming.launchCancelled")); return; }
                    launchPath = dialog.FileName; _prefs.GameLaunchPaths[gameKey] = launchPath; _prefs.SelectedGame = gameKey; SavePreferences();
                }
            }
            int profileIndex = _sessionProfilePicker == null ? 1 : Math.Max(0, _sessionProfilePicker.SelectedIndex);
            if (!ApplyGameProfile(gameKey, profileIndex)) return;
            try
            {
                if (!File.Exists(launchPath)) throw new FileNotFoundException(Localizer.T("gaming.launchFailed"), launchPath);
                bool fortnitePresetReapplied = false;
                try { fortnitePresetReapplied = ReapplyFortniteGraphicsForLaunch(gameKey); }
                catch (Exception ex)
                {
                    ThemedDialog.Show(this, Localizer.T("fortnite.title"), Localizer.T("fortnite.launchProtection") + "\r\n\r\n" + DescribeSystemError(ex), false);
                    return;
                }
                if (!ApplyGameStretchForLaunch(gameKey)) return;
                string working = Path.GetDirectoryName(launchPath);
                Process.Start(new ProcessStartInfo(launchPath) { UseShellExecute = true, WorkingDirectory = String.IsNullOrWhiteSpace(working) ? Environment.CurrentDirectory : working });
                SetStatus(Localizer.T("gaming.launchGame") + " · " + Localizer.T(gameKey) + (fortnitePresetReapplied ? " · " + Localizer.T("fortnite.reapplied") : ""));
            }
            catch (Exception ex) { RestoreGameStretchSession(); ThemedDialog.Show(this, Localizer.T("gaming.launchFailed"), DescribeSystemError(ex), false); }
        }

        private bool ApplyGameStretchForLaunch(string gameKey)
        {
            string saved;
            if (!_prefs.GameStretchProfiles.TryGetValue(gameKey, out saved) || String.IsNullOrWhiteSpace(saved)) return true;
            string device; int width, height;
            if (!TryParseGameStretchProfile(saved, out device, out width, out height) || width == 0 || height == 0) return true;
            lock (_gameStretchSessionLock)
                if (!String.IsNullOrEmpty(_gameStretchSessionGameKey)) return String.Equals(_gameStretchSessionGameKey, gameKey, StringComparison.OrdinalIgnoreCase);
            if (!Screen.AllScreens.Any(s => String.Equals(s.DeviceName, device, StringComparison.OrdinalIgnoreCase)))
            {
                ThemedDialog.Show(this, Localizer.T("stretch.title"), Localizer.T("stretch.applyFailed"), false); return false;
            }
            DisplayMode original;
            if (!TryGetCurrentDisplayMode(device, out original)) { ThemedDialog.Show(this, Localizer.T("stretch.title"), Localizer.T("stretch.applyFailed"), false); return false; }
            if (original.dmPelsWidth == width && original.dmPelsHeight == height) return true;
            DisplayMode requested = original; requested.dmPelsWidth = width; requested.dmPelsHeight = height; requested.dmFields |= DisplayFieldWidth | DisplayFieldHeight;
            if (ChangeDisplaySettingsEx(device, ref requested, IntPtr.Zero, DisplayChangeTest, IntPtr.Zero) != 0)
            { ThemedDialog.Show(this, Localizer.T("stretch.title"), Localizer.T("stretch.unsupported"), false); return false; }
            string originalText = FormatDisplayMode(original);
            string state = "game=" + EncodeSessionToken(gameKey) + "\r\ndevice=" + EncodeSessionToken(device) + "\r\noriginal=" + EncodeSessionToken(originalText) + "\r\nstarted=" + DateTime.UtcNow.Ticks.ToString(CultureInfo.InvariantCulture);
            string temporary = GameStretchSessionBackupPath + ".tmp";
            try
            {
                File.WriteAllText(temporary, state, Encoding.UTF8);
                if (File.Exists(GameStretchSessionBackupPath)) File.Replace(temporary, GameStretchSessionBackupPath, null); else File.Move(temporary, GameStretchSessionBackupPath);
                if (ChangeDisplaySettingsEx(device, ref requested, IntPtr.Zero, 0, IntPtr.Zero) != 0) throw new IOException(Localizer.T("stretch.applyFailed"));
                lock (_gameStretchSessionLock)
                {
                    _gameStretchSessionGameKey = gameKey; _gameStretchSessionDevice = device; _gameStretchSessionOriginal = originalText;
                    _gameStretchSessionStartedUtc = DateTime.UtcNow; _gameStretchSessionSawGame = false;
                }
                ScheduleCrosshairRecenter();
                return true;
            }
            catch (Exception ex)
            {
                try { if (File.Exists(temporary)) File.Delete(temporary); } catch { }
                try { ChangeDisplaySettingsEx(device, ref original, IntPtr.Zero, 0, IntPtr.Zero); } catch { }
                try { if (File.Exists(GameStretchSessionBackupPath)) File.Delete(GameStretchSessionBackupPath); } catch { }
                ThemedDialog.Show(this, Localizer.T("stretch.title"), DescribeSystemError(ex), false); return false;
            }
        }

        private bool ReapplyFortniteGraphicsForLaunch(string gameKey)
        {
            if (!String.Equals(gameKey, "game.fortnite", StringComparison.OrdinalIgnoreCase)) return false;
            string path = GetFortniteSettingsPath(), statePath = GetFortniteProfileStatePath(GetFortniteSettingsPath());
            if (!File.Exists(statePath)) return false;
            string state = File.ReadAllText(statePath, Encoding.UTF8).Trim();
            int quality;
            if (String.Equals(state, "High", StringComparison.OrdinalIgnoreCase)) quality = 3;
            else if (String.Equals(state, "Medium", StringComparison.OrdinalIgnoreCase)) quality = 2;
            else if (String.Equals(state, "Potato", StringComparison.OrdinalIgnoreCase)) quality = 1;
            else if (String.Equals(state, "Extreme", StringComparison.OrdinalIgnoreCase)) quality = 0;
            else throw new InvalidDataException("The saved Fortnite graphics profile is not recognized.");
            if (!File.Exists(path)) throw new FileNotFoundException(Localizer.T("fortnite.notFound"), path);

            string[] lines = File.ReadAllLines(path, Encoding.UTF8);
            if (SetFortniteQualityValues(lines, quality) == 0) throw new InvalidDataException(Localizer.T("fortnite.keysMissing"));
            string backup = path + ".freezer-original.bak";
            EnsureFortniteOriginalBackup(path, backup);
            string temporary = path + ".freezer-launch.tmp";
            try
            {
                File.WriteAllLines(temporary, lines, new UTF8Encoding(true));
                File.Replace(temporary, path, null);
            }
            finally { try { if (File.Exists(temporary)) File.Delete(temporary); } catch { } }
            return true;
        }

        private string FortniteWallpaperPath { get { return Path.Combine(_stateRoot, "fortnite-tile.png"); } }

        private void RenderFortniteWallpaperCard()
        {
            RoundPanel card = Card(100);
            Label title = MakeLabel(Localizer.T("fortnite.wallpaperTitle"), 10, Palette.Text, true); title.Location = new Point(16, 10); title.Size = new Size(380, 21); card.Controls.Add(title);
            Label hint = MakeLabel(Localizer.T("fortnite.wallpaperHint"), 8, Palette.Muted, false); hint.Location = new Point(16, 34); hint.Size = new Size(card.Width - 360, 52); hint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; card.Controls.Add(hint);
            Button choose = MakeButton(Localizer.T("fortnite.wallpaperChoose"), Palette.Accent, 34); choose.Width = 146; choose.Location = new Point(card.Width - 318, 31); choose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            choose.Click += delegate { ChooseFortniteWallpaper(); }; card.Controls.Add(choose);
            Button reset = MakeButton(Localizer.T("fortnite.wallpaperReset"), Palette.Surface2, 34); reset.Width = 146; reset.Location = new Point(card.Width - 162, 31); reset.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            reset.Click += delegate { ResetFortniteWallpaper(); }; card.Controls.Add(reset);
            EnableFortniteWallpaperDrop(card);
            _content.Controls.Add(card);
        }

        private void EnableFortniteWallpaperDrop(Control control)
        {
            control.AllowDrop = true;
            control.DragEnter += delegate(object sender, DragEventArgs e) { e.Effect = e.Data != null && e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None; };
            control.DragDrop += delegate(object sender, DragEventArgs e)
            {
                string[] files = e.Data == null ? null : e.Data.GetData(DataFormats.FileDrop) as string[];
                if (files != null && files.Length > 0) SetFortniteWallpaper(files[0]);
            };
            foreach (Control child in control.Controls) EnableFortniteWallpaperDrop(child);
        }

        private void ChooseFortniteWallpaper()
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = Localizer.T("fortnite.wallpaperChoose"); dialog.Filter = "Bilder (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp"; dialog.CheckFileExists = true;
                if (dialog.ShowDialog(this) == DialogResult.OK) SetFortniteWallpaper(dialog.FileName);
            }
        }

        private void SetFortniteWallpaper(string sourcePath)
        {
            try
            {
                if (String.IsNullOrWhiteSpace(sourcePath) || !File.Exists(sourcePath) || new FileInfo(sourcePath).Length > 20L * 1024L * 1024L || !new[] { ".png", ".jpg", ".jpeg", ".bmp" }.Contains(Path.GetExtension(sourcePath).ToLowerInvariant()))
                    throw new InvalidDataException(Localizer.T("fortnite.wallpaperInvalid"));
                string destination = FortniteWallpaperPath, temporary = destination + ".tmp";
                using (Image source = Image.FromFile(sourcePath))
                {
                    if (source.Width < 32 || source.Height < 32 || source.Width > 12000 || source.Height > 12000 || (long)source.Width * (long)source.Height > 16000000L) throw new InvalidDataException(Localizer.T("fortnite.wallpaperInvalid"));
                    double scale = Math.Min(1.0, Math.Min(1280.0 / source.Width, 720.0 / source.Height));
                    int w = Math.Max(1, (int)Math.Round(source.Width * scale)), h = Math.Max(1, (int)Math.Round(source.Height * scale));
                    using (Bitmap bitmap = new Bitmap(w, h, PixelFormat.Format32bppArgb))
                    using (Graphics graphics = Graphics.FromImage(bitmap))
                    {
                        graphics.InterpolationMode = InterpolationMode.HighQualityBicubic; graphics.SmoothingMode = SmoothingMode.HighQuality;
                        graphics.DrawImage(source, new Rectangle(0, 0, w, h)); bitmap.Save(temporary, ImageFormat.Png);
                    }
                }
                if (File.Exists(destination)) File.Replace(temporary, destination, null); else File.Move(temporary, destination);
                _prefs.FortniteBackgroundCustomized = true; SavePreferences(); SetStatus(Localizer.T("fortnite.wallpaperSaved")); ShowPage("games");
            }
            catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("fortnite.wallpaperTitle"), ex is InvalidDataException ? ex.Message : DescribeSystemError(ex), false); }
            finally { try { string temporary = FortniteWallpaperPath + ".tmp"; if (File.Exists(temporary)) File.Delete(temporary); } catch { } }
        }

        private void ResetFortniteWallpaper()
        {
            try { if (File.Exists(FortniteWallpaperPath)) File.Delete(FortniteWallpaperPath); _prefs.FortniteBackgroundCustomized = false; SavePreferences(); SetStatus(Localizer.T("fortnite.wallpaperResetDone")); ShowPage("games"); }
            catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("fortnite.wallpaperTitle"), DescribeSystemError(ex), false); }
        }

        private FlowLayoutPanel BuildGamePage(int page, string[] keys, int width)
        {
            FlowLayoutPanel tiles = new FlowLayoutPanel(); tiles.Width = width; tiles.Height = 252; tiles.WrapContents = false; tiles.Margin = Padding.Empty; tiles.Padding = Padding.Empty; tiles.BackColor = Palette.Background;
            int tileWidth = Math.Max(220, (width - 22) / 3);
            for (int i = page * 3; i < Math.Min(keys.Length, page * 3 + 3); i++) tiles.Controls.Add(RenderGameTile(keys[i], tileWidth));
            return tiles;
        }

        private void ResizeGamePage(FlowLayoutPanel page, int width)
        {
            if (page == null || page.IsDisposed) return;
            page.Width = width; int tileWidth = Math.Max(220, (width - 22) / 3);
            foreach (Control tile in page.Controls) ResizeGameTile(tile, tileWidth);
        }

        private void BeginGameSlide(int direction)
        {
            if (_gameSlideTimer.Enabled || _gameViewport == null || _gameTiles == null || _gameKeys == null) return;
            int pageCount = (_gameKeys.Length + 2) / 3;
            int target = _gamePage + direction;
            if (target < 0 || target >= pageCount) return;
            _gamePageTarget = target; _gameSlideDirection = direction; _gameSlideProgress = 0;
            _gameIncomingTiles = BuildGamePage(target, _gameKeys, _gameViewport.Width);
            _gameIncomingTiles.Location = new Point(direction * _gameViewport.Width, 0);
            _gameViewport.Controls.Add(_gameIncomingTiles); _gameIncomingTiles.BringToFront();
            _gamePrevious.Enabled = false; _gameNext.Enabled = false;
            if (_prefs.Motion == "off" || _prefs.ReduceMotion) { FinishGameSlide(); return; }
            _gameSlideTimer.Interval = 16; _gameSlideTimer.Start();
        }

        private void AnimateGameSlide(object sender, EventArgs e)
        {
            _gameSlideProgress = Math.Min(1.0, _gameSlideProgress + (_prefs.Motion == "slow" ? 0.07 : 0.14));
            PositionGameSlide();
            if (_gameSlideProgress >= 1.0) FinishGameSlide();
        }

        private void PositionGameSlide()
        {
            if (_gameViewport == null || _gameTiles == null || _gameIncomingTiles == null) return;
            int width = _gameViewport.ClientSize.Width;
            double eased = 1.0 - Math.Pow(1.0 - _gameSlideProgress, 3.0);
            int offset = (int)Math.Round(width * eased);
            _gameTiles.Location = new Point(-_gameSlideDirection * offset, 0);
            _gameIncomingTiles.Location = new Point(_gameSlideDirection * (width - offset), 0);
        }

        private void FinishGameSlide()
        {
            _gameSlideTimer.Stop();
            if (_gameViewport == null || _gameTiles == null || _gameIncomingTiles == null) return;
            FlowLayoutPanel old = _gameTiles; FlowLayoutPanel incoming = _gameIncomingTiles;
            _gameViewport.Controls.Remove(old); old.Dispose(); incoming.Location = Point.Empty;
            _gameTiles = incoming; _gameIncomingTiles = null; _gamePage = _gamePageTarget;
            int pageCount = (_gameKeys.Length + 2) / 3;
            _gamePageLabel.Text = String.Format(CultureInfo.CurrentCulture, Localizer.T("games.page"), _gamePage + 1, pageCount);
            _gamePrevious.Enabled = _gamePage > 0; _gameNext.Enabled = _gamePage + 1 < pageCount;
        }

        private void StopGameSlide()
        {
            _gameSlideTimer.Stop();
            if (_gameIncomingTiles != null && !_gameIncomingTiles.IsDisposed) _gameIncomingTiles.Dispose();
            _gameIncomingTiles = null; _gameSlideProgress = 0;
        }

        private void ApplyX3dProfile(Optimization item)
        {
            string cpu = ReadCpuName();
            if (cpu.IndexOf("X3D", StringComparison.OrdinalIgnoreCase) < 0)
            {
                ThemedDialog.Show(this, item.Title, String.Format(CultureInfo.CurrentCulture, Localizer.T("x3d.notDetected"), String.IsNullOrWhiteSpace(cpu) ? "—" : cpu), false);
                return;
            }
            string details = item.Description + "\r\n\r\n" + String.Format(CultureInfo.CurrentCulture, Localizer.T("x3d.detected"), cpu) + "\r\n\r\n" + Localizer.T("gaming.boostDetails") + "\r\n\r\n" + Localizer.T("repair.userRights");
            if (!ThemedDialog.Confirm(this, item.Title, details)) return;
            List<string> applied = new List<string>();
            try
            {
                Optimization mode = _optimizations.First(x => x.Key == "game_mode");
                Optimization dvr = _optimizations.First(x => x.Key == "game_dvr");
                if (!_tweaks.IsActive("game_mode")) { _tweaks.Apply("game_mode", mode.Edits); applied.Add("game_mode"); }
                if (!_tweaks.IsActive("game_dvr")) { _tweaks.Apply("game_dvr", dvr.Edits); applied.Add("game_dvr"); }
                QueueGamingSessionBoost();
                SetStatus(Localizer.T("games.applied")); RefreshGamingModeButton();
                if (_page == "optimizations") ShowPage(_page);
            }
            catch (Exception ex)
            {
                for (int i = applied.Count - 1; i >= 0; i--) try { _tweaks.Restore(applied[i]); } catch { }
                ThemedDialog.Show(this, Localizer.T("error.optimization"), DescribeSystemError(ex), false);
                RefreshGamingModeButton();
            }
        }

        private static string ReadCpuName()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0", false))
                    return key == null ? String.Empty : Convert.ToString(key.GetValue("ProcessorNameString", String.Empty), CultureInfo.CurrentCulture).Trim();
            }
            catch { return String.Empty; }
        }

        private void RunDesktopAssistant(Optimization item)
        {
            string cpu = ReadCpuName(); Reading reading = _sampler.Sample();
            List<string> graphics = ReadGpuNames();
            List<string> suggested = new List<string>();
            if (!_tweaks.IsActive("game_mode")) suggested.Add("game_mode");
            if (reading.RamTotalMb <= 16384 && !_tweaks.IsActive("game_dvr")) suggested.Add("game_dvr");
            if (reading.RamTotalMb > 0 && reading.RamTotalMb <= 8192 && !_tweaks.IsActive("visual_effects")) suggested.Add("visual_effects");

            StringBuilder report = new StringBuilder();
            report.AppendLine(Localizer.T("desktop.cpu") + ": " + (String.IsNullOrWhiteSpace(cpu) ? "—" : cpu));
            report.AppendLine(Localizer.T("desktop.logicalCores") + ": " + Environment.ProcessorCount.ToString(CultureInfo.InvariantCulture));
            report.AppendLine(Localizer.T("desktop.ram") + ": " + (reading.RamTotalMb > 0 ? (reading.RamTotalMb / 1024.0).ToString("0.0", CultureInfo.CurrentCulture) + " GB" : "—"));
            report.AppendLine(Localizer.T("desktop.gpu") + ": " + (graphics.Count > 0 ? String.Join(", ", graphics.Take(2)) : Localizer.T("desktop.noGpu")));
            report.AppendLine(); report.AppendLine(Localizer.T("desktop.recommendations") + ":");
            report.AppendLine("• " + Localizer.T("desktop.suggestMode"));
            if (reading.RamTotalMb <= 16384) report.AppendLine("• " + Localizer.T("desktop.suggestCapture"));
            if (reading.RamTotalMb > 0 && reading.RamTotalMb <= 8192) report.AppendLine("• " + Localizer.T("desktop.suggestVisual"));
            if (cpu.IndexOf("X3D", StringComparison.OrdinalIgnoreCase) >= 0) report.AppendLine("• " + Localizer.T("desktop.suggestX3d"));
            if (graphics.Count > 0) report.AppendLine("• " + Localizer.T("optitem.open_graphics.title") + ": " + Localizer.T("optitem.open_graphics.desc"));
            report.AppendLine(); report.Append(Localizer.T("desktop.body"));

            string prompt = item.Title + "\r\n\r\n" + report.ToString();
            if (suggested.Count == 0)
            {
                ThemedDialog.Show(this, item.Title, prompt, false); return;
            }
            if (!ThemedDialog.Confirm(this, Localizer.T("desktop.apply"), prompt)) return;
            List<string> applied = new List<string>();
            try
            {
                foreach (string key in suggested)
                {
                    Optimization option = _optimizations.First(x => x.Key == key);
                    _tweaks.Apply(key, option.Edits); applied.Add(key);
                }
                QueueGamingSessionBoost();
                RefreshGamingModeButton(); SetStatus(Localizer.T("optimization.done")); ShowPage("optimizations");
            }
            catch (Exception ex)
            {
                for (int i = applied.Count - 1; i >= 0; i--) try { _tweaks.Restore(applied[i]); } catch { }
                ThemedDialog.Show(this, Localizer.T("error.optimization"), DescribeSystemError(ex), false); RefreshGamingModeButton();
            }
        }

        private static List<string> ReadGpuNames()
        {
            List<string> names = new List<string>();
            try
            {
                EnumerationOptions options = new EnumerationOptions(); options.Timeout = TimeSpan.FromSeconds(3);
                using (ManagementObjectSearcher search = new ManagementObjectSearcher(new ManagementScope(@"\\.\root\CIMV2"), new ObjectQuery("SELECT Name FROM Win32_VideoController"), options))
                using (ManagementObjectCollection results = search.Get())
                {
                    foreach (ManagementObject item in results)
                    {
                        using (item)
                        {
                            string name = Convert.ToString(item["Name"], CultureInfo.CurrentCulture);
                            if (String.IsNullOrWhiteSpace(name)) continue;
                            string normalized = name.Trim();
                            bool virtualDisplay = normalized.IndexOf("virtual", StringComparison.OrdinalIgnoreCase) >= 0
                                || normalized.IndexOf("parsec", StringComparison.OrdinalIgnoreCase) >= 0
                                || normalized.IndexOf("indirect display", StringComparison.OrdinalIgnoreCase) >= 0
                                || normalized.IndexOf("remote display", StringComparison.OrdinalIgnoreCase) >= 0;
                            if (!virtualDisplay && !names.Contains(normalized)) names.Add(normalized);
                        }
                    }
                }
            }
            catch { }
            return names;
        }

        private void QueueHardwareIdentityRead()
        {
            if (Interlocked.Exchange(ref _hardwareIdentityQueued, 1) != 0) return;
            ThreadPool.QueueUserWorkItem(delegate
            {
                string cpu = ReadCpuName();
                List<string> gpuNames = ReadGpuNames();
                string gpu = gpuNames.Count > 0 ? String.Join(" / ", gpuNames.Take(2).Select(CleanHardwareName)) : "";
                string ramType = ReadRamTypeName();
                string board = ReadMainboardName();
                string storage = ReadStorageNames();
                try
                {
                    if (IsDisposed || !IsHandleCreated) return;
                    BeginInvoke((MethodInvoker)delegate
                    {
                        if (IsDisposed) return;
                        _cpuModelName = CleanHardwareName(cpu);
                        _gpuModelName = gpu;
                        _ramTypeName = ramType;
                        _boardModelName = CleanHardwareName(board);
                        _storageModelName = CleanHardwareName(storage);
                        UpdateHomeHardwareSummary(_latest);
                    });
                }
                catch { }
            });
        }

        private static string CleanHardwareName(string value)
        {
            if (String.IsNullOrWhiteSpace(value)) return "";
            string clean = Regex.Replace(value, @"[\p{C}]+", " ");
            clean = Regex.Replace(clean, @"\s+", " ").Trim();
            return clean;
        }

        private static string ReadMainboardName()
        {
            try
            {
                using (ManagementObjectSearcher search = new ManagementObjectSearcher(new ManagementScope(@"\\.\root\CIMV2"), new ObjectQuery("SELECT Manufacturer, Product FROM Win32_BaseBoard"), new EnumerationOptions { Timeout = TimeSpan.FromSeconds(3) }))
                using (ManagementObjectCollection rows = search.Get())
                {
                    foreach (ManagementObject row in rows)
                    using (row)
                    {
                        string maker = Convert.ToString(row["Manufacturer"], CultureInfo.CurrentCulture);
                        string model = Convert.ToString(row["Product"], CultureInfo.CurrentCulture);
                        string result = String.Join(" ", new[] { maker, model }.Where(x => !String.IsNullOrWhiteSpace(x)));
                        if (!String.IsNullOrWhiteSpace(result)) return result;
                    }
                }
            }
            catch { }
            return "";
        }

        private static string ReadRamTypeName()
        {
            try
            {
                HashSet<string> types = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                uint fastest = 0;
                using (ManagementObjectSearcher search = new ManagementObjectSearcher(new ManagementScope(@"\\.\root\CIMV2"), new ObjectQuery("SELECT SMBIOSMemoryType, ConfiguredClockSpeed, Speed FROM Win32_PhysicalMemory"), new EnumerationOptions { Timeout = TimeSpan.FromSeconds(3) }))
                using (ManagementObjectCollection rows = search.Get())
                {
                    foreach (ManagementObject row in rows)
                    using (row)
                    {
                        uint type = 0, speed = 0;
                        try { type = Convert.ToUInt32(row["SMBIOSMemoryType"], CultureInfo.InvariantCulture); } catch { }
                        try { speed = Convert.ToUInt32(row["ConfiguredClockSpeed"], CultureInfo.InvariantCulture); } catch { }
                        if (speed == 0) try { speed = Convert.ToUInt32(row["Speed"], CultureInfo.InvariantCulture); } catch { }
                        if (speed > fastest) fastest = speed;
                        string ddr = type == 20 ? "DDR" : type == 21 ? "DDR2" : type == 24 ? "DDR3" : type == 26 ? "DDR4" : type == 34 ? "DDR5" : type == 30 ? "LPDDR4" : type == 35 ? "LPDDR5" : "";
                        if (ddr.Length > 0) types.Add(ddr);
                    }
                }
                string kind = types.Count == 1 ? types.First() : types.Count > 1 ? "Mixed DDR" : "";
                if (fastest > 0) kind += (kind.Length > 0 ? " · " : "") + fastest.ToString(CultureInfo.InvariantCulture) + " MT/s";
                return kind;
            }
            catch { return ""; }
        }

        private static string ReadStorageNames()
        {
            try
            {
                List<string> models = new List<string>();
                using (ManagementObjectSearcher search = new ManagementObjectSearcher(new ManagementScope(@"\\.\root\CIMV2"), new ObjectQuery("SELECT Model, InterfaceType FROM Win32_DiskDrive"), new EnumerationOptions { Timeout = TimeSpan.FromSeconds(3) }))
                using (ManagementObjectCollection rows = search.Get())
                {
                    foreach (ManagementObject row in rows)
                    using (row)
                    {
                        string interfaceType = Convert.ToString(row["InterfaceType"], CultureInfo.CurrentCulture);
                        if (String.Equals(interfaceType, "USB", StringComparison.OrdinalIgnoreCase)) continue;
                        string model = CleanHardwareName(Convert.ToString(row["Model"], CultureInfo.CurrentCulture));
                        if (model.Length > 0 && !models.Contains(model, StringComparer.OrdinalIgnoreCase)) models.Add(model);
                        if (models.Count >= 2) break;
                    }
                }
                return String.Join(" · ", models);
            }
            catch { }
            return "";
        }

        private void UpdateHomeHardwareSummary(Reading reading)
        {
            string loading = Localizer.T("home.hardwareLoading");
            GaugeControl cpuGauge, gpuGauge, ramGauge;
            if (_gauges.TryGetValue("cpu", out cpuGauge) && cpuGauge != null && !cpuGauge.IsDisposed)
                cpuGauge.Details = String.IsNullOrWhiteSpace(_cpuModelName) ? loading : _cpuModelName;
            if (_gauges.TryGetValue("gpu", out gpuGauge) && gpuGauge != null && !gpuGauge.IsDisposed)
                gpuGauge.Details = String.IsNullOrWhiteSpace(_gpuModelName) ? loading : _gpuModelName;
            if (_gauges.TryGetValue("ram", out ramGauge) && ramGauge != null && !ramGauge.IsDisposed)
            {
                List<string> ramParts = new List<string>();
                if (reading != null && reading.RamTotalMb > 0) ramParts.Add(Math.Round(reading.RamTotalMb / 1024.0).ToString("0", CultureInfo.CurrentCulture) + " GB");
                if (!String.IsNullOrWhiteSpace(_ramTypeName)) ramParts.Add(_ramTypeName);
                ramGauge.Details = ramParts.Count == 0 ? loading : String.Join(" · ", ramParts);
            }
            if (_homeBoardName != null && !_homeBoardName.IsDisposed)
                _homeBoardName.Text = "• " + Localizer.T("home.mainboard") + " — " + (String.IsNullOrWhiteSpace(_boardModelName) ? loading : _boardModelName);
            if (_homeStorageName != null && !_homeStorageName.IsDisposed)
                _homeStorageName.Text = "• " + Localizer.T("home.storage") + " — " + (String.IsNullOrWhiteSpace(_storageModelName) ? loading : _storageModelName);
        }

        private void ShowObsStreamingGuide()
        {
            string gpu = String.IsNullOrWhiteSpace(_gpuModelName) ? Localizer.T("diagnostic.notAvailable") : _gpuModelName;
            string primary = gpu.Split('/').FirstOrDefault() ?? "";
            string encoderKey = primary.IndexOf("NVIDIA", StringComparison.OrdinalIgnoreCase) >= 0 ? "gaming.obsNvidia"
                : (primary.IndexOf("AMD", StringComparison.OrdinalIgnoreCase) >= 0 || primary.IndexOf("Radeon", StringComparison.OrdinalIgnoreCase) >= 0) ? "gaming.obsAmd"
                : (primary.IndexOf("Intel", StringComparison.OrdinalIgnoreCase) >= 0) ? "gaming.obsIntel" : "gaming.obsUnknown";
            string message = Localizer.T(encoderKey).Replace("{0}", gpu)
                + "\r\n\r\n" + Localizer.T("gaming.obsCommon")
                + "\r\n\r\n" + Localizer.T("gaming.streamerDetails")
                + "\r\n\r\n" + Localizer.T("gaming.obsNotice");
            ThemedDialog.Show(this, Localizer.T("gaming.obsGuideTitle"), message, false);
        }

        private void ShowRestorePointHelp()
        {
            ThemedDialog.Show(this, Localizer.T("restore.infoTitle"), Localizer.T("restore.infoBody"), false);
        }

        private void ShowWelcomeDialog()
        {
            string message = Localizer.T("welcome.body") + "\r\n\r\n" + Localizer.T("tutorial.body") + "\r\n\r\n" + Localizer.T("restore.infoBody");
            ThemedDialog.Show(this, Localizer.T("welcome.title"), message, false);
        }

        private void OpenSystemProtection()
        {
            try { Process.Start(new ProcessStartInfo("SystemPropertiesProtection.exe") { UseShellExecute = true }); }
            catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("error.action"), DescribeSystemError(ex), false); }
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct DisplayMode
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
            public short dmSpecVersion, dmDriverVersion, dmSize, dmDriverExtra;
            public int dmFields;
            public int dmPositionX, dmPositionY, dmDisplayOrientation, dmDisplayFixedOutput;
            public short dmColor, dmDuplex, dmYResolution, dmTTOption, dmCollate;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmFormName;
            public short dmLogPixels;
            public int dmBitsPerPel, dmPelsWidth, dmPelsHeight, dmDisplayFlags, dmDisplayFrequency;
            public int dmICMMethod, dmICMIntent, dmMediaType, dmDitherType, dmReserved1, dmReserved2;
            public int dmPanningWidth, dmPanningHeight;
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool EnumDisplaySettings(string deviceName, int modeNumber, ref DisplayMode mode);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int ChangeDisplaySettingsEx(string deviceName, ref DisplayMode mode, IntPtr window, int flags, IntPtr parameter);
        private const int CurrentDisplaySettings = -1;
        private const int DisplayChangeTest = 0x00000002;
        private const int DisplayFieldBitsPerPixel = 0x00040000;
        private const int DisplayFieldWidth = 0x00080000;
        private const int DisplayFieldHeight = 0x00100000;
        private const int DisplayFieldFrequency = 0x00400000;
        private const int DisplayFieldPosition = 0x00000020;

        private static bool TryGetCurrentDisplayMode(string deviceName, out DisplayMode mode)
        {
            mode = new DisplayMode(); mode.dmSize = (short)Marshal.SizeOf(typeof(DisplayMode));
            return EnumDisplaySettings(deviceName, CurrentDisplaySettings, ref mode);
        }

        private sealed class StretchResolutionOption
        {
            public readonly int Width, Height;
            public StretchResolutionOption(int width, int height) { Width = width; Height = height; }
            public override string ToString() { return Width.ToString(CultureInfo.InvariantCulture) + " × " + Height.ToString(CultureInfo.InvariantCulture); }
        }

        private void RenderPotatoGraphics()
        {
            AddPageHeading(Localizer.T("potato.title"), Localizer.T("potato.subtitle"));
            string path = GetFortniteSettingsPath();
            string backup = path + ".freezer-original.bak";

            RoundPanel statusCard = Card(74);
            Label gpuStatus = MakeLabel(Localizer.T("potato.detecting"), 10, Palette.Text, true);
            gpuStatus.Location = new Point(16, 12); gpuStatus.Size = new Size(statusCard.Width - 32, 23);
            gpuStatus.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; statusCard.Controls.Add(gpuStatus);
            Label fileStatus = MakeLabel(Localizer.T("potato.path") + ": " + path, 8, Palette.Muted, false);
            fileStatus.Location = new Point(16, 39); fileStatus.Size = new Size(statusCard.Width - 32, 20);
            fileStatus.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; statusCard.Controls.Add(fileStatus);
            _content.Controls.Add(statusCard);

            Button[] profileButtons = new Button[3];
            AddPotatoProfileCard("potato.normal", "potato.normalDesc", profileButtons, 0, false);
            AddPotatoProfileCard("potato.light", "potato.lightDesc", profileButtons, 1, false);
            AddPotatoProfileCard("potato.extreme", "potato.extremeDesc", profileButtons, 2, true);

            RoundPanel warningCard = Card(146);
            Label readOnlyWarning = MakeLabel(Localizer.T("potato.readOnly"), 9, Palette.Muted, false);
            readOnlyWarning.Location = new Point(16, 13); readOnlyWarning.Size = new Size(warningCard.Width - 32, 55);
            readOnlyWarning.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; warningCard.Controls.Add(readOnlyWarning);
            Label driverNote = MakeLabel(Localizer.T("potato.driverNote"), 9, Palette.Muted, false);
            driverNote.Location = new Point(16, 75); driverNote.Size = new Size(warningCard.Width - 32, 58);
            driverNote.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; warningCard.Controls.Add(driverNote);
            _content.Controls.Add(warningCard);

            RoundPanel resetCard = Card(76);
            Label resetHint = MakeLabel(Localizer.T("potato.restoreConfirm"), 9, Palette.Muted, false);
            resetHint.Location = new Point(16, 13); resetHint.Size = new Size(Math.Max(180, resetCard.Width - 245), 48);
            resetHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; resetCard.Controls.Add(resetHint);
            Button reset = MakeButton(Localizer.T("potato.reset"), Palette.Accent, 40);
            reset.Width = 210; reset.Location = new Point(resetCard.Width - 226, 17);
            reset.Anchor = AnchorStyles.Top | AnchorStyles.Right; reset.Enabled = File.Exists(backup);
            reset.Click += delegate { RestoreFortniteOriginal(path, backup, true); };
            resetCard.Controls.Add(reset); _content.Controls.Add(resetCard);

            Task.Factory.StartNew<List<string>>(delegate { return ReadGpuNames(); }).ContinueWith(delegate(Task<List<string>> task)
            {
                try
                {
                    List<string> gpuNames = task.Status == TaskStatus.RanToCompletion ? task.Result : new List<string>();
                    bool nvidia = gpuNames.Any(x => x.IndexOf("NVIDIA", StringComparison.OrdinalIgnoreCase) >= 0);
                    BeginInvoke((Action)delegate
                    {
                        if (IsDisposed || _page != "potatoGraphics" || gpuStatus.IsDisposed) return;
                            _potatoGpuChecked = true; _potatoNvidiaAvailable = nvidia;
                        gpuStatus.Text = nvidia
                            ? String.Format(CultureInfo.CurrentCulture, Localizer.T("potato.nvidiaReady"), String.Join(", ", gpuNames.Where(x => x.IndexOf("NVIDIA", StringComparison.OrdinalIgnoreCase) >= 0).ToArray()))
                            : Localizer.T("potato.unsupported");
                        gpuStatus.ForeColor = nvidia ? Palette.Green : Palette.Accent;
                        bool fileExists = File.Exists(path);
                        if (!fileExists) fileStatus.Text = Localizer.T("potato.noFile") + "  ·  " + path;
                        foreach (Button button in profileButtons) if (button != null && !button.IsDisposed) button.Enabled = nvidia && fileExists;
                        reset.Enabled = File.Exists(backup);
                    });
                }
                catch { }
            });
        }

        private void AddPotatoProfileCard(string titleKey, string descriptionKey, Button[] buttons, int profile, bool isExtreme)
        {
            RoundPanel card = Card(126);
            Label title = MakeLabel(Localizer.T(titleKey), 12, Palette.Text, true);
            title.Location = new Point(16, 13); title.Size = new Size(card.Width - 220, 24);
            title.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; card.Controls.Add(title);
            Label description = MakeLabel(Localizer.T(descriptionKey), 9, Palette.Muted, false);
            description.Location = new Point(16, 43); description.Size = new Size(Math.Max(180, card.Width - 220), 66);
            description.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; card.Controls.Add(description);
            Button apply = MakeButton(Localizer.T("potato.apply"), isExtreme ? Palette.Accent : Palette.Surface2, 40);
            apply.Width = 180; apply.Location = new Point(card.Width - 196, 43);
            apply.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            apply.Click += delegate { ApplyFortnitePotatoProfile(profile); };
            card.Controls.Add(apply); buttons[profile] = apply;
            _content.Controls.Add(card);
        }

        private void RenderStretchResolutionPage()
        {
            AddPageHeading(Localizer.T("stretch.title"), Localizer.T("stretch.pageSubtitle"));

            RoundPanel card = Card(305);
            Label monitorLabel = MakeLabel(Localizer.T("stretch.monitor"), 10, Palette.Text, true);
            monitorLabel.Location = new Point(16, 18); monitorLabel.Size = new Size(170, 22); card.Controls.Add(monitorLabel);
            ComboBox monitorPicker = MakeCombo(new string[0]); monitorPicker.DropDownStyle = ComboBoxStyle.DropDownList;
            monitorPicker.Location = new Point(190, 13); monitorPicker.Size = new Size(Math.Max(260, card.Width - 220), 32);
            monitorPicker.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            foreach (Screen screen in Screen.AllScreens) monitorPicker.Items.Add(new CrosshairDisplayOption(screen));
            card.Controls.Add(monitorPicker);

            Label currentTitle = MakeLabel(Localizer.T("stretch.currentMode"), 9, Palette.Muted, false);
            currentTitle.Location = new Point(16, 54); currentTitle.Size = new Size(170, 20); card.Controls.Add(currentTitle);
            Label currentMode = MakeLabel("—", 10, Palette.Text, true);
            currentMode.Location = new Point(190, 54); currentMode.Size = new Size(Math.Max(260, card.Width - 220), 20);
            currentMode.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; card.Controls.Add(currentMode);

            Label presetLabel = MakeLabel(Localizer.T("stretch.availableModes"), 10, Palette.Text, true);
            presetLabel.Location = new Point(16, 91); presetLabel.Size = new Size(170, 22); card.Controls.Add(presetLabel);
            ComboBox presetPicker = MakeCombo(new string[0]); presetPicker.DropDownStyle = ComboBoxStyle.DropDownList;
            presetPicker.Location = new Point(190, 86); presetPicker.Size = new Size(Math.Max(260, card.Width - 220), 32);
            presetPicker.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; card.Controls.Add(presetPicker);

            Label customLabel = MakeLabel(Localizer.T("stretch.customSize"), 10, Palette.Text, true);
            customLabel.Location = new Point(16, 137); customLabel.Size = new Size(170, 22); card.Controls.Add(customLabel);
            NumericUpDown widthPicker = new NumericUpDown(); widthPicker.Minimum = 640; widthPicker.Maximum = 16384; widthPicker.Increment = 1;
            widthPicker.Location = new Point(190, 132); widthPicker.Size = new Size(130, 30); widthPicker.TextAlign = HorizontalAlignment.Center;
            widthPicker.BackColor = Palette.Surface2; widthPicker.ForeColor = Palette.Text; widthPicker.BorderStyle = BorderStyle.FixedSingle;
            card.Controls.Add(widthPicker);
            Label multiply = MakeLabel("×", 12, Palette.Muted, true); multiply.Location = new Point(328, 135); multiply.Size = new Size(24, 24); card.Controls.Add(multiply);
            NumericUpDown heightPicker = new NumericUpDown(); heightPicker.Minimum = 480; heightPicker.Maximum = 16384; heightPicker.Increment = 1;
            heightPicker.Location = new Point(360, 132); heightPicker.Size = new Size(130, 30); heightPicker.TextAlign = HorizontalAlignment.Center;
            heightPicker.BackColor = Palette.Surface2; heightPicker.ForeColor = Palette.Text; heightPicker.BorderStyle = BorderStyle.FixedSingle;
            card.Controls.Add(heightPicker);

            Label status = MakeLabel("", 9, Palette.Muted, false); status.Location = new Point(16, 178);
            status.Size = new Size(Math.Max(400, card.Width - 32), 40); status.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; card.Controls.Add(status);

            Button restore = MakeButton(Localizer.T("stretch.restore"), Palette.Surface2, 40);
            restore.Width = 200; restore.Location = new Point(16, 238); restore.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            card.Controls.Add(restore);
            Button apply = MakeButton(Localizer.T("stretch.apply"), Palette.Accent, 40);
            apply.Width = 200; apply.Location = new Point(card.Width - 216, 238); apply.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            card.Controls.Add(apply);
            _content.Controls.Add(card);

            RoundPanel note = Card(92);
            Label noteText = MakeLabel(Localizer.T("stretch.hint"), 9, Palette.Muted, false);
            noteText.Location = new Point(16, 16); noteText.Size = new Size(Math.Max(400, note.Width - 32), 58);
            noteText.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; note.Controls.Add(noteText); _content.Controls.Add(note);

            Action loadModes = delegate
            {
                CrosshairDisplayOption selected = monitorPicker.SelectedItem as CrosshairDisplayOption;
                if (selected == null)
                {
                    currentMode.Text = Localizer.T("stretch.noMonitors"); presetPicker.Items.Clear(); restore.Enabled = false; apply.Enabled = false; return;
                }
                DisplayMode current;
                if (!TryGetCurrentDisplayMode(selected.Screen.DeviceName, out current))
                {
                    currentMode.Text = Localizer.T("stretch.applyFailed"); presetPicker.Items.Clear(); restore.Enabled = false; apply.Enabled = false; return;
                }
                apply.Enabled = true;
                currentMode.Text = current.dmPelsWidth.ToString(CultureInfo.InvariantCulture) + " × " + current.dmPelsHeight.ToString(CultureInfo.InvariantCulture)
                    + (current.dmDisplayFrequency > 1 ? " · " + current.dmDisplayFrequency.ToString(CultureInfo.InvariantCulture) + " Hz" : "");
                widthPicker.Value = Math.Max(widthPicker.Minimum, Math.Min(widthPicker.Maximum, current.dmPelsWidth));
                heightPicker.Value = Math.Max(heightPicker.Minimum, Math.Min(heightPicker.Maximum, current.dmPelsHeight));

                presetPicker.BeginUpdate(); presetPicker.Items.Clear();
                HashSet<string> known = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                Action<int, int> addMode = delegate(int w, int h)
                {
                    if (w < 640 || h < 480 || w > 16384 || h > 16384) return;
                    string id = w.ToString(CultureInfo.InvariantCulture) + "x" + h.ToString(CultureInfo.InvariantCulture);
                    if (known.Add(id)) presetPicker.Items.Add(new StretchResolutionOption(w, h));
                };
                for (int i = 0; i < 512; i++)
                {
                    DisplayMode mode = new DisplayMode(); mode.dmSize = (short)Marshal.SizeOf(typeof(DisplayMode));
                    if (!EnumDisplaySettings(selected.Screen.DeviceName, i, ref mode)) break;
                    addMode(mode.dmPelsWidth, mode.dmPelsHeight);
                }
                int[,] common = { { 1280, 720 }, { 1280, 960 }, { 1280, 1024 }, { 1440, 1080 }, { 1600, 900 }, { 1600, 1080 }, { 1720, 1080 }, { 1750, 1080 }, { 1920, 1080 } };
                for (int i = 0; i < common.GetLength(0); i++)
                {
                    DisplayMode suggested = current; suggested.dmPelsWidth = common[i, 0]; suggested.dmPelsHeight = common[i, 1];
                    suggested.dmFields |= DisplayFieldWidth | DisplayFieldHeight;
                    suggested.dmFields &= ~DisplayFieldFrequency;
                    if (ChangeDisplaySettingsEx(selected.Screen.DeviceName, ref suggested, IntPtr.Zero, DisplayChangeTest, IntPtr.Zero) == 0)
                        addMode(common[i, 0], common[i, 1]);
                }
                presetPicker.EndUpdate();
                StretchResolutionOption currentOption = presetPicker.Items.Cast<StretchResolutionOption>()
                    .FirstOrDefault(x => x.Width == current.dmPelsWidth && x.Height == current.dmPelsHeight);
                if (currentOption != null) presetPicker.SelectedItem = currentOption;
                string saved; restore.Enabled = _prefs.StretchOriginalModes.TryGetValue(selected.Screen.DeviceName, out saved);
                status.Text = restore.Enabled ? Localizer.T("stretch.kept") : "";
            };

            monitorPicker.SelectedIndexChanged += delegate { loadModes(); };
            presetPicker.SelectedIndexChanged += delegate
            {
                StretchResolutionOption option = presetPicker.SelectedItem as StretchResolutionOption;
                if (option != null) { widthPicker.Value = option.Width; heightPicker.Value = option.Height; }
            };
            if (monitorPicker.Items.Count > 0)
            {
                int primaryIndex = 0;
                for (int i = 0; i < monitorPicker.Items.Count; i++)
                    if (((CrosshairDisplayOption)monitorPicker.Items[i]).Screen.Primary) { primaryIndex = i; break; }
                monitorPicker.SelectedIndex = primaryIndex;
            }
            else loadModes();

            restore.Click += delegate
            {
                CrosshairDisplayOption selected = monitorPicker.SelectedItem as CrosshairDisplayOption;
                if (selected == null) return;
                if (RestoreStretchResolution(selected.Screen.DeviceName))
                {
                    ScheduleCrosshairRecenter(); loadModes(); status.Text = Localizer.T("stretch.reverted"); SetStatus(Localizer.T("stretch.reverted"));
                }
                else ThemedDialog.Show(this, Localizer.T("stretch.title"), Localizer.T("stretch.applyFailed"), false);
            };
            apply.Click += delegate
            {
                CrosshairDisplayOption selected = monitorPicker.SelectedItem as CrosshairDisplayOption;
                if (selected == null) { ThemedDialog.Show(this, Localizer.T("stretch.title"), Localizer.T("stretch.noMonitors"), false); return; }
                DisplayMode original;
                if (!TryGetCurrentDisplayMode(selected.Screen.DeviceName, out original))
                { ThemedDialog.Show(this, Localizer.T("stretch.title"), Localizer.T("stretch.applyFailed"), false); return; }

                int requestedWidth = Decimal.ToInt32(widthPicker.Value), requestedHeight = Decimal.ToInt32(heightPicker.Value);
                DisplayMode requested = original; requested.dmPelsWidth = requestedWidth; requested.dmPelsHeight = requestedHeight;
                requested.dmFields |= DisplayFieldWidth | DisplayFieldHeight;
                if (ChangeDisplaySettingsEx(selected.Screen.DeviceName, ref requested, IntPtr.Zero, DisplayChangeTest, IntPtr.Zero) != 0)
                {
                    DisplayMode fallback = original; fallback.dmPelsWidth = requestedWidth; fallback.dmPelsHeight = requestedHeight;
                    fallback.dmFields |= DisplayFieldWidth | DisplayFieldHeight; fallback.dmFields &= ~DisplayFieldFrequency;
                    if (ChangeDisplaySettingsEx(selected.Screen.DeviceName, ref fallback, IntPtr.Zero, DisplayChangeTest, IntPtr.Zero) != 0)
                    { ThemedDialog.Show(this, Localizer.T("stretch.title"), Localizer.T("stretch.unsupported"), false); return; }
                    requested = fallback;
                }

                bool hadBaseline = _prefs.StretchOriginalModes.ContainsKey(selected.Screen.DeviceName);
                if (!hadBaseline) { _prefs.StretchOriginalModes[selected.Screen.DeviceName] = FormatDisplayMode(original); SavePreferences(); }
                if (ChangeDisplaySettingsEx(selected.Screen.DeviceName, ref requested, IntPtr.Zero, 0, IntPtr.Zero) != 0)
                {
                    if (!hadBaseline) { _prefs.StretchOriginalModes.Remove(selected.Screen.DeviceName); SavePreferences(); }
                    ThemedDialog.Show(this, Localizer.T("stretch.title"), Localizer.T("stretch.applyFailed"), false); return;
                }
                ScheduleCrosshairRecenter();
                if (!ConfirmStretchResolution(this))
                {
                    ChangeDisplaySettingsEx(selected.Screen.DeviceName, ref original, IntPtr.Zero, 0, IntPtr.Zero);
                    ScheduleCrosshairRecenter();
                    if (!hadBaseline) { _prefs.StretchOriginalModes.Remove(selected.Screen.DeviceName); SavePreferences(); }
                    loadModes(); status.Text = Localizer.T("stretch.reverted"); SetStatus(Localizer.T("stretch.reverted")); return;
                }
                loadModes(); status.Text = Localizer.T("stretch.modeApplied"); SetStatus(Localizer.T("stretch.modeApplied"));
            };
        }

        private void ShowStretchResolutionDialog()
        {
            using (Form form = new Form())
            {
                form.Text = Localizer.T("stretch.title"); form.FormBorderStyle = FormBorderStyle.None; form.StartPosition = FormStartPosition.CenterParent;
                form.ClientSize = new Size(620, 350); form.BackColor = Palette.Surface; form.ForeColor = Palette.Text; form.Font = UiFontCache.Get("Segoe UI", 9F, FontStyle.Regular); form.ShowInTaskbar = false;
                Panel header = new Panel(); header.Dock = DockStyle.Top; header.Height = 56; header.BackColor = Palette.Sidebar;
                Label title = MakeLabel(Localizer.T("stretch.title"), 13, Palette.Text, true); title.Location = new Point(20, 15); title.Size = new Size(560, 26); header.Controls.Add(title); form.Controls.Add(header);
                Label hint = MakeLabel(Localizer.T("stretch.hint"), 8, Palette.Muted, false); hint.Location = new Point(20, 66); hint.Size = new Size(580, 62); form.Controls.Add(hint);

                Label monitorLabel = MakeLabel(Localizer.T("stretch.monitor"), 9, Palette.Text, true); monitorLabel.Location = new Point(20, 139); monitorLabel.Size = new Size(150, 22); form.Controls.Add(monitorLabel);
                ComboBox monitorPicker = MakeCombo(new string[0]); monitorPicker.Location = new Point(184, 134); monitorPicker.Width = 412;
                Screen[] screens = Screen.AllScreens; foreach (Screen screen in screens) monitorPicker.Items.Add(new CrosshairDisplayOption(screen));
                if (monitorPicker.Items.Count > 0) monitorPicker.SelectedIndex = Array.FindIndex(screens, x => x.Primary);
                form.Controls.Add(monitorPicker);

                Label presetLabel = MakeLabel(Localizer.T("stretch.preset"), 9, Palette.Text, true); presetLabel.Location = new Point(20, 184); presetLabel.Size = new Size(150, 22); form.Controls.Add(presetLabel);
                ComboBox presetPicker = MakeCombo(new string[0]); presetPicker.Location = new Point(184, 179); presetPicker.Width = 250; form.Controls.Add(presetPicker);
                Label resolutionLabel = MakeLabel(Localizer.T("stretch.resolution"), 9, Palette.Text, true); resolutionLabel.Location = new Point(20, 229); resolutionLabel.Size = new Size(160, 22); form.Controls.Add(resolutionLabel);
                NumericUpDown widthPicker = new NumericUpDown(); widthPicker.Minimum = 640; widthPicker.Maximum = 16384; widthPicker.Increment = 10; widthPicker.Location = new Point(184, 224); widthPicker.Size = new Size(115, 28); widthPicker.BackColor = Palette.Surface2; widthPicker.ForeColor = Palette.Text; widthPicker.BorderStyle = BorderStyle.FixedSingle; form.Controls.Add(widthPicker);
                Label multiply = MakeLabel("×", 12, Palette.Muted, true); multiply.Location = new Point(307, 224); multiply.Size = new Size(22, 25); form.Controls.Add(multiply);
                NumericUpDown heightPicker = new NumericUpDown(); heightPicker.Minimum = 480; heightPicker.Maximum = 16384; heightPicker.Increment = 10; heightPicker.Location = new Point(335, 224); heightPicker.Size = new Size(115, 28); heightPicker.BackColor = Palette.Surface2; heightPicker.ForeColor = Palette.Text; heightPicker.BorderStyle = BorderStyle.FixedSingle; form.Controls.Add(heightPicker);

                Button reset = MakeButton(Localizer.T("stretch.restore"), Palette.Surface2, 38); reset.Location = new Point(20, 294); reset.Width = 175; reset.Enabled = false; form.Controls.Add(reset);
                Button cancel = MakeButton(Localizer.T("stretch.cancel"), Palette.Surface2, 38); cancel.Location = new Point(375, 294); cancel.Width = 100; cancel.DialogResult = DialogResult.Cancel; form.Controls.Add(cancel);
                Button apply = MakeButton(Localizer.T("stretch.apply"), Palette.Accent, 38); apply.Location = new Point(485, 294); apply.Width = 110; form.Controls.Add(apply);
                form.CancelButton = cancel;

                Action loadPresets = delegate
                {
                    Screen selected = monitorPicker.SelectedItem is CrosshairDisplayOption ? ((CrosshairDisplayOption)monitorPicker.SelectedItem).Screen : Screen.PrimaryScreen;
                    DisplayMode current;
                    if (!TryGetCurrentDisplayMode(selected.DeviceName, out current)) return;
                    widthPicker.Value = Math.Max(widthPicker.Minimum, Math.Min(widthPicker.Maximum, current.dmPelsWidth));
                    heightPicker.Value = Math.Max(heightPicker.Minimum, Math.Min(heightPicker.Maximum, current.dmPelsHeight));
                    presetPicker.BeginUpdate(); presetPicker.Items.Clear();
                    HashSet<string> known = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    Action<int, int> addMode = delegate(int w, int h)
                    {
                        if (w < 640 || h < 480 || w > 16384 || h > 16384) return;
                        string id = w.ToString(CultureInfo.InvariantCulture) + "x" + h.ToString(CultureInfo.InvariantCulture);
                        if (known.Add(id)) presetPicker.Items.Add(new StretchResolutionOption(w, h));
                    };
                    for (int i = 0; i < 512; i++)
                    {
                        DisplayMode mode = new DisplayMode(); mode.dmSize = (short)Marshal.SizeOf(typeof(DisplayMode));
                        if (!EnumDisplaySettings(selected.DeviceName, i, ref mode)) break;
                        addMode(mode.dmPelsWidth, mode.dmPelsHeight);
                    }
                    int[,] common = { { 1440, 1080 }, { 1720, 1080 }, { 1750, 1080 }, { 1600, 1080 }, { 1280, 960 }, { 1280, 1024 }, { 1024, 768 } };
                    for (int i = 0; i < common.GetLength(0); i++)
                    {
                        DisplayMode suggested = current; suggested.dmPelsWidth = common[i, 0]; suggested.dmPelsHeight = common[i, 1]; suggested.dmFields |= DisplayFieldWidth | DisplayFieldHeight;
                        if (ChangeDisplaySettingsEx(selected.DeviceName, ref suggested, IntPtr.Zero, DisplayChangeTest, IntPtr.Zero) == 0) addMode(common[i, 0], common[i, 1]);
                    }
                    StretchResolutionOption selectedMode = null;
                    for (int i = 0; i < presetPicker.Items.Count; i++)
                    {
                        StretchResolutionOption option = (StretchResolutionOption)presetPicker.Items[i];
                        if (option.Width == current.dmPelsWidth && option.Height == current.dmPelsHeight) { selectedMode = option; break; }
                    }
                    presetPicker.EndUpdate();
                    if (selectedMode != null) presetPicker.SelectedItem = selectedMode;
                    string saved; reset.Enabled = _prefs.StretchOriginalModes.TryGetValue(selected.DeviceName, out saved);
                };
                monitorPicker.SelectedIndexChanged += delegate { loadPresets(); };
                presetPicker.SelectedIndexChanged += delegate
                {
                    StretchResolutionOption option = presetPicker.SelectedItem as StretchResolutionOption;
                    if (option != null) { widthPicker.Value = Math.Max(widthPicker.Minimum, Math.Min(widthPicker.Maximum, option.Width)); heightPicker.Value = Math.Max(heightPicker.Minimum, Math.Min(heightPicker.Maximum, option.Height)); }
                };
                loadPresets();

                reset.Click += delegate
                {
                    CrosshairDisplayOption choice = monitorPicker.SelectedItem as CrosshairDisplayOption;
                    if (choice == null) return;
                    if (RestoreStretchResolution(choice.Screen.DeviceName)) { ScheduleCrosshairRecenter(); loadPresets(); SetStatus(Localizer.T("stretch.reverted")); }
                    else ThemedDialog.Show(form, Localizer.T("stretch.title"), Localizer.T("stretch.applyFailed"), false);
                };
                apply.Click += delegate
                {
                    CrosshairDisplayOption choice = monitorPicker.SelectedItem as CrosshairDisplayOption;
                    if (choice == null) return;
                    DisplayMode original;
                    if (!TryGetCurrentDisplayMode(choice.Screen.DeviceName, out original)) { ThemedDialog.Show(form, Localizer.T("stretch.title"), Localizer.T("stretch.applyFailed"), false); return; }
                    int requestedWidth = Decimal.ToInt32(widthPicker.Value), requestedHeight = Decimal.ToInt32(heightPicker.Value);
                    DisplayMode requested = original; requested.dmPelsWidth = requestedWidth; requested.dmPelsHeight = requestedHeight; requested.dmFields |= DisplayFieldWidth | DisplayFieldHeight;
                    if (ChangeDisplaySettingsEx(choice.Screen.DeviceName, ref requested, IntPtr.Zero, DisplayChangeTest, IntPtr.Zero) != 0)
                    { ThemedDialog.Show(form, Localizer.T("stretch.title"), Localizer.T("stretch.unsupported"), false); return; }
                    bool hadBaseline = _prefs.StretchOriginalModes.ContainsKey(choice.Screen.DeviceName);
                    if (!hadBaseline) { _prefs.StretchOriginalModes[choice.Screen.DeviceName] = FormatDisplayMode(original); SavePreferences(); }
                    if (ChangeDisplaySettingsEx(choice.Screen.DeviceName, ref requested, IntPtr.Zero, 0, IntPtr.Zero) != 0)
                    {
                        if (!hadBaseline) { _prefs.StretchOriginalModes.Remove(choice.Screen.DeviceName); SavePreferences(); }
                        ThemedDialog.Show(form, Localizer.T("stretch.title"), Localizer.T("stretch.applyFailed"), false); return;
                    }
                    if (!ConfirmStretchResolution(form))
                    {
                        ChangeDisplaySettingsEx(choice.Screen.DeviceName, ref original, IntPtr.Zero, 0, IntPtr.Zero);
                        ScheduleCrosshairRecenter();
                        if (!hadBaseline) { _prefs.StretchOriginalModes.Remove(choice.Screen.DeviceName); SavePreferences(); }
                        loadPresets(); SetStatus(Localizer.T("stretch.reverted")); return;
                    }
                    ScheduleCrosshairRecenter(); reset.Enabled = true; loadPresets(); SetStatus(Localizer.T("status.saved")); ThemedDialog.Show(form, Localizer.T("stretch.title"), Localizer.T("stretch.kept"), false);
                };
                form.ShowDialog(this);
            }
        }

        private static string FormatDisplayMode(DisplayMode mode)
        {
            return mode.dmPelsWidth.ToString(CultureInfo.InvariantCulture) + "x" + mode.dmPelsHeight.ToString(CultureInfo.InvariantCulture) + "x" + Math.Max(1, mode.dmDisplayFrequency).ToString(CultureInfo.InvariantCulture);
        }

        private bool RestoreStretchResolution(string deviceName)
        {
            string saved;
            if (!_prefs.StretchOriginalModes.TryGetValue(deviceName, out saved)) return false;
            string[] pieces = saved.Split('x'); int width, height, frequency;
            if (pieces.Length != 3 || !Int32.TryParse(pieces[0], out width) || !Int32.TryParse(pieces[1], out height) || !Int32.TryParse(pieces[2], out frequency)) return false;
            if (width < 640 || height < 480 || width > 16384 || height > 16384 || frequency < 1 || frequency > 1000) return false;
            DisplayMode current;
            if (!TryGetCurrentDisplayMode(deviceName, out current)) return false;
            DisplayMode mode;
            if (!TryFindDisplayMode(deviceName, width, height, frequency, current.dmBitsPerPel, out mode))
            {
                mode = current; mode.dmPelsWidth = width; mode.dmPelsHeight = height;
                mode.dmFields |= DisplayFieldWidth | DisplayFieldHeight;
                if (frequency > 1) { mode.dmDisplayFrequency = frequency; mode.dmFields |= DisplayFieldFrequency; }
            }
            if ((current.dmFields & DisplayFieldPosition) != 0)
            {
                mode.dmPositionX = current.dmPositionX; mode.dmPositionY = current.dmPositionY; mode.dmFields |= DisplayFieldPosition;
            }
            if (ChangeDisplaySettingsEx(deviceName, ref mode, IntPtr.Zero, DisplayChangeTest, IntPtr.Zero) != 0)
            {
                // Some display drivers reject a saved refresh-rate combination even though
                // the original dimensions remain valid. Retry with the driver's default rate.
                DisplayMode fallback = current; fallback.dmPelsWidth = width; fallback.dmPelsHeight = height;
                fallback.dmFields |= DisplayFieldWidth | DisplayFieldHeight; fallback.dmFields &= ~DisplayFieldFrequency;
                if ((current.dmFields & DisplayFieldPosition) != 0) { fallback.dmPositionX = current.dmPositionX; fallback.dmPositionY = current.dmPositionY; fallback.dmFields |= DisplayFieldPosition; }
                if (ChangeDisplaySettingsEx(deviceName, ref fallback, IntPtr.Zero, DisplayChangeTest, IntPtr.Zero) != 0) return false;
                mode = fallback;
            }
            if (ChangeDisplaySettingsEx(deviceName, ref mode, IntPtr.Zero, 0, IntPtr.Zero) != 0) return false;
            _prefs.StretchOriginalModes.Remove(deviceName); SavePreferences();
            return true;
        }

        private static bool TryFindDisplayMode(string deviceName, int width, int height, int frequency, int bitsPerPixel, out DisplayMode bestMode)
        {
            bestMode = new DisplayMode(); long bestScore = Int64.MaxValue; bool found = false;
            for (int index = 0; index < 512; index++)
            {
                DisplayMode candidate = new DisplayMode(); candidate.dmSize = (short)Marshal.SizeOf(typeof(DisplayMode));
                if (!EnumDisplaySettings(deviceName, index, ref candidate)) break;
                if (candidate.dmPelsWidth != width || candidate.dmPelsHeight != height) continue;
                long refreshDelta = Math.Abs((long)candidate.dmDisplayFrequency - frequency);
                long colorPenalty = candidate.dmBitsPerPel == bitsPerPixel ? 0L : 10000000L;
                long score = colorPenalty + refreshDelta;
                if (score < bestScore) { bestScore = score; bestMode = candidate; found = true; }
                if (score == 0) break;
            }
            return found;
        }

        private bool ConfirmStretchResolution(IWin32Window owner)
        {
            using (Form form = new Form())
            using (System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer())
            {
                form.Text = Localizer.T("stretch.confirmTitle"); form.FormBorderStyle = FormBorderStyle.None; form.StartPosition = FormStartPosition.CenterParent;
                form.ClientSize = new Size(500, 220); form.BackColor = Palette.Surface; form.ForeColor = Palette.Text; form.Font = UiFontCache.Get("Segoe UI", 9F, FontStyle.Regular); form.ShowInTaskbar = false;
                Panel top = new Panel(); top.Dock = DockStyle.Top; top.Height = 54; top.BackColor = Palette.Sidebar;
                Label title = MakeLabel(Localizer.T("stretch.confirmTitle"), 12, Palette.Text, true); title.Location = new Point(18, 14); title.Size = new Size(460, 25); top.Controls.Add(title); form.Controls.Add(top);
                Label body = MakeLabel("", 10, Palette.Text, false); body.Location = new Point(20, 75); body.Size = new Size(460, 58); body.TextAlign = ContentAlignment.MiddleLeft; form.Controls.Add(body);
                Button revert = MakeButton(Localizer.T("stretch.cancel"), Palette.Surface2, 38); revert.Location = new Point(190, 158); revert.Width = 130; revert.DialogResult = DialogResult.Cancel; form.Controls.Add(revert);
                Button keep = MakeButton(Localizer.T("stretch.confirm"), Palette.Accent, 38); keep.Location = new Point(330, 158); keep.Width = 150; keep.DialogResult = DialogResult.OK; form.Controls.Add(keep);
                form.CancelButton = revert; form.AcceptButton = keep;
                int remaining = 15; Action update = delegate { body.Text = String.Format(CultureInfo.CurrentCulture, Localizer.T("stretch.confirmBody"), remaining); };
                update(); timer.Interval = 1000; timer.Tick += delegate { remaining--; if (remaining <= 0) { timer.Stop(); form.DialogResult = DialogResult.Cancel; form.Close(); } else update(); };
                timer.Start(); DialogResult result = form.ShowDialog(owner); timer.Stop();
                return result == DialogResult.OK;
            }
        }

        private sealed class CrosshairDisplayOption
        {
            public readonly Screen Screen;
            public CrosshairDisplayOption(Screen screen) { Screen = screen; }
            public override string ToString() { return DisplayLabels.ForScreen(Screen); }
        }

        private sealed class GameColorProfileOption
        {
            public readonly string Vendor, Profile;
            public GameColorProfileOption(string vendor, string profile) { Vendor = vendor ?? ""; Profile = profile ?? ""; }
            public override string ToString()
            {
                if (String.IsNullOrEmpty(Vendor)) return Localizer.T("gaming.noColorProfile");
                if (Profile == "__standard__") return Localizer.T(Vendor == "nvidia" ? "gaming.nvidiaStandard" : "gaming.amdStandard");
                return String.Format(CultureInfo.CurrentCulture, Localizer.T(Vendor == "nvidia" ? "gaming.nvidiaProfile" : "gaming.amdProfile"), Profile);
            }
        }

        private void RebuildGameColorProfileOptions()
        {
            if (_sessionColorProfilePicker == null || _sessionColorProfilePicker.IsDisposed) return;
            _sessionColorProfilePicker.BeginUpdate(); _sessionColorProfilePicker.Items.Clear();
            _sessionColorProfilePicker.Items.Add(new GameColorProfileOption("", ""));
            if (_prefs.NvidiaColorProfiles.Count > 0 || (_nvidiaColorSection != null && _nvidiaColorSection.HardwarePresent))
                _sessionColorProfilePicker.Items.Add(new GameColorProfileOption("nvidia", "__standard__"));
            if (_prefs.AmdColorProfiles.Count > 0 || (_amdColorSection != null && _amdColorSection.HardwarePresent))
                _sessionColorProfilePicker.Items.Add(new GameColorProfileOption("amd", "__standard__"));
            foreach (string name in _prefs.NvidiaColorProfiles.Keys.Select(x => x.Split('\t')[0]).Where(x => !String.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase))
                _sessionColorProfilePicker.Items.Add(new GameColorProfileOption("nvidia", name));
            foreach (string name in _prefs.AmdColorProfiles.Keys.Select(x => x.Split('\t')[0]).Where(x => !String.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase))
                _sessionColorProfilePicker.Items.Add(new GameColorProfileOption("amd", name));
            if (_sessionColorProfilePicker.Items.Count > 0 && _sessionColorProfilePicker.SelectedIndex < 0) _sessionColorProfilePicker.SelectedIndex = 0;
            _sessionColorProfilePicker.EndUpdate();
        }

        private void SelectGameColorProfile(string vendor, string profile)
        {
            if (_sessionColorProfilePicker == null) return;
            GameColorProfileOption option = _sessionColorProfilePicker.Items.Cast<object>().OfType<GameColorProfileOption>()
                .FirstOrDefault(x => String.Equals(x.Vendor, vendor ?? "", StringComparison.OrdinalIgnoreCase) && String.Equals(x.Profile, profile ?? "", StringComparison.OrdinalIgnoreCase));
            _sessionColorProfilePicker.SelectedItem = option ?? _sessionColorProfilePicker.Items.Cast<object>().OfType<GameColorProfileOption>().FirstOrDefault(x => String.IsNullOrEmpty(x.Vendor));
        }

        private void SaveGameColorProfileSelection()
        {
            if (_sessionGamePicker == null || _sessionGamePicker.SelectedIndex < 0) return;
            string gameKey = _gameKeys[_sessionGamePicker.SelectedIndex];
            GameColorProfileOption selected = _sessionColorProfilePicker.SelectedItem as GameColorProfileOption;
            _prefs.NvidiaGameProfiles.Remove(gameKey); _prefs.AmdGameProfiles.Remove(gameKey);
            if (selected != null && !String.IsNullOrEmpty(selected.Vendor))
            {
                if (selected.Vendor == "nvidia") _prefs.NvidiaGameProfiles[gameKey] = selected.Profile;
                else if (selected.Vendor == "amd") _prefs.AmdGameProfiles[gameKey] = selected.Profile;
            }
            SavePreferences(); SetStatus(Localizer.T("gaming.combinedSaved"));
        }

        private static bool TryParseGameStretchProfile(string value, out string device, out int width, out int height)
        {
            device = ""; width = 0; height = 0;
            if (String.IsNullOrWhiteSpace(value)) return false;
            string[] parts = value.Split('|'); string[] dimensions;
            if (parts.Length != 2 || String.IsNullOrWhiteSpace(parts[0])) return false;
            dimensions = parts[1].Split('x');
            if (dimensions.Length != 2 || !Int32.TryParse(dimensions[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out width) || !Int32.TryParse(dimensions[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out height)) return false;
            if (width < 0 || height < 0 || (width == 0) != (height == 0) || width > 16384 || height > 16384) return false;
            device = parts[0]; return true;
        }

        private void RefreshGameStretchOptions(string gameKey, int desiredWidth, int desiredHeight)
        {
            if (_sessionStretchResolutionPicker == null || _sessionStretchResolutionPicker.IsDisposed) return;
            CrosshairDisplayOption selectedDisplay = _sessionStretchDisplayPicker.SelectedItem as CrosshairDisplayOption;
            if (selectedDisplay == null && _sessionStretchDisplayPicker.Items.Count > 0)
            {
                selectedDisplay = _sessionStretchDisplayPicker.Items[0] as CrosshairDisplayOption;
                _sessionStretchDisplayPicker.SelectedItem = selectedDisplay;
            }
            _sessionStretchResolutionPicker.BeginUpdate(); _sessionStretchResolutionPicker.Items.Clear();
            _sessionStretchResolutionPicker.Items.Add(new StretchResolutionOption(0, 0));
            if (selectedDisplay != null)
            {
                string device = selectedDisplay.Screen.DeviceName; HashSet<string> known = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                Action<int, int> add = delegate(int w, int h)
                {
                    if (w < 640 || h < 480 || w > 16384 || h > 16384) return;
                    string key = w.ToString(CultureInfo.InvariantCulture) + "x" + h.ToString(CultureInfo.InvariantCulture);
                    if (known.Add(key)) _sessionStretchResolutionPicker.Items.Add(new StretchResolutionOption(w, h));
                };
                for (int i = 0; i < 512; i++)
                {
                    DisplayMode mode = new DisplayMode(); mode.dmSize = (short)Marshal.SizeOf(typeof(DisplayMode));
                    if (!EnumDisplaySettings(device, i, ref mode)) break;
                    add(mode.dmPelsWidth, mode.dmPelsHeight);
                }
                DisplayMode current;
                if (TryGetCurrentDisplayMode(device, out current))
                {
                    int[,] common = { { 1440, 1080 }, { 1720, 1080 }, { 1750, 1080 }, { 1600, 1080 }, { 1280, 960 }, { 1280, 1024 }, { 1024, 768 } };
                    for (int i = 0; i < common.GetLength(0); i++)
                    {
                        DisplayMode suggested = current; suggested.dmPelsWidth = common[i, 0]; suggested.dmPelsHeight = common[i, 1]; suggested.dmFields |= DisplayFieldWidth | DisplayFieldHeight;
                        if (ChangeDisplaySettingsEx(device, ref suggested, IntPtr.Zero, DisplayChangeTest, IntPtr.Zero) == 0) add(common[i, 0], common[i, 1]);
                    }
                }
            }
            _sessionStretchResolutionPicker.EndUpdate();
            StretchResolutionOption target = _sessionStretchResolutionPicker.Items.Cast<object>().OfType<StretchResolutionOption>().FirstOrDefault(x => x.Width == desiredWidth && x.Height == desiredHeight);
            _sessionStretchResolutionPicker.SelectedItem = target ?? _sessionStretchResolutionPicker.Items[0];
            if (!_loadingCombinedProfile) SaveGameStretchSelection();
        }

        private void SaveGameStretchSelection()
        {
            if (_loadingCombinedProfile || _sessionGamePicker == null || _sessionGamePicker.SelectedIndex < 0 || _sessionStretchResolutionPicker == null) return;
            string gameKey = _gameKeys[_sessionGamePicker.SelectedIndex];
            CrosshairDisplayOption display = _sessionStretchDisplayPicker.SelectedItem as CrosshairDisplayOption;
            StretchResolutionOption resolution = _sessionStretchResolutionPicker.SelectedItem as StretchResolutionOption;
            if (resolution == null || resolution.Width == 0 || display == null) _prefs.GameStretchProfiles.Remove(gameKey);
            else _prefs.GameStretchProfiles[gameKey] = display.Screen.DeviceName + "|" + resolution.Width.ToString(CultureInfo.InvariantCulture) + "x" + resolution.Height.ToString(CultureInfo.InvariantCulture);
            SavePreferences(); SetStatus(Localizer.T("gaming.combinedSaved"));
        }

        private void RebuildGameSessionProfilePickers()
        {
            if (_sessionGamePicker == null || _sessionGamePicker.IsDisposed) return;
            RebuildGameColorProfileOptions();
            if (_sessionGamePicker.SelectedIndex >= 0) RefreshGameStretchOptions(_gameKeys[_sessionGamePicker.SelectedIndex], 0, 0);
        }

        private void QueueGameStretchSessionMonitor()
        {
            lock (_gameStretchSessionLock) { if (String.IsNullOrEmpty(_gameStretchSessionGameKey) || _closing) return; }
            if (Interlocked.CompareExchange(ref _gameStretchMonitorBusy, 1, 0) != 0) return;
            ThreadPool.QueueUserWorkItem(delegate
            {
                bool found = false, sawGame; string target;
                lock (_gameStretchSessionLock) { target = _gameStretchSessionGameKey; sawGame = _gameStretchSessionSawGame; }
                try
                {
                    if (!String.IsNullOrEmpty(target))
                    {
                        foreach (Process process in Process.GetProcesses())
                        {
                            try { if (IsGameProcessName(process.ProcessName) && String.Equals(GameKeyForProcess(process.ProcessName), target, StringComparison.OrdinalIgnoreCase)) { found = true; break; } }
                            catch { }
                            finally { try { process.Dispose(); } catch { } }
                        }
                    }
                }
                catch { }
                bool shouldRestore = false;
                lock (_gameStretchSessionLock)
                {
                    if (String.IsNullOrEmpty(_gameStretchSessionGameKey)) { Interlocked.Exchange(ref _gameStretchMonitorBusy, 0); return; }
                    if (found) _gameStretchSessionSawGame = true;
                    else if (_gameStretchSessionSawGame || DateTime.UtcNow - _gameStretchSessionStartedUtc > TimeSpan.FromMinutes(3)) shouldRestore = true;
                }
                if (shouldRestore)
                {
                    try { if (!IsDisposed && IsHandleCreated) BeginInvoke((MethodInvoker)RestoreGameStretchSession); } catch { }
                }
                Interlocked.Exchange(ref _gameStretchMonitorBusy, 0);
            });
        }

        private void RestoreStaleGameStretchSession()
        {
            try
            {
                if (!File.Exists(GameStretchSessionBackupPath)) return;
                Dictionary<string, string> state = File.ReadAllLines(GameStretchSessionBackupPath).Select(x => x.Split(new[] { '=' }, 2)).Where(x => x.Length == 2).ToDictionary(x => x[0], x => x[1], StringComparer.OrdinalIgnoreCase);
                string device, original;
                if (!TryDecodeSessionToken(state.ContainsKey("device") ? state["device"] : "", out device) || !TryDecodeSessionToken(state.ContainsKey("original") ? state["original"] : "", out original)) return;
                if (TryApplySavedDisplayMode(device, original)) try { File.Delete(GameStretchSessionBackupPath); } catch { }
            }
            catch { }
        }

        private void RestoreGameStretchSession()
        {
            string device, original;
            lock (_gameStretchSessionLock)
            {
                device = _gameStretchSessionDevice; original = _gameStretchSessionOriginal;
                if (String.IsNullOrEmpty(device) && File.Exists(GameStretchSessionBackupPath))
                {
                    try
                    {
                        Dictionary<string, string> state = File.ReadAllLines(GameStretchSessionBackupPath).Select(x => x.Split(new[] { '=' }, 2)).Where(x => x.Length == 2).ToDictionary(x => x[0], x => x[1], StringComparer.OrdinalIgnoreCase);
                        TryDecodeSessionToken(state.ContainsKey("device") ? state["device"] : "", out device);
                        TryDecodeSessionToken(state.ContainsKey("original") ? state["original"] : "", out original);
                    }
                    catch { }
                }
            }
            if (!String.IsNullOrEmpty(device) && !String.IsNullOrEmpty(original) && TryApplySavedDisplayMode(device, original))
            {
                try { if (File.Exists(GameStretchSessionBackupPath)) File.Delete(GameStretchSessionBackupPath); } catch { }
                lock (_gameStretchSessionLock) { _gameStretchSessionGameKey = _gameStretchSessionDevice = _gameStretchSessionOriginal = ""; _gameStretchSessionSawGame = false; }
                ScheduleCrosshairRecenter();
            }
        }

        private static bool TryApplySavedDisplayMode(string deviceName, string saved)
        {
            if (String.IsNullOrWhiteSpace(deviceName)) return false;
            string[] pieces = (saved ?? "").Split('x'); int width, height, frequency;
            if (pieces.Length != 3 || !Int32.TryParse(pieces[0], out width) || !Int32.TryParse(pieces[1], out height) || !Int32.TryParse(pieces[2], out frequency)) return false;
            DisplayMode current; if (!TryGetCurrentDisplayMode(deviceName, out current)) return false;
            DisplayMode mode;
            if (!TryFindDisplayMode(deviceName, width, height, frequency, current.dmBitsPerPel, out mode))
            { mode = current; mode.dmPelsWidth = width; mode.dmPelsHeight = height; mode.dmFields |= DisplayFieldWidth | DisplayFieldHeight; if (frequency > 1) { mode.dmDisplayFrequency = frequency; mode.dmFields |= DisplayFieldFrequency; } }
            if ((current.dmFields & DisplayFieldPosition) != 0) { mode.dmPositionX = current.dmPositionX; mode.dmPositionY = current.dmPositionY; mode.dmFields |= DisplayFieldPosition; }
            if (ChangeDisplaySettingsEx(deviceName, ref mode, IntPtr.Zero, DisplayChangeTest, IntPtr.Zero) != 0)
            { DisplayMode fallback = current; fallback.dmPelsWidth = width; fallback.dmPelsHeight = height; fallback.dmFields |= DisplayFieldWidth | DisplayFieldHeight; fallback.dmFields &= ~DisplayFieldFrequency; if (ChangeDisplaySettingsEx(deviceName, ref fallback, IntPtr.Zero, DisplayChangeTest, IntPtr.Zero) != 0) return false; mode = fallback; }
            return ChangeDisplaySettingsEx(deviceName, ref mode, IntPtr.Zero, 0, IntPtr.Zero) == 0;
        }

        private static string EncodeSessionToken(string value) { return Convert.ToBase64String(Encoding.UTF8.GetBytes(value ?? "")).TrimEnd('=').Replace('+', '-').Replace('/', '_'); }
        private static bool TryDecodeSessionToken(string token, out string value)
        {
            value = "";
            try { string raw = (token ?? "").Replace('-', '+').Replace('_', '/'); while (raw.Length % 4 != 0) raw += "="; value = Encoding.UTF8.GetString(Convert.FromBase64String(raw)); return true; }
            catch { return false; }
        }

        private Control RenderGameTile(string gameKey, int width)
        {
            RoundPanel tile = new RoundPanel(); tile.Name = "game-tile"; tile.BackColor = Palette.Surface; tile.Width = width; tile.Height = 238; tile.Margin = new Padding(0, 0, 8, 0); tile.Padding = new Padding(0);
            tile.Tag = gameKey;
            GameArtworkPanel art = new GameArtworkPanel(gameKey, GameAccent(gameKey)); art.Name = "game-art"; art.Location = new Point(1, 1); art.Size = new Size(tile.Width - 2, 84); tile.Controls.Add(art);
            if (gameKey == "game.fortnite" && _prefs.FortniteBackgroundCustomized && File.Exists(FortniteWallpaperPath)) art.SetCustomArtwork(FortniteWallpaperPath);
            string name = Localizer.T(gameKey);
            Label game = MakeLabel(name, 13, Palette.Text, true); game.Name = "game-name"; game.AccessibleName = name; game.AccessibleDescription = name;
            game.Location = new Point(13, 4); game.Size = new Size(tile.Width - 110, 76); game.AutoEllipsis = false; game.UseMnemonic = false; game.TextAlign = ContentAlignment.MiddleLeft;
            game.Text = WrapGameName(name, game.Width, game.Font); art.Controls.Add(game);
            string[] profileKeys = { "Lite", "Balanced", "Power", "MaxFPS", "Streamer" };
            ComboBox profile = MakeCombo(new[] { Localizer.T("games.lite"), Localizer.T("games.balanced"), Localizer.T("games.power"), Localizer.T("games.maxFps"), Localizer.T("games.streamer") });
            string saved; if (!_prefs.GameProfiles.TryGetValue(gameKey, out saved)) saved = "Balanced";
            profile.Name = "game-profile"; int savedIndex = Array.IndexOf(profileKeys, saved); profile.SelectedIndex = savedIndex < 0 ? 1 : savedIndex; profile.Location = new Point(13, 91); profile.Width = tile.Width - 26;
            profile.SelectedIndexChanged += delegate
            {
                _prefs.GameProfiles[gameKey] = profileKeys[Math.Max(0, profile.SelectedIndex)];
                SavePreferences(); SetStatus(Localizer.T("games.profileSaved"));
            };
            tile.Controls.Add(profile);
            Button apply = MakeButton(gameKey == "game.fortnite" ? Localizer.T("games.applyShort") : Localizer.T("games.apply"), Palette.Accent, 36); apply.Name = "game-apply"; apply.Location = new Point(13, 139); apply.Width = gameKey == "game.fortnite" ? (tile.Width - 34) / 2 : tile.Width - 26;
            apply.Click += delegate { ApplyGameProfile(gameKey, profile.SelectedIndex); }; tile.Controls.Add(apply);
            if (gameKey == "game.fortnite")
            {
                Button graphics = MakeButton(Localizer.T("games.fortniteGraphics"), Palette.Surface2, 36); graphics.Name = "game-graphics"; graphics.Location = new Point(apply.Right + 8, 139); graphics.Width = (tile.Width - 34) / 2;
                graphics.Click += delegate { ShowFortniteGraphicsDialog(); }; tile.Controls.Add(graphics);
            }
            if (gameKey == "game.fortnite")
            {
                Button potato = MakeButton(Localizer.T(IsFortnitePotatoActive(GetFortniteSettingsPath()) ? "fortnite.potatoButtonOff" : "fortnite.potatoButtonOn"), Palette.Surface2, 34);
                potato.Name = "game-potato"; potato.Location = new Point(13, 180); potato.Width = tile.Width - 26;
                potato.AccessibleDescription = Localizer.T("fortnite.hint");
                potato.Click += delegate { ToggleFortnitePotatoGraphics(); UpdateFortnitePotatoButton(potato); };
                tile.Controls.Add(potato);
            }
            Label scope = MakeLabel(Localizer.T("games.applyHint"), 8, Palette.Muted, false); scope.Name = "game-scope"; scope.Location = new Point(13, gameKey == "game.fortnite" ? 218 : 184); scope.Size = new Size(tile.Width - 26, 36); tile.Controls.Add(scope);
            return tile;
        }

        private static Color GameAccent(string key)
        {
            if (key == "game.fortnite") return Color.FromArgb(54, 160, 255);
            if (key == "game.minecraft" || key == "game.minecraftBedrock" || key == "game.farming") return Color.FromArgb(107, 200, 92);
            if (key == "game.valorant" || key == "game.apex") return Color.FromArgb(255, 86, 92);
            if (key == "game.gta" || key == "game.rocket") return Color.FromArgb(255, 171, 64);
            if (key == "game.cyberpunk") return Color.FromArgb(244, 212, 63);
            if (key == "game.overwatch" || key == "game.counterstrike") return Color.FromArgb(245, 142, 67);
            if (key == "game.r6") return Color.FromArgb(112, 171, 235);
            return Color.FromArgb(170, 121, 250);
        }

        private static string WrapGameName(string name, int width, Font font)
        {
            if (String.IsNullOrWhiteSpace(name)) return name;
            int maxWidth = Math.Max(70, width - 4); StringBuilder wrapped = new StringBuilder(); string line = "";
            foreach (string word in name.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string next = line.Length == 0 ? word : line + " " + word;
                if (line.Length > 0 && TextRenderer.MeasureText(next, font, new Size(Int32.MaxValue, Int32.MaxValue), TextFormatFlags.NoPadding | TextFormatFlags.SingleLine).Width > maxWidth)
                { if (wrapped.Length > 0) wrapped.AppendLine(); wrapped.Append(line); line = word; }
                else line = next;
            }
            if (line.Length > 0) { if (wrapped.Length > 0) wrapped.AppendLine(); wrapped.Append(line); }
            return wrapped.ToString();
        }

        private static void ResizeGameTile(Control tile, int width)
        {
            if (tile == null || tile.IsDisposed) return;
            width = Math.Max(220, width); tile.Width = width;
            Control art = tile.Controls.Cast<Control>().FirstOrDefault(x => x.Name == "game-art");
            Control name = art == null ? null : art.Controls.Cast<Control>().FirstOrDefault(x => x.Name == "game-name");
            Control profile = tile.Controls.Cast<Control>().FirstOrDefault(x => x.Name == "game-profile");
            Control apply = tile.Controls.Cast<Control>().FirstOrDefault(x => x.Name == "game-apply");
            Control graphics = tile.Controls.Cast<Control>().FirstOrDefault(x => x.Name == "game-graphics");
            Control potato = tile.Controls.Cast<Control>().FirstOrDefault(x => x.Name == "game-potato");
            Control scope = tile.Controls.Cast<Control>().FirstOrDefault(x => x.Name == "game-scope");
            if (art != null) art.Width = width - 2;
            if (name != null) { name.Location = new Point(13, 4); name.Width = width - 110; Label label = name as Label; if (label != null) label.Text = WrapGameName(label.AccessibleName ?? label.Text, label.Width, label.Font); }
            if (profile != null) profile.Width = width - 26;
            if (apply != null) apply.Width = graphics == null ? width - 26 : (width - 34) / 2;
            if (graphics != null) { graphics.Width = (width - 34) / 2; graphics.Location = new Point(apply == null ? 13 + (width - 34) / 2 + 8 : apply.Right + 8, 139); }
            if (potato != null) { potato.Width = width - 26; potato.Location = new Point(13, 180); }
            if (scope != null) scope.Width = width - 26;
        }

        private static string GetFortniteSettingsPath()
        {
            string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FortniteGame", "Saved", "Config");
            string[] candidates = { Path.Combine(root, "WindowsClient", "GameUserSettings.ini"), Path.Combine(root, "Windows", "GameUserSettings.ini"), Path.Combine(root, "WinGDK", "GameUserSettings.ini") };
            return candidates.FirstOrDefault(File.Exists) ?? candidates[0];
        }

        private static string GetFortniteProfileStatePath(string settingsPath) { return settingsPath + ".freezer-profile"; }
        private static string GetFortniteOriginalAttributesPath(string settingsPath) { return settingsPath + ".freezer-original.attributes"; }

        private static bool IsFortniteRunning()
        {
            Process[] processes = Process.GetProcessesByName("FortniteClient-Win64-Shipping");
            bool running = processes.Length > 0;
            foreach (Process process in processes) try { process.Dispose(); } catch { }
            return running;
        }

        private static bool IsFortnitePotatoActive(string settingsPath)
        {
            try { return File.Exists(GetFortniteProfileStatePath(settingsPath)) && Regex.IsMatch(File.ReadAllText(GetFortniteProfileStatePath(settingsPath)).Trim(), "^(Potato|Extreme)$", RegexOptions.IgnoreCase); }
            catch { return false; }
        }

        private void UpdateFortnitePotatoButton(Button button)
        {
            if (button == null || button.IsDisposed) return;
            button.Text = Localizer.T(IsFortnitePotatoActive(GetFortniteSettingsPath()) ? "fortnite.potatoButtonOff" : "fortnite.potatoButtonOn");
        }

        private void ToggleFortnitePotatoGraphics()
        {
            string path = GetFortniteSettingsPath(); string backup = path + ".freezer-original.bak";
            if (IsFortnitePotatoActive(path)) RestoreFortniteOriginal(path, backup, false);
            else ApplyFortniteGraphicsPreset(3, path, backup);
        }

        private void RestoreFortniteOriginal(string path, string backup, bool askFirst)
        {
            if (!File.Exists(backup)) { ThemedDialog.Show(this, Localizer.T("potato.title"), Localizer.T("potato.noBackup"), false); return; }
            if (IsFortniteRunning()) { ThemedDialog.Show(this, Localizer.T("potato.title"), Localizer.T("potato.running"), false); return; }
            if (askFirst && !ThemedDialog.Confirm(this, Localizer.T("potato.title"), Localizer.T("potato.restoreConfirm") + "\r\n\r\n" + backup)) return;
            try
            {
                RestoreFortniteFileFromBackup(path, backup);
                string state = GetFortniteProfileStatePath(path); if (File.Exists(state)) File.Delete(state);
                ThemedDialog.Show(this, Localizer.T("fortnite.title"), Localizer.T("fortnite.potatoRestored"), false);
                if (_page == "potatoGraphics") ShowPage("potatoGraphics");
            }
            catch (Exception ex)
            {
                try { if (File.Exists(path)) File.SetAttributes(path, File.GetAttributes(path) & ~FileAttributes.ReadOnly); } catch { }
                ThemedDialog.Show(this, Localizer.T("error.action"), DescribeSystemError(ex), false);
            }
        }

        private static FileAttributes GetFortniteOriginalAttributes(string path, string backup)
        {
            try
            {
                string metadata = GetFortniteOriginalAttributesPath(path); int raw;
                if (File.Exists(metadata) && Int32.TryParse(File.ReadAllText(metadata).Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out raw))
                    return (FileAttributes)raw;
            }
            catch { }
            try { if (File.Exists(backup)) return File.GetAttributes(backup); } catch { }
            return FileAttributes.Normal;
        }

        private static void RestoreFortniteFileFromBackup(string path, string backup)
        {
            string temporary = path + ".freezer-restore-" + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                File.Copy(backup, temporary, true);
                File.SetAttributes(temporary, FileAttributes.Normal);
                if (File.Exists(path))
                {
                    FileAttributes current = File.GetAttributes(path);
                    if ((current & FileAttributes.ReadOnly) != 0) File.SetAttributes(path, current & ~FileAttributes.ReadOnly);
                    File.Replace(temporary, path, null);
                }
                else File.Move(temporary, path);
                File.SetAttributes(path, GetFortniteOriginalAttributes(path, backup) & ~FileAttributes.ReadOnly);
            }
            finally
            {
                try { if (File.Exists(temporary)) { File.SetAttributes(temporary, FileAttributes.Normal); File.Delete(temporary); } } catch { }
            }
        }

        private void ApplyFortnitePotatoProfile(int profile)
        {
            string path = GetFortniteSettingsPath(); string backup = path + ".freezer-original.bak";
            if (profile == 0) { RestoreFortniteOriginal(path, backup, true); return; }
            if (profile != 1 && profile != 2) return;
            if (IsFortniteRunning()) { ThemedDialog.Show(this, Localizer.T("potato.title"), Localizer.T("potato.running"), false); return; }
            if (!File.Exists(path)) { ThemedDialog.Show(this, Localizer.T("potato.title"), Localizer.T("potato.noFile") + "\r\n\r\n" + path, false); return; }

            if (!_potatoGpuChecked || !_potatoNvidiaAvailable) { ThemedDialog.Show(this, Localizer.T("potato.title"), Localizer.T("potato.unsupported"), false); return; }

            string[] lines;
            try { lines = File.ReadAllLines(path, Encoding.UTF8); }
            catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("error.action"), DescribeSystemError(ex), false); return; }
            int quality = profile == 1 ? 1 : 0;
            if (SetFortnitePotatoQualityValues(lines, quality) != 3)
            { ThemedDialog.Show(this, Localizer.T("potato.title"), Localizer.T("potato.keysMissing"), false); return; }

            string nipFile = null, inspector = null;
            if (profile == 2)
            {
                using (OpenFileDialog dialog = new OpenFileDialog())
                {
                    dialog.Title = Localizer.T("potato.nipPrompt"); dialog.Filter = "NVIDIA Profile Inspector (*.nip)|*.nip";
                    dialog.CheckFileExists = true; dialog.Multiselect = false;
                    if (dialog.ShowDialog(this) != DialogResult.OK) return;
                    nipFile = dialog.FileName;
                }
                inspector = FindNvidiaProfileInspector();
                if (String.IsNullOrEmpty(inspector))
                {
                    using (OpenFileDialog dialog = new OpenFileDialog())
                    {
                        dialog.Title = Localizer.T("potato.npiPrompt"); dialog.Filter = "nvidiaProfileInspector.exe|nvidiaProfileInspector.exe|Programme (*.exe)|*.exe";
                        dialog.CheckFileExists = true; dialog.Multiselect = false;
                        if (dialog.ShowDialog(this) != DialogResult.OK) return;
                        if (!String.Equals(Path.GetFileName(dialog.FileName), "nvidiaProfileInspector.exe", StringComparison.OrdinalIgnoreCase))
                        { ThemedDialog.Show(this, Localizer.T("potato.title"), Localizer.T("potato.importFailed"), false); return; }
                        inspector = dialog.FileName;
                    }
                }
            }

            string profileTitle = Localizer.T(profile == 1 ? "potato.light" : "potato.extreme");
            string warning = Localizer.T("potato.confirm") + "\r\n\r\n" + Localizer.T("potato.readOnly");
            if (profile == 2) warning += "\r\n\r\n" + Localizer.T("potato.driverNote") + "\r\n\r\n" + Path.GetFileName(nipFile);
            if (!ThemedDialog.Confirm(this, profileTitle, warning)) return;

            try { EnsureFortniteOriginalBackup(path, backup); }
            catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("error.action"), DescribeSystemError(ex), false); return; }
            if (profile == 2 && !TryStartNvidiaProfileImport(inspector, nipFile)) return;

            try
            {
                WriteFortnitePotatoSettings(path, lines, profile == 2 ? "Extreme" : "Potato");
                ThemedDialog.Show(this, profileTitle, Localizer.T(profile == 2 ? "potato.importStarted" : "potato.lightDone") + "\r\n\r\n" + backup, false);
                if (_page == "potatoGraphics") ShowPage("potatoGraphics");
            }
            catch (Exception ex)
            {
                string message = DescribeSystemError(ex);
                if (profile == 2) message = Localizer.T("potato.configFailedAfterDriver") + "\r\n\r\n" + Localizer.T("potato.driverNote") + "\r\n\r\n" + message;
                ThemedDialog.Show(this, Localizer.T("error.action"), message, false);
            }
        }

        private bool TryStartNvidiaProfileImport(string inspector, string nipFile)
        {
            try
            {
                ProcessStartInfo info = new ProcessStartInfo();
                info.FileName = inspector;
                info.Arguments = "-silentImport \"" + nipFile.Replace("\"", "\\\"") + "\"";
                info.WorkingDirectory = Path.GetDirectoryName(inspector);
                info.UseShellExecute = true; info.Verb = "runas";
                Process process = Process.Start(info);
                if (process == null) throw new InvalidOperationException(Localizer.T("potato.importFailed"));
                process.Dispose();
                return true;
            }
            catch (System.ComponentModel.Win32Exception ex)
            {
                if (ex.NativeErrorCode == 1223)
                    ThemedDialog.Show(this, Localizer.T("potato.title"), Localizer.T("potato.importCancelled"), false);
                else
                    ThemedDialog.Show(this, Localizer.T("potato.title"), Localizer.T("potato.importFailed") + "\r\n\r\n" + DescribeSystemError(ex), false);
                return false;
            }
            catch (Exception ex)
            {
                ThemedDialog.Show(this, Localizer.T("potato.title"), Localizer.T("potato.importFailed") + "\r\n\r\n" + DescribeSystemError(ex), false);
                return false;
            }
        }

        private static string FindNvidiaProfileInspector()
        {
            string[] candidates = {
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "nvidiaProfileInspector.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "NVIDIA Profile Inspector", "nvidiaProfileInspector.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "NVIDIA Profile Inspector", "nvidiaProfileInspector.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NVIDIA Profile Inspector", "nvidiaProfileInspector.exe")
            };
            return candidates.FirstOrDefault(File.Exists);
        }

        private static void WriteFortnitePotatoSettings(string path, string[] lines, string profileName)
        {
            string backup = path + ".freezer-original.bak";
            string state = GetFortniteProfileStatePath(path);
            string temporary = path + ".freezer-potato-" + Guid.NewGuid().ToString("N") + ".tmp";
            string rollback = path + ".freezer-potato-rollback-" + Guid.NewGuid().ToString("N") + ".tmp";
            bool hadState = File.Exists(state); string previousState = hadState ? File.ReadAllText(state, Encoding.UTF8) : null;
            FileAttributes originalAttributes = File.Exists(path) ? File.GetAttributes(path) : FileAttributes.Normal;
            bool replaced = false;
            try
            {
                EnsureFortniteOriginalBackup(path, backup);
                if (File.Exists(path)) { File.Copy(path, rollback, false); File.SetAttributes(rollback, FileAttributes.Normal); }
                File.WriteAllLines(temporary, lines, new UTF8Encoding(true));
                File.SetAttributes(temporary, FileAttributes.Normal);
                if (File.Exists(path))
                {
                    if ((originalAttributes & FileAttributes.ReadOnly) != 0) File.SetAttributes(path, originalAttributes & ~FileAttributes.ReadOnly);
                    File.Replace(temporary, path, null);
                }
                else File.Move(temporary, path);
                replaced = true;
                File.SetAttributes(path, GetFortniteOriginalAttributes(path, backup) | FileAttributes.ReadOnly);
                File.WriteAllText(state, profileName, new UTF8Encoding(false));
            }
            catch
            {
                if (replaced && File.Exists(rollback))
                {
                    try
                    {
                        if (File.Exists(path)) File.SetAttributes(path, File.GetAttributes(path) & ~FileAttributes.ReadOnly);
                        File.Copy(rollback, temporary, true); File.SetAttributes(temporary, FileAttributes.Normal);
                        if (File.Exists(path)) File.Replace(temporary, path, null); else File.Move(temporary, path);
                        File.SetAttributes(path, originalAttributes & ~FileAttributes.ReadOnly);
                        if (hadState) File.WriteAllText(state, previousState ?? String.Empty, new UTF8Encoding(false));
                        else if (File.Exists(state)) File.Delete(state);
                    }
                    catch { }
                }
                else if (File.Exists(path))
                {
                    try { File.SetAttributes(path, originalAttributes & ~FileAttributes.ReadOnly); } catch { }
                }
                throw;
            }
            finally
            {
                try { if (File.Exists(temporary)) { File.SetAttributes(temporary, FileAttributes.Normal); File.Delete(temporary); } } catch { }
                try { if (File.Exists(rollback)) { File.SetAttributes(rollback, FileAttributes.Normal); File.Delete(rollback); } } catch { }
            }
        }

        private void ShowFortniteGraphicsDialog()
        {
            string path = GetFortniteSettingsPath(); string backup = path + ".freezer-original.bak";
            using (Form form = new Form())
            using (Label title = new Label())
            using (Label hint = new Label())
            using (ComboBox preset = MakeCombo(new[] { Localizer.T("fortnite.tierHigh"), Localizer.T("fortnite.tierMedium"), Localizer.T("fortnite.tierLow"), Localizer.T("fortnite.tierExtreme"), Localizer.T("fortnite.restore") }))
            using (Button apply = MakeButton(Localizer.T("fortnite.apply"), Palette.Accent, 36))
            using (Button cancel = MakeButton(Localizer.T("dialog.cancel"), Palette.Surface2, 36))
            using (Button help = MakeButton(Localizer.T("fortnite.help"), Palette.Surface2, 36))
            {
                form.Text = Localizer.T("fortnite.title"); form.FormBorderStyle = FormBorderStyle.None; form.StartPosition = FormStartPosition.CenterParent;
                form.ClientSize = new Size(620, 310); form.BackColor = Palette.Surface; form.ForeColor = Palette.Text; form.Font = UiFontCache.Get("Segoe UI", 9F, FontStyle.Regular); form.ShowInTaskbar = false;
                Panel top = new Panel(); top.Dock = DockStyle.Top; top.Height = 58; top.BackColor = Palette.Sidebar;
                title.Text = Localizer.T("fortnite.title"); title.Font = UiFontCache.Get("Segoe UI Semibold", 12F, FontStyle.Bold); title.ForeColor = Palette.Text; title.Location = new Point(20, 17); title.Size = new Size(570, 26); top.Controls.Add(title);
                hint.Text = Localizer.T("fortnite.hint"); hint.ForeColor = Palette.Muted; hint.Location = new Point(20, 74); hint.Size = new Size(580, 115); hint.AutoEllipsis = true; form.Controls.Add(hint);
                preset.Location = new Point(20, 202); preset.Size = new Size(360, 32); preset.SelectedIndex = 0; form.Controls.Add(preset);
                Label file = new Label(); file.Text = path; file.ForeColor = Palette.Muted; file.Location = new Point(20, 242); file.Size = new Size(580, 22); file.AutoEllipsis = true; form.Controls.Add(file);
                apply.Size = new Size(130, 36); apply.Location = new Point(620 - 284, 264); form.Controls.Add(apply);
                cancel.Size = new Size(130, 36); cancel.Location = new Point(620 - 142, 264); cancel.DialogResult = DialogResult.Cancel; form.Controls.Add(cancel);
                help.Size = new Size(190, 36); help.Location = new Point(20, 264); help.AccessibleDescription = "https://www.epicgames.com/help/c-34254770/c-38015632/pcfortnite-a25544495";
                help.Click += delegate
                {
                    try { Process.Start(help.AccessibleDescription); }
                    catch (Exception ex) { ThemedDialog.Show(form, Localizer.T("fortnite.help"), Localizer.T("fortnite.helpError") + "\r\n\r\n" + DescribeSystemError(ex), false); }
                };
                form.Controls.Add(help);
                apply.Click += delegate { form.DialogResult = DialogResult.OK; form.Close(); };
                preset.SelectedIndexChanged += delegate { apply.Enabled = preset.SelectedIndex == 4 ? File.Exists(backup) : File.Exists(path); };
                apply.Enabled = File.Exists(path);
                if (!File.Exists(path)) hint.Text = Localizer.T("fortnite.notFound") + "\r\n\r\n" + hint.Text;
                form.Controls.Add(top); form.AcceptButton = apply; form.CancelButton = cancel;
                if (form.ShowDialog(this) == DialogResult.OK) ApplyFortniteGraphicsPreset(preset.SelectedIndex, path, backup);
            }
        }

        private void ApplyFortniteGraphicsPreset(int profile, string path, string backup)
        {
            Process[] gameProcesses = Process.GetProcessesByName("FortniteClient-Win64-Shipping");
            bool gameRunning = gameProcesses.Length > 0; foreach (Process gameProcess in gameProcesses) try { gameProcess.Dispose(); } catch { }
            if (gameRunning) { ThemedDialog.Show(this, Localizer.T("fortnite.title"), Localizer.T("fortnite.running"), false); return; }
            if (profile == 4)
            {
                RestoreFortniteOriginal(path, backup, true);
                return;
            }
            if (!File.Exists(path)) { ThemedDialog.Show(this, Localizer.T("fortnite.title"), Localizer.T("fortnite.notFound"), false); return; }
            string[] tierKeys = { "fortnite.tierHigh", "fortnite.tierMedium", "fortnite.tierLow", "fortnite.tierExtreme" };
            if (profile < 0 || profile > 3) return;
            if (!ThemedDialog.Confirm(this, Localizer.T("fortnite.title"), Localizer.T(tierKeys[profile]) + "\r\n\r\n" + Localizer.T("fortnite.confirm") + "\r\n\r\n" + Localizer.T("fortnite.hint"))) return;
            try
            {
                string[] lines = File.ReadAllLines(path, Encoding.UTF8);
                int quality = 3 - profile;
                int changed = SetFortniteQualityValues(lines, quality);
                if (changed == 0) { ThemedDialog.Show(this, Localizer.T("fortnite.title"), Localizer.T("fortnite.keysMissing"), false); return; }
                EnsureFortniteOriginalBackup(path, backup);
                string temporary = path + ".freezer-write.tmp";
                try { File.WriteAllLines(temporary, lines, new UTF8Encoding(true)); File.Replace(temporary, path, null); }
                finally { try { if (File.Exists(temporary)) File.Delete(temporary); } catch { } }
                string profileState = profile == 3 ? "Extreme" : profile == 2 ? "Potato" : profile == 1 ? "Medium" : "High";
                File.WriteAllText(GetFortniteProfileStatePath(path), profileState, new UTF8Encoding(false));
                ThemedDialog.Show(this, Localizer.T("fortnite.title"), Localizer.T(profile == 3 ? "fortnite.potatoEnabled" : "fortnite.done") + "\r\n\r\n" + backup, false);
            }
            catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("error.action"), DescribeSystemError(ex), false); }
        }

        private static void EnsureFortniteOriginalBackup(string path, string backup)
        {
            FileAttributes sourceAttributes = File.Exists(path) ? File.GetAttributes(path) : FileAttributes.Normal;
            string temporary = backup + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                if (!File.Exists(backup))
                {
                    File.Copy(path, temporary, false);
                    if (new FileInfo(temporary).Length != new FileInfo(path).Length) throw new IOException("The Fortnite settings backup could not be verified.");
                    try { File.Move(temporary, backup); }
                    catch (IOException) { if (!File.Exists(backup)) throw; }
                }
                string metadata = GetFortniteOriginalAttributesPath(path);
                if (!File.Exists(metadata))
                {
                    FileAttributes attributes = File.Exists(backup) ? File.GetAttributes(backup) : sourceAttributes;
                    File.WriteAllText(metadata, ((int)attributes).ToString(CultureInfo.InvariantCulture), new UTF8Encoding(false));
                }
            }
            finally { try { if (File.Exists(temporary)) File.Delete(temporary); } catch { } }
        }

        private static int SetFortnitePotatoQualityValues(string[] lines, int quality)
        {
            string[] keys = { "sg.ViewDistanceQuality", "sg.ShadowQuality", "sg.TextureQuality" };
            bool inScalability = false; int updated = 0;
            for (int i = 0; i < lines.Length; i++)
            {
                string trimmed = lines[i].Trim();
                if (trimmed.StartsWith("[", StringComparison.Ordinal) && trimmed.EndsWith("]", StringComparison.Ordinal))
                { inScalability = String.Equals(trimmed, "[ScalabilityGroups]", StringComparison.OrdinalIgnoreCase); continue; }
                if (!inScalability) continue;
                foreach (string key in keys)
                {
                    if (!Regex.IsMatch(lines[i], @"^\s*" + Regex.Escape(key) + @"\s*=", RegexOptions.IgnoreCase)) continue;
                    int equals = lines[i].IndexOf('='); lines[i] = lines[i].Substring(0, equals + 1) + quality.ToString(CultureInfo.InvariantCulture); updated++; break;
                }
            }
            return updated;
        }

        private static int SetFortniteQualityValues(string[] lines, int quality)
        {
            string[] keys = { "sg.ViewDistanceQuality", "sg.AntiAliasingQuality", "sg.ShadowQuality", "sg.GlobalIlluminationQuality", "sg.ReflectionQuality", "sg.PostProcessQuality", "sg.TextureQuality", "sg.EffectsQuality", "sg.FoliageQuality", "sg.ShadingQuality" };
            bool inScalability = false; int updated = 0;
            for (int i = 0; i < lines.Length; i++)
            {
                string trimmed = lines[i].Trim();
                if (trimmed.StartsWith("[", StringComparison.Ordinal) && trimmed.EndsWith("]", StringComparison.Ordinal))
                { inScalability = String.Equals(trimmed, "[ScalabilityGroups]", StringComparison.OrdinalIgnoreCase); continue; }
                if (!inScalability) continue;
                foreach (string key in keys)
                {
                    if (Regex.IsMatch(lines[i], @"^\s*" + Regex.Escape(key) + @"\s*=", RegexOptions.IgnoreCase))
                    {
                        int equals = lines[i].IndexOf('='); lines[i] = lines[i].Substring(0, equals + 1) + quality.ToString(CultureInfo.InvariantCulture); updated++; break;
                    }
                }
            }
            return updated;
        }

        private bool ApplyGameProfile(string gameKey, int profileIndex)
        {
            string[] profileKeys = { "Lite", "Balanced", "Power", "MaxFPS", "Streamer" };
            profileIndex = Math.Max(0, Math.Min(profileKeys.Length - 1, profileIndex));
            string profile = profileKeys[profileIndex];
            string gameName = Localizer.T(gameKey);
            string detailKey = profile == "MaxFPS" ? "games.maxFpsDetails" : profile == "Streamer" ? "games.streamerDetails" : profile == "Lite" ? "games.liteDetails" : profile == "Power" ? "games.powerDetails" : "games.balancedDetails";
            string profileName = Localizer.T(profile == "MaxFPS" ? "games.maxFps" : profile == "Streamer" ? "games.streamer" : profile == "Lite" ? "games.lite" : profile == "Power" ? "games.power" : "games.balanced");
            string details = gameName + " · " + profileName + "\r\n\r\n" + Localizer.T(detailKey) + "\r\n\r\n" + Localizer.T("gaming.boostDetails") + "\r\n\r\n" + Localizer.T("games.applyHint");
            if (profile == "Power" || profile == "MaxFPS") details += "\r\n\r\n" + Localizer.T("repair.adminWhy");
            if (!ThemedDialog.Confirm(this, gameName + " · " + Localizer.T("games.profile"), Localizer.T("games.apply") + "?\r\n\r\n" + details)) return false;
            List<string> applied = new List<string>();
            try
            {
                Optimization mode = _optimizations.First(x => x.Key == "game_mode");
                if (!_tweaks.IsActive("game_mode")) { _tweaks.Apply("game_mode", mode.Edits); applied.Add("game_mode"); }
                if (profile == "Balanced" || profile == "Power" || profile == "MaxFPS")
                {
                    Optimization dvr = _optimizations.First(x => x.Key == "game_dvr");
                    if (!_tweaks.IsActive("game_dvr")) { _tweaks.Apply("game_dvr", dvr.Edits); applied.Add("game_dvr"); }
                }
                if ((profile == "Power" || profile == "MaxFPS") && !_tweaks.IsActive("cpu_policy")) { ApplyCpuPolicy(); applied.Add("cpu_policy"); }
                _prefs.GameProfiles[gameKey] = profile; SavePreferences();
                QueueGamingSessionBoost();
                SetStatus(Localizer.T("games.applied")); RefreshGamingModeButton();
                if (_page == "optimizations") ShowPage(_page);
                return true;
            }
            catch (Exception ex)
            {
                for (int i = applied.Count - 1; i >= 0; i--)
                {
                    try { if (applied[i] == "cpu_policy") RestoreCpuPolicy(); else _tweaks.Restore(applied[i]); } catch { }
                }
                string message = DescribeSystemError(ex);
                if (ex is UnauthorizedAccessException) message = Localizer.T("error.adminHint") + "\r\n\r\n" + message;
                ThemedDialog.Show(this, Localizer.T("error.optimization"), message, false);
                RefreshGamingModeButton();
                return false;
            }
        }

        private ComboBox MakeCombo(string[] values)
        {
            ModernComboBox c = new ModernComboBox(); c.DropDownStyle = ComboBoxStyle.DropDownList; c.FlatStyle = FlatStyle.Flat; c.BackColor = Palette.Surface2;
            c.ForeColor = Palette.Text; c.Font = UiFontCache.Get("Segoe UI", 9F, FontStyle.Regular); c.Items.AddRange(values); c.Height = 32; return c;
        }

        private ComboBox MakeColorCombo(string[] values)
        {
            ModernComboBox c = new ModernComboBox(); c.DropDownStyle = ComboBoxStyle.DropDownList; c.FlatStyle = FlatStyle.Flat;
            c.BackColor = Palette.Surface2; c.ForeColor = Palette.Text; c.Font = UiFontCache.Get("Segoe UI", 9F, FontStyle.Regular);
            c.Items.AddRange(values); c.Height = 32; return c;
        }

        private void RenderHardware()
        {
            AddPageHeading(Localizer.T("hardware.title"), Localizer.T("hardware.subtitle"));
            FlowLayoutPanel metrics = new FlowLayoutPanel(); metrics.Width = Math.Max(600, _content.ClientSize.Width - 56); metrics.Height = 174; metrics.WrapContents = false; metrics.BackColor = Palette.Background;
            AddGauge(metrics, "cpu", Localizer.T("metric.cpu")); AddGauge(metrics, "gpu", Localizer.T("metric.gpu")); AddGauge(metrics, "ram", Localizer.T("metric.ram")); _content.Controls.Add(metrics);
            RoundPanel detail = Card(164); AddValue(detail, "hardware_cpu", "CPU —", 11, Palette.Text, new Point(16, 15), new Size(detail.Width - 32, 24));
            AddValue(detail, "hardware_ram", "RAM —", 11, Palette.Text, new Point(16, 44), new Size(detail.Width - 32, 24));
            AddValue(detail, "hardware_gpu", "GPU —", 11, Palette.Text, new Point(16, 73), new Size(detail.Width - 32, 24));
            AddValue(detail, "hardware_fps", "FPS —", 11, Palette.Text, new Point(16, 102), new Size(detail.Width - 32, 24));
            AddValue(detail, "hardware_cores", Localizer.T("metric.cores") + " —", 9, Palette.Muted, new Point(16, 132), new Size(detail.Width - 32, 23)); _content.Controls.Add(detail);
            UpdateHomeHardwareSummary(_latest);
            RoundPanel capture = Card(112); Label title = MakeLabel(Localizer.T("hardware.target"), 11, Palette.Text, true); title.Location = new Point(16, 13); title.Size = new Size(300, 23); capture.Controls.Add(title);
            _processPicker = MakeCombo(new string[0]); _processPicker.Location = new Point(16, 48); _processPicker.Width = 360; capture.Controls.Add(_processPicker);
            Button refresh = MakeButton(Localizer.T("hardware.refresh"), Palette.Surface2, 36); refresh.Width = 98; refresh.Click += delegate { RefreshProcesses(); }; capture.Controls.Add(refresh);
            Button attach = MakeButton(Localizer.T("hardware.attach"), Palette.Accent, 36); attach.Width = 104; attach.Click += delegate { AttachFps(); }; capture.Controls.Add(attach);
            Button overlay = MakeButton(Localizer.T("hardware.overlay"), Palette.Surface2, 36); overlay.Width = 126; overlay.Click += delegate { ToggleOverlay(); }; capture.Controls.Add(overlay);
            Button stop = MakeButton(Localizer.T("hardware.detach"), Palette.Surface2, 36); stop.Width = 108; stop.Click += delegate { _fpsAutoCapture = false; _fpsPinnedProcessId = -1; _fps.Stop(); if (_hardwareStatus != null) _hardwareStatus.Text = Localizer.T("hardware.subtitle"); UpdateSampleTimer(); }; capture.Controls.Add(stop);
            Action layoutCapture = delegate
            {
                int right = capture.ClientSize.Width - 16;
                stop.Location = new Point(Math.Max(16, right - stop.Width), 47);
                overlay.Location = new Point(Math.Max(16, stop.Left - overlay.Width - 8), 47);
                attach.Location = new Point(Math.Max(16, overlay.Left - attach.Width - 8), 47);
                refresh.Location = new Point(Math.Max(16, attach.Left - refresh.Width - 8), 47);
                _processPicker.Width = Math.Max(180, refresh.Left - _processPicker.Left - 8);
                if (_hardwareStatus != null) _hardwareStatus.Size = new Size(Math.Max(180, capture.ClientSize.Width - 32), 20);
            };
            capture.Resize += delegate { layoutCapture(); };
            layoutCapture();
            _hardwareStatus = MakeLabel(Localizer.T("monitor.unavailable"), 8, Palette.Muted, false); _hardwareStatus.Location = new Point(16, 82); _hardwareStatus.Size = new Size(capture.Width - 32, 20); capture.Controls.Add(_hardwareStatus);
            _content.Controls.Add(capture);
            Label limits = MakeLabel(Localizer.T("hardware.sensorLimit"), 8, Palette.Muted, false); limits.Width = Math.Max(500, _content.ClientSize.Width - 56); limits.Height = 32; limits.Margin = new Padding(0, 2, 0, 10); _content.Controls.Add(limits);
            RefreshProcesses(); UpdateReadings(_latest, _fps.Get());
        }

        private void RefreshProcesses()
        {
            if (_processPicker == null || _processPicker.IsDisposed) return;
            int currentPid = (_processPicker.SelectedItem as ProcessChoice) == null ? -1 : ((_processPicker.SelectedItem as ProcessChoice).Pid);
            _processPicker.BeginUpdate(); _processPicker.Items.Clear();
            List<ProcessChoice> choices = new List<ProcessChoice>();
            foreach (Process p in Process.GetProcesses())
            {
                try { string name = p.ProcessName; if (IsGameProcessName(name)) choices.Add(new ProcessChoice { Pid = p.Id, Name = name, DisplayName = Localizer.T(GameKeyForProcess(name)) }); }
                catch { }
                finally { try { p.Dispose(); } catch { } }
            }
            foreach (ProcessChoice choice in choices.OrderBy(x => x.Name)) _processPicker.Items.Add(choice);
            if (_processPicker.Items.Count > 0)
            {
                int index = 0; for (int i = 0; i < _processPicker.Items.Count; i++) if (((ProcessChoice)_processPicker.Items[i]).Pid == currentPid) index = i;
                _processPicker.SelectedIndex = index;
            }
            _processPicker.EndUpdate();
        }

        private void AttachFps()
        {
            ProcessChoice choice = _processPicker == null ? null : _processPicker.SelectedItem as ProcessChoice;
            if (choice == null) { SetStatus(Localizer.T("fps.noTarget")); return; }
            _fpsAutoCapture = true;
            _fpsPinnedProcessId = choice.Pid;
            if (!_presentMonReady)
            {
                QueuePresentMonExtraction();
                if (_hardwareStatus != null) _hardwareStatus.Text = Localizer.T("fps.preparing");
                SetStatus(Localizer.T("fps.preparing"));
                UpdateSampleTimer();
                return;
            }
            if (_fps.Start(_presentMonPath, choice.Pid))
            {
                _hardwareStatus.Text = String.Format(CultureInfo.CurrentCulture, Localizer.T("fps.captureAttached"), choice.DisplayName ?? choice.Name, choice.Pid);
                UpdateSampleTimer();
            }
            else ThemedDialog.Show(this, Localizer.T("metric.fps"), Localizer.T("fps.captureError") + "\r\n\r\n" + Localizer.T("overlay.hint"), false);
        }

        private string GameKeyForProcess(string process)
        {
            if (process == "javaw") return "game.minecraft";
            if (process == "Minecraft.Windows") return "game.minecraftBedrock";
            if (process.IndexOf("League", StringComparison.OrdinalIgnoreCase) >= 0) return "game.league";
            if (String.Equals(process, "TslGame", StringComparison.OrdinalIgnoreCase)) return "game.pubg";
            if (String.Equals(process, "cod", StringComparison.OrdinalIgnoreCase)) return "game.warzone";
            if (String.Equals(process, "dota2", StringComparison.OrdinalIgnoreCase)) return "game.dota";
            if (String.Equals(process, "RobloxPlayerBeta", StringComparison.OrdinalIgnoreCase)) return "game.roblox";
            if (String.Equals(process, "FC26", StringComparison.OrdinalIgnoreCase)) return "game.fc26";
            if (process.IndexOf("Fortnite", StringComparison.OrdinalIgnoreCase) >= 0) return "game.fortnite";
            if (process.IndexOf("VALORANT", StringComparison.OrdinalIgnoreCase) >= 0) return "game.valorant";
            if (process.IndexOf("GTA5", StringComparison.OrdinalIgnoreCase) >= 0) return "game.gta";
            if (process.IndexOf("Cyberpunk", StringComparison.OrdinalIgnoreCase) >= 0) return "game.cyberpunk";
            if (process.IndexOf("RocketLeague", StringComparison.OrdinalIgnoreCase) >= 0) return "game.rocket";
            if (process.IndexOf("Overwatch", StringComparison.OrdinalIgnoreCase) >= 0) return "game.overwatch";
            if (process.IndexOf("RainbowSix", StringComparison.OrdinalIgnoreCase) >= 0) return "game.r6";
            if (process.IndexOf("r5apex", StringComparison.OrdinalIgnoreCase) >= 0) return "game.apex";
            if (process.IndexOf("helldivers", StringComparison.OrdinalIgnoreCase) >= 0) return "game.helldivers";
            if (process.IndexOf("FarmingSimulator", StringComparison.OrdinalIgnoreCase) >= 0) return "game.farming";
            if (process == "cs2") return "game.counterstrike";
            foreach (KeyValuePair<string, string> launch in _prefs.GameLaunchPaths)
                if (String.Equals(Path.GetFileNameWithoutExtension(launch.Value), process, StringComparison.OrdinalIgnoreCase)) return launch.Key;
            return process;
        }

        private void RenderColorProfiles()
        {
            AddPageHeading(Localizer.T("colors.title"), Localizer.T("colors.subtitle"));
            _nvidiaColorSection = CreateColorSection(true);
            _amdColorSection = CreateColorSection(false);
            _content.Controls.Add(_nvidiaColorSection.Card);
            _content.Controls.Add(_amdColorSection.Card);
            RoundPanel note = Card(92);
            Label noteText = MakeLabel(Localizer.T("colors.displayHint") + "\r\n" + Localizer.T("colors.globalNote") + "\r\n" + Localizer.T("colors.monitoring"), 9, Palette.Muted, false);
            noteText.Location = new Point(14, 10); noteText.Size = new Size(note.Width - 30, 72); noteText.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; note.Controls.Add(noteText); _content.Controls.Add(note);
            QueueColorHardwareRefresh();
        }

        private ColorProfileSection CreateColorSection(bool nvidia)
        {
            ColorProfileSection section = new ColorProfileSection { IsNvidia = nvidia, Vendor = nvidia ? "nvidia" : "amd" };
            section.Card = Card(94);
            Label title = MakeLabel(Localizer.T(nvidia ? "colors.nvidia" : "colors.amd"), 16, Palette.Text, true);
            title.Location = new Point(16, 10); title.Size = new Size(350, 25); section.Card.Controls.Add(title);
            section.Status = MakeLabel(Localizer.T("colors.sectionStatus"), 9, Palette.Muted, false);
            section.Status.Location = new Point(16, 36); section.Status.Size = new Size(section.Card.Width - 32, 42); section.Status.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; section.Card.Controls.Add(section.Status);
            section.Editor = new RoundPanel(); section.Editor.BackColor = Palette.Surface2; section.Editor.Location = new Point(8, 78); section.Editor.Size = new Size(section.Card.Width - 16, 438); section.Editor.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; section.Editor.Visible = false; section.Card.Controls.Add(section.Editor);
            Label deviceLabel = MakeLabel(Localizer.T("colors.device"), 9, Palette.Muted, true); section.Editor.Controls.Add(deviceLabel);
            section.DevicePicker = MakeColorCombo(new string[0]); section.Editor.Controls.Add(section.DevicePicker);
            Label profileLabel = MakeLabel(Localizer.T("colors.profile"), 9, Palette.Muted, true); section.Editor.Controls.Add(profileLabel);
            section.ProfilePicker = MakeColorCombo(new[] { Localizer.T("colors.standard") }); section.Editor.Controls.Add(section.ProfilePicker);
            section.SaturationLabel = MakeLabel(Localizer.T(nvidia ? "colors.digitalVibrance" : "colors.saturation"), 9, Palette.Muted, true); section.Editor.Controls.Add(section.SaturationLabel);
            section.Saturation = new ModernSlider(); section.Saturation.Minimum = 0; section.Saturation.Maximum = 100; section.Saturation.BackColor = Palette.Surface; section.Saturation.AccessibleName = Localizer.T(nvidia ? "colors.digitalVibrance" : "colors.saturation"); section.Editor.Controls.Add(section.Saturation);
            section.ValueLabel = MakeLabel("—", 10, Palette.Accent, true); section.Editor.Controls.Add(section.ValueLabel);
            section.BrightnessLabel = MakeLabel(Localizer.T("colors.brightness"), 9, Palette.Muted, true); section.Editor.Controls.Add(section.BrightnessLabel);
            section.Brightness = new ModernSlider(); section.Brightness.BackColor = Palette.Surface; section.Brightness.AccessibleName = Localizer.T("colors.brightness"); section.Editor.Controls.Add(section.Brightness);
            section.BrightnessValue = MakeLabel("—", 9, Palette.Accent, true); section.Editor.Controls.Add(section.BrightnessValue);
            section.ContrastLabel = MakeLabel(Localizer.T("colors.contrast"), 9, Palette.Muted, true); section.Editor.Controls.Add(section.ContrastLabel);
            section.Contrast = new ModernSlider(); section.Contrast.BackColor = Palette.Surface; section.Contrast.AccessibleName = Localizer.T("colors.contrast"); section.Editor.Controls.Add(section.Contrast);
            section.ContrastValue = MakeLabel("—", 9, Palette.Accent, true); section.Editor.Controls.Add(section.ContrastValue);
            section.HueLabel = MakeLabel(Localizer.T("colors.hue"), 9, Palette.Muted, true); section.Editor.Controls.Add(section.HueLabel);
            section.Hue = new ModernSlider(); section.Hue.BackColor = Palette.Surface; section.Hue.AccessibleName = Localizer.T("colors.hue"); section.Editor.Controls.Add(section.Hue);
            section.HueValue = MakeLabel("—", 9, Palette.Accent, true); section.Editor.Controls.Add(section.HueValue);
            section.DriverHelp = MakeLabel(Localizer.T(nvidia ? "colors.nvidiaNote" : "colors.amdGammaNote"), 8, Palette.Muted, false); section.Editor.Controls.Add(section.DriverHelp);
            section.DriverPanelButton = MakeButton(Localizer.T("colors.openControlPanel"), Palette.Surface2, 34); section.DriverPanelButton.Click += delegate { OpenNvidiaControlPanel(); }; section.Editor.Controls.Add(section.DriverPanelButton);
            Label nameLabel = MakeLabel(Localizer.T("colors.profileName"), 9, Palette.Muted, true); section.Editor.Controls.Add(nameLabel);
            section.ProfileName = new TextBox(); section.ProfileName.BackColor = Palette.Surface2; section.ProfileName.ForeColor = Palette.Text; section.ProfileName.BorderStyle = BorderStyle.FixedSingle; section.ProfileName.Font = UiFontCache.Get("Segoe UI", 9F, FontStyle.Regular); section.Editor.Controls.Add(section.ProfileName);
            section.SaveButton = MakeButton(Localizer.T("colors.save"), Palette.Surface2, 36); section.SaveButton.Click += delegate { SaveColorProfile(section); }; section.Editor.Controls.Add(section.SaveButton);
            section.ApplyButton = MakeButton(Localizer.T("colors.apply"), Palette.Surface2, 36); section.ApplyButton.Click += delegate { ApplySelectedColorProfile(section); }; section.Editor.Controls.Add(section.ApplyButton);
            section.ResetButton = MakeButton(Localizer.T("colors.reset"), Palette.Accent, 36); section.ResetButton.Click += delegate { ApplyStandardColorProfile(section, true); }; section.Editor.Controls.Add(section.ResetButton);
            Label gameLabel = MakeLabel(Localizer.T("colors.game"), 9, Palette.Muted, true); section.Editor.Controls.Add(gameLabel);
            string[] gameKeys = { "game.fortnite", "game.minecraft", "game.minecraftBedrock", "game.valorant", "game.gta", "game.cyberpunk", "game.rocket", "game.overwatch", "game.r6", "game.apex", "game.helldivers", "game.farming", "game.counterstrike", "game.league", "game.pubg", "game.warzone", "game.dota", "game.roblox", "game.fc26" };
            section.GamePicker = MakeColorCombo(gameKeys.Select(Localizer.T).ToArray()); section.GamePicker.SelectedIndex = 0; section.Editor.Controls.Add(section.GamePicker);
            section.GameProfilePicker = MakeColorCombo(new[] { Localizer.T("colors.noProfile"), Localizer.T("colors.standard") }); section.Editor.Controls.Add(section.GameProfilePicker);
            section.AssignButton = MakeButton(Localizer.T("colors.saveAssignment"), Palette.Surface2, 36); section.AssignButton.Click += delegate { SaveColorGameAssignment(section); }; section.Editor.Controls.Add(section.AssignButton);
            section.SavedProfilesLabel = MakeLabel(Localizer.T("colors.savedProfiles"), 9, Palette.Muted, true); section.Editor.Controls.Add(section.SavedProfilesLabel);
            section.SavedProfileChips = new FlowLayoutPanel(); section.SavedProfileChips.BackColor = Palette.Surface; section.SavedProfileChips.FlowDirection = FlowDirection.LeftToRight; section.SavedProfileChips.WrapContents = false; section.SavedProfileChips.AutoScroll = true; section.SavedProfileChips.Margin = Padding.Empty; section.SavedProfileChips.Padding = new Padding(0, 2, 2, 2); section.Editor.Controls.Add(section.SavedProfileChips);
            section.DevicePicker.SelectedIndexChanged += delegate
            {
                ColorDisplayInfo selected = section.DevicePicker.SelectedItem as ColorDisplayInfo;
                if (selected != null && section.ApiReady)
                {
                    if (section.IsNvidia) _prefs.NvidiaSelectedDisplay = selected.DeviceKey;
                    else _prefs.AmdSelectedDisplay = selected.DeviceKey;
                    SavePreferences();
                }
                UpdateColorSectionControls(section, true);
            };
            section.ProfilePicker.SelectedIndexChanged += delegate { UpdateColorSectionControls(section, true); UpdateSavedColorProfileChipSelection(section); };
            section.Saturation.ValueChanged += delegate { UpdateColorValueLabel(section.Saturation, section.ValueLabel, false); };
            section.Brightness.ValueChanged += delegate { UpdateColorValueLabel(section.Brightness, section.BrightnessValue, false); };
            section.Contrast.ValueChanged += delegate { UpdateColorValueLabel(section.Contrast, section.ContrastValue, false); };
            section.Hue.ValueChanged += delegate { UpdateColorValueLabel(section.Hue, section.HueValue, true); };
            section.GamePicker.SelectedIndexChanged += delegate { RefreshColorGameProfilePicker(section); };
            section.Card.SizeChanged += delegate { LayoutColorSection(section); };
            LayoutColorSection(section);
            return section;
        }

        private void LayoutColorSection(ColorProfileSection section)
        {
            if (section == null || section.Card == null || section.Card.IsDisposed) return;
            int width = section.Editor.ClientSize.Width; int comboWidth = Math.Max(180, width - 178);
            section.Status.Width = Math.Max(200, width - 32);
            section.DevicePicker.Location = new Point(150, 3); section.DevicePicker.Size = new Size(comboWidth, 30); section.DevicePicker.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            section.ProfilePicker.Location = new Point(150, 42); section.ProfilePicker.Size = new Size(comboWidth, 30); section.ProfilePicker.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            int sliderWidth = Math.Max(150, width - 270);
            section.SaturationLabel.Location = new Point(16, 81); section.SaturationLabel.Size = new Size(130, 24);
            section.Saturation.Location = new Point(150, 77); section.Saturation.Size = new Size(sliderWidth, 30); section.Saturation.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            section.ValueLabel.Location = new Point(width - 95, 81); section.ValueLabel.Size = new Size(76, 24); section.ValueLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            section.BrightnessLabel.Location = new Point(16, 115); section.BrightnessLabel.Size = new Size(130, 24);
            section.Brightness.Location = new Point(150, 111); section.Brightness.Size = new Size(sliderWidth, 30); section.Brightness.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            section.BrightnessValue.Location = new Point(width - 95, 115); section.BrightnessValue.Size = new Size(76, 24); section.BrightnessValue.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            section.ContrastLabel.Location = new Point(16, 149); section.ContrastLabel.Size = new Size(130, 24);
            section.Contrast.Location = new Point(150, 145); section.Contrast.Size = new Size(sliderWidth, 30); section.Contrast.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            section.ContrastValue.Location = new Point(width - 95, 149); section.ContrastValue.Size = new Size(76, 24); section.ContrastValue.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            section.HueLabel.Location = new Point(16, 183); section.HueLabel.Size = new Size(130, 24);
            section.Hue.Location = new Point(150, 179); section.Hue.Size = new Size(sliderWidth, 30); section.Hue.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            section.HueValue.Location = new Point(width - 95, 183); section.HueValue.Size = new Size(76, 24); section.HueValue.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            section.DriverHelp.Location = new Point(150, section.IsNvidia ? 250 : 213); section.DriverHelp.Size = new Size(Math.Max(200, width - 178), 32); section.DriverHelp.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            section.DriverPanelButton.Location = new Point(150, 212); section.DriverPanelButton.Size = new Size(230, 34);
            int x = 150, rowWidth = Math.Max(500, width - 166), gap = 7;
            int saveWidth = 140, applyWidth = 128, resetWidth = 156;
            int nameWidth = Math.Max(130, rowWidth - saveWidth - applyWidth - resetWidth - gap * 4);
            int nameY = section.IsNvidia ? 286 : 251;
            section.ProfileName.Location = new Point(x, nameY + 3); section.ProfileName.Size = new Size(nameWidth, 30); section.ProfileName.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            x += nameWidth + gap;
            section.SaveButton.Location = new Point(x, nameY); section.SaveButton.Size = new Size(saveWidth, 36); x += saveWidth + gap;
            section.ApplyButton.Location = new Point(x, nameY); section.ApplyButton.Size = new Size(applyWidth, 36); x += applyWidth + gap;
            section.ResetButton.Location = new Point(x, nameY); section.ResetButton.Size = new Size(resetWidth, 36);
            int gameRowWidth = Math.Max(500, width - 166), gameButtonWidth = 145, gameGap = 8;
            int gameComboWidth = Math.Max(140, (gameRowWidth - gameButtonWidth - gameGap * 2) / 2);
            int gameY = nameY + 49;
            section.GamePicker.Location = new Point(150, gameY + 3); section.GamePicker.Size = new Size(gameComboWidth, 30); section.GamePicker.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            section.GameProfilePicker.Location = new Point(150 + gameComboWidth + gameGap, gameY + 3); section.GameProfilePicker.Size = new Size(gameComboWidth, 30); section.GameProfilePicker.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            section.AssignButton.Location = new Point(width - 16 - gameButtonWidth, gameY); section.AssignButton.Size = new Size(gameButtonWidth, 36); section.AssignButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            int chipsY = gameY + 45;
            section.SavedProfilesLabel.Location = new Point(16, chipsY + 7); section.SavedProfilesLabel.Size = new Size(130, 24);
            section.SavedProfileChips.Location = new Point(150, chipsY); section.SavedProfileChips.Size = new Size(Math.Max(150, width - 178), 52); section.SavedProfileChips.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            section.Brightness.Visible = section.BrightnessLabel.Visible = section.BrightnessValue.Visible = !section.IsNvidia;
            section.Contrast.Visible = section.ContrastLabel.Visible = section.ContrastValue.Visible = !section.IsNvidia;
            section.Hue.Visible = section.HueLabel.Visible = section.HueValue.Visible = !section.IsNvidia;
            section.DriverPanelButton.Visible = section.IsNvidia;
            section.DriverHelp.Visible = true;
        }

        private void QueueColorHardwareRefresh()
        {
            if (Interlocked.CompareExchange(ref _colorHardwareRefreshBusy, 1, 0) != 0) return;
            ThreadPool.QueueUserWorkItem(delegate
            {
                bool nvidia = false, amd = false;
                try
                {
                    using (ManagementObjectSearcher search = new ManagementObjectSearcher(new ManagementScope(@"\\.\root\CIMV2"), new ObjectQuery("SELECT Name, PNPDeviceID FROM Win32_VideoController"), new EnumerationOptions { Timeout = TimeSpan.FromSeconds(3) }))
                    using (ManagementObjectCollection results = search.Get())
                    {
                        foreach (ManagementObject item in results)
                        {
                            string name = Convert.ToString(item["Name"]), pnp = Convert.ToString(item["PNPDeviceID"]);
                            string identity = (name + " " + pnp).ToLowerInvariant();
                            if (identity.Contains("nvidia") || identity.Contains("ven_10de")) nvidia = true;
                            if (identity.Contains("amd") || identity.Contains("advanced micro") || identity.Contains("ven_1002") || name.StartsWith("ATI", StringComparison.OrdinalIgnoreCase)) amd = true;
                        }
                    }
                }
                catch { }
                IList<ColorDisplayInfo> nvidiaDevices = new List<ColorDisplayInfo>(), amdDevices = new List<ColorDisplayInfo>();
                string nvidiaError = "", amdError = "";
                if (nvidia) try { nvidiaDevices = NvidiaColorApi.GetDisplays().Select(x => new ColorDisplayInfo { DeviceKey = x.DeviceName, DisplayLabel = x.DisplayLabel, CurrentLevel = x.CurrentLevel, MinimumLevel = x.MinimumLevel, MaximumLevel = x.MaximumLevel, DefaultLevel = x.DefaultLevel, IsNvidia = true }).ToList(); } catch (Exception ex) { nvidiaError = ex.Message; }
                if (amd) try { amdDevices = AmdColorApi.GetDisplays(); } catch (Exception ex) { amdError = ex.Message; }
                try
                {
                    if (!_closing && !IsDisposed) BeginInvoke((MethodInvoker)delegate
                    {
                        if (_page != "colorProfiles" || IsDisposed) return;
                        UpdateColorSectionHardware(_nvidiaColorSection, nvidia, nvidiaDevices, nvidiaError);
                        UpdateColorSectionHardware(_amdColorSection, amd, amdDevices, amdError);
                    });
                }
                catch { }
                finally { Interlocked.Exchange(ref _colorHardwareRefreshBusy, 0); }
            });
        }

        private void UpdateColorSectionHardware(ColorProfileSection section, bool detected, IList<ColorDisplayInfo> devices, string error)
        {
            if (section == null || section.Card == null || section.Card.IsDisposed) return;
            section.HardwarePresent = detected; section.ApiReady = devices != null && devices.Count > 0; section.Devices = devices ?? new List<ColorDisplayInfo>();
            section.DevicePicker.Items.Clear();
            foreach (ColorDisplayInfo device in section.Devices) section.DevicePicker.Items.Add(device);
            if (section.ApiReady)
            {
                string savedDevice = section.IsNvidia ? _prefs.NvidiaSelectedDisplay : _prefs.AmdSelectedDisplay;
                ColorDisplayInfo selection = section.Devices.FirstOrDefault(x => String.Equals(x.DeviceKey, savedDevice, StringComparison.OrdinalIgnoreCase)) ?? section.Devices[0];
                section.DevicePicker.SelectedItem = selection;
                section.Status.Text = section.Vendor.ToUpperInvariant() + " · " + section.Devices.Count.ToString(CultureInfo.InvariantCulture) + " " + Localizer.T("colors.device");
                section.Status.ForeColor = Palette.Green;
                RefreshColorProfilePicker(section, null);
            }
            else
            {
                section.Status.Text = detected ? Localizer.T("colors.driverUnavailable") : Localizer.T(section.IsNvidia ? "colors.noNvidia" : "colors.noAmd");
                section.Status.ForeColor = detected ? Palette.Red : Palette.Muted;
            }
            SetColorSectionEnabled(section, section.ApiReady);
            UpdateColorSectionControls(section, false);
            RebuildGameSessionProfilePickers();
        }

        private static void SetColorSectionEnabled(ColorProfileSection section, bool enabled)
        {
            section.Editor.Visible = enabled;
            section.Card.Height = enabled ? 530 : 94;
            section.DevicePicker.Enabled = enabled; section.ProfilePicker.Enabled = enabled; section.Saturation.Enabled = enabled;
            section.Brightness.Enabled = section.Contrast.Enabled = section.Hue.Enabled = enabled;
            section.ProfileName.Enabled = enabled; section.SaveButton.Enabled = enabled; section.ApplyButton.Enabled = enabled; section.ResetButton.Enabled = enabled;
            section.GamePicker.Enabled = enabled; section.GameProfilePicker.Enabled = enabled; section.AssignButton.Enabled = enabled;
        }

        private Dictionary<string, int> ColorValues(ColorProfileSection section)
        { return section.IsNvidia ? _prefs.NvidiaColorProfiles : _prefs.AmdColorProfiles; }
        private Dictionary<string, string> ColorAssignments(ColorProfileSection section)
        { return section.IsNvidia ? _prefs.NvidiaGameProfiles : _prefs.AmdGameProfiles; }
        private Dictionary<string, string> ColorExtras(ColorProfileSection section)
        { return section.IsNvidia ? _prefs.NvidiaColorAdjustments : _prefs.AmdColorAdjustments; }
        private string ColorProfileKey(string profile, string device) { return profile + "\t" + device; }

        private static string SerializeColorExtras(ColorProfileSection section, ColorDisplayInfo display)
        {
            if (section == null || section.IsNvidia || display == null) return "";
            List<string> values = new List<string>();
            if (display.Adjustments.ContainsKey("brightness")) values.Add("brightness:" + section.Brightness.Value.ToString(CultureInfo.InvariantCulture));
            if (display.Adjustments.ContainsKey("contrast")) values.Add("contrast:" + section.Contrast.Value.ToString(CultureInfo.InvariantCulture));
            if (display.Adjustments.ContainsKey("hue")) values.Add("hue:" + section.Hue.Value.ToString(CultureInfo.InvariantCulture));
            return String.Join(";", values);
        }

        private static Dictionary<string, int> ParseColorExtras(string serialized)
        {
            Dictionary<string, int> result = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (string part in (serialized ?? "").Split(';'))
            {
                int separator = part.IndexOf(':'); int value;
                if (separator <= 0 || !Int32.TryParse(part.Substring(separator + 1), NumberStyles.Integer, CultureInfo.InvariantCulture, out value)) continue;
                string key = part.Substring(0, separator);
                if (key == "brightness" || key == "contrast" || key == "hue") result[key] = value;
            }
            return result;
        }

        private void RefreshColorProfilePicker(ColorProfileSection section, string selectProfile)
        {
            if (section == null || section.ProfilePicker == null || section.ProfilePicker.IsDisposed) return;
            string previous = selectProfile ?? Convert.ToString(section.ProfilePicker.SelectedItem);
            section.ProfilePicker.Items.Clear(); section.ProfilePicker.Items.Add(Localizer.T("colors.standard"));
            HashSet<string> names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string key in ColorValues(section).Keys)
            {
                string[] parts = key.Split('\t'); if (parts.Length == 2) names.Add(parts[0]);
            }
            foreach (string name in names.OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase)) section.ProfilePicker.Items.Add(name);
            section.ProfilePicker.SelectedItem = section.ProfilePicker.Items.Contains(previous) ? previous : Localizer.T("colors.standard");
            RefreshSavedColorProfileChips(section, names);
            RefreshColorGameProfilePicker(section);
        }

        private void RefreshSavedColorProfileChips(ColorProfileSection section, IEnumerable<string> names)
        {
            if (section == null || section.SavedProfileChips == null || section.SavedProfileChips.IsDisposed) return;
            section.SavedProfileChips.SuspendLayout();
            try
            {
                foreach (Control oldControl in section.SavedProfileChips.Controls.Cast<Control>().ToArray()) oldControl.Dispose();
                section.SavedProfileChips.Controls.Clear();
                List<string> profiles = names.OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase).ToList();
                if (profiles.Count == 0)
                {
                    Label empty = MakeLabel(Localizer.T("colors.noSavedProfiles"), 9, Palette.Muted, false);
                    empty.TextAlign = ContentAlignment.MiddleLeft; empty.Size = new Size(260, 32); section.SavedProfileChips.Controls.Add(empty);
                    return;
                }
                string selected = Convert.ToString(section.ProfilePicker.SelectedItem);
                foreach (string profile in profiles)
                {
                    string captured = profile;
                    Button chip = MakeButton(profile, String.Equals(selected, profile, StringComparison.OrdinalIgnoreCase) ? Palette.Accent : Palette.Surface2, 32);
                    chip.Width = Math.Min(190, Math.Max(92, TextRenderer.MeasureText(profile, chip.Font).Width + 28));
                    chip.Margin = new Padding(0, 0, 7, 4); chip.Click += delegate { section.ProfilePicker.SelectedItem = captured; };
                    section.SavedProfileChips.Controls.Add(chip);
                }
            }
            finally { section.SavedProfileChips.ResumeLayout(); }
        }

        private void UpdateColorValueLabel(ColorProfileSection section)
        {
            if (section == null || section.ValueLabel == null || section.ValueLabel.IsDisposed) return;
            section.ValueLabel.Text = section.Saturation.Value.ToString(CultureInfo.InvariantCulture) + " / " + section.Saturation.Maximum.ToString(CultureInfo.InvariantCulture);
        }

        private static void UpdateColorValueLabel(ModernSlider slider, Label label, bool hue)
        {
            if (slider == null || label == null || label.IsDisposed) return;
            label.Text = slider.Value.ToString(CultureInfo.InvariantCulture) + (hue ? "" : " / " + slider.Maximum.ToString(CultureInfo.InvariantCulture));
        }

        private void UpdateSavedColorProfileChipSelection(ColorProfileSection section)
        {
            if (section == null || section.SavedProfileChips == null || section.SavedProfileChips.IsDisposed) return;
            string selected = Convert.ToString(section.ProfilePicker.SelectedItem);
            foreach (Control control in section.SavedProfileChips.Controls)
            {
                Button chip = control as Button; if (chip == null) continue;
                chip.BackColor = String.Equals(chip.Text, selected, StringComparison.OrdinalIgnoreCase) ? Palette.Accent : Palette.Surface2;
                chip.Invalidate();
            }
        }

        private void RefreshColorGameProfilePicker(ColorProfileSection section)
        {
            if (section == null || section.GameProfilePicker == null || section.GameProfilePicker.IsDisposed) return;
            string current = Convert.ToString(section.GameProfilePicker.SelectedItem);
            section.GameProfilePicker.Items.Clear(); section.GameProfilePicker.Items.Add(Localizer.T("colors.noProfile")); section.GameProfilePicker.Items.Add(Localizer.T("colors.standard"));
            HashSet<string> names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string key in ColorValues(section).Keys) { string[] parts = key.Split('\t'); if (parts.Length == 2) names.Add(parts[0]); }
            foreach (string name in names.OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase)) section.GameProfilePicker.Items.Add(name);
            string gameKey = SelectedColorGameKey(section); string assignment;
            if (ColorAssignments(section).TryGetValue(gameKey, out assignment)) current = assignment == "__standard__" ? Localizer.T("colors.standard") : assignment;
            else current = Localizer.T("colors.noProfile");
            section.GameProfilePicker.SelectedItem = section.GameProfilePicker.Items.Contains(current) ? current : Localizer.T("colors.noProfile");
        }

        private string SelectedColorGameKey(ColorProfileSection section)
        {
            if (section.GamePicker == null || section.GamePicker.SelectedIndex < 0) return "game.fortnite";
            string[] keys = { "game.fortnite", "game.minecraft", "game.minecraftBedrock", "game.valorant", "game.gta", "game.cyberpunk", "game.rocket", "game.overwatch", "game.r6", "game.apex", "game.helldivers", "game.farming", "game.counterstrike", "game.league", "game.pubg", "game.warzone", "game.dota", "game.roblox", "game.fc26" };
            return keys[Math.Max(0, Math.Min(keys.Length - 1, section.GamePicker.SelectedIndex))];
        }

        private void UpdateColorSectionControls(ColorProfileSection section, bool profileSelection)
        {
            if (section == null || section.Card == null || section.Card.IsDisposed) return;
            ColorDisplayInfo display = section.DevicePicker.SelectedItem as ColorDisplayInfo;
            if (display == null) { section.ValueLabel.Text = "—"; return; }
            int minimum = display.MinimumLevel, maximum = Math.Max(display.MinimumLevel + 1, display.MaximumLevel);
            section.Saturation.Minimum = Math.Min(section.Saturation.Minimum, minimum);
            section.Saturation.Maximum = Math.Max(section.Saturation.Maximum, maximum);
            section.Saturation.Minimum = minimum; section.Saturation.Maximum = maximum;
            if (profileSelection)
            {
                string profile = Convert.ToString(section.ProfilePicker.SelectedItem);
                int value;
                if (String.Equals(profile, Localizer.T("colors.standard"), StringComparison.Ordinal)) value = display.DefaultLevel;
                else if (!ColorValues(section).TryGetValue(ColorProfileKey(profile, display.DeviceKey), out value)) value = display.CurrentLevel;
                section.Saturation.Value = Math.Max(section.Saturation.Minimum, Math.Min(section.Saturation.Maximum, value));
            }
            else
            {
                section.Saturation.Value = Math.Max(section.Saturation.Minimum, Math.Min(section.Saturation.Maximum, display.CurrentLevel));
            }
            UpdateColorValueLabel(section);
            if (section.IsNvidia) return;
            Dictionary<string, int> savedExtras = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            string selectedProfile = Convert.ToString(section.ProfilePicker.SelectedItem);
            if (profileSelection && !String.Equals(selectedProfile, Localizer.T("colors.standard"), StringComparison.Ordinal))
            {
                string serialized;
                if (ColorExtras(section).TryGetValue(ColorProfileKey(selectedProfile, display.DeviceKey), out serialized)) savedExtras = ParseColorExtras(serialized);
            }
            SetAdjustmentControl(section.Brightness, section.BrightnessLabel, section.BrightnessValue, display, "brightness", profileSelection, selectedProfile, savedExtras);
            SetAdjustmentControl(section.Contrast, section.ContrastLabel, section.ContrastValue, display, "contrast", profileSelection, selectedProfile, savedExtras);
            SetAdjustmentControl(section.Hue, section.HueLabel, section.HueValue, display, "hue", profileSelection, selectedProfile, savedExtras);
        }

        private static void SetAdjustmentControl(ModernSlider slider, Label title, Label valueLabel, ColorDisplayInfo display, string key, bool profileSelection, string profile, Dictionary<string, int> saved)
        {
            ColorAdjustmentRange range;
            bool available = display.Adjustments.TryGetValue(key, out range);
            slider.Visible = title.Visible = valueLabel.Visible = available;
            if (!available) { valueLabel.Text = "—"; return; }
            slider.Minimum = range.Minimum; slider.Maximum = range.Maximum;
            int value = range.Current;
            if (profileSelection)
            {
                if (String.Equals(profile, Localizer.T("colors.standard"), StringComparison.Ordinal)) value = range.Default;
                else if (!saved.TryGetValue(key, out value)) value = range.Current;
            }
            slider.Value = Math.Max(slider.Minimum, Math.Min(slider.Maximum, value));
            UpdateColorValueLabel(slider, valueLabel, key == "hue");
        }

        private void SaveColorProfile(ColorProfileSection section)
        {
            if (!section.ApiReady) return;
            string name = (section.ProfileName.Text ?? "").Trim();
            if (name.Length < 1 || name.Length > 32 || name.IndexOfAny(new[] { '\r', '\n', '\t', '=' }) >= 0 || String.Equals(name, Localizer.T("colors.standard"), StringComparison.OrdinalIgnoreCase))
            { SetColorSectionStatus(section, Localizer.T("colors.badName"), Palette.Red); return; }
            ColorDisplayInfo display = section.DevicePicker.SelectedItem as ColorDisplayInfo; if (display == null) return;
            ColorValues(section)[ColorProfileKey(name, display.DeviceKey)] = section.Saturation.Value;
            ColorExtras(section)[ColorProfileKey(name, display.DeviceKey)] = SerializeColorExtras(section, display);
            SavePreferences(); RefreshColorProfilePicker(section, name);
            ThreadPool.QueueUserWorkItem(delegate { try { ApplyValuesToDisplay(section.IsNvidia, display, name); SetColorSectionStatus(section, Localizer.T("colors.saved") + " " + Localizer.T("colors.applied"), Palette.Green); }
                catch (Exception ex) { SetColorSectionStatus(section, ex.Message, Palette.Red); } });
        }

        private void ApplySelectedColorProfile(ColorProfileSection section)
        {
            if (!section.ApiReady) return;
            ColorDisplayInfo display = section.DevicePicker.SelectedItem as ColorDisplayInfo; if (display == null) return;
            string profile = Convert.ToString(section.ProfilePicker.SelectedItem);
            string profileKey = String.Equals(profile, Localizer.T("colors.standard"), StringComparison.Ordinal) ? "__standard__" : profile;
            if (profileKey != "__standard__" && !ColorValues(section).ContainsKey(ColorProfileKey(profileKey, display.DeviceKey)))
            { SetColorSectionStatus(section, Localizer.T("colors.profileNotForDisplay"), Palette.Accent); return; }
            string deviceKey = display.DeviceKey, deviceLabel = display.DisplayLabel;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try { ApplyColorProfile(section.IsNvidia, profileKey, deviceKey); SetColorSectionStatus(section, (profileKey == "__standard__" ? Localizer.T("colors.restored") : Localizer.T("colors.applied")) + " · " + deviceLabel, Palette.Green); try { BeginInvoke((MethodInvoker)delegate { if (!IsDisposed && _page == "colorProfiles") UpdateColorSectionControls(section, true); }); } catch { } }
                catch (Exception ex) { SetColorSectionStatus(section, ex.Message, Palette.Red); }
            });
        }

        private void ApplyStandardColorProfile(ColorProfileSection section, bool showStatus)
        {
            if (!section.ApiReady) return;
            ColorDisplayInfo display = section.DevicePicker.SelectedItem as ColorDisplayInfo; if (display == null) return;
            string deviceKey = display.DeviceKey, deviceLabel = display.DisplayLabel;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try { ApplyColorProfile(section.IsNvidia, "__standard__", deviceKey); if (showStatus) SetColorSectionStatus(section, Localizer.T("colors.restored") + " · " + deviceLabel, Palette.Green); try { BeginInvoke((MethodInvoker)delegate { if (!IsDisposed && _page == "colorProfiles") UpdateColorSectionControls(section, true); }); } catch { } }
                catch (Exception ex) { SetColorSectionStatus(section, ex.Message, Palette.Red); }
            });
        }

        private void SaveColorGameAssignment(ColorProfileSection section)
        {
            if (!section.ApiReady) return;
            string choice = Convert.ToString(section.GameProfilePicker.SelectedItem), none = Localizer.T("colors.noProfile"), standard = Localizer.T("colors.standard");
            string gameKey = SelectedColorGameKey(section);
            if (String.Equals(choice, none, StringComparison.Ordinal)) ColorAssignments(section).Remove(gameKey);
            else ColorAssignments(section)[gameKey] = String.Equals(choice, standard, StringComparison.Ordinal) ? "__standard__" : choice;
            SavePreferences(); SetColorSectionStatus(section, Localizer.T("colors.assignmentSaved"), Palette.Green);
        }

        private void SetColorSectionStatus(ColorProfileSection section, string text, Color color)
        {
            if (_closing || IsDisposed || section == null) return;
            try { BeginInvoke((MethodInvoker)delegate { if (!_closing && _page == "colorProfiles" && section.Status != null && !section.Status.IsDisposed) { section.Status.Text = text; section.Status.ForeColor = color; } }); } catch { }
        }

        private IList<ColorDisplayInfo> GetColorDisplays(bool nvidia)
        {
            if (nvidia) return NvidiaColorApi.GetDisplays().Select(x =>
            {
                ColorDisplayInfo item = new ColorDisplayInfo { DeviceKey = x.DeviceName, DisplayLabel = x.DisplayLabel, CurrentLevel = x.CurrentLevel, MinimumLevel = x.MinimumLevel, MaximumLevel = x.MaximumLevel, DefaultLevel = x.DefaultLevel, IsNvidia = true };
                item.Adjustments["saturation"] = new ColorAdjustmentRange { Current = x.CurrentLevel, Default = x.DefaultLevel, Minimum = x.MinimumLevel, Maximum = x.MaximumLevel, Step = 1 };
                return item;
            }).ToList();
            return AmdColorApi.GetDisplays();
        }

        private void SetColorLevel(bool nvidia, ColorDisplayInfo display, int level)
        { if (nvidia) NvidiaColorApi.SetLevel(display.DeviceKey, level); else AmdColorApi.SetLevel(display.DeviceKey, level); }

        private void ApplyColorProfile(bool nvidia, string profile, string onlyDeviceKey = null)
        {
            IList<ColorDisplayInfo> devices = GetColorDisplays(nvidia);
            if (!String.IsNullOrWhiteSpace(onlyDeviceKey))
                devices = devices.Where(x => String.Equals(x.DeviceKey, onlyDeviceKey, StringComparison.OrdinalIgnoreCase)).ToList();
            if (devices.Count == 0) throw new InvalidOperationException(Localizer.T("colors.deviceUnavailable"));
            Dictionary<string, int> values = nvidia ? _prefs.NvidiaColorProfiles : _prefs.AmdColorProfiles;
            Dictionary<string, Dictionary<string, int>> before = new Dictionary<string, Dictionary<string, int>>(StringComparer.OrdinalIgnoreCase);
            try
            {
                foreach (ColorDisplayInfo display in devices)
                {
                    before[display.DeviceKey] = display.Adjustments.ToDictionary(x => x.Key, x => x.Value.Current, StringComparer.OrdinalIgnoreCase);
                    int value = display.DefaultLevel;
                    if (profile != "__standard__" && !values.TryGetValue(ColorProfileKey(profile, display.DeviceKey), out value)) continue;
                    SetColorLevel(nvidia, display, profile == "__standard__" ? display.DefaultLevel : value);
                    if (!nvidia)
                    {
                        if (profile == "__standard__")
                        {
                            foreach (KeyValuePair<string, ColorAdjustmentRange> adjustment in display.Adjustments)
                                if (!String.Equals(adjustment.Key, "saturation", StringComparison.OrdinalIgnoreCase)) AmdColorApi.SetAdjustment(display.DeviceKey, adjustment.Key, adjustment.Value.Default);
                        }
                        else ApplyExtraValues(display, profile);
                    }
                }
            }
            catch
            {
                foreach (ColorDisplayInfo display in devices)
                {
                    Dictionary<string, int> saved;
                    if (!before.TryGetValue(display.DeviceKey, out saved)) continue;
                    foreach (KeyValuePair<string, int> item in saved)
                    {
                        try
                        {
                            if (nvidia && String.Equals(item.Key, "saturation", StringComparison.OrdinalIgnoreCase)) NvidiaColorApi.SetLevel(display.DeviceKey, item.Value);
                            else SetDisplayAdjustment(nvidia, display, item.Key, item.Value);
                        }
                        catch { }
                    }
                }
                throw;
            }
        }

        private void ApplyValuesToDisplay(bool nvidia, ColorDisplayInfo display, string profile)
        {
            int value;
            if ((nvidia ? _prefs.NvidiaColorProfiles : _prefs.AmdColorProfiles).TryGetValue(ColorProfileKey(profile, display.DeviceKey), out value)) SetColorLevel(nvidia, display, value);
            if (!nvidia) ApplyExtraValues(display, profile);
        }

        private void ApplyExtraValues(ColorDisplayInfo display, string profile)
        {
            string serialized;
            if (!_prefs.AmdColorAdjustments.TryGetValue(ColorProfileKey(profile, display.DeviceKey), out serialized)) return;
            Dictionary<string, int> values = ParseColorExtras(serialized);
            foreach (KeyValuePair<string, int> item in values)
                if (display.Adjustments.ContainsKey(item.Key)) SetDisplayAdjustment(false, display, item.Key, item.Value);
        }

        private static void SetDisplayAdjustment(bool nvidia, ColorDisplayInfo display, string key, int value)
        {
            if (nvidia) return;
            AmdColorApi.SetAdjustment(display.DeviceKey, key, value);
        }

        private void OpenNvidiaControlPanel()
        {
            try
            {
                string[] candidates = {
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "NVIDIA Corporation", "Control Panel Client", "nvcplui.exe"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "NVIDIA Corporation", "Control Panel Client", "nvcplui.exe")
                };
                string executable = candidates.FirstOrDefault(File.Exists);
                Process.Start(new ProcessStartInfo { FileName = executable ?? "nvcplui.exe", UseShellExecute = true });
            }
            catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("colors.nvidia"), Localizer.T("colors.panelUnavailable") + "\r\n\r\n" + DescribeSystemError(ex), false); }
        }

        private void QueueColorProfileMonitor()
        {
            if (_closing) return;
            lock (_colorProfileLock) { if (_prefs.NvidiaGameProfiles.Count == 0 && _prefs.AmdGameProfiles.Count == 0 && _activeColorGames.Count == 0) return; }
            if (Interlocked.CompareExchange(ref _colorProfileScanBusy, 1, 0) != 0) return;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    if (_closing) return;
                    string gameKey = FindRunningColorGameKey();
                    lock (_colorProfileLock)
                    {
                        if (_closing) return;
                        ProcessColorGameForVendor(true, gameKey);
                        ProcessColorGameForVendor(false, gameKey);
                    }
                }
                catch { }
                finally { Interlocked.Exchange(ref _colorProfileScanBusy, 0); }
            });
        }

        private string FindRunningColorGameKey()
        {
            Process[] processes;
            try { processes = Process.GetProcesses(); } catch { return null; }
            try
            {
                string fallback = null;
                foreach (Process process in processes)
                {
                    try
                    {
                        string name = process.ProcessName;
                        if (!IsGameProcessName(name)) continue;
                        string key = GameKeyForProcess(name);
                        if (_prefs.NvidiaGameProfiles.ContainsKey(key) || _prefs.AmdGameProfiles.ContainsKey(key)) return key;
                        if (fallback == null) fallback = key;
                    }
                    catch { }
                }
                return fallback;
            }
            finally { foreach (Process process in processes) try { process.Dispose(); } catch { } }
        }

        private void ProcessColorGameForVendor(bool nvidia, string runningGameKey)
        {
            string vendor = nvidia ? "nvidia" : "amd"; Dictionary<string, string> assigned = nvidia ? _prefs.NvidiaGameProfiles : _prefs.AmdGameProfiles;
            string active, activeProfile; _activeColorGames.TryGetValue(vendor, out active); _activeColorProfiles.TryGetValue(vendor, out activeProfile);
            string profile = null;
            if (!String.IsNullOrEmpty(runningGameKey)) assigned.TryGetValue(runningGameKey, out profile);
            if (!String.IsNullOrEmpty(profile))
            {
                if (String.Equals(active, runningGameKey, StringComparison.OrdinalIgnoreCase) && String.Equals(activeProfile, profile, StringComparison.OrdinalIgnoreCase)) return;
                ApplyColorProfile(nvidia, profile); _activeColorGames[vendor] = runningGameKey;
                _activeColorProfiles[vendor] = profile;
                if (nvidia) { _prefs.ActiveNvidiaColorGame = runningGameKey; _prefs.ActiveNvidiaColorProfile = profile; }
                else { _prefs.ActiveAmdColorGame = runningGameKey; _prefs.ActiveAmdColorProfile = profile; }
                SavePreferences();
                SetColorSectionStatus(nvidia ? _nvidiaColorSection : _amdColorSection, Localizer.T("colors.applied") + " · " + Localizer.T(runningGameKey), Palette.Green);
            }
            else if (!String.IsNullOrEmpty(active))
            {
                ApplyColorProfile(nvidia, "__standard__"); _activeColorGames.Remove(vendor);
                _activeColorProfiles.Remove(vendor);
                if (nvidia) { _prefs.ActiveNvidiaColorGame = ""; _prefs.ActiveNvidiaColorProfile = ""; }
                else { _prefs.ActiveAmdColorGame = ""; _prefs.ActiveAmdColorProfile = ""; }
                SavePreferences();
                SetColorSectionStatus(nvidia ? _nvidiaColorSection : _amdColorSection, Localizer.T("colors.restored"), Palette.Muted);
            }
        }

        private void RestoreActiveColorProfiles()
        {
            lock (_colorProfileLock)
            {
                foreach (string vendor in _activeColorGames.Keys.ToArray())
                    try { ApplyColorProfile(vendor == "nvidia", "__standard__"); } catch { }
                _activeColorGames.Clear(); _activeColorProfiles.Clear();
                _prefs.ActiveNvidiaColorGame = ""; _prefs.ActiveAmdColorGame = ""; _prefs.ActiveNvidiaColorProfile = ""; _prefs.ActiveAmdColorProfile = "";
            }
        }

        private static bool TryReadDisplayTimeoutValues(string powercfg, string scheme, out int acSeconds, out int dcSeconds)
        {
            acSeconds = dcSeconds = -1;
            try
            {
                if (!Regex.IsMatch(scheme ?? "", "^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$", RegexOptions.IgnoreCase)) return false;
                string path = @"SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes\" + scheme + @"\7516b95f-f776-4464-8c53-06167f40cc99\3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e";
                RegistryView view = Environment.Is64BitOperatingSystem ? RegistryView.Registry64 : RegistryView.Registry32;
                using (RegistryKey root = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, view))
                using (RegistryKey setting = root.OpenSubKey(path, false))
                {
                    if (setting == null) return false;
                    object ac = setting.GetValue("ACSettingIndex", null), dc = setting.GetValue("DCSettingIndex", null);
                    if (ac == null || dc == null) return false;
                    acSeconds = Convert.ToInt32(ac, CultureInfo.InvariantCulture); dcSeconds = Convert.ToInt32(dc, CultureInfo.InvariantCulture);
                    return acSeconds >= 0 && dcSeconds >= 0 && acSeconds <= 604800 && dcSeconds <= 604800;
                }
            }
            catch { return false; }
        }

        private static bool TryReadTimeoutBackup(string path, out List<Tuple<string, int, int>> snapshots)
        {
            snapshots = new List<Tuple<string, int, int>>();
            try
            {
                Dictionary<string, string> values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (string line in File.ReadAllLines(path, Encoding.UTF8))
                {
                    string[] parts = line.Split(new[] { '=' }, 2);
                    if (parts.Length == 2) values[parts[0]] = parts[1];
                }
                string legacyScheme, legacyAc, legacyDc;
                if (values.TryGetValue("scheme", out legacyScheme) && values.TryGetValue("ac", out legacyAc) && values.TryGetValue("dc", out legacyDc))
                {
                    int ac, dc;
                    if (!Regex.IsMatch(legacyScheme, "^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$", RegexOptions.IgnoreCase) ||
                        !Int32.TryParse(legacyAc, NumberStyles.Integer, CultureInfo.InvariantCulture, out ac) || ac < 0 || ac > 604800 ||
                        !Int32.TryParse(legacyDc, NumberStyles.Integer, CultureInfo.InvariantCulture, out dc) || dc < 0 || dc > 604800) return false;
                    snapshots.Add(Tuple.Create(legacyScheme, ac, dc));
                    return true;
                }
                for (int index = 0; index < 64; index++)
                {
                    string scheme, acText, dcText;
                    if (!values.TryGetValue("scheme." + index.ToString(CultureInfo.InvariantCulture), out scheme)) continue;
                    if (!values.TryGetValue("ac." + index.ToString(CultureInfo.InvariantCulture), out acText) || !values.TryGetValue("dc." + index.ToString(CultureInfo.InvariantCulture), out dcText)) return false;
                    int ac, dc;
                    if (!Regex.IsMatch(scheme, "^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$", RegexOptions.IgnoreCase) ||
                        !Int32.TryParse(acText, NumberStyles.Integer, CultureInfo.InvariantCulture, out ac) || ac < 0 || ac > 604800 ||
                        !Int32.TryParse(dcText, NumberStyles.Integer, CultureInfo.InvariantCulture, out dc) || dc < 0 || dc > 604800) return false;
                    snapshots.Add(Tuple.Create(scheme, ac, dc));
                }
                return snapshots.Count > 0;
            }
            catch { return false; }
        }

        private static void WriteTimeoutBackup(string path, IList<Tuple<string, int, int>> snapshots)
        {
            StringBuilder text = new StringBuilder("format=2\r\n");
            for (int index = 0; index < snapshots.Count; index++)
            {
                text.Append("scheme.").Append(index.ToString(CultureInfo.InvariantCulture)).Append('=').AppendLine(snapshots[index].Item1);
                text.Append("ac.").Append(index.ToString(CultureInfo.InvariantCulture)).Append('=').AppendLine(snapshots[index].Item2.ToString(CultureInfo.InvariantCulture));
                text.Append("dc.").Append(index.ToString(CultureInfo.InvariantCulture)).Append('=').AppendLine(snapshots[index].Item3.ToString(CultureInfo.InvariantCulture));
            }
            string temporary = path + ".tmp";
            File.WriteAllText(temporary, text.ToString(), Encoding.UTF8);
            if (File.Exists(path)) File.Replace(temporary, path, null); else File.Move(temporary, path);
        }

        private void DisableDisplayTimeoutForActivePlan()
        {
            string powercfg = PowerCfgPath, scheme = ReadActivePowerScheme(PowerCfgPath); int ac, dc;
            if (!TryReadDisplayTimeoutValues(powercfg, scheme, out ac, out dc)) throw new IOException(Localizer.T("settings.screenTimeoutFailed"));
            bool createdBackup = !File.Exists(DisplayTimeoutBackupPath);
            List<Tuple<string, int, int>> snapshots = new List<Tuple<string, int, int>>();
            if (!createdBackup && !TryReadTimeoutBackup(DisplayTimeoutBackupPath, out snapshots)) throw new InvalidDataException(Localizer.T("settings.screenTimeoutFailed"));
            if (!snapshots.Any(x => String.Equals(x.Item1, scheme, StringComparison.OrdinalIgnoreCase)))
            {
                snapshots.Add(Tuple.Create(scheme, ac, dc));
                WriteTimeoutBackup(DisplayTimeoutBackupPath, snapshots);
            }
            try
            {
                RunProcess(powercfg, "/setacvalueindex " + scheme + " SUB_VIDEO VIDEOIDLE 0", 6000);
                RunProcess(powercfg, "/setdcvalueindex " + scheme + " SUB_VIDEO VIDEOIDLE 0", 6000);
                if (String.Equals(ReadActivePowerScheme(powercfg), scheme, StringComparison.OrdinalIgnoreCase)) RunProcess(powercfg, "/setactive " + scheme, 6000);
                int checkAc, checkDc;
                if (!TryReadDisplayTimeoutValues(powercfg, scheme, out checkAc, out checkDc) || checkAc != 0 || checkDc != 0) throw new IOException(Localizer.T("settings.screenTimeoutFailed"));
            }
            catch
            {
                try { RunProcess(powercfg, "/setacvalueindex " + scheme + " SUB_VIDEO VIDEOIDLE " + ac.ToString(CultureInfo.InvariantCulture), 6000); } catch { }
                try { RunProcess(powercfg, "/setdcvalueindex " + scheme + " SUB_VIDEO VIDEOIDLE " + dc.ToString(CultureInfo.InvariantCulture), 6000); } catch { }
                if (createdBackup) try { File.Delete(DisplayTimeoutBackupPath); } catch { }
                throw;
            }
        }

        private void RestoreDisplayTimeoutBackup()
        {
            if (!File.Exists(DisplayTimeoutBackupPath)) return;
            List<Tuple<string, int, int>> snapshots;
            if (!TryReadTimeoutBackup(DisplayTimeoutBackupPath, out snapshots)) throw new InvalidDataException(Localizer.T("settings.screenTimeoutFailed"));
            string powercfg = PowerCfgPath;
            string active = ReadActivePowerScheme(powercfg);
            foreach (Tuple<string, int, int> snapshot in snapshots)
            {
                RunProcess(powercfg, "/setacvalueindex " + snapshot.Item1 + " SUB_VIDEO VIDEOIDLE " + snapshot.Item2.ToString(CultureInfo.InvariantCulture), 6000);
                RunProcess(powercfg, "/setdcvalueindex " + snapshot.Item1 + " SUB_VIDEO VIDEOIDLE " + snapshot.Item3.ToString(CultureInfo.InvariantCulture), 6000);
                if (String.Equals(active, snapshot.Item1, StringComparison.OrdinalIgnoreCase)) RunProcess(powercfg, "/setactive " + snapshot.Item1, 6000);
            }
            File.Delete(DisplayTimeoutBackupPath);
        }

        private void RenderSettings()
        {
            AddPageHeading(Localizer.T("settings.title"), Localizer.T("settings.subtitle"));
            RoundPanel language = Card(92); Label langTitle = MakeLabel(Localizer.T("settings.language"), 11, Palette.Text, true); langTitle.Location = new Point(16, 16); langTitle.Size = new Size(210, 24); language.Controls.Add(langTitle);
            ComboBox langs = MakeCombo(Localizer.Languages.Values.ToArray()); langs.Location = new Point(250, 15); langs.Width = 230; langs.SelectedItem = Localizer.Languages[_prefs.Language];
            langs.SelectedIndexChanged += delegate { string code = Localizer.Languages.First(x => x.Value == Convert.ToString(langs.SelectedItem)).Key; _prefs.Language = code; Localizer.Current = code; SavePreferences(); ApplySidebarWidth(); RefreshGamingModeButton(); RefreshTrayMenuText(); SetStatus(Localizer.T("status.saved")); ShowPage("settings"); RefreshOverlayAppearance(); };
            language.Controls.Add(langs); _content.Controls.Add(language);
            RoundPanel accent = Card(92); Label accentTitle = MakeLabel(Localizer.T("settings.accent"), 11, Palette.Text, true); accentTitle.Location = new Point(16, 16); accentTitle.Size = new Size(210, 24); accent.Controls.Add(accentTitle);
            ComboBox colors = MakeCombo(new[] { Localizer.T("theme.orange"), Localizer.T("theme.cyan"), Localizer.T("theme.violet"), Localizer.T("theme.lime"), Localizer.T("theme.pink") }); colors.Location = new Point(250, 15); colors.Width = 230;
            string[] colorKeys = { "orange", "cyan", "violet", "lime", "pink" }; colors.SelectedItem = Localizer.T("theme." + _prefs.Accent);
            colors.SelectedIndexChanged += delegate { _prefs.Accent = colorKeys[colors.SelectedIndex]; Palette.Select(_prefs.Accent); SavePreferences(); ShowPage("settings"); ApplyPalette(); };
            accent.Controls.Add(colors); _content.Controls.Add(accent);
            RoundPanel motion = Card(108); Label motionTitle = MakeLabel(Localizer.T("settings.motionTitle"), 11, Palette.Text, true); motionTitle.Location = new Point(16, 15); motionTitle.Size = new Size(300, 23); motion.Controls.Add(motionTitle);
            Label motionHint = MakeLabel(Localizer.T("settings.motionHint"), 9, Palette.Muted, false); motionHint.Location = new Point(16, 42); motionHint.Size = new Size(motion.Width - 250, 42); motion.Controls.Add(motionHint);
            ComboBox motionMode = MakeCombo(new[] { Localizer.T("settings.motionFast"), Localizer.T("settings.motionSlow"), Localizer.T("settings.motionOff") });
            motionMode.Location = new Point(motion.Width - 240, 33); motionMode.Width = 205; motionMode.SelectedIndex = _prefs.Motion == "off" ? 2 : _prefs.Motion == "slow" ? 1 : 0;
            motionMode.SelectedIndexChanged += delegate { _prefs.Motion = motionMode.SelectedIndex == 2 ? "off" : motionMode.SelectedIndex == 1 ? "slow" : "fast"; _prefs.ReduceMotion = _prefs.Motion == "off"; _sidebarTimer.Interval = _prefs.Motion == "slow" ? 16 : 10; SavePreferences(); SetStatus(Localizer.T("status.saved")); SetSidebarExpanded(_sidebarPinned); };
            motion.Controls.Add(motionMode); _content.Controls.Add(motion);
            RoundPanel tray = Card(98); Label trayTitle = MakeLabel(Localizer.T("settings.trayTitle"), 11, Palette.Text, true); trayTitle.Location = new Point(16, 14); trayTitle.Size = new Size(420, 23); tray.Controls.Add(trayTitle);
            Label trayHint = MakeLabel(Localizer.T("settings.trayHint"), 8, Palette.Muted, false); trayHint.Location = new Point(16, 42); trayHint.Size = new Size(tray.Width - 32, 38); tray.Controls.Add(trayHint);
            CheckBox trayToggle = new CheckBox(); trayToggle.Text = Localizer.T("state.on"); trayToggle.Checked = _prefs.MinimizeToTray; trayToggle.ForeColor = Palette.Text; trayToggle.BackColor = Palette.Surface; trayToggle.FlatStyle = FlatStyle.Flat; trayToggle.Location = new Point(tray.Width - 120, 14); trayToggle.Size = new Size(96, 24);
            trayToggle.CheckedChanged += delegate { _prefs.MinimizeToTray = trayToggle.Checked; SavePreferences(); if (_trayIcon != null) _trayIcon.Visible = trayToggle.Checked; SetStatus(Localizer.T("status.saved")); };
            tray.Controls.Add(trayToggle); _content.Controls.Add(tray);
            RoundPanel updatePreference = Card(76); Label updatePreferenceTitle = MakeLabel(Localizer.T("updates.autoCheck"), 10, Palette.Text, true); updatePreferenceTitle.Location = new Point(16, 13); updatePreferenceTitle.Size = new Size(updatePreference.Width - 110, 22); updatePreferenceTitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; updatePreference.Controls.Add(updatePreferenceTitle);
            Label updatePreferenceHint = MakeLabel(Localizer.T("updates.autoCheckHint"), 8, Palette.Muted, false); updatePreferenceHint.Location = new Point(16, 39); updatePreferenceHint.Size = new Size(updatePreference.Width - 110, 22); updatePreferenceHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; updatePreference.Controls.Add(updatePreferenceHint);
            ToggleSwitch updatePreferenceToggle = new ToggleSwitch(); updatePreferenceToggle.Location = new Point(updatePreference.Width - 58, 24); updatePreferenceToggle.Checked = _prefs.AutoUpdateCheck; updatePreferenceToggle.Anchor = AnchorStyles.Top | AnchorStyles.Right; updatePreference.Controls.Add(updatePreferenceToggle);
            updatePreferenceToggle.CheckedChanged += delegate { _prefs.AutoUpdateCheck = updatePreferenceToggle.Checked; SavePreferences(); SetStatus(Localizer.T("status.saved")); if (_prefs.AutoUpdateCheck) { QueueLocalUpdateCheck(); QueueRemoteUpdateCheck(); } };
            _content.Controls.Add(updatePreference);
            RoundPanel overlaySettings = Card(158); Label overlayTitle = MakeLabel(Localizer.T("settings.overlayTitle"), 11, Palette.Text, true); overlayTitle.Location = new Point(16, 14); overlayTitle.Size = new Size(330, 23); overlaySettings.Controls.Add(overlayTitle);
            Label overlayHint = MakeLabel(Localizer.T("settings.overlayHint"), 8, Palette.Muted, false); overlayHint.Location = new Point(16, 40); overlayHint.Size = new Size(overlaySettings.Width - 32, 20); overlaySettings.Controls.Add(overlayHint);
            Label sizeLabel = MakeLabel(Localizer.T("overlay.title"), 9, Palette.Text, false); sizeLabel.Location = new Point(16, 75); sizeLabel.Size = new Size(110, 22); overlaySettings.Controls.Add(sizeLabel);
            ComboBox sizePicker = MakeCombo(new[] { Localizer.T("overlay.compact"), Localizer.T("overlay.standard"), Localizer.T("overlay.large") }); sizePicker.Location = new Point(130, 70); sizePicker.Width = 170; sizePicker.SelectedIndex = _prefs.OverlaySize == "compact" ? 0 : _prefs.OverlaySize == "large" ? 2 : 1;
            sizePicker.SelectedIndexChanged += delegate { _prefs.OverlaySize = sizePicker.SelectedIndex == 0 ? "compact" : sizePicker.SelectedIndex == 2 ? "large" : "standard"; SavePreferences(); RefreshOverlayAppearance(); SetStatus(Localizer.T("status.saved")); }; overlaySettings.Controls.Add(sizePicker);
            Label opacityLabel = MakeLabel(Localizer.T("overlay.opacity"), 9, Palette.Text, false); opacityLabel.Location = new Point(330, 75); opacityLabel.Size = new Size(75, 22); overlaySettings.Controls.Add(opacityLabel);
            ComboBox opacityPicker = MakeCombo(new[] { "70%", "80%", "90%", "100%" }); opacityPicker.Location = new Point(410, 70); opacityPicker.Width = 110; opacityPicker.SelectedIndex = _prefs.OverlayOpacity <= 70 ? 0 : _prefs.OverlayOpacity <= 80 ? 1 : _prefs.OverlayOpacity <= 90 ? 2 : 3;
            opacityPicker.SelectedIndexChanged += delegate { _prefs.OverlayOpacity = new[] { 70, 80, 90, 100 }[opacityPicker.SelectedIndex]; SavePreferences(); RefreshOverlayAppearance(); SetStatus(Localizer.T("status.saved")); }; overlaySettings.Controls.Add(opacityPicker);
            CheckBox showCpu = new CheckBox(); showCpu.Text = Localizer.T("overlay.showCpu"); showCpu.Checked = _prefs.OverlayShowCpu; showCpu.ForeColor = Palette.Text; showCpu.BackColor = Palette.Surface; showCpu.FlatStyle = FlatStyle.Flat; showCpu.Location = new Point(16, 111); showCpu.Size = new Size(112, 24); overlaySettings.Controls.Add(showCpu);
            CheckBox showGpu = new CheckBox(); showGpu.Text = Localizer.T("overlay.showGpu"); showGpu.Checked = _prefs.OverlayShowGpu; showGpu.ForeColor = Palette.Text; showGpu.BackColor = Palette.Surface; showGpu.FlatStyle = FlatStyle.Flat; showGpu.Location = new Point(132, 111); showGpu.Size = new Size(112, 24); overlaySettings.Controls.Add(showGpu);
            CheckBox showRam = new CheckBox(); showRam.Text = Localizer.T("overlay.showRam"); showRam.Checked = _prefs.OverlayShowRam; showRam.ForeColor = Palette.Text; showRam.BackColor = Palette.Surface; showRam.FlatStyle = FlatStyle.Flat; showRam.Location = new Point(248, 111); showRam.Size = new Size(112, 24); overlaySettings.Controls.Add(showRam);
            CheckBox showFps = new CheckBox(); showFps.Text = Localizer.T("overlay.showFps"); showFps.Checked = _prefs.OverlayShowFps; showFps.ForeColor = Palette.Text; showFps.BackColor = Palette.Surface; showFps.FlatStyle = FlatStyle.Flat; showFps.Location = new Point(364, 111); showFps.Size = new Size(112, 24); overlaySettings.Controls.Add(showFps);
            EventHandler overlaySelectionChanged = delegate { _prefs.OverlayShowCpu = showCpu.Checked; _prefs.OverlayShowGpu = showGpu.Checked; _prefs.OverlayShowRam = showRam.Checked; _prefs.OverlayShowFps = showFps.Checked; SavePreferences(); RefreshOverlayAppearance(); SetStatus(Localizer.T("status.saved")); };
            showCpu.CheckedChanged += overlaySelectionChanged; showGpu.CheckedChanged += overlaySelectionChanged; showRam.CheckedChanged += overlaySelectionChanged; showFps.CheckedChanged += overlaySelectionChanged;
            _content.Controls.Add(overlaySettings);
            RoundPanel monitor = Card(92); Label monitorTitle = MakeLabel(Localizer.T("settings.monitorTitle"), 11, Palette.Text, true); monitorTitle.Location = new Point(16, 17); monitorTitle.Size = new Size(300, 24); monitor.Controls.Add(monitorTitle);
            Label monitorDesc = MakeLabel(Localizer.T("settings.monitorDesc"), 9, Palette.Muted, false); monitorDesc.Location = new Point(16, 45); monitorDesc.Size = new Size(monitor.Width - 32, 36); monitor.Controls.Add(monitorDesc); _content.Controls.Add(monitor);

            bool displayTimeoutEnabled = File.Exists(DisplayTimeoutBackupPath);
            RoundPanel timeout = Card(132); Label timeoutTitle = MakeLabel(Localizer.T("settings.screenTimeoutTitle"), 11, Palette.Text, true); timeoutTitle.Location = new Point(16, 13); timeoutTitle.Size = new Size(timeout.Width - 112, 24); timeoutTitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; timeout.Controls.Add(timeoutTitle);
            Label timeoutHint = MakeLabel(Localizer.T("settings.screenTimeoutHint"), 8, Palette.Muted, false); timeoutHint.Location = new Point(16, 40); timeoutHint.Size = new Size(timeout.Width - 220, 58); timeoutHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; timeout.Controls.Add(timeoutHint);
            Label timeoutState = MakeLabel(Localizer.T(displayTimeoutEnabled ? "settings.screenTimeoutOn" : "settings.screenTimeoutOff"), 8, displayTimeoutEnabled ? Palette.Accent : Palette.Muted, true); timeoutState.Location = new Point(16, 101); timeoutState.Size = new Size(timeout.Width - 230, 20); timeoutState.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; timeout.Controls.Add(timeoutState);
            ToggleSwitch timeoutToggle = new ToggleSwitch(); timeoutToggle.Checked = displayTimeoutEnabled; timeoutToggle.Location = new Point(timeout.Width - 64, 17); timeoutToggle.Anchor = AnchorStyles.Top | AnchorStyles.Right; timeoutToggle.AccessibleName = Localizer.T("settings.screenTimeoutTitle"); timeout.Controls.Add(timeoutToggle);
            Button timeoutRestore = MakeButton(Localizer.T("settings.screenTimeoutRestore"), Palette.Surface2, 34); timeoutRestore.Width = 190; timeoutRestore.Location = new Point(timeout.Width - 206, 88); timeoutRestore.Anchor = AnchorStyles.Top | AnchorStyles.Right; timeoutRestore.Visible = displayTimeoutEnabled; timeout.Controls.Add(timeoutRestore);
            timeoutToggle.CheckedChanged += delegate
            {
                if (timeoutToggle.Checked)
                {
                    try { DisableDisplayTimeoutForActivePlan(); timeoutState.Text = Localizer.T("settings.screenTimeoutOn"); timeoutState.ForeColor = Palette.Accent; timeoutRestore.Visible = true; SetStatus(Localizer.T("settings.screenTimeoutSaved")); }
                    catch (Exception ex)
                    {
                        timeoutToggle.SetCheckedSilently(File.Exists(DisplayTimeoutBackupPath));
                        string detail = DescribeSystemError(ex);
                        if (detail.IndexOf("access denied", StringComparison.OrdinalIgnoreCase) >= 0 || detail.IndexOf("zugriff verweigert", StringComparison.OrdinalIgnoreCase) >= 0) detail = Localizer.T("error.adminHint") + "\r\n\r\n" + detail;
                        ThemedDialog.Show(this, Localizer.T("settings.screenTimeoutTitle"), Localizer.T("settings.screenTimeoutFailed") + "\r\n\r\n" + detail, false);
                    }
                }
                else
                {
                    try { RestoreDisplayTimeoutBackup(); timeoutState.Text = Localizer.T("settings.screenTimeoutOff"); timeoutState.ForeColor = Palette.Muted; timeoutRestore.Visible = false; SetStatus(Localizer.T("settings.screenTimeoutRestored")); }
                    catch (Exception ex) { timeoutToggle.SetCheckedSilently(File.Exists(DisplayTimeoutBackupPath)); ThemedDialog.Show(this, Localizer.T("settings.screenTimeoutTitle"), Localizer.T("settings.screenTimeoutFailed") + "\r\n\r\n" + DescribeSystemError(ex), false); }
                }
            };
            timeoutRestore.Click += delegate
            {
                try { RestoreDisplayTimeoutBackup(); timeoutToggle.SetCheckedSilently(false); timeoutState.Text = Localizer.T("settings.screenTimeoutOff"); timeoutState.ForeColor = Palette.Muted; timeoutRestore.Visible = false; SetStatus(Localizer.T("settings.screenTimeoutRestored")); }
                catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("settings.screenTimeoutTitle"), Localizer.T("settings.screenTimeoutFailed") + "\r\n\r\n" + DescribeSystemError(ex), false); }
            };
            _content.Controls.Add(timeout);

            RoundPanel restore = Card(94); Label restoreTitle = MakeLabel(Localizer.T("restore.infoTitle"), 11, Palette.Text, true); restoreTitle.Location = new Point(16, 14); restoreTitle.Size = new Size(restore.Width - 190, 24); restore.Controls.Add(restoreTitle);
            Label restoreHint = MakeLabel(Localizer.T("restore.infoBody"), 8, Palette.Muted, false); restoreHint.Location = new Point(16, 40); restoreHint.Size = new Size(restore.Width - 200, 45); restoreHint.AutoEllipsis = true; restore.Controls.Add(restoreHint);
            restore.Cursor = Cursors.Hand; restore.Click += delegate { ShowRestorePointHelp(); }; restoreTitle.Click += delegate { ShowRestorePointHelp(); }; restoreHint.Click += delegate { ShowRestorePointHelp(); };
            Button protection = MakeButton(Localizer.T("restore.open"), Palette.Accent, 36); protection.Width = 165; protection.Location = new Point(restore.Width - 183, 28); protection.Click += delegate { OpenSystemProtection(); }; restore.Controls.Add(protection); _content.Controls.Add(restore);


        }

        private void RenderCrosshair()
        {
            AddPageHeading(Localizer.T("crosshair.title"), Localizer.T("crosshair.hint"));
            RoundPanel cross = Card(344); Label crossTitle = MakeLabel(Localizer.T("crosshair.title"), 11, Palette.Text, true); crossTitle.Location = new Point(16, 12); crossTitle.Size = new Size(300, 23); cross.Controls.Add(crossTitle);
            Label crossHint = MakeLabel(Localizer.T("crosshair.hint"), 8, Palette.Muted, false); crossHint.Location = new Point(16, 36); crossHint.Size = new Size(cross.Width - 32, 34); cross.Controls.Add(crossHint);
            Label displayLabel = MakeLabel(Localizer.T("crosshair.monitor"), 9, Palette.Text, false); displayLabel.Location = new Point(16, 77); displayLabel.Size = new Size(130, 24); cross.Controls.Add(displayLabel);
            ComboBox displayPicker = MakeCombo(new string[0]); displayPicker.Location = new Point(150, 72); displayPicker.Width = Math.Max(230, cross.Width - 174);
            Screen[] screens = Screen.AllScreens; foreach (Screen screen in screens) displayPicker.Items.Add(new CrosshairDisplayOption(screen));
            int selectedScreen = 0; for (int i = 0; i < displayPicker.Items.Count; i++) if (((CrosshairDisplayOption)displayPicker.Items[i]).Screen.DeviceName == _prefs.CrosshairScreen) selectedScreen = i;
            if (displayPicker.Items.Count > 0) displayPicker.SelectedIndex = selectedScreen; cross.Controls.Add(displayPicker);
            Label shapeLabel = MakeLabel(Localizer.T("crosshair.shape"), 9, Palette.Text, false); shapeLabel.Location = new Point(16, 112); shapeLabel.Size = new Size(95, 24); cross.Controls.Add(shapeLabel);
            string[] shapes = { "plus", "x", "circle", "dot", "square", "diamond", "t", "brackets", "cross", "circleCross", "chevron", "star", "custom" }; ComboBox shapePicker = MakeCombo(shapes.Select(x => Localizer.T("crosshair." + x)).ToArray()); shapePicker.Location = new Point(110, 107); shapePicker.Width = 150; shapePicker.SelectedIndex = Math.Max(0, Array.IndexOf(shapes, _prefs.CrosshairShape)); cross.Controls.Add(shapePicker);
            Label colorLabel = MakeLabel(Localizer.T("crosshair.color"), 9, Palette.Text, false); colorLabel.Location = new Point(278, 112); colorLabel.Size = new Size(65, 24); cross.Controls.Add(colorLabel);
            string[] colorsCrosshair = { "white", "lime", "cyan", "yellow", "red", "magenta", "orange", "purple", "pink", "blue" }; ComboBox colorPicker = MakeCombo(colorsCrosshair.Select(x => Localizer.T("crosshair." + x)).ToArray()); colorPicker.Location = new Point(344, 107); colorPicker.Width = 142; colorPicker.SelectedIndex = Math.Max(0, Array.IndexOf(colorsCrosshair, _prefs.CrosshairColor)); cross.Controls.Add(colorPicker);
            Label crossSizeLabel = MakeLabel(Localizer.T("crosshair.size"), 9, Palette.Text, false); crossSizeLabel.Location = new Point(16, 151); crossSizeLabel.Size = new Size(90, 24); cross.Controls.Add(crossSizeLabel);
            int[] sizes = { 12, 16, 20, 24, 28, 32, 40, 48 }; ComboBox sizeCross = MakeCombo(sizes.Select(x => x.ToString(CultureInfo.InvariantCulture)).ToArray()); sizeCross.Location = new Point(110, 146); sizeCross.Width = 95; sizeCross.SelectedItem = sizes.Contains(_prefs.CrosshairSize) ? _prefs.CrosshairSize.ToString(CultureInfo.InvariantCulture) : "20"; cross.Controls.Add(sizeCross);
            Label gapLabel = MakeLabel(Localizer.T("crosshair.gap"), 9, Palette.Text, false); gapLabel.Location = new Point(218, 151); gapLabel.Size = new Size(80, 24); cross.Controls.Add(gapLabel);
            int[] gaps = { 0, 2, 4, 6, 8, 10, 12, 16 }; ComboBox gapCross = MakeCombo(gaps.Select(x => x.ToString(CultureInfo.InvariantCulture)).ToArray()); gapCross.Location = new Point(298, 146); gapCross.Width = 78; gapCross.SelectedItem = gaps.Contains(_prefs.CrosshairGap) ? _prefs.CrosshairGap.ToString(CultureInfo.InvariantCulture) : "4"; cross.Controls.Add(gapCross);
            Label thicknessLabel = MakeLabel(Localizer.T("crosshair.thickness"), 9, Palette.Text, false); thicknessLabel.Location = new Point(388, 151); thicknessLabel.Size = new Size(104, 24); cross.Controls.Add(thicknessLabel);
            ComboBox thicknessPicker = MakeCombo(new[] { "1", "2", "3", "4", "5" }); thicknessPicker.Location = new Point(495, 146); thicknessPicker.Width = 65; thicknessPicker.SelectedItem = _prefs.CrosshairThickness.ToString(CultureInfo.InvariantCulture); cross.Controls.Add(thicknessPicker);
            Label opacityLabel = MakeLabel(Localizer.T("crosshair.opacity"), 9, Palette.Text, false); opacityLabel.Location = new Point(16, 269); opacityLabel.Size = new Size(124, 24); cross.Controls.Add(opacityLabel);
            ModernSlider opacityCross = new ModernSlider(); opacityCross.Minimum = 10; opacityCross.Maximum = 100; opacityCross.Value = _prefs.CrosshairOpacity; opacityCross.Location = new Point(150, 264); opacityCross.Size = new Size(250, 30); cross.Controls.Add(opacityCross);
            Label opacityValue = MakeLabel(_prefs.CrosshairOpacity.ToString(CultureInfo.InvariantCulture) + "%", 9, Palette.Accent, true); opacityValue.Location = new Point(405, 268); opacityValue.Size = new Size(48, 24); cross.Controls.Add(opacityValue);
            Label outlineLabel = MakeLabel(Localizer.T("crosshair.outline"), 9, Palette.Text, false); outlineLabel.Location = new Point(470, 269); outlineLabel.Size = new Size(58, 24); cross.Controls.Add(outlineLabel);
            ToggleSwitch outlineToggle = new ToggleSwitch(); outlineToggle.Checked = _prefs.CrosshairOutline; outlineToggle.Location = new Point(531, 266); outlineToggle.AccessibleName = Localizer.T("crosshair.outline"); cross.Controls.Add(outlineToggle);
            Label glowLabel = MakeLabel(Localizer.T("crosshair.glow"), 9, Palette.Text, false); glowLabel.Location = new Point(592, 269); glowLabel.Size = new Size(110, 24); cross.Controls.Add(glowLabel);
            ToggleSwitch glowToggle = new ToggleSwitch(); glowToggle.Checked = _prefs.CrosshairGlow; glowToggle.Location = new Point(702, 266); glowToggle.AccessibleName = Localizer.T("crosshair.glow"); cross.Controls.Add(glowToggle);
            Label effectHint = MakeLabel(Localizer.T("crosshair.effectHint"), 8, Palette.Muted, false); effectHint.Location = new Point(16, 306); effectHint.Size = new Size(cross.Width - 32, 23); effectHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; cross.Controls.Add(effectHint);
            CrosshairPreviewControl preview = new CrosshairPreviewControl();
            bool crosshairRunning = _crosshair != null && !_crosshair.IsDisposed;
            Action saveCrosshairSelections = delegate
            {
                _prefs.CrosshairShape = shapes[Math.Max(0, shapePicker.SelectedIndex)]; _prefs.CrosshairColor = colorsCrosshair[Math.Max(0, colorPicker.SelectedIndex)];
                Int32.TryParse(Convert.ToString(sizeCross.SelectedItem), out _prefs.CrosshairSize); Int32.TryParse(Convert.ToString(gapCross.SelectedItem), out _prefs.CrosshairGap); Int32.TryParse(Convert.ToString(thicknessPicker.SelectedItem), out _prefs.CrosshairThickness);
                _prefs.CrosshairOpacity = opacityCross.Value; _prefs.CrosshairOutline = outlineToggle.Checked; _prefs.CrosshairGlow = glowToggle.Checked;
                CrosshairDisplayOption option = displayPicker.SelectedItem as CrosshairDisplayOption; if (option != null) _prefs.CrosshairScreen = option.Screen.DeviceName;
                SavePreferences();
            };
            Action updatePreview = delegate { preview.ApplyStyle(_prefs.CrosshairShape, _prefs.CrosshairColor, _prefs.CrosshairSize, _prefs.CrosshairGap, _prefs.CrosshairThickness, _prefs.CrosshairOpacity, _prefs.CrosshairOutline, _prefs.CrosshairGlow, CrosshairCustomImagePath()); };
            Button crosshairReload = MakeButton(Localizer.T("crosshair.reload"), Palette.Surface2, 36); crosshairReload.Width = 160; crosshairReload.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            crosshairReload.Click += delegate
            {
                saveCrosshairSelections();
                if (_crosshair != null && !_crosshair.IsDisposed) { RecenterActiveCrosshair(); SetStatus(Localizer.T("crosshair.reloadDone")); }
                else SetStatus(Localizer.T("crosshair.saved"));
            };
            cross.Controls.Add(crosshairReload);
            Label crosshairState = MakeLabel(Localizer.T(crosshairRunning ? "state.on" : "state.off"), 8, crosshairRunning ? Palette.Green : Palette.Muted, true); crosshairState.TextAlign = ContentAlignment.MiddleRight; crosshairState.Size = new Size(48, 22); crosshairState.Anchor = AnchorStyles.Top | AnchorStyles.Right; cross.Controls.Add(crosshairState);
            ToggleSwitch crosshairToggle = new ToggleSwitch(); crosshairToggle.Checked = crosshairRunning; crosshairToggle.AccessibleName = Localizer.T("crosshair.title"); crosshairToggle.Anchor = AnchorStyles.Top | AnchorStyles.Right; cross.Controls.Add(crosshairToggle);
            Action layoutCrosshairButtons = delegate
            {
                int right = cross.ClientSize.Width - 16;
                crosshairToggle.Location = new Point(right - crosshairToggle.Width, 183);
                crosshairState.Location = new Point(crosshairToggle.Left - crosshairState.Width - 8, 185);
                crosshairReload.Location = new Point(crosshairState.Left - crosshairReload.Width - 10, 179);
            };
            cross.Resize += delegate { layoutCrosshairButtons(); };
            layoutCrosshairButtons();

            Button customEditor = MakeButton(Localizer.T("crosshair.customButton"), Palette.Accent, 36); customEditor.Location = new Point(16, 222); customEditor.Width = 205; cross.Controls.Add(customEditor);
            Button importImage = MakeButton(Localizer.T("crosshair.importButton"), Palette.Surface2, 36); importImage.Location = new Point(229, 222); importImage.Width = 150; cross.Controls.Add(importImage);
            RoundPanel dropZone = new RoundPanel(); dropZone.BackColor = Palette.Surface2; dropZone.Location = new Point(390, 222); dropZone.Size = new Size(Math.Max(180, cross.ClientSize.Width - 406), 36); dropZone.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; dropZone.Cursor = Cursors.Hand;
            Label dropText = MakeLabel(Localizer.T("crosshair.dropHint"), 8, Palette.Muted, false); dropText.Dock = DockStyle.Fill; dropText.TextAlign = ContentAlignment.MiddleCenter; dropZone.Controls.Add(dropText);
            cross.Controls.Add(dropZone);
            customEditor.Click += delegate
            {
                string exported = Path.Combine(Path.GetTempPath(), "freezer-crosshair-" + Guid.NewGuid().ToString("N") + ".png");
                using (CustomCrosshairEditorForm editor = new CustomCrosshairEditorForm(exported, File.Exists(CrosshairCustomImagePath()) ? CrosshairCustomImagePath() : null))
                {
                    if (editor.ShowDialog(this) == DialogResult.OK && ImportCrosshairImage(exported)) ShowPage("crosshair");
                }
                try { if (File.Exists(exported)) File.Delete(exported); } catch { }
            };
            importImage.Click += delegate { ChooseCrosshairImage(); };
            Action<string> importDroppedImage = delegate(string path) { if (ImportCrosshairImage(path)) ShowPage("crosshair"); };
            SetCrosshairDropTarget(dropZone, importDroppedImage);
            SetCrosshairDropTarget(dropText, importDroppedImage);
            SetCrosshairDropTarget(cross, importDroppedImage);
            crosshairToggle.CheckedChanged += delegate
            {
                bool enable = crosshairToggle.Checked; saveCrosshairSelections();
                if (enable)
                {
                    try
                    {
                        Screen screen = FindCurrentCrosshairScreen(_prefs.CrosshairScreen);
                        _crosshair = new CrosshairForm(screen.Bounds, _prefs.CrosshairShape, _prefs.CrosshairColor, _prefs.CrosshairSize, _prefs.CrosshairGap, _prefs.CrosshairThickness, _prefs.CrosshairOpacity, _prefs.CrosshairOutline, _prefs.CrosshairGlow, CrosshairCustomImagePath());
                        _crosshair.Show(); _prefs.CrosshairEnabled = true;
                    }
                    catch (Exception ex) { try { if (_crosshair != null && !_crosshair.IsDisposed) _crosshair.Close(); } catch { } _crosshair = null; _prefs.CrosshairEnabled = false; crosshairToggle.SetCheckedSilently(false); ThemedDialog.Show(this, Localizer.T("crosshair.title"), DescribeSystemError(ex), false); }
                }
                else
                {
                    if (_crosshair != null && !_crosshair.IsDisposed) _crosshair.Close(); _crosshair = null; _prefs.CrosshairEnabled = false;
                }
                crosshairState.Text = Localizer.T(crosshairToggle.Checked ? "state.on" : "state.off"); crosshairState.ForeColor = crosshairToggle.Checked ? Palette.Green : Palette.Muted;
                crosshairReload.Enabled = true; SavePreferences();
            };
            EventHandler previewChange = delegate
            {
                saveCrosshairSelections();
                updatePreview();
                if (_crosshair != null && !_crosshair.IsDisposed) RecenterActiveCrosshair();
            };
            displayPicker.SelectedIndexChanged += previewChange; shapePicker.SelectedIndexChanged += previewChange; colorPicker.SelectedIndexChanged += previewChange; sizeCross.SelectedIndexChanged += previewChange; gapCross.SelectedIndexChanged += previewChange; thicknessPicker.SelectedIndexChanged += previewChange;
            opacityCross.ValueChanged += delegate { opacityValue.Text = opacityCross.Value.ToString(CultureInfo.InvariantCulture) + "%"; previewChange(this, EventArgs.Empty); };
            outlineToggle.CheckedChanged += previewChange; glowToggle.CheckedChanged += previewChange;
            updatePreview();

            RoundPanel presetCard = Card(128); Label previewTitle = MakeLabel(Localizer.T("crosshair.preview"), 10, Palette.Text, true); previewTitle.Location = new Point(16, 12); previewTitle.Size = new Size(170, 22); presetCard.Controls.Add(previewTitle);
            preview.Location = new Point(16, 39); preview.Size = new Size(92, 76); presetCard.Controls.Add(preview);
            Label presetLabel = MakeLabel(Localizer.T("crosshair.presets"), 9, Palette.Text, false); presetLabel.Location = new Point(126, 35); presetLabel.Size = new Size(230, 20); presetCard.Controls.Add(presetLabel);
            ComboBox presetPicker = MakeCombo(_prefs.CrosshairPresets.Keys.OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase).ToArray()); presetPicker.Location = new Point(126, 59); presetPicker.Width = 245; presetCard.Controls.Add(presetPicker);
            Button savePreset = MakeButton(Localizer.T("crosshair.presetSave"), Palette.Accent, 36); savePreset.Location = new Point(385, 55); savePreset.Width = 136; presetCard.Controls.Add(savePreset);
            Button applyPreset = MakeButton(Localizer.T("crosshair.presetApply"), Palette.Surface2, 36); applyPreset.Location = new Point(531, 55); applyPreset.Width = 112; presetCard.Controls.Add(applyPreset);
            Button deletePreset = MakeButton(Localizer.T("crosshair.presetDelete"), Palette.Surface2, 36); deletePreset.Location = new Point(653, 55); deletePreset.Width = 112; presetCard.Controls.Add(deletePreset);
            Action refreshPresetPicker = delegate
            {
                string selected = Convert.ToString(presetPicker.SelectedItem); presetPicker.Items.Clear();
                foreach (string item in _prefs.CrosshairPresets.Keys.OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase)) presetPicker.Items.Add(item);
                if (!String.IsNullOrEmpty(selected) && presetPicker.Items.Contains(selected)) presetPicker.SelectedItem = selected; else if (presetPicker.Items.Count > 0) presetPicker.SelectedIndex = 0;
            };
            savePreset.Click += delegate
            {
                saveCrosshairSelections();
                string name = ThemedDialog.Prompt(this, Localizer.T("crosshair.presetSave"), Localizer.T("crosshair.presetName"));
                if (String.IsNullOrWhiteSpace(name)) return;
                if (_prefs.CrosshairPresets.ContainsKey(name) && !ThemedDialog.Confirm(this, Localizer.T("crosshair.presetSave"), Localizer.T("crosshair.presetOverwrite"))) return;
                if (_prefs.CrosshairShape == "custom")
                {
                    if (!File.Exists(CrosshairCustomImagePath())) { ThemedDialog.Show(this, Localizer.T("crosshair.presets"), Localizer.T("crosshair.presetImageMissing"), false); return; }
                    try { string presetImage = CrosshairPresetImagePath(name); Directory.CreateDirectory(Path.GetDirectoryName(presetImage)); File.Copy(CrosshairCustomImagePath(), presetImage, true); }
                    catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("crosshair.presetSave"), DescribeSystemError(ex), false); return; }
                }
                else { try { string oldImage = CrosshairPresetImagePath(name); if (File.Exists(oldImage)) File.Delete(oldImage); } catch { } }
                _prefs.CrosshairPresets[name] = String.Join("|", new[] { _prefs.CrosshairShape, _prefs.CrosshairColor, _prefs.CrosshairSize.ToString(CultureInfo.InvariantCulture), _prefs.CrosshairGap.ToString(CultureInfo.InvariantCulture), _prefs.CrosshairThickness.ToString(CultureInfo.InvariantCulture), _prefs.CrosshairOpacity.ToString(CultureInfo.InvariantCulture), _prefs.CrosshairOutline ? "1" : "0", _prefs.CrosshairGlow ? "1" : "0" });
                SavePreferences(); refreshPresetPicker(); presetPicker.SelectedItem = name; SetStatus(Localizer.T("crosshair.presetSaved"));
            };
            applyPreset.Click += delegate
            {
                string name = Convert.ToString(presetPicker.SelectedItem), data;
                if (String.IsNullOrWhiteSpace(name) || !_prefs.CrosshairPresets.TryGetValue(name, out data)) { ThemedDialog.Show(this, Localizer.T("crosshair.presets"), Localizer.T("crosshair.presetSelect"), false); return; }
                string[] values = (data ?? "").Split('|'); int size, gap, thickness, opacity;
                if (values.Length != 8 || !shapes.Contains(values[0]) || !colorsCrosshair.Contains(values[1]) || !Int32.TryParse(values[2], out size) || !sizes.Contains(size) || !Int32.TryParse(values[3], out gap) || !gaps.Contains(gap) || !Int32.TryParse(values[4], out thickness) || thickness < 1 || thickness > 5 || !Int32.TryParse(values[5], out opacity) || opacity < 10 || opacity > 100 || (values[6] != "0" && values[6] != "1") || (values[7] != "0" && values[7] != "1"))
                { ThemedDialog.Show(this, Localizer.T("crosshair.presets"), Localizer.T("crosshair.presetInvalid"), false); return; }
                if (values[0] == "custom")
                {
                    string presetImage = CrosshairPresetImagePath(name);
                    if (!File.Exists(presetImage)) { ThemedDialog.Show(this, Localizer.T("crosshair.presets"), Localizer.T("crosshair.presetImageMissing"), false); return; }
                    try { File.Copy(presetImage, CrosshairCustomImagePath(), true); preview.ReloadImage(); if (_crosshair != null && !_crosshair.IsDisposed) _crosshair.ReloadCustomImage(); }
                    catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("crosshair.presets"), DescribeSystemError(ex), false); return; }
                }
                shapePicker.SelectedIndex = Array.IndexOf(shapes, values[0]); colorPicker.SelectedIndex = Array.IndexOf(colorsCrosshair, values[1]); sizeCross.SelectedItem = size.ToString(CultureInfo.InvariantCulture); gapCross.SelectedItem = gap.ToString(CultureInfo.InvariantCulture); thicknessPicker.SelectedItem = thickness.ToString(CultureInfo.InvariantCulture); opacityCross.Value = opacity; outlineToggle.Checked = values[6] == "1"; glowToggle.Checked = values[7] == "1"; previewChange(this, EventArgs.Empty);
            };
            deletePreset.Click += delegate
            {
                string name = Convert.ToString(presetPicker.SelectedItem);
                if (String.IsNullOrWhiteSpace(name) || !_prefs.CrosshairPresets.ContainsKey(name)) { ThemedDialog.Show(this, Localizer.T("crosshair.presets"), Localizer.T("crosshair.presetSelect"), false); return; }
                if (!ThemedDialog.Confirm(this, Localizer.T("crosshair.presetDelete"), Localizer.T("crosshair.presetDeleteConfirm").Replace("{0}", name))) return;
                _prefs.CrosshairPresets.Remove(name); try { string presetImage = CrosshairPresetImagePath(name); if (File.Exists(presetImage)) File.Delete(presetImage); } catch { }
                SavePreferences(); refreshPresetPicker(); SetStatus(Localizer.T("crosshair.presetRemoved"));
            };
            _content.Controls.Add(cross);
            _content.Controls.Add(presetCard);
        }

        private void RenderRepair()
        {
            AddPageHeading(Localizer.T("repair.title"), Localizer.T("repair.subtitle"));
            RoundPanel card = Card(276); Label title = MakeLabel(Localizer.T("repair.reportTitle"), 13, Palette.Text, true); title.Location = new Point(16, 12); title.Size = new Size(450, 24); card.Controls.Add(title);
            TextBox report = new TextBox(); report.Multiline = true; report.ReadOnly = true; report.ScrollBars = ScrollBars.Vertical; report.BorderStyle = BorderStyle.FixedSingle;
            report.BackColor = Palette.Surface2; report.ForeColor = Palette.Text; report.Font = UiFontCache.Get("Consolas", 9F, FontStyle.Regular); report.Location = new Point(16, 42); report.Size = new Size(card.Width - 32, 132); report.Text = BuildDiagnosticsReport(); card.Controls.Add(report);
            Button diagnose = MakeButton(Localizer.T("repair.diagnose"), Palette.Surface2, 36); diagnose.Location = new Point(16, 190); diagnose.Width = 145;
            diagnose.Click += delegate { report.Text = BuildDiagnosticsReport(); SetStatus(Localizer.T("repair.reportTitle")); };
            Button repair = MakeButton(Localizer.T("repair.auto"), Palette.Accent, 36); repair.Location = new Point(171, 190); repair.Width = 145;
            repair.Click += delegate { if (ThemedDialog.Confirm(this, Localizer.T("repair.auto"), Localizer.T("repair.autoDescription"))) { string result = AutoRepair(); report.Text = BuildDiagnosticsReport() + "\r\n" + result; } };
            Button folder = MakeButton(Localizer.T("repair.openFolder"), Palette.Surface2, 36); folder.Location = new Point(326, 190); folder.Width = 145; folder.Click += delegate { try { Process.Start("explorer.exe", _stateRoot); } catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("error.action"), DescribeSystemError(ex), false); } };
            Button restore = MakeButton(Localizer.T("repair.restoreTweaks"), Palette.Surface2, 36); restore.Location = new Point(481, 190); restore.Width = 185;
            restore.Click += delegate
            {
                string warning = Localizer.T("repair.restoreTweaks") + "?\r\n\r\n" + Localizer.T("optimization.confirm");
                if (File.Exists(Path.Combine(_stateRoot, "cpu-policy.txt"))) warning += "\r\n\r\n" + Localizer.T("repair.adminWhy");
                if (ThemedDialog.Confirm(this, Localizer.T("repair.title"), warning)) RestoreAll();
            };
            Button export = MakeButton(Localizer.T("diagnostic.export"), Palette.Surface2, 32); export.Location = new Point(16, 232); export.Width = 188;
            export.Click += delegate { PreviewAndExportDiagnostics(); };
            card.Controls.Add(diagnose); card.Controls.Add(repair); card.Controls.Add(folder); card.Controls.Add(restore); card.Controls.Add(export); _content.Controls.Add(card);
            RoundPanel streaming = Card(96);
            Label streamingTitle = MakeLabel(Localizer.T("gaming.obsGuideTitle"), 12, Palette.Text, true); streamingTitle.Location = new Point(16, 12); streamingTitle.Size = new Size(500, 23); streaming.Controls.Add(streamingTitle);
            Label streamingHint = MakeLabel(Localizer.T("gaming.obsGuideHint"), 9, Palette.Muted, false); streamingHint.Location = new Point(16, 42); streamingHint.Size = new Size(streaming.Width - 242, 38); streamingHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; streaming.Controls.Add(streamingHint);
            Button streamingHelp = MakeButton(Localizer.T("gaming.obsGuideButton"), Palette.Accent, 38); streamingHelp.Width = 200; streamingHelp.Location = new Point(streaming.Width - 216, 29); streamingHelp.Anchor = AnchorStyles.Top | AnchorStyles.Right; streamingHelp.Click += delegate { ShowObsStreamingGuide(); }; streaming.Controls.Add(streamingHelp);
            _content.Controls.Add(streaming);
        }

        private void RenderPerformance()
        {
            AddPageHeading(Localizer.T("benchmark.title"), Localizer.T("benchmark.subtitle"));
            RoundPanel intro = Card(75);
            Label introText = MakeLabel(Localizer.T("benchmark.idle") + "\r\n" + Localizer.T("benchmark.sampleThreshold") + "\r\n" + Localizer.T("benchmark.hardwareUnknown"), 8, Palette.Muted, false);
            introText.Location = new Point(16, 14); introText.Size = new Size(intro.Width - 32, 48); introText.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; intro.Controls.Add(introText); _content.Controls.Add(intro);

            RoundPanel run = Card(156);
            Label runTitle = MakeLabel(Localizer.T("benchmark.runTitle"), 12, Palette.Text, true); runTitle.Location = new Point(16, 12); runTitle.Size = new Size(300, 23); run.Controls.Add(runTitle);
            _benchmarkGamePicker = MakeCombo(new string[0]); _benchmarkGamePicker.Location = new Point(16, 47); _benchmarkGamePicker.Width = 350; run.Controls.Add(_benchmarkGamePicker);
            Button refresh = MakeButton(Localizer.T("benchmark.refresh"), Palette.Surface2, 32); refresh.Location = new Point(374, 46); refresh.Width = 136; refresh.Click += delegate { RefreshBenchmarkProcesses(); }; run.Controls.Add(refresh);
            _benchmarkProfilePicker = MakeCombo(new[] { Localizer.T("benchmark.profileBalanced"), Localizer.T("benchmark.profileMax"), Localizer.T("benchmark.profileStreamer"), Localizer.T("benchmark.profileCustom") });
            _benchmarkProfilePicker.SelectedIndex = 0; _benchmarkProfilePicker.Location = new Point(16, 91); _benchmarkProfilePicker.Width = 220; run.Controls.Add(_benchmarkProfilePicker);
            _benchmarkDurationPicker = MakeCombo(new[] { "30 s", "60 s", "120 s" }); _benchmarkDurationPicker.SelectedIndex = 0; _benchmarkDurationPicker.Location = new Point(246, 91); _benchmarkDurationPicker.Width = 100; run.Controls.Add(_benchmarkDurationPicker);
            _benchmarkStartButton = MakeButton(Localizer.T("benchmark.start"), Palette.Accent, 36); _benchmarkStartButton.Width = 142; _benchmarkStartButton.Anchor = AnchorStyles.Top | AnchorStyles.Right; run.Controls.Add(_benchmarkStartButton);
            _benchmarkStopButton = MakeButton(Localizer.T("benchmark.stop"), Palette.Surface2, 36); _benchmarkStopButton.Width = 142; _benchmarkStopButton.Anchor = AnchorStyles.Top | AnchorStyles.Right; _benchmarkStopButton.Enabled = false; run.Controls.Add(_benchmarkStopButton);
            _benchmarkStatusLabel = MakeLabel(Localizer.T("benchmark.idle"), 8, Palette.Muted, false); _benchmarkStatusLabel.Location = new Point(16, 128); _benchmarkStatusLabel.Size = new Size(run.Width - 32, 19); _benchmarkStatusLabel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; run.Controls.Add(_benchmarkStatusLabel);
            Action layoutRun = delegate { int right = run.ClientSize.Width - 16; _benchmarkStopButton.Location = new Point(right - _benchmarkStopButton.Width, 91); _benchmarkStartButton.Location = new Point(_benchmarkStopButton.Left - _benchmarkStartButton.Width - 8, 91); };
            run.Resize += delegate { layoutRun(); }; layoutRun();
            _benchmarkStartButton.Click += delegate { StartBenchmark(); };
            _benchmarkStopButton.Click += delegate { FinishBenchmark(false); };
            _content.Controls.Add(run); RefreshBenchmarkProcesses();

            RoundPanel results = Card(146);
            Label resultTitle = MakeLabel(Localizer.T("benchmark.results"), 12, Palette.Text, true); resultTitle.Location = new Point(16, 12); resultTitle.Size = new Size(500, 23); results.Controls.Add(resultTitle);
            _benchmarkResultsLabel = MakeLabel(Localizer.T("benchmark.noResults"), 9, Palette.Muted, false); _benchmarkResultsLabel.Location = new Point(16, 42); _benchmarkResultsLabel.Size = new Size(results.Width - 32, 90); _benchmarkResultsLabel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; results.Controls.Add(_benchmarkResultsLabel);
            _content.Controls.Add(results); RenderLatestBenchmarkResult();

            RoundPanel diagnosis = Card(106);
            Label diagnosisTitle = MakeLabel(Localizer.T("benchmark.diagnosis"), 12, Palette.Text, true); diagnosisTitle.Location = new Point(16, 12); diagnosisTitle.Size = new Size(400, 22); diagnosis.Controls.Add(diagnosisTitle);
            _benchmarkDiagnosisLabel = MakeLabel(Localizer.T("benchmark.diagnosisUnknown"), 9, Palette.Muted, false); _benchmarkDiagnosisLabel.Location = new Point(16, 42); _benchmarkDiagnosisLabel.Size = new Size(diagnosis.Width - 32, 48); _benchmarkDiagnosisLabel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; diagnosis.Controls.Add(_benchmarkDiagnosisLabel);
            _content.Controls.Add(diagnosis); UpdateBenchmarkDiagnosis();

            RoundPanel history = Card(181);
            Label historyTitle = MakeLabel(Localizer.T("benchmark.compareTitle"), 12, Palette.Text, true); historyTitle.Location = new Point(16, 12); historyTitle.Size = new Size(360, 22); history.Controls.Add(historyTitle);
            _benchmarkBaselinePicker = MakeCombo(new string[0]); _benchmarkBaselinePicker.Location = new Point(16, 47); _benchmarkBaselinePicker.Width = 340; history.Controls.Add(_benchmarkBaselinePicker);
            _benchmarkComparePicker = MakeCombo(new string[0]); _benchmarkComparePicker.Location = new Point(366, 47); _benchmarkComparePicker.Width = 340; history.Controls.Add(_benchmarkComparePicker);
            Button compare = MakeButton(Localizer.T("benchmark.compare"), Palette.Accent, 34); compare.Location = new Point(16, 91); compare.Width = 150; compare.Click += delegate { ShowBenchmarkComparison(); }; history.Controls.Add(compare);
            Button exportCsv = MakeButton(Localizer.T("benchmark.exportCsv"), Palette.Surface2, 34); exportCsv.Location = new Point(174, 91); exportCsv.Width = 132; exportCsv.Click += delegate { ExportSelectedBenchmarkCsv(); }; history.Controls.Add(exportCsv);
            Label compareResult = MakeLabel("", 9, Palette.Muted, false); compareResult.Name = "benchmarkComparison"; compareResult.Location = new Point(16, 132); compareResult.Size = new Size(history.Width - 32, 40); compareResult.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; history.Controls.Add(compareResult);
            Action layoutHistory = delegate { int available = Math.Max(300, history.ClientSize.Width - 48); int half = (available - 8) / 2; _benchmarkBaselinePicker.Width = half; _benchmarkComparePicker.Left = 24 + half; _benchmarkComparePicker.Width = half; compareResult.Width = Math.Max(200, history.ClientSize.Width - 32); };
            history.Resize += delegate { layoutHistory(); }; layoutHistory();
            _content.Controls.Add(history); PopulateBenchmarkPickers();

            RoundPanel system = Card(146);
            Label systemTitle = MakeLabel(Localizer.T("benchmark.hardware"), 12, Palette.Text, true); systemTitle.Location = new Point(16, 12); systemTitle.Size = new Size(400, 22); system.Controls.Add(systemTitle);
            string memory = _latest.RamTotalMb > 0 ? (_latest.RamTotalMb / 1024.0).ToString("0.0", CultureInfo.CurrentCulture) + " GB" : Localizer.T("monitor.unavailable");
            string hardware = "CPU: " + (String.IsNullOrWhiteSpace(_cpuModelName) ? Localizer.T("monitor.unavailable") : _cpuModelName) + "\r\nGPU: " + (String.IsNullOrWhiteSpace(_gpuModelName) ? Localizer.T("monitor.unavailable") : _gpuModelName) + "\r\nRAM: " + memory + (String.IsNullOrWhiteSpace(_ramTypeName) ? "" : " · " + _ramTypeName) + "\r\nWindows: " + Environment.OSVersion.VersionString + "\r\n" + GetMonitorSummary();
            _performanceHardwareLabel = MakeLabel(hardware, 8, Palette.Muted, false); _performanceHardwareLabel.Location = new Point(16, 40); _performanceHardwareLabel.Size = new Size(system.Width - 32, 70); _performanceHardwareLabel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; system.Controls.Add(_performanceHardwareLabel);
            Button displaySettings = MakeButton(Localizer.T("benchmark.openDisplay"), Palette.Surface2, 32); displaySettings.Location = new Point(16, 108); displaySettings.Width = 160; displaySettings.Click += delegate { OpenSystemTarget("ms-settings:display"); }; system.Controls.Add(displaySettings);
            Button startupSettings = MakeButton(Localizer.T("benchmark.openStartup"), Palette.Surface2, 32); startupSettings.Location = new Point(186, 108); startupSettings.Width = 180; startupSettings.Click += delegate { OpenSystemTarget("ms-settings:startupapps"); }; system.Controls.Add(startupSettings);
            Button drivers = MakeButton(Localizer.T("benchmark.openDrivers"), Palette.Surface2, 32); drivers.Location = new Point(376, 108); drivers.Width = 174; drivers.Click += delegate { OpenOfficialDriverPage(); }; system.Controls.Add(drivers);
            Button taskManager = MakeButton(Localizer.T("benchmark.taskManager"), Palette.Surface2, 32); taskManager.Location = new Point(560, 108); taskManager.Width = 160; taskManager.Click += delegate { try { Process.Start("taskmgr.exe"); } catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("error.action"), DescribeSystemError(ex), false); } }; system.Controls.Add(taskManager);
            _content.Controls.Add(system);

            RoundPanel activity = Card(122);
            Label activityTitle = MakeLabel(Localizer.T("benchmark.activityTitle"), 12, Palette.Text, true); activityTitle.Location = new Point(16, 12); activityTitle.Size = new Size(450, 22); activity.Controls.Add(activityTitle);
            _performanceActivityLabel = MakeLabel(Localizer.T("benchmark.activityLoading"), 8, Palette.Muted, false); _performanceActivityLabel.Location = new Point(16, 42); _performanceActivityLabel.Size = new Size(activity.Width - 192, 60); _performanceActivityLabel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; activity.Controls.Add(_performanceActivityLabel);
            Button activityRefresh = MakeButton(Localizer.T("benchmark.refreshActivity"), Palette.Surface2, 34); activityRefresh.Width = 164; activityRefresh.Location = new Point(activity.Width - 180, 42); activityRefresh.Anchor = AnchorStyles.Top | AnchorStyles.Right; activityRefresh.Click += delegate { RefreshPerformanceActivity(); }; activity.Controls.Add(activityRefresh);
            _content.Controls.Add(activity); RefreshPerformanceActivity();
        }

        private string GetMonitorSummary()
        {
            try { return String.Join(" · ", Screen.AllScreens.Select(x => (x.Primary ? "Hauptmonitor " : "Monitor ") + x.Bounds.Width + "×" + x.Bounds.Height)); }
            catch { return Localizer.T("monitor.unavailable"); }
        }

        private void RefreshBenchmarkProcesses()
        {
            if (_benchmarkGamePicker == null || _benchmarkGamePicker.IsDisposed) return;
            int current = (_benchmarkGamePicker.SelectedItem as ProcessChoice) == null ? -1 : ((_benchmarkGamePicker.SelectedItem as ProcessChoice).Pid);
            _benchmarkGamePicker.BeginUpdate(); _benchmarkGamePicker.Items.Clear();
            foreach (Process process in Process.GetProcesses())
            {
                try { if (IsGameProcessName(process.ProcessName)) _benchmarkGamePicker.Items.Add(new ProcessChoice { Pid = process.Id, Name = process.ProcessName, DisplayName = Localizer.T(GameKeyForProcess(process.ProcessName)) }); }
                catch { }
                finally { try { process.Dispose(); } catch { } }
            }
            if (_benchmarkGamePicker.Items.Count > 0)
            {
                int selected = 0;
                for (int i = 0; i < _benchmarkGamePicker.Items.Count; i++) if (((ProcessChoice)_benchmarkGamePicker.Items[i]).Pid == current) selected = i;
                _benchmarkGamePicker.SelectedIndex = selected;
            }
            _benchmarkGamePicker.EndUpdate();
            if (_benchmarkStatusLabel != null && !_benchmarkStatusLabel.IsDisposed && _benchmarkGamePicker.Items.Count == 0) _benchmarkStatusLabel.Text = Localizer.T("benchmark.noGame");
        }

        private void StartBenchmark()
        {
            if (_benchmarkRunning) return;
            ProcessChoice game = _benchmarkGamePicker == null ? null : _benchmarkGamePicker.SelectedItem as ProcessChoice;
            if (game == null) { SetStatus(Localizer.T("benchmark.noGame")); if (_benchmarkStatusLabel != null) _benchmarkStatusLabel.Text = Localizer.T("benchmark.noGame"); return; }
            if (!_presentMonReady || !File.Exists(_presentMonPath)) { QueuePresentMonExtraction(); if (_benchmarkStatusLabel != null) _benchmarkStatusLabel.Text = Localizer.T("benchmark.presentMonMissing"); return; }
            _fps.Stop(); _fpsPinnedProcessId = game.Pid; _fpsAutoCapture = false;
            if (!_fps.Start(_presentMonPath, game.Pid)) { _fpsPinnedProcessId = -1; _fpsAutoCapture = true; if (_benchmarkStatusLabel != null) _benchmarkStatusLabel.Text = Localizer.T("benchmark.presentMonMissing"); return; }
            _benchmarkDurationSeconds = _benchmarkDurationPicker != null && _benchmarkDurationPicker.SelectedIndex == 2 ? 120 : _benchmarkDurationPicker != null && _benchmarkDurationPicker.SelectedIndex == 1 ? 60 : 30;
            _benchmarkStartedUtc = DateTime.UtcNow; _benchmarkSamples.Clear(); _benchmarkRunning = true;
            _benchmarkStartButton.Enabled = false; _benchmarkStopButton.Enabled = true;
            if (_benchmarkStatusLabel != null) _benchmarkStatusLabel.Text = Localizer.T("benchmark.running");
            UpdateSampleTimer();
        }

        private void UpdateBenchmarkProgress()
        {
            if (!_benchmarkRunning || _benchmarkStatusLabel == null || _benchmarkStatusLabel.IsDisposed) return;
            int elapsed = (int)(DateTime.UtcNow - _benchmarkStartedUtc).TotalSeconds;
            _benchmarkStatusLabel.Text = Localizer.T("benchmark.running") + " " + Math.Min(elapsed, _benchmarkDurationSeconds) + "/" + _benchmarkDurationSeconds + " s · " + _fps.Get().FrameCount + " frames";
        }

        private void FinishBenchmark(bool timedOut)
        {
            if (!_benchmarkRunning) return;
            _benchmarkRunning = false;
            double elapsed = (DateTime.UtcNow - _benchmarkStartedUtc).TotalSeconds;
            FrameStats stats = _fps.GetBenchmarkStats();
            ProcessChoice game = _benchmarkGamePicker == null ? null : _benchmarkGamePicker.SelectedItem as ProcessChoice;
            string profile = _benchmarkProfilePicker == null ? Localizer.T("benchmark.profileCustom") : Convert.ToString(_benchmarkProfilePicker.SelectedItem);
            _fps.Stop(); _fpsPinnedProcessId = -1; _fpsAutoCapture = true;
            if (_benchmarkStartButton != null && !_benchmarkStartButton.IsDisposed) _benchmarkStartButton.Enabled = true;
            if (_benchmarkStopButton != null && !_benchmarkStopButton.IsDisposed) _benchmarkStopButton.Enabled = false;
            if (stats.FrameCount < 60 || elapsed < 5)
            {
                if (_benchmarkStatusLabel != null) _benchmarkStatusLabel.Text = Localizer.T("benchmark.noResults");
                UpdateSampleTimer(); return;
            }
            BenchmarkRecord record = new BenchmarkRecord
            {
                Utc = DateTime.UtcNow, Game = game == null ? "Spiel" : game.DisplayName, Profile = profile,
                DurationSeconds = Math.Min((int)Math.Round(elapsed), _benchmarkDurationSeconds), Frames = stats.FrameCount,
                AverageFps = stats.Average, MinimumFps = stats.Minimum, OnePercentLow = stats.OnePercentLow, PointOnePercentLow = stats.PointOnePercentLow,
                AverageFrameTimeMs = stats.AverageFrameTimeMs, P95FrameTimeMs = stats.P95FrameTimeMs,
                CpuAverage = AverageReading(_benchmarkSamples, delegate(Reading r) { return r.Cpu; }), CpuPeak = PeakReading(_benchmarkSamples, delegate(Reading r) { return r.Cpu; }),
                GpuAverage = AverageReading(_benchmarkSamples, delegate(Reading r) { return r.Gpu; }), GpuPeak = PeakReading(_benchmarkSamples, delegate(Reading r) { return r.Gpu; }),
                RamAverage = AverageReading(_benchmarkSamples, delegate(Reading r) { return r.Ram; }), RamPeak = PeakReading(_benchmarkSamples, delegate(Reading r) { return r.Ram; })
            };
            _benchmarkRecords.Add(record);
            _benchmarkRecords = _benchmarkRecords.OrderBy(x => x.Utc).TakeLastCompat(40).ToList();
            try { _benchmarkHistory.Save(_benchmarkRecords); _benchmarkStatusLabel.Text = Localizer.T("benchmark.saved"); }
            catch (Exception ex) { FreezerLog.Write("Benchmark save failed", ex); _benchmarkStatusLabel.Text = DescribeSystemError(ex); }
            RenderLatestBenchmarkResult(); PopulateBenchmarkPickers(); UpdateBenchmarkDiagnosis(); UpdateSampleTimer();
        }

        private void CancelBenchmark(string message)
        {
            if (!_benchmarkRunning) return;
            _benchmarkRunning = false; _fps.Stop(); _fpsPinnedProcessId = -1; _fpsAutoCapture = true; _benchmarkSamples.Clear();
            if (_benchmarkStatusLabel != null && !_benchmarkStatusLabel.IsDisposed) _benchmarkStatusLabel.Text = message;
            if (_benchmarkStartButton != null && !_benchmarkStartButton.IsDisposed) _benchmarkStartButton.Enabled = true;
            if (_benchmarkStopButton != null && !_benchmarkStopButton.IsDisposed) _benchmarkStopButton.Enabled = false;
        }

        private static Reading CloneReading(Reading r)
        {
            return new Reading { Cpu = r.Cpu, Gpu = r.Gpu, Ram = r.Ram, RamUsedMb = r.RamUsedMb, RamTotalMb = r.RamTotalMb, AppMb = r.AppMb, Cores = r.Cores, CoreUsage = r.CoreUsage == null ? new double[0] : (double[])r.CoreUsage.Clone() };
        }

        private static double AverageReading(IEnumerable<Reading> rows, Func<Reading, double> value)
        {
            double[] samples = rows.Select(value).Where(x => x >= 0 && !Double.IsNaN(x) && !Double.IsInfinity(x)).ToArray();
            return samples.Length == 0 ? -1 : samples.Average();
        }

        private static double PeakReading(IEnumerable<Reading> rows, Func<Reading, double> value)
        {
            double[] samples = rows.Select(value).Where(x => x >= 0 && !Double.IsNaN(x) && !Double.IsInfinity(x)).ToArray();
            return samples.Length == 0 ? -1 : samples.Max();
        }

        private void RenderLatestBenchmarkResult()
        {
            if (_benchmarkResultsLabel == null || _benchmarkResultsLabel.IsDisposed) return;
            if (_benchmarkRecords.Count == 0) { _benchmarkResultsLabel.Text = Localizer.T("benchmark.noResults"); if (_benchmarkDiagnosisLabel != null) _benchmarkDiagnosisLabel.Text = Localizer.T("benchmark.diagnosisUnknown"); return; }
            BenchmarkRecord r = _benchmarkRecords.OrderBy(x => x.Utc).Last();
            _benchmarkResultsLabel.Text = r.Game + " · " + r.Profile + " · " + r.DurationSeconds + " s\r\n" +
                Localizer.T("benchmark.avgFps") + ": " + Format(r.AverageFps) + "   " + Localizer.T("benchmark.oneLow") + ": " + Format(r.OnePercentLow) + "   " + Localizer.T("benchmark.pointOneLow") + ": " + Format(r.PointOnePercentLow) + "\r\n" +
                Localizer.T("benchmark.frameTime") + ": " + Format(r.AverageFrameTimeMs) + " / " + Format(r.P95FrameTimeMs) + " ms   " + Localizer.T("benchmark.frameCount") + ": " + r.Frames + "\r\n" +
                Localizer.T("benchmark.resources") + ": " + Format(r.CpuAverage) + "% / " + Format(r.GpuAverage) + "% / " + Format(r.RamAverage) + "%";
        }

        private void PopulateBenchmarkPickers()
        {
            if (_benchmarkBaselinePicker == null || _benchmarkBaselinePicker.IsDisposed || _benchmarkComparePicker == null || _benchmarkComparePicker.IsDisposed) return;
            _benchmarkBaselinePicker.Items.Clear(); _benchmarkComparePicker.Items.Clear();
            List<BenchmarkRecord> ordered = _benchmarkRecords.OrderBy(x => x.Utc).ToList();
            for (int i = 0; i < ordered.Count; i++) { _benchmarkBaselinePicker.Items.Add(new BenchmarkRunChoice { Index = i, Record = ordered[i] }); _benchmarkComparePicker.Items.Add(new BenchmarkRunChoice { Index = i, Record = ordered[i] }); }
            if (ordered.Count > 0) { _benchmarkBaselinePicker.SelectedIndex = Math.Max(0, ordered.Count - 2); _benchmarkComparePicker.SelectedIndex = ordered.Count - 1; }
        }

        private void ShowBenchmarkComparison()
        {
            BenchmarkRunChoice baseline = _benchmarkBaselinePicker == null ? null : _benchmarkBaselinePicker.SelectedItem as BenchmarkRunChoice;
            BenchmarkRunChoice current = _benchmarkComparePicker == null ? null : _benchmarkComparePicker.SelectedItem as BenchmarkRunChoice;
            Label label = _content.Controls.Cast<Control>().OfType<RoundPanel>().SelectMany(x => x.Controls.Cast<Control>()).OfType<Label>().FirstOrDefault(x => x.Name == "benchmarkComparison");
            if (label == null) return;
            if (baseline == null || current == null) { label.Text = Localizer.T("benchmark.noResults"); return; }
            BenchmarkRecord a = baseline.Record, b = current.Record;
            string deltaFps = DeltaText(a.AverageFps, b.AverageFps), deltaLow = DeltaText(a.OnePercentLow, b.OnePercentLow);
            label.Text = String.Format(CultureInfo.CurrentCulture, Localizer.T("benchmark.comparison"), Format(a.AverageFps), Format(b.AverageFps), deltaFps, Format(a.OnePercentLow), Format(b.OnePercentLow), deltaLow, Format(a.P95FrameTimeMs), Format(b.P95FrameTimeMs)) +
                (String.Equals(a.Game, b.Game, StringComparison.OrdinalIgnoreCase) ? "" : "\r\n" + Localizer.T("benchmark.incomparableGames"));
        }

        private static string DeltaText(double before, double after)
        {
            if (before <= 0 || after < 0) return "—";
            double change = (after - before) * 100.0 / before;
            return (change > 0 ? "+" : "") + change.ToString("0.0", CultureInfo.CurrentCulture) + "%";
        }

        private void ExportSelectedBenchmarkCsv()
        {
            BenchmarkRunChoice choice = _benchmarkComparePicker == null ? null : _benchmarkComparePicker.SelectedItem as BenchmarkRunChoice;
            if (choice == null) { SetStatus(Localizer.T("benchmark.noResults")); return; }
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "CSV-Datei (*.csv)|*.csv"; dialog.FileName = "Freezer-Messlauf-" + choice.Record.Utc.ToString("yyyyMMdd-HHmm", CultureInfo.InvariantCulture) + ".csv";
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                BenchmarkRecord r = choice.Record;
                string[] lines = { "DateUtc,Game,Profile,DurationSeconds,Frames,AverageFps,MinimumFps,OnePercentLow,PointOnePercentLow,AverageFrameTimeMs,P95FrameTimeMs,CpuAverage,CpuPeak,GpuAverage,GpuPeak,RamAverage,RamPeak",
                    String.Join(",", new[] { Csv(r.Utc.ToUniversalTime().ToString("o", CultureInfo.InvariantCulture)), Csv(r.Game), Csv(r.Profile), r.DurationSeconds.ToString(CultureInfo.InvariantCulture), r.Frames.ToString(CultureInfo.InvariantCulture), NumberCsv(r.AverageFps), NumberCsv(r.MinimumFps), NumberCsv(r.OnePercentLow), NumberCsv(r.PointOnePercentLow), NumberCsv(r.AverageFrameTimeMs), NumberCsv(r.P95FrameTimeMs), NumberCsv(r.CpuAverage), NumberCsv(r.CpuPeak), NumberCsv(r.GpuAverage), NumberCsv(r.GpuPeak), NumberCsv(r.RamAverage), NumberCsv(r.RamPeak) }) };
                try { File.WriteAllLines(dialog.FileName, lines, new UTF8Encoding(true)); SetStatus(Localizer.T("benchmark.csvSaved")); }
                catch (Exception ex) { FreezerLog.Write("Benchmark CSV export failed", ex); ThemedDialog.Show(this, Localizer.T("error.action"), DescribeSystemError(ex), false); }
            }
        }

        private static string Csv(string value) { return "\"" + (value ?? String.Empty).Replace("\"", "\"\"") + "\""; }
        private static string NumberCsv(double value) { return value < 0 ? "" : value.ToString("0.###", CultureInfo.InvariantCulture); }

        private void UpdateBenchmarkDiagnosis()
        {
            if (_benchmarkDiagnosisLabel == null || _benchmarkDiagnosisLabel.IsDisposed) return;
            if (_benchmarkSamples.Count < 5 && _benchmarkRecords.Count == 0) { _benchmarkDiagnosisLabel.Text = Localizer.T("benchmark.diagnosisUnknown"); return; }
            BenchmarkRecord previous = _benchmarkRecords.OrderBy(x => x.Utc).LastOrDefault();
            double gpu = _benchmarkSamples.Count >= 5 ? AverageReading(_benchmarkSamples, delegate(Reading r) { return r.Gpu; }) : (previous == null ? -1 : previous.GpuAverage);
            double ram = _benchmarkSamples.Count >= 5 ? PeakReading(_benchmarkSamples, delegate(Reading r) { return r.Ram; }) : (previous == null ? -1 : previous.RamPeak);
            double maxCore = _benchmarkSamples.Count >= 5 ? _benchmarkSamples.SelectMany(x => x.CoreUsage ?? new double[0]).Where(x => x >= 0 && !Double.IsNaN(x)).DefaultIfEmpty(-1).Max() : -1;
            if (gpu < 0 && ram < 0 && maxCore < 0) { _benchmarkDiagnosisLabel.Text = Localizer.T("benchmark.diagnosisUnknown"); return; }
            List<string> hints = new List<string>();
            if (gpu >= 92) hints.Add(String.Format(CultureInfo.CurrentCulture, Localizer.T("benchmark.gpuPressure"), Format(gpu)));
            if (maxCore >= 90 && (gpu < 90 || gpu < 0)) hints.Add(String.Format(CultureInfo.CurrentCulture, Localizer.T("benchmark.cpuPressure"), Format(maxCore)));
            if (ram >= 90) hints.Add(String.Format(CultureInfo.CurrentCulture, Localizer.T("benchmark.ramPressure"), Format(ram)));
            _benchmarkDiagnosisLabel.Text = hints.Count == 0 ? Localizer.T("benchmark.diagnosisClear") : String.Join("\r\n", hints) + "\r\n" + Localizer.T("benchmark.heuristic");
        }

        private void OpenSystemTarget(string target)
        {
            try { Process.Start(new ProcessStartInfo(target) { UseShellExecute = true }); }
            catch (Exception ex) { FreezerLog.Write("Could not open Windows settings target", ex); ThemedDialog.Show(this, Localizer.T("error.action"), DescribeSystemError(ex), false); }
        }

        private void OpenOfficialDriverPage()
        {
            string gpu = _gpuModelName ?? String.Empty;
            string url = gpu.IndexOf("NVIDIA", StringComparison.OrdinalIgnoreCase) >= 0 ? "https://www.nvidia.com/Download/index.aspx" :
                gpu.IndexOf("AMD", StringComparison.OrdinalIgnoreCase) >= 0 || gpu.IndexOf("Radeon", StringComparison.OrdinalIgnoreCase) >= 0 ? "https://www.amd.com/en/support/download/drivers.html" :
                gpu.IndexOf("Intel", StringComparison.OrdinalIgnoreCase) >= 0 ? "https://www.intel.com/content/www/us/en/download-center/home.html" : null;
            if (url == null) { ThemedDialog.Show(this, Localizer.T("benchmark.openDrivers"), Localizer.T("benchmark.noDriverVendor"), false); return; }
            OpenSystemTarget(url);
        }

        private void RefreshPerformanceActivity()
        {
            if (_performanceActivityLabel == null || _performanceActivityLabel.IsDisposed) return;
            _performanceActivityLabel.Text = Localizer.T("benchmark.activityLoading");
            ThreadPool.QueueUserWorkItem(delegate
            {
                string summary = BuildPerformanceActivitySummary();
                try { BeginInvoke((MethodInvoker)delegate { if (_performanceActivityLabel != null && !_performanceActivityLabel.IsDisposed) _performanceActivityLabel.Text = summary; }); }
                catch { }
            });
        }

        private static string BuildPerformanceActivitySummary()
        {
            List<Tuple<string, double>> processes = new List<Tuple<string, double>>();
            foreach (Process process in Process.GetProcesses())
            {
                try { processes.Add(Tuple.Create(process.ProcessName, process.WorkingSet64 / 1048576.0)); }
                catch { }
                finally { try { process.Dispose(); } catch { } }
            }
            string top = String.Join(" · ", processes.OrderByDescending(x => x.Item2).Take(5).Select(x => x.Item1 + " " + x.Item2.ToString("0", CultureInfo.InvariantCulture) + " MB"));
            int entries = 0;
            string[] runKeys = { "Software\\Microsoft\\Windows\\CurrentVersion\\Run", "Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce" };
            foreach (string subKey in runKeys)
            {
                try { using (RegistryKey key = Registry.CurrentUser.OpenSubKey(subKey, false)) if (key != null) entries += key.ValueCount; } catch { }
                try { using (RegistryKey key = Registry.LocalMachine.OpenSubKey(subKey, false)) if (key != null) entries += key.ValueCount; } catch { }
            }
            foreach (Environment.SpecialFolder folder in new[] { Environment.SpecialFolder.Startup, Environment.SpecialFolder.CommonStartup })
            {
                try { string path = Environment.GetFolderPath(folder); if (Directory.Exists(path)) entries += Directory.GetFiles(path).Length; } catch { }
            }
            return String.Format(CultureInfo.CurrentCulture, Localizer.T("benchmark.topProcesses"), String.IsNullOrEmpty(top) ? Localizer.T("monitor.unavailable") : top) + "\r\n" +
                String.Format(CultureInfo.CurrentCulture, Localizer.T("benchmark.startupCount"), entries.ToString(CultureInfo.CurrentCulture));
        }

        private void UpdatePerformanceHardwareSummary()
        {
            if (_performanceHardwareLabel == null || _performanceHardwareLabel.IsDisposed) return;
            string memory = _latest.RamTotalMb > 0 ? (_latest.RamTotalMb / 1024.0).ToString("0.0", CultureInfo.CurrentCulture) + " GB" : Localizer.T("monitor.unavailable");
            _performanceHardwareLabel.Text = "CPU: " + (String.IsNullOrWhiteSpace(_cpuModelName) ? Localizer.T("monitor.unavailable") : _cpuModelName) +
                "\r\nGPU: " + (String.IsNullOrWhiteSpace(_gpuModelName) ? Localizer.T("monitor.unavailable") : _gpuModelName) +
                "\r\nRAM: " + memory + (String.IsNullOrWhiteSpace(_ramTypeName) ? "" : " · " + _ramTypeName) +
                "\r\nWindows: " + Environment.OSVersion.VersionString + "\r\n" + GetMonitorSummary();
        }

        private string BuildDiagnosticsReport()
        {
            List<string> lines = new List<string>();
            lines.Add(Localizer.T("repair.stateFolder") + ": " + _stateRoot);
            bool settingsExists = File.Exists(_settingsFile);
            bool settingsValid = !settingsExists || IsSettingsFileValid();
            lines.Add((settingsExists ? (settingsValid ? Localizer.T("repair.settingsOk") : Localizer.T("repair.settingsBad")) : Localizer.T("repair.settingsMissing")));
            lines.Add((IsPresentMonAvailable() ? Localizer.T("repair.presentmonOk") : Localizer.T("repair.presentmonBad")) + " · " + _presentMonPath);
            int snapshots = _tweaks.ActiveKeys().Count + (File.Exists(Path.Combine(_stateRoot, "cpu-policy.txt")) ? 1 : 0); bool snapshotValid = AreSnapshotsValid();
            lines.Add((snapshotValid ? Localizer.T("repair.snapshotClean") : Localizer.T("repair.snapshotDamaged")) + " · " + snapshots);
            lines.Add(Localizer.T("repair.snapshotCount") + ": " + snapshots);
            lines.Add(Localizer.T("repair.displaySafe"));
            lines.Add(Localizer.T("repair.framework") + ": " + Environment.Version.ToString());
            lines.Add(Localizer.T("metric.logicalCores") + ": " + Environment.ProcessorCount.ToString(CultureInfo.InvariantCulture));
            lines.Add(Localizer.T("diagnostic.ram") + ": " + ReadDiagnosticMemory());
            lines.Add(ReadProcessResourceSummary());
            lines.Add(Localizer.T("diagnostic.acpiTemp") + ": " + ReadAcpiTemperatureSummary());
            lines.Add(Localizer.T("diagnostic.videoDrivers") + ": " + ReadVideoDriverSummary());
            lines.Add(IsAdministrator() ? Localizer.T("diagnostic.elevated") : Localizer.T("diagnostic.admin"));
            lines.Add(Localizer.T("repair.userRights"));
            return String.Join(Environment.NewLine, lines);
        }

        private string BuildShareableDiagnosticsReport()
        {
            bool settingsExists = File.Exists(_settingsFile);
            bool settingsValid = !settingsExists || IsSettingsFileValid();
            List<string> lines = new List<string>();
            lines.Add("Freezer diagnostic summary " + AppVersion);
            lines.Add("Created UTC: " + DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
            lines.Add("Windows: " + Environment.OSVersion.VersionString);
            lines.Add(".NET Framework: " + Environment.Version.ToString());
            lines.Add("Logical processors: " + Environment.ProcessorCount.ToString(CultureInfo.InvariantCulture));
            lines.Add("CPU model: " + (String.IsNullOrWhiteSpace(_cpuModelName) ? "not available" : _cpuModelName));
            lines.Add("GPU model: " + (String.IsNullOrWhiteSpace(_gpuModelName) ? "not available" : _gpuModelName));
            lines.Add("RAM type: " + (String.IsNullOrWhiteSpace(_ramTypeName) ? "not available" : _ramTypeName));
            lines.Add("RAM total MB: " + (_latest.RamTotalMb > 0 ? _latest.RamTotalMb.ToString("0", CultureInfo.InvariantCulture) : "not available"));
            lines.Add("Current sensors CPU/GPU/RAM %: " + Format(_latest.Cpu) + " / " + Format(_latest.Gpu) + " / " + Format(_latest.Ram));
            lines.Add("Displays: " + GetMonitorSummary());
            lines.Add("Settings: " + (settingsExists ? (settingsValid ? "present and valid" : "present; validation failed") : "not created"));
            lines.Add("PresentMon: " + (IsPresentMonAvailable() ? "available" : "not available"));
            lines.Add("Saved restore snapshots: " + _tweaks.ActiveKeys().Count.ToString(CultureInfo.InvariantCulture));
            lines.Add("Privacy: no user name, full file paths, process IDs, serial numbers, or process list included.");
            lines.Add("Logs and settings contents are not included. Freezer does not upload this report.");
            return String.Join(Environment.NewLine, lines);
        }

        private void PreviewAndExportDiagnostics()
        {
            string report = BuildShareableDiagnosticsReport();
            using (Form preview = new Form())
            {
                preview.Text = Localizer.T("diagnostic.previewTitle"); preview.StartPosition = FormStartPosition.CenterParent;
                preview.FormBorderStyle = FormBorderStyle.Sizable; preview.MinimumSize = new Size(620, 440); preview.Size = new Size(760, 560);
                preview.BackColor = Palette.Background; preview.ForeColor = Palette.Text; preview.Font = UiFontCache.Get("Segoe UI", 9F, FontStyle.Regular);
                TableLayoutPanel layout = new TableLayoutPanel(); layout.Dock = DockStyle.Fill; layout.Padding = new Padding(16); layout.ColumnCount = 1; layout.RowCount = 3;
                layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58)); layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
                Label hint = MakeLabel(Localizer.T("diagnostic.previewHint"), 9, Palette.Muted, false); hint.Dock = DockStyle.Fill; hint.AutoEllipsis = false; layout.Controls.Add(hint, 0, 0);
                TextBox content = new TextBox(); content.Dock = DockStyle.Fill; content.Multiline = true; content.ReadOnly = true; content.ScrollBars = ScrollBars.Both; content.WordWrap = false;
                content.BackColor = Palette.Surface; content.ForeColor = Palette.Text; content.BorderStyle = BorderStyle.FixedSingle; content.Font = UiFontCache.Get("Consolas", 9F, FontStyle.Regular); content.Text = report; layout.Controls.Add(content, 0, 1);
                FlowLayoutPanel actions = new FlowLayoutPanel(); actions.Dock = DockStyle.Fill; actions.FlowDirection = FlowDirection.RightToLeft; actions.WrapContents = false; actions.Padding = new Padding(0, 8, 0, 0); actions.BackColor = Color.Transparent;
                Button cancel = MakeButton(Localizer.T("dialog.cancel"), Palette.Surface2, 36); cancel.Width = 120; cancel.DialogResult = DialogResult.Cancel;
                Button save = MakeButton(Localizer.T("diagnostic.exportNow"), Palette.Accent, 36); save.Width = 170;
                save.Click += delegate
                {
                    using (SaveFileDialog dialog = new SaveFileDialog())
                    {
                        dialog.Filter = "Textdatei (*.txt)|*.txt"; dialog.FileName = "Freezer-Diagnose-" + DateTime.Now.ToString("yyyyMMdd-HHmm", CultureInfo.InvariantCulture) + ".txt";
                        if (dialog.ShowDialog(preview) != DialogResult.OK) return;
                        try { File.WriteAllText(dialog.FileName, report, new UTF8Encoding(true)); SetStatus(Localizer.T("diagnostic.exported")); preview.DialogResult = DialogResult.OK; preview.Close(); }
                        catch (Exception ex) { FreezerLog.Write("Diagnostic report export failed", ex); ThemedDialog.Show(preview, Localizer.T("error.action"), DescribeSystemError(ex), false); }
                    }
                };
                actions.Controls.Add(cancel); actions.Controls.Add(save); layout.Controls.Add(actions, 0, 2); preview.Controls.Add(layout); preview.CancelButton = cancel;
                preview.ShowDialog(this);
            }
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private sealed class DiagnosticMemoryStatus
        {
            public uint Length = (uint)Marshal.SizeOf(typeof(DiagnosticMemoryStatus));
            public uint MemoryLoad; public ulong TotalPhys; public ulong AvailPhys; public ulong TotalPageFile;
            public ulong AvailPageFile; public ulong TotalVirtual; public ulong AvailVirtual; public ulong AvailExtendedVirtual;
        }
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool GlobalMemoryStatusEx([In, Out] DiagnosticMemoryStatus status);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint GetGuiResources(IntPtr process, uint flags);

        private static string ReadProcessResourceSummary()
        {
            try
            {
                using (Process process = Process.GetCurrentProcess())
                {
                    long managedBytes = GC.GetTotalMemory(false);
                    uint gdi = GetGuiResources(process.Handle, 0);
                    uint user = GetGuiResources(process.Handle, 1);
                    return String.Format(CultureInfo.CurrentCulture, Localizer.T("diagnostic.appResources"),
                        Math.Round(process.WorkingSet64 / 1048576.0),
                        Math.Round(process.PrivateMemorySize64 / 1048576.0),
                        Math.Round(process.VirtualMemorySize64 / 1048576.0),
                        process.HandleCount, gdi, user, Math.Round(managedBytes / 1048576.0));
                }
            }
            catch { return Localizer.T("diagnostic.notAvailable"); }
        }

        private static string ReadDiagnosticMemory()
        {
            try
            {
                DiagnosticMemoryStatus memory = new DiagnosticMemoryStatus();
                if (!GlobalMemoryStatusEx(memory) || memory.TotalPhys == 0) return Localizer.T("diagnostic.notAvailable");
                double total = memory.TotalPhys / 1048576.0, used = (memory.TotalPhys - memory.AvailPhys) / 1048576.0;
                return String.Format(CultureInfo.CurrentCulture, "{0:0} / {1:0} MB ({2}%)", used, total, memory.MemoryLoad);
            }
            catch { return Localizer.T("diagnostic.notAvailable"); }
        }

        private static string ReadAcpiTemperatureSummary()
        {
            List<string> values = new List<string>();
            try
            {
                EnumerationOptions options = new EnumerationOptions(); options.Timeout = TimeSpan.FromSeconds(2);
                using (ManagementObjectSearcher search = new ManagementObjectSearcher(new ManagementScope("root\\WMI"), new ObjectQuery("SELECT CurrentTemperature FROM MSAcpi_ThermalZoneTemperature"), options))
                using (ManagementObjectCollection results = search.Get())
                {
                    int index = 0;
                    foreach (ManagementObject item in results)
                    {
                        using (item)
                        {
                            double raw; if (item["CurrentTemperature"] == null || !Double.TryParse(Convert.ToString(item["CurrentTemperature"], CultureInfo.InvariantCulture), NumberStyles.Float, CultureInfo.InvariantCulture, out raw)) continue;
                            double celsius = raw / 10.0 - 273.15;
                            if (celsius < -20 || celsius > 150) continue;
                            values.Add("T" + (++index).ToString(CultureInfo.InvariantCulture) + " " + celsius.ToString("0.0", CultureInfo.CurrentCulture) + " °C");
                            if (values.Count >= 4) break;
                        }
                    }
                }
            }
            catch { }
            return values.Count == 0 ? Localizer.T("diagnostic.notAvailable") : String.Join(", ", values);
        }

        private static string ReadVideoDriverSummary()
        {
            List<string> values = new List<string>();
            try
            {
                EnumerationOptions options = new EnumerationOptions(); options.Timeout = TimeSpan.FromSeconds(2);
                using (ManagementObjectSearcher search = new ManagementObjectSearcher(new ManagementScope(@"\\.\root\CIMV2"), new ObjectQuery("SELECT Name, DriverVersion, Status FROM Win32_VideoController"), options))
                using (ManagementObjectCollection results = search.Get())
                {
                    foreach (ManagementObject item in results)
                    {
                        using (item)
                        {
                            string name = Convert.ToString(item["Name"], CultureInfo.CurrentCulture);
                            string version = Convert.ToString(item["DriverVersion"], CultureInfo.CurrentCulture);
                            string status = Convert.ToString(item["Status"], CultureInfo.CurrentCulture);
                            if (String.IsNullOrWhiteSpace(name)) continue;
                            values.Add(name.Trim() + (String.IsNullOrWhiteSpace(version) ? "" : " · " + version.Trim()) + (String.IsNullOrWhiteSpace(status) ? "" : " · " + status.Trim()));
                            if (values.Count >= 3) break;
                        }
                    }
                }
            }
            catch { }
            return values.Count == 0 ? Localizer.T("diagnostic.noGpu") : String.Join("\r\n", values);
        }

        private void RenderUpdates()
        {
            AddPageHeading(Localizer.T("updates.title"), Localizer.T("updates.subtitle"));
            RoundPanel card = Card(244);
            Label current = MakeLabel(String.Format(CultureInfo.CurrentCulture, Localizer.T("updates.current"), AppVersion), 11, Palette.Text, true);
            current.Location = new Point(18, 18); current.Size = new Size(card.Width - 36, 25); card.Controls.Add(current);
            Label status = MakeLabel(_remoteUpdateVersion != null ? String.Format(CultureInfo.CurrentCulture, Localizer.T("updates.available"), _remoteUpdateTag) : Localizer.T("updates.manual"), 9, Palette.Muted, false);
            status.Location = new Point(18, 50); status.Size = new Size(card.Width - 36, 48); status.AutoEllipsis = true; status.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; card.Controls.Add(status);
            Label autoLabel = MakeLabel(Localizer.T("updates.autoCheck"), 9, Palette.Text, true); autoLabel.Location = new Point(18, 106); autoLabel.Size = new Size(390, 22); autoLabel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; card.Controls.Add(autoLabel);
            ToggleSwitch autoToggle = new ToggleSwitch(); autoToggle.Location = new Point(410, 101); autoToggle.Checked = _prefs.AutoUpdateCheck; card.Controls.Add(autoToggle);
            autoToggle.CheckedChanged += delegate { _prefs.AutoUpdateCheck = autoToggle.Checked; SavePreferences(); SetStatus(Localizer.T("status.saved")); if (_prefs.AutoUpdateCheck) { QueueLocalUpdateCheck(); QueueRemoteUpdateCheck(); } };
            FlowLayoutPanel actions = new FlowLayoutPanel(); actions.Location = new Point(18, 145); actions.Size = new Size(card.Width - 36, 82); actions.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; actions.FlowDirection = FlowDirection.LeftToRight; actions.WrapContents = true; actions.AutoScroll = false; actions.BackColor = Palette.Surface; card.Controls.Add(actions);
            Button check = MakeButton(Localizer.T("updates.check"), Palette.Accent, 38); check.Width = 164; check.Margin = new Padding(0, 0, 8, 8);
            check.Click += delegate { CheckForUpdates(status, check); }; actions.Controls.Add(check);
            Button releases = MakeButton(Localizer.T("updates.open"), Palette.Surface2, 38); releases.Width = 164; releases.Margin = new Padding(0, 0, 8, 8);
            releases.Click += delegate { OpenReleasesPage(); }; actions.Controls.Add(releases);
            Button scan = MakeButton(Localizer.T("updates.scanLocal"), Palette.Surface2, 38); scan.Width = 174; scan.Margin = new Padding(0, 0, 8, 8);
            scan.Click += delegate { ScanLocalUpdateFiles(); }; actions.Controls.Add(scan);
            Button choose = MakeButton(Localizer.T("updates.chooseFile"), Palette.Surface2, 38); choose.Width = 180; choose.Margin = new Padding(0, 0, 8, 8);
            choose.Click += delegate { ChooseLocalUpdateFile(); }; actions.Controls.Add(choose);
            _content.Controls.Add(card);
            if (_localUpdateCandidate != null)
            {
                RoundPanel local = Card(160);
                string sourcePath = String.IsNullOrWhiteSpace(_localUpdateCandidate.SourcePath) ? _localUpdateCandidate.Path : _localUpdateCandidate.SourcePath;
                Label found = MakeLabel(String.Format(CultureInfo.CurrentCulture, Localizer.T("updates.localDetails"), _localUpdateCandidate.Version, sourcePath), 9, Palette.Text, false);
                found.Location = new Point(15, 9); found.Size = new Size(local.Width - 30, 48); found.AutoEllipsis = true; found.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; local.Controls.Add(found);
                FlowLayoutPanel localActions = new FlowLayoutPanel(); localActions.Location = new Point(18, 68); localActions.Size = new Size(local.Width - 36, 78); localActions.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; localActions.WrapContents = true; localActions.AutoScroll = false; localActions.BackColor = Palette.Surface; local.Controls.Add(localActions);
                Button install = MakeButton(Localizer.T("updates.install"), Palette.Accent, 38); install.Width = 164; install.Margin = new Padding(0, 0, 8, 8); install.Click += delegate { InstallLocalUpdate(); }; localActions.Controls.Add(install);
                Button reveal = MakeButton(Localizer.T("updates.localShow"), Palette.Surface2, 38); reveal.Width = 184; reveal.Margin = new Padding(0, 0, 8, 8);
                reveal.Click += delegate { ShowLocalUpdateInExplorer(); }; localActions.Controls.Add(reveal); _content.Controls.Add(local);
            }
            Label info = MakeLabel(Localizer.T("updates.manual"), 9, Palette.Muted, false); info.Width = card.Width; info.Height = 56; info.Margin = new Padding(1, 12, 0, 5); _content.Controls.Add(info);
        }

        private void ScanLocalUpdateFiles()
        {
            try
            {
                _localUpdateCandidate = FindLocalUpdateCandidate();
                if (_localUpdateCandidate == null) ThemedDialog.Show(this, Localizer.T("updates.title"), Localizer.T("updates.noLocal"), false);
                ShowPage("updates");
            }
            catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("updates.title"), DescribeSystemError(ex), false); }
        }

        private void ChooseLocalUpdateFile()
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = Localizer.T("updates.chooseFile"); dialog.Filter = "Freezer update (*.exe;*.zip)|*.exe;*.zip|Windows executable (*.exe)|*.exe|ZIP package (*.zip)|*.zip|All files (*.*)|*.*";
                dialog.CheckFileExists = true; dialog.Multiselect = false;
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    Version installed; if (!Version.TryParse(AppVersion, out installed)) throw new InvalidDataException();
                    string extension = Path.GetExtension(dialog.FileName);
                    LocalUpdateCandidate candidate = extension.Equals(".zip", StringComparison.OrdinalIgnoreCase)
                        ? ExtractUpdatePackage(dialog.FileName, installed)
                        : CreateUpdateCandidateFromExecutable(dialog.FileName, installed);
                    if (candidate == null) { ThemedDialog.Show(this, Localizer.T("updates.title"), Localizer.T("updates.invalidFile"), false); return; }
                    _localUpdateCandidate = candidate; ShowPage("updates");
                }
                catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("updates.title"), DescribeSystemError(ex), false); }
            }
        }

        private LocalUpdateCandidate CreateUpdateCandidateFromExecutable(string path, Version installed)
        {
            string full = Path.GetFullPath(path); Version version;
            if (String.Equals(full, Path.GetFullPath(Application.ExecutablePath), StringComparison.OrdinalIgnoreCase)
                || !TryGetFreezerVersion(full, out version) || version <= installed) return null;
            return new LocalUpdateCandidate { Path = full, SourcePath = full, Version = version };
        }

        private void ShowLocalUpdateInExplorer()
        {
            try
            {
                if (_localUpdateCandidate == null || !File.Exists(_localUpdateCandidate.Path)) { ThemedDialog.Show(this, Localizer.T("updates.title"), Localizer.T("updates.failed"), false); return; }
                string sourcePath = String.IsNullOrWhiteSpace(_localUpdateCandidate.SourcePath) ? _localUpdateCandidate.Path : _localUpdateCandidate.SourcePath;
                Process.Start(new ProcessStartInfo("explorer.exe", "/select,\"" + sourcePath + "\"") { UseShellExecute = true });
            }
            catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("error.action"), DescribeSystemError(ex), false); }
        }

        private static string FileSha256(string path)
        {
            using (SHA256 hash = SHA256.Create())
            using (FileStream stream = File.OpenRead(path))
                return BitConverter.ToString(hash.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
        }

        private void InstallLocalUpdate()
        {
            LocalUpdateCandidate candidate = _localUpdateCandidate;
            if (candidate == null || !File.Exists(candidate.Path)) { ThemedDialog.Show(this, Localizer.T("updates.title"), Localizer.T("updates.failed"), false); return; }
            Version verifiedVersion;
            if (!TryGetFreezerVersion(candidate.Path, out verifiedVersion) || verifiedVersion != candidate.Version)
            { ThemedDialog.Show(this, Localizer.T("updates.title"), Localizer.T("updates.invalidFile"), false); return; }
            string target = Path.GetFullPath(Application.ExecutablePath), source = Path.GetFullPath(candidate.Path);
            if (String.Equals(target, source, StringComparison.OrdinalIgnoreCase)) { ThemedDialog.Show(this, Localizer.T("updates.title"), Localizer.T("updates.invalidFile"), false); return; }
            string shownSource = String.IsNullOrWhiteSpace(candidate.SourcePath) ? source : candidate.SourcePath;
            string confirm = String.Format(CultureInfo.CurrentCulture, Localizer.T("updates.applyConfirm"), candidate.Version, shownSource);
            if (!ThemedDialog.Confirm(this, Localizer.T("updates.title"), confirm)) return;

            string scriptPath = Path.Combine(Path.GetTempPath(), "Freezer-update-" + Guid.NewGuid().ToString("N") + ".ps1");
            string updateLog = Path.Combine(_stateRoot, "update-install.log");
            string backup = target + "." + AppVersion + ".bak";
            try
            {
                string sha = FileSha256(source);
                StringBuilder script = new StringBuilder();
                script.AppendLine("$ErrorActionPreference = 'Stop'");
                script.AppendLine("$source = " + PowerShellLiteral(source));
                script.AppendLine("$target = " + PowerShellLiteral(target));
                script.AppendLine("$backup = " + PowerShellLiteral(backup));
                script.AppendLine("$log = " + PowerShellLiteral(updateLog));
                script.AppendLine("$expectedVersion = " + PowerShellLiteral(candidate.Version.ToString()));
                script.AppendLine("$expectedHash = " + PowerShellLiteral(sha));
                int waitPid; using (Process current = Process.GetCurrentProcess()) waitPid = current.Id;
                script.AppendLine("$waitPid = " + waitPid.ToString(CultureInfo.InvariantCulture));
                script.AppendLine("$temp = $target + '.update.tmp'");
                script.AppendLine("$targetWasBackedUp = $false");
                script.AppendLine("try {");
                script.AppendLine("  for ($i = 0; $i -lt 120; $i++) { $p = Get-Process -Id $waitPid -ErrorAction SilentlyContinue; if (-not $p) { break }; Start-Sleep -Milliseconds 250 }");
                script.AppendLine("  if (Get-Process -Id $waitPid -ErrorAction SilentlyContinue) { throw 'Freezer did not close in time.' }");
                script.AppendLine("  $sourceAssembly = [Reflection.Assembly]::ReflectionOnlyLoadFrom($source)");
                script.AppendLine("  $sourceProduct = $sourceAssembly.GetCustomAttributesData() | Where-Object { $_.AttributeType.FullName -eq 'System.Reflection.AssemblyProductAttribute' } | Select-Object -First 1");
                script.AppendLine("  $sourceVersion = [Reflection.AssemblyName]::GetAssemblyName($source).Version");
                script.AppendLine("  $sourceVersionText = '{0}.{1}.{2}' -f $sourceVersion.Major, $sourceVersion.Minor, $sourceVersion.Build");
                script.AppendLine("  if (-not $sourceProduct -or $sourceProduct.ConstructorArguments.Count -eq 0 -or [string]$sourceProduct.ConstructorArguments[0].Value -ne 'Freezer' -or $sourceVersionText -ne $expectedVersion) { throw 'The selected file is not the expected Freezer build.' }");
                script.AppendLine("  if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash) { throw 'The selected update file changed after confirmation.' }");
                script.AppendLine("  Copy-Item -LiteralPath $source -Destination $temp -Force");
                script.AppendLine("  if ((Get-FileHash -LiteralPath $temp -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash) { throw 'The staged update file did not verify.' }");
                script.AppendLine("  Copy-Item -LiteralPath $target -Destination $backup -Force");
                script.AppendLine("  $targetWasBackedUp = $true");
                script.AppendLine("  Copy-Item -LiteralPath $temp -Destination $target -Force");
                script.AppendLine("  if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash) { throw 'The installed file did not verify.' }");
                script.AppendLine("  Start-Process -FilePath $target");
                script.AppendLine("  Add-Content -LiteralPath $log -Value ('Installed ' + $expectedVersion + ' at ' + (Get-Date -Format o))");
                script.AppendLine("} catch {");
                script.AppendLine("  if ($targetWasBackedUp -and (Test-Path -LiteralPath $backup)) { try { Copy-Item -LiteralPath $backup -Destination $target -Force } catch {} }");
                script.AppendLine("  Add-Content -LiteralPath $log -Value ('Update failed at ' + (Get-Date -Format o) + ': ' + $_.Exception.Message)");
                script.AppendLine("  if (Test-Path -LiteralPath $source) { try { Start-Process -FilePath $source } catch {} }");
                script.AppendLine("} finally { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue; Remove-Item -LiteralPath $MyInvocation.MyCommand.Path -Force -ErrorAction SilentlyContinue }");
                File.WriteAllText(scriptPath, script.ToString(), new UTF8Encoding(true));
                string powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell\\v1.0\\powershell.exe");
                ProcessStartInfo start = new ProcessStartInfo();
                start.FileName = powershell; start.Arguments = "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File \"" + scriptPath.Replace("\"", "\\\"") + "\"";
                start.UseShellExecute = false; start.CreateNoWindow = true; start.WindowStyle = ProcessWindowStyle.Hidden;
                Process.Start(start);
                _exitRequested = true; Close();
            }
            catch (Exception ex)
            {
                try { if (File.Exists(scriptPath)) File.Delete(scriptPath); } catch { }
                ThemedDialog.Show(this, Localizer.T("updates.title"), Localizer.T("updates.installFailed") + "\r\n\r\n" + DescribeSystemError(ex), false);
            }
        }

        private void CheckForUpdates(Label status, Button check)
        {
            if (_updateClient != null)
            {
                try { _updateClient.CancelAsync(); _updateClient.Dispose(); } catch { }
                _updateClient = null;
            }
            WebClient client = new WebClient();
            _updateClient = client;
            try { ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; } catch { }
            client.Headers[HttpRequestHeader.UserAgent] = "Freezer-PC-Optimizer/" + AppVersion;
            client.Headers[HttpRequestHeader.Accept] = "application/vnd.github+json";
            status.Text = Localizer.T("updates.checking"); check.Enabled = false;
            client.DownloadStringCompleted += delegate(object sender, DownloadStringCompletedEventArgs e)
            {
                try
                {
                    if (!Object.ReferenceEquals(_updateClient, client)) { client.Dispose(); return; }
                    _updateClient = null; client.Dispose();
                    if (IsDisposed || Disposing || status.IsDisposed || check.IsDisposed) return;
                    BeginInvoke((MethodInvoker)delegate
                    {
                        if (status.IsDisposed || check.IsDisposed) return;
                        check.Enabled = true;
                        if (e.Cancelled || e.Error != null) { status.Text = Localizer.T("updates.failed"); return; }
                        Match tagMatch = Regex.Match(e.Result ?? "", "\"tag_name\"\\s*:\\s*\"([^\"]+)\"");
                        if (!tagMatch.Success) { status.Text = Localizer.T("updates.noRelease"); return; }
                        string tag = tagMatch.Groups[1].Value;
                        string digits = Regex.Match(tag, "\\d+(?:\\.\\d+){1,3}").Value;
                        Version remote, installed;
                        if (!Version.TryParse(digits, out remote) || !Version.TryParse(AppVersion, out installed)) { status.Text = Localizer.T("updates.noRelease"); return; }
                        if (remote > installed) { _remoteUpdateTag = tag; _remoteUpdateVersion = remote; }
                        else { _remoteUpdateTag = ""; _remoteUpdateVersion = null; }
                        status.Text = remote > installed
                            ? String.Format(CultureInfo.CurrentCulture, Localizer.T("updates.available"), tag)
                            : String.Format(CultureInfo.CurrentCulture, Localizer.T("updates.latest"), tag);
                    });
                }
                catch { try { if (!status.IsDisposed) status.Text = Localizer.T("updates.failed"); if (!check.IsDisposed) check.Enabled = true; } catch { } }
            };
            try { client.DownloadStringAsync(new Uri(GitHubLatestReleaseApi)); }
            catch { check.Enabled = true; status.Text = Localizer.T("updates.failed"); _updateClient = null; client.Dispose(); }
        }

        private void OpenReleasesPage()
        {
            try { Process.Start(new ProcessStartInfo(GitHubReleasesUrl) { UseShellExecute = true }); }
            catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("error.action"), DescribeSystemError(ex), false); }
        }

        private bool IsSettingsFileValid()
        {
            try
            {
                foreach (string line in File.ReadAllLines(_settingsFile, Encoding.UTF8))
                {
                    if (String.IsNullOrWhiteSpace(line)) continue;
                    int split = line.IndexOf('='); if (split <= 0) return false;
                    string key = line.Substring(0, split), value = line.Substring(split + 1);
                    if (key == "language" && !Localizer.Languages.ContainsKey(value)) return false;
                    if (key == "accent" && !Palette.Accents.ContainsKey(value)) return false;
                    if (key == "reduceMotion" && value != "0" && value != "1") return false;
                    if (key == "animation" && !new[] { "fast", "slow", "off" }.Contains(value)) return false;
                    if (key == "overlaySize" && !new[] { "compact", "standard", "large" }.Contains(value)) return false;
                    if (key == "overlayOpacity") { int opacity; if (!Int32.TryParse(value, out opacity) || opacity < 70 || opacity > 100) return false; }
                    if ((key == "restorePointNoticeShown" || key == "crosshairEnabled" || key == "overlayShowCpu" || key == "overlayShowGpu" || key == "overlayShowRam" || key == "overlayShowFps" || key == "minimizeToTray" || key == "autoUpdateCheck" || key == "fortniteBackground") && value != "0" && value != "1") return false;
                    if (key == "crosshairColor" && !new[] { "white", "lime", "cyan", "yellow", "red", "magenta", "orange", "purple", "pink", "blue" }.Contains(value)) return false;
                    if (key == "crosshairSize") { int n; if (!Int32.TryParse(value, out n) || n < 8 || n > 48) return false; }
                    if (key == "crosshairGap") { int n; if (!Int32.TryParse(value, out n) || n < 0 || n > 16) return false; }
                    if (key == "crosshairThickness") { int n; if (!Int32.TryParse(value, out n) || n < 1 || n > 5) return false; }
                    if (key == "networkQosPolicyName" && value.Length > 0 && !Regex.IsMatch(value, "^FreezerGameQoS_[A-Fa-f0-9]{8}$")) return false;
                    if (key == "crosshairShape" && !new[] { "plus", "x", "circle", "dot", "square", "diamond", "t", "brackets", "cross", "circleCross", "chevron", "star", "custom" }.Contains(value)) return false;
                    if (key == "selectedGame" && !value.StartsWith("game.", StringComparison.Ordinal)) return false;
                    if (key.StartsWith("stretchOriginal.", StringComparison.Ordinal))
                    {
                        string displayName = key.Substring("stretchOriginal.".Length);
                        string dimensions = displayName.StartsWith(@"\\.\DISPLAY", StringComparison.OrdinalIgnoreCase) ? displayName.Substring(11) : "";
                        int displayIndex;
                        if (!Int32.TryParse(dimensions, NumberStyles.None, CultureInfo.InvariantCulture, out displayIndex) || displayIndex < 1 || !Regex.IsMatch(value, "^\\d{3,5}x\\d{3,5}x\\d{1,4}$")) return false;
                    }
                    if (key.StartsWith("game.", StringComparison.Ordinal) && !new[] { "Lite", "Balanced", "Power", "MaxFPS", "Streamer" }.Contains(value)) return false;
                    if (key.StartsWith("gameStretch.", StringComparison.Ordinal))
                    {
                        string decoded; string display; int width, height;
                        if (key.Length <= "gameStretch.".Length || !TryDecodeSessionToken(value, out decoded) || !TryParseGameStretchProfile(decoded, out display, out width, out height)) return false;
                    }
                    if (key.StartsWith("gameLaunch.", StringComparison.Ordinal) && (key.Length <= "gameLaunch.".Length || String.IsNullOrWhiteSpace(value))) return false;
                    bool known = key == "language" || key == "accent" || key == "reduceMotion" || key == "animation" || key == "overlaySize" || key == "overlayOpacity" || key == "overlayShowCpu" || key == "overlayShowGpu" || key == "overlayShowRam" || key == "overlayShowFps" || key == "restorePointNoticeShown" || key == "minimizeToTray" || key == "autoUpdateCheck" || key == "crosshairEnabled" || key == "crosshairScreen" || key == "crosshairShape" || key == "crosshairColor" || key == "crosshairSize" || key == "crosshairGap" || key == "crosshairThickness" || key == "selectedGame" || key == "fortniteBackground" || key == "nvidiaDisplay" || key == "amdDisplay" || key == "activeNvidiaColorGame" || key == "activeAmdColorGame" || key == "activeNvidiaColorProfile" || key == "activeAmdColorProfile" || key == "networkQosPolicyName" || key == "networkQosApp" || key.StartsWith("stretchOriginal.", StringComparison.Ordinal) || key.StartsWith("game.", StringComparison.Ordinal) || key.StartsWith("gameLaunch.", StringComparison.Ordinal) || key.StartsWith("gameStretch.", StringComparison.Ordinal) || key.StartsWith("nvidiaGame.", StringComparison.Ordinal) || key.StartsWith("amdGame.", StringComparison.Ordinal) || key.StartsWith("nvidiaColor.", StringComparison.Ordinal) || key.StartsWith("nvidiaColorExtra.", StringComparison.Ordinal) || key.StartsWith("amdColor.", StringComparison.Ordinal) || key.StartsWith("amdColorExtra.", StringComparison.Ordinal);
                    if (!known) return false;
                }
                return true;
            }
            catch { return false; }
        }

        private bool AreSnapshotsValid()
        {
            try
            {
                string directory = Path.Combine(_stateRoot, "snapshots"); if (!Directory.Exists(directory)) return true;
                foreach (string file in Directory.GetFiles(directory, "*.xml"))
                {
                    XDocument doc = XDocument.Load(file); if (doc.Root == null || doc.Root.Name != "Snapshot") return false;
                    foreach (XElement entry in doc.Root.Elements("Entry"))
                    {
                        if (entry.Attribute("path") == null || entry.Attribute("name") == null || entry.Attribute("exists") == null || entry.Attribute("oldKind") == null || entry.Attribute("old") == null || entry.Attribute("new") == null) return false;
                        int oldKind, newValue; bool existed;
                        if (!Int32.TryParse(Convert.ToString(entry.Attribute("oldKind")), out oldKind) || !Int32.TryParse(Convert.ToString(entry.Attribute("new")), out newValue) || !Boolean.TryParse(Convert.ToString(entry.Attribute("exists")), out existed)) return false;
                    }
                }
                string cpuBackup = Path.Combine(_stateRoot, "cpu-policy.txt");
                if (File.Exists(cpuBackup))
                {
                    string[] lines = File.ReadAllLines(cpuBackup); int value;
                    if (lines.Length < 2 || !Regex.IsMatch(lines[0], "^[0-9a-f-]{36}$", RegexOptions.IgnoreCase) || !Int32.TryParse(lines[1], out value)) return false;
                }
                return true;
            }
            catch { return false; }
        }

        private bool IsPresentMonAvailable()
        {
            try { using (Stream resource = Assembly.GetExecutingAssembly().GetManifestResourceStream("PresentMon.exe")) return resource != null && PresentMonMatchesResource(_presentMonPath, resource); }
            catch { return false; }
        }

        private string AutoRepair()
        {
            List<string> results = new List<string>();
            try
            {
                Directory.CreateDirectory(_stateRoot); Directory.CreateDirectory(Path.Combine(_stateRoot, "snapshots"));
                if (File.Exists(_settingsFile) && !IsSettingsFileValid())
                {
                    string backup = _settingsFile + ".damaged-" + DateTime.Now.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture);
                    File.Copy(_settingsFile, backup, false); File.Delete(_settingsFile);
                    _prefs.Language = Localizer.Languages.ContainsKey(_prefs.Language) ? _prefs.Language : "de";
                    _prefs.Accent = Palette.Accents.ContainsKey(_prefs.Accent) ? _prefs.Accent : "orange";
                    _prefs.ReduceMotion = false; _prefs.Motion = "fast"; _prefs.GameProfiles.Clear(); _prefs.OverlaySize = "standard"; _prefs.OverlayOpacity = 90;
                    _prefs.Save(_settingsFile);
                    if (!IsSettingsFileValid()) throw new IOException(Localizer.T("repair.settingsBad"));
                    results.Add(Localizer.T("repair.backupMade") + " " + backup);
                }
                if (!IsPresentMonAvailable())
                {
                    ExtractPresentMon();
                    results.Add(IsPresentMonAvailable() ? Localizer.T("repair.presentmonOk") : Localizer.T("repair.presentmonMissing"));
                }
                if (!AreSnapshotsValid()) results.Add(Localizer.T("repair.snapshotDamaged"));
                if (results.Count == 0) results.Add(Localizer.T("repair.noChanges"));
                SetStatus(Localizer.T("repair.complete"));
                return Localizer.T("repair.repaired") + "\r\n" + String.Join("\r\n", results);
            }
            catch (Exception ex) { return Localizer.T("error.action") + ":\r\n" + DescribeSystemError(ex); }
        }

        private static bool IsAdministrator()
        {
            try
            {
                System.Security.Principal.WindowsIdentity identity = System.Security.Principal.WindowsIdentity.GetCurrent();
                return new System.Security.Principal.WindowsPrincipal(identity).IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
            }
            catch { return false; }
        }

        private static string DescribeSystemError(Exception ex)
        {
            if (ex is UnauthorizedAccessException) return Localizer.T("error.adminHint") + "\r\n\r\n" + ex.Message;
            System.ComponentModel.Win32Exception win32 = ex as System.ComponentModel.Win32Exception;
            if (win32 != null && win32.NativeErrorCode == 5) return Localizer.T("error.adminHint") + "\r\n\r\n" + ex.Message;
            return Localizer.T("error.operation") + "\r\n" + ex.Message;
        }

        private void RestoreAll()
        {
            List<string> results = new List<string>();
            _streamerModeActive = false; _streamerEnabledGameMode = false;
            if (File.Exists(MouseAccelerationBackupPath)) try { results.Add(Localizer.OptimizationText("mouse_accel", false, "Mouse acceleration") + ": " + RestoreMouseAcceleration()); } catch (Exception ex) { results.Add(Localizer.OptimizationText("mouse_accel", false, "Mouse acceleration") + ": " + DescribeSystemError(ex)); }
            foreach (string key in _tweaks.ActiveKeys())
            {
                string title = _optimizations.FirstOrDefault(x => x.Key == key) == null ? key : _optimizations.First(x => x.Key == key).Title;
                try { results.Add(title + ": " + _tweaks.Restore(key)); } catch (Exception ex) { results.Add(title + ": " + DescribeSystemError(ex)); }
            }
            if (File.Exists(Path.Combine(_stateRoot, "cpu-policy.txt"))) try { results.Add(_optimizations.First(x => x.Key == "cpu_policy").Title + ": " + RestoreCpuPolicy()); } catch (Exception ex) { results.Add(DescribeSystemError(ex)); }
            QueueGamingSessionBoost();
            ThemedDialog.Show(this, Localizer.T("repair.title"), results.Count == 0 ? Localizer.T("restore.none") : String.Join("\r\n", results), false);
            RefreshGamingModeButton();
            ShowPage("repair");
        }

        private void SampleTick(object sender, EventArgs e)
        {
            if (_closing || _sampleBusy) return; _sampleBusy = true;
            ThreadPool.QueueUserWorkItem(delegate
            {
                Reading r;
                try { if (!_benchmarkRunning) EnsureAutoFpsCapture(); } catch (Exception ex) { FreezerLog.Write("Automatic FPS capture failed", ex); }
                try { r = _sampler.Sample(); _hardwareSampleErrorLogged = false; }
                catch (Exception ex) { if (!_hardwareSampleErrorLogged) FreezerLog.Write("Hardware sensor sample failed", ex); _hardwareSampleErrorLogged = true; r = new Reading(); }
                FrameStats fps = _fps.Get();
                try { BeginInvoke((MethodInvoker)delegate
                {
                    _sampleBusy = false; _latest = r; UpdateReadings(r, fps);
                    if (_benchmarkRunning)
                    {
                        if (_benchmarkSamples.Count < 900) _benchmarkSamples.Add(CloneReading(r));
                        if ((DateTime.UtcNow - _benchmarkStartedUtc).TotalSeconds >= _benchmarkDurationSeconds) FinishBenchmark(true);
                        else UpdateBenchmarkProgress();
                    }
                }); }
                catch { _sampleBusy = false; }
            });
        }

        private void EnsureAutoFpsCapture()
        {
            if (!_fpsAutoCapture) return;
            if (!_presentMonReady) { QueuePresentMonExtraction(); return; }
            ProcessChoice target = null;
            if (_fpsPinnedProcessId > 0)
            {
                try
                {
                    using (Process pinned = Process.GetProcessById(_fpsPinnedProcessId))
                        if (!pinned.HasExited && IsGameProcessName(pinned.ProcessName)) target = new ProcessChoice { Pid = pinned.Id, Name = pinned.ProcessName, DisplayName = Localizer.T(GameKeyForProcess(pinned.ProcessName)) };
                }
                catch { _fpsPinnedProcessId = -1; }
            }
            if (target == null) target = FindRunningGameTarget();
            if (target == null)
            {
                if (_fps.Running) _fps.Stop();
                return;
            }
            if (_fps.Running && _fps.ProcessId == target.Pid) return;
            _fps.Stop();
            _fps.Start(_presentMonPath, target.Pid);
        }

        private ProcessChoice FindRunningGameTarget()
        {
            List<ProcessChoice> choices = new List<ProcessChoice>();
            foreach (Process process in Process.GetProcesses())
            {
                try
                {
                    string name = process.ProcessName;
                    string key = GameKeyForProcess(name);
                    if (IsGameProcessName(name))
                        choices.Add(new ProcessChoice { Pid = process.Id, Name = name, DisplayName = Localizer.T(key) });
                }
                catch { }
                finally { try { process.Dispose(); } catch { } }
            }
            return choices.OrderBy(x => x.Name, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
        }

        private bool IsGameProcessName(string name)
        {
            if (String.IsNullOrWhiteSpace(name)) return false;
            if (GameProcessNames.Any(x => String.Equals(x, name, StringComparison.OrdinalIgnoreCase))) return true;
            return _prefs.GameLaunchPaths.Values.Any(path => String.Equals(Path.GetFileNameWithoutExtension(path), name, StringComparison.OrdinalIgnoreCase));
        }

        private void UpdateReadings(Reading r, FrameStats fps)
        {
            if (IsDisposed) return;
            if (_gauges.ContainsKey("cpu")) _gauges["cpu"].Value = r.Cpu;
            if (_gauges.ContainsKey("gpu")) _gauges["gpu"].Value = r.Gpu;
            if (_gauges.ContainsKey("ram")) _gauges["ram"].Value = r.Ram;
            UpdateHomeHardwareSummary(r);
            UpdatePerformanceHardwareSummary();
            if (_headerFpsLabel != null && !_headerFpsLabel.IsDisposed) _headerFpsLabel.Text = FormatHeaderFps(fps);
            SetValue("fps", Format(fps.Current)); SetValue("fps_detail", Localizer.T("metric.fpsMin") + " " + Format(fps.Minimum) + "   " + Localizer.T("metric.fpsAvg") + " " + Format(fps.Average));
            SetValue("hardware_cpu", Localizer.T("metric.cpu") + " " + Format(r.Cpu) + " % · " + r.Cores + " " + Localizer.T("metric.logicalCores"));
            SetValue("hardware_ram", "RAM " + r.RamUsedMb.ToString("0", CultureInfo.InvariantCulture) + " / " + r.RamTotalMb.ToString("0", CultureInfo.InvariantCulture) + " MB · " + Format(r.Ram) + " %");
            SetValue("hardware_gpu", Localizer.T("metric.gpu") + " " + Format(r.Gpu) + " % · " + (r.Gpu < 0 ? Localizer.T("monitor.unavailable") : Localizer.T("metric.gpuCounters")));
            SetValue("hardware_fps", Localizer.T("metric.fps") + " " + Format(fps.Current) + " · " + Localizer.T("overlay.details") + " " + Format(fps.Minimum) + " · " + Localizer.T("overlay.average") + " " + Format(fps.Average));
            string cores = String.Join("  ·  ", r.CoreUsage.Take(16).Select((value, index) => index + 1 + ": " + Format(value) + "%"));
            if (r.CoreUsage.Length > 16) cores += "  ·  +" + (r.CoreUsage.Length - 16);
            SetValue("hardware_cores", Localizer.T("metric.cores") + " (" + r.Cores + "): " + (String.IsNullOrEmpty(cores) ? "—" : cores));
            if (_overlay != null && !_overlay.IsDisposed) _overlay.UpdateValues(r, fps);
        }
        private void UpdateFpsTick(object sender, EventArgs e)
        {
            if (_closing) return;
            FrameStats fps = _fps.Get();
            SetValue("fps", Format(fps.Current));
            SetValue("fps_detail", Localizer.T("metric.fpsMin") + " " + Format(fps.Minimum) + "   " + Localizer.T("metric.fpsAvg") + " " + Format(fps.Average));
            SetValue("hardware_fps", Localizer.T("metric.fps") + " " + Format(fps.Current) + " · " + Localizer.T("overlay.details") + " " + Format(fps.Minimum) + " · " + Localizer.T("overlay.average") + " " + Format(fps.Average));
            if (_headerFpsLabel != null && !_headerFpsLabel.IsDisposed) _headerFpsLabel.Text = FormatHeaderFps(fps);
            if (_overlay != null && !_overlay.IsDisposed) _overlay.UpdateValues(_latest, fps);
        }
        private string FormatHeaderFps(FrameStats fps)
        {
            return "FPS " + Format(fps.Current) + "  |  MIN " + Format(fps.Minimum) + "  |  AVG " + Format(fps.Average);
        }
        private static string Format(double value) { return value < 0 || Double.IsNaN(value) ? "—" : value.ToString("0", CultureInfo.InvariantCulture); }
        private void SetValue(string key, string value) { if (_valueLabels.ContainsKey(key) && !_valueLabels[key].IsDisposed) _valueLabels[key].Text = value; }
        private void UpdateSampleTimer()
        {
            bool overlayVisible = _overlay != null && !_overlay.IsDisposed && _overlay.Visible;
            bool windowVisible = Visible && WindowState != FormWindowState.Minimized;
            bool needed = (windowVisible && (_page == "home" || _page == "hardware" || _page == "performance")) || overlayVisible;
            if (_benchmarkRunning && !needed) CancelBenchmark(Localizer.T("benchmark.cancelled"));
            if (needed) { _sampleTimer.Start(); _fpsUiTimer.Start(); }
            else { _sampleTimer.Stop(); _fpsUiTimer.Stop(); _fps.Stop(); }
        }

        private void ToggleOverlay()
        {
            if (_overlay != null && !_overlay.IsDisposed) { _overlay.Close(); _overlay = null; }
            else CreateOverlay();
            UpdateSampleTimer();
        }

        private void CreateOverlay()
        {
            OverlayForm created = new OverlayForm(_prefs.OverlaySize, _prefs.OverlayOpacity, _prefs.OverlayShowCpu, _prefs.OverlayShowGpu, _prefs.OverlayShowRam, _prefs.OverlayShowFps);
            _overlay = created;
            created.FormClosed += delegate { if (_overlay == created) _overlay = null; UpdateSampleTimer(); };
            created.Show(this); created.UpdateValues(_latest, _fps.Get());
        }

        private void RefreshOverlayAppearance()
        {
            bool visible = _overlay != null && !_overlay.IsDisposed && _overlay.Visible;
            if (_overlay != null && !_overlay.IsDisposed) { _overlay.Close(); _overlay = null; }
            if (visible) CreateOverlay();
            UpdateSampleTimer();
        }

        private void ApplyPalette()
        {
            BackColor = Palette.Background; _header.BackColor = Palette.Sidebar; _sidebar.BackColor = Palette.Sidebar; _footer.BackColor = Palette.Sidebar; _content.BackColor = Palette.Background;
            ShowPage(_page);
        }
        private void SavePreferences() { try { _prefs.Save(_settingsFile); } catch (Exception ex) { SetStatus(ex.Message); } }
        private void SetStatus(string text) { if (!_closing && !IsDisposed) _status.Text = text; }
        private void OnClosing(object sender, FormClosingEventArgs e)
        {
            if (!_exitRequested && _prefs.MinimizeToTray && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true; WindowState = FormWindowState.Minimized; ShowInTaskbar = false; Hide();
                if (_trayIcon != null) { _trayIcon.Visible = true; try { _trayIcon.ShowBalloonTip(1400, "Freezer", Localizer.T("tray.tooltip"), ToolTipIcon.Info); } catch { } }
                return;
            }
            RestoreGameStretchSession();
            _closing = true; _streamerModeActive = false;
            SystemEvents.DisplaySettingsChanged -= HandleDisplaySettingsChanged;
            if (_streamerEnabledGameMode) { try { _tweaks.Restore("game_mode"); } catch { } _streamerEnabledGameMode = false; }
            _sidebarTimer.Stop(); _sampleTimer.Stop(); _fpsUiTimer.Stop(); _gamingBoostTimer.Stop(); _colorProfileTimer.Stop(); _displayRefreshTimer.Stop();
            RestoreActiveColorProfiles();
            _sidebarTimer.Dispose(); _sampleTimer.Dispose(); _fpsUiTimer.Dispose(); _gamingBoostTimer.Dispose(); _colorProfileTimer.Dispose(); _displayRefreshTimer.Dispose();
            if (_welcomeTimer != null) { _welcomeTimer.Stop(); _welcomeTimer.Dispose(); _welcomeTimer = null; }
            lock (_gamingBoostLock) { RestoreGamePrioritiesLocked(); ReleaseTimerResolutionLocked(); RestoreGamingPowerPlan(); }
            _gameSlideTimer.Stop(); _gameSlideTimer.Dispose(); _fps.Dispose(); _sampler.Dispose();
            if (_updateClient != null) { try { _updateClient.CancelAsync(); _updateClient.Dispose(); } catch { } _updateClient = null; }
            if (_overlay != null && !_overlay.IsDisposed) _overlay.Close();
            if (_crosshair != null && !_crosshair.IsDisposed) _crosshair.Close();
            _prefs.CrosshairEnabled = false; SavePreferences();
            if (_trayIcon != null) { try { _trayIcon.Visible = false; _trayIcon.Dispose(); } catch { } _trayIcon = null; }
        }
    }

    internal sealed class ModernComboBox : ComboBox
    {
        private Control _arrow;
        private Control _arrowParent;
        private LayoutEventHandler _parentLayoutHandler;
        private EventHandler _boundsHandler, _enabledHandler, _visibleHandler;

        public ModernComboBox()
        {
            DrawMode = DrawMode.OwnerDrawFixed; ItemHeight = 26; IntegralHeight = false; DropDownHeight = 240;
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        protected override void OnParentChanged(EventArgs e)
        {
            DetachArrow(); base.OnParentChanged(e); AttachArrow();
        }

        private void AttachArrow()
        {
            if (Parent == null) return;
            _arrowParent = Parent;
            _arrow = new ComboArrowControl(delegate
            {
                try { Focus(); DroppedDown = !DroppedDown; }
                catch (ObjectDisposedException) { }
                catch (InvalidOperationException) { }
            });
            _arrowParent.Controls.Add(_arrow); _arrow.BringToFront();
            _parentLayoutHandler = delegate(object sender, LayoutEventArgs args) { SyncArrow(); };
            _boundsHandler = delegate { SyncArrow(); };
            _enabledHandler = delegate { if (_arrow != null) { _arrow.Enabled = Enabled; _arrow.Invalidate(); } };
            _visibleHandler = delegate { if (_arrow != null) _arrow.Visible = Visible; };
            _arrowParent.Layout += _parentLayoutHandler;
            LocationChanged += _boundsHandler; SizeChanged += _boundsHandler;
            EnabledChanged += _enabledHandler; VisibleChanged += _visibleHandler;
            SyncArrow();
        }

        private void SyncArrow()
        {
            if (_arrow == null || _arrowParent == null || _arrow.IsDisposed) return;
            int width = Math.Min(30, Math.Max(24, Height));
            // Cover the native arrow cell edge-to-edge so its bright Windows theme
            // pixels cannot leak through around the dark custom chevron.
            _arrow.Bounds = new Rectangle(Math.Max(0, Left + Width - width), Top, width, Math.Max(1, Height));
            _arrow.Visible = Visible; _arrow.Enabled = Enabled; _arrow.BringToFront(); _arrow.Invalidate();
        }

        private void DetachArrow()
        {
            if (_arrowParent != null && _parentLayoutHandler != null) _arrowParent.Layout -= _parentLayoutHandler;
            if (_boundsHandler != null) { LocationChanged -= _boundsHandler; SizeChanged -= _boundsHandler; }
            if (_enabledHandler != null) EnabledChanged -= _enabledHandler;
            if (_visibleHandler != null) VisibleChanged -= _visibleHandler;
            if (_arrow != null)
            {
                if (_arrowParent != null) _arrowParent.Controls.Remove(_arrow);
                _arrow.Dispose(); _arrow = null;
            }
            _arrowParent = null; _parentLayoutHandler = null; _boundsHandler = null; _enabledHandler = null; _visibleHandler = null;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) DetachArrow();
            base.Dispose(disposing);
        }

        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            if (e.Index < 0)
            {
                using (SolidBrush background = new SolidBrush(Palette.Surface2)) e.Graphics.FillRectangle(background, e.Bounds);
                Rectangle selectedText = Rectangle.Inflate(e.Bounds, -7, 0); selectedText.Width = Math.Max(0, selectedText.Width - 30);
                if (!String.IsNullOrEmpty(Text)) TextRenderer.DrawText(e.Graphics, Text, Font, selectedText, Enabled ? Palette.Text : Palette.Muted, TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);
                return;
            }
            bool selected = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
            Color backgroundColor = selected ? Color.FromArgb(62, Palette.Accent.R, Palette.Accent.G, Palette.Accent.B) : Palette.Surface2;
            using (SolidBrush background = new SolidBrush(backgroundColor)) e.Graphics.FillRectangle(background, e.Bounds);
            string label = Convert.ToString(Items[e.Index]);
            Color foreground = Enabled ? Palette.Text : Palette.Muted;
            TextRenderer.DrawText(e.Graphics, label, Font, Rectangle.Inflate(e.Bounds, -8, 0), foreground, TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);
            if ((e.State & DrawItemState.Focus) == DrawItemState.Focus) e.DrawFocusRectangle();
        }
    }

    internal sealed class ComboArrowControl : Control
    {
        public ComboArrowControl(Action onClick)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Palette.Surface2; Cursor = Cursors.Hand; TabStop = false;
            if (onClick != null) Click += delegate { onClick(); };
            MouseEnter += delegate { Invalidate(); }; MouseLeave += delegate { Invalidate(); };
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Enabled ? Palette.Surface2 : Palette.Surface);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Color fill = Enabled ? Palette.Surface2 : Palette.Surface;
            if (ClientRectangle.Width <= 0 || ClientRectangle.Height <= 0) return;
            e.Graphics.Clear(fill);
            using (Pen border = new Pen(Palette.Border)) e.Graphics.DrawLine(border, 0, 1, 0, ClientSize.Height - 2);
            int cx = ClientSize.Width / 2, cy = ClientSize.Height / 2;
            Color arrowColor = Enabled ? (ClientRectangle.Contains(PointToClient(Cursor.Position)) ? Palette.Accent : Palette.Text) : Palette.Muted;
            using (Pen arrow = new Pen(arrowColor, 1.8F))
            {
                arrow.StartCap = LineCap.Round; arrow.EndCap = LineCap.Round;
                e.Graphics.DrawLine(arrow, cx - 4, cy - 1, cx, cy + 3);
                e.Graphics.DrawLine(arrow, cx, cy + 3, cx + 4, cy - 1);
            }
        }
    }

    internal sealed class ModernSlider : Control
    {
        private int _minimum, _maximum = 100, _value;
        private bool _dragging;
        public event EventHandler ValueChanged;

        public int Minimum
        {
            get { return _minimum; }
            set { _minimum = value; if (_maximum <= _minimum) _maximum = _minimum + 1; SetValue(_value); Invalidate(); }
        }
        public int Maximum
        {
            get { return _maximum; }
            set { _maximum = Math.Max(_minimum + 1, value); SetValue(_value); Invalidate(); }
        }
        public int Value
        {
            get { return _value; }
            set { SetValue(value); }
        }

        public ModernSlider()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            TabStop = true; Cursor = Cursors.Hand; Height = 30; BackColor = Palette.Surface;
        }

        private void SetValue(int value)
        {
            int clamped = Math.Max(_minimum, Math.Min(_maximum, value));
            if (clamped == _value) { Invalidate(); return; }
            _value = clamped; Invalidate();
            EventHandler changed = ValueChanged; if (changed != null) changed(this, EventArgs.Empty);
        }

        protected override void OnPaintBackground(PaintEventArgs e) { e.Graphics.Clear(BackColor); }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
            int left = 9, right = Math.Max(left + 1, Width - 10), center = Height / 2;
            int thumbRadius = 8;
            float fraction = (_value - _minimum) / (float)Math.Max(1, _maximum - _minimum);
            int thumbX = left + (int)Math.Round((right - left) * fraction);
            Color rail = Enabled ? Palette.Border : Palette.Surface2;
            using (Pen p = new Pen(rail, 5F)) { p.StartCap = LineCap.Round; p.EndCap = LineCap.Round; g.DrawLine(p, left, center, right, center); }
            using (Pen p = new Pen(Enabled ? Palette.Accent : Palette.Muted, 5F)) { p.StartCap = LineCap.Round; p.EndCap = LineCap.Round; g.DrawLine(p, left, center, thumbX, center); }
            for (int i = 0; i <= 10; i++)
            {
                int x = left + (int)Math.Round((right - left) * (i / 10.0));
                using (Pen p = new Pen(i / 10.0 <= fraction ? Palette.Accent : Palette.Border, 1F)) g.DrawLine(p, x, center + 7, x, center + 10);
            }
            Rectangle thumb = new Rectangle(thumbX - thumbRadius, center - thumbRadius, thumbRadius * 2, thumbRadius * 2);
            using (SolidBrush fill = new SolidBrush(Enabled ? Palette.Accent : Palette.Muted)) g.FillEllipse(fill, thumb);
            using (Pen outline = new Pen(BackColor, 2F)) g.DrawEllipse(outline, thumb);
            if (Focused) using (Pen focus = new Pen(Palette.Accent, 1F)) g.DrawEllipse(focus, Rectangle.Inflate(thumb, 3, 3));
        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && Enabled) { Focus(); _dragging = true; SetFromPointer(e.X); }
            base.OnMouseDown(e);
        }
        protected override void OnMouseMove(MouseEventArgs e) { if (_dragging && Enabled) SetFromPointer(e.X); base.OnMouseMove(e); }
        protected override void OnMouseUp(MouseEventArgs e) { _dragging = false; base.OnMouseUp(e); }
        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Down) { SetValue(_value - 1); e.Handled = true; }
            else if (e.KeyCode == Keys.Right || e.KeyCode == Keys.Up) { SetValue(_value + 1); e.Handled = true; }
            else if (e.KeyCode == Keys.PageDown) { SetValue(_value - Math.Max(1, (_maximum - _minimum) / 10)); e.Handled = true; }
            else if (e.KeyCode == Keys.PageUp) { SetValue(_value + Math.Max(1, (_maximum - _minimum) / 10)); e.Handled = true; }
            base.OnKeyDown(e);
        }
        private void SetFromPointer(int x)
        {
            int left = 9, right = Math.Max(left + 1, Width - 10);
            double fraction = Math.Max(0.0, Math.Min(1.0, (x - left) / (double)(right - left)));
            SetValue(_minimum + (int)Math.Round((_maximum - _minimum) * fraction));
        }
    }

    internal sealed class RoundedActionButton : Button
    {
        private bool _hovered, _pressed;
        public RoundedActionButton()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            FlatStyle = FlatStyle.Flat; FlatAppearance.BorderSize = 0; UseVisualStyleBackColor = false;
        }
        protected override void OnMouseEnter(EventArgs e) { _hovered = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hovered = false; _pressed = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { if (e.Button == MouseButtons.Left) _pressed = true; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { _pressed = false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnEnabledChanged(EventArgs e) { Invalidate(); base.OnEnabledChanged(e); }
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Color background = Parent == null ? Palette.Background : Parent.BackColor;
            if (background == Color.Transparent) background = Palette.Background;
            e.Graphics.Clear(background);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Color background = Parent == null ? Palette.Background : Parent.BackColor;
            if (background == Color.Transparent) background = Palette.Background;
            g.Clear(background); g.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle bounds = new Rectangle(0, 0, Math.Max(0, Width - 1), Math.Max(0, Height - 1));
            if (bounds.Width < 2 || bounds.Height < 2) return;
            Color fill = Enabled ? BackColor : Palette.Surface2;
            if (Enabled && _pressed) fill = BlendColor(fill, Color.Black, 0.12);
            else if (Enabled && _hovered && BackColor != Palette.Border) fill = BlendColor(fill, Color.White, 0.045);
            int radius = Math.Min(18, Math.Max(5, Math.Min(bounds.Width, bounds.Height) / 2));
            using (GraphicsPath shape = MakeRounded(bounds, radius))
            using (SolidBrush brush = new SolidBrush(fill)) g.FillPath(brush, shape);
            if (Enabled && BackColor != Palette.Border)
            {
                Rectangle outline = Rectangle.Inflate(bounds, -1, -1);
                using (GraphicsPath shape = MakeRounded(outline, Math.Max(3, radius - 1)))
                using (Pen border = new Pen(Palette.Border, 1F)) g.DrawPath(border, shape);
            }
            TextFormatFlags flags = TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding;
            if (TextAlign == ContentAlignment.MiddleLeft || TextAlign == ContentAlignment.TopLeft || TextAlign == ContentAlignment.BottomLeft) flags |= TextFormatFlags.Left;
            else if (TextAlign == ContentAlignment.MiddleRight || TextAlign == ContentAlignment.TopRight || TextAlign == ContentAlignment.BottomRight) flags |= TextFormatFlags.Right;
            else flags |= TextFormatFlags.HorizontalCenter;
            if (TextAlign == ContentAlignment.TopLeft || TextAlign == ContentAlignment.TopCenter || TextAlign == ContentAlignment.TopRight) flags &= ~TextFormatFlags.VerticalCenter;
            if (TextAlign == ContentAlignment.BottomLeft || TextAlign == ContentAlignment.BottomCenter || TextAlign == ContentAlignment.BottomRight) flags |= TextFormatFlags.Bottom;
            if (Text != null && (Text.IndexOf('\n') >= 0 || Text.IndexOf('\r') >= 0)) { flags &= ~TextFormatFlags.EndEllipsis; flags |= TextFormatFlags.WordBreak; }
            Color textColor = Enabled ? ForeColor : Palette.Muted;
            Rectangle text = Rectangle.Inflate(bounds, -10, -3);
            TextRenderer.DrawText(g, Text, Font, text, textColor, flags);
        }
        private static Color BlendColor(Color from, Color to, double amount)
        {
            return Color.FromArgb((int)(from.R + (to.R - from.R) * amount), (int)(from.G + (to.G - from.G) * amount), (int)(from.B + (to.B - from.B) * amount));
        }
        private static GraphicsPath MakeRounded(Rectangle r, int radius)
        {
            GraphicsPath path = new GraphicsPath(); int d = radius * 2;
            path.AddArc(r.X, r.Y, d, d, 180, 90); path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90); path.AddArc(r.X, r.Bottom - d, d, d, 90, 90); path.CloseFigure(); return path;
        }
    }

    internal sealed class SidebarNavigationButton : Button
    {
        private static readonly Font ExpandedIconFont = UiFontCache.Get("Segoe UI Symbol", 12F, FontStyle.Regular);
        private static readonly Font CollapsedIconFont = UiFontCache.Get("Segoe UI Symbol", 13F, FontStyle.Regular);
        private readonly string _icon;
        private string _caption;
        private double _hover, _hoverTarget, _active, _activeTarget;
        private bool _expanded;

        public bool Expanded
        {
            get { return _expanded; }
            set { if (_expanded == value) return; _expanded = value; Invalidate(); }
        }

        public SidebarNavigationButton(string icon, string caption)
        {
            _icon = icon ?? ""; SetCaption(caption);
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            FlatStyle = FlatStyle.Flat; FlatAppearance.BorderSize = 0; UseVisualStyleBackColor = false;
            BackColor = Palette.Sidebar; ForeColor = Palette.Text; Font = UiFontCache.Get("Segoe UI Semibold", 9F, FontStyle.Bold);
            Cursor = Cursors.Hand; Height = 48; AccessibleRole = AccessibleRole.PushButton;
        }

        public void SetCaption(string caption)
        {
            caption = caption ?? "";
            if (_caption == caption) return;
            _caption = caption; Text = _caption; AccessibleName = _caption; Invalidate();
        }

        public void SetActiveTarget(bool active, bool instant)
        {
            _activeTarget = active ? 1.0 : 0.0;
            if (instant) { _active = _activeTarget; Invalidate(); }
        }

        public void SetHoverTarget(bool hovered, bool instant)
        {
            _hoverTarget = hovered ? 1.0 : 0.0;
            if (instant) { _hover = _hoverTarget; Invalidate(); }
        }

        public void SnapVisuals()
        {
            _hover = _hoverTarget; _active = _activeTarget; Invalidate();
        }

        public bool AdvanceVisual(double step)
        {
            bool changed = MoveToward(ref _hover, _hoverTarget, step) | MoveToward(ref _active, _activeTarget, step);
            if (changed) Invalidate();
            return Math.Abs(_hover - _hoverTarget) > 0.001 || Math.Abs(_active - _activeTarget) > 0.001;
        }

        private static bool MoveToward(ref double value, double target, double step)
        {
            double difference = target - value;
            if (Math.Abs(difference) < 0.001) { value = target; return false; }
            value += Math.Sign(difference) * Math.Min(Math.Abs(difference), step);
            return true;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Palette.Sidebar);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            g.Clear(Palette.Sidebar);
            Rectangle bounds = new Rectangle(3, 2, Math.Max(0, Width - 6), Math.Max(0, Height - 4));
            if (bounds.Width > 0 && bounds.Height > 0)
            {
                Color fill = Blend(Palette.Sidebar, Palette.Accent, 0.20 * _active);
                fill = Blend(fill, Palette.Surface2, (_active > 0.02 ? 0.25 : 0.48) * _hover);
                using (GraphicsPath path = Rounded(bounds, 9))
                using (SolidBrush brush = new SolidBrush(fill)) g.FillPath(brush, path);
                if (_active > 0.01 || _hover > 0.01)
                {
                    Color edge = Blend(Palette.Sidebar, Palette.Border, Math.Max(_active, _hover) * 0.55);
                    using (GraphicsPath path = Rounded(bounds, 9))
                    using (Pen pen = new Pen(edge, 1F)) g.DrawPath(pen, path);
                }
                if (_active > 0.01)
                {
                    Rectangle marker = new Rectangle(7, Math.Max(4, (Height - 22) / 2), 3, 22);
                    using (GraphicsPath path = Rounded(marker, 2))
                    using (SolidBrush brush = new SolidBrush(Blend(Palette.Sidebar, Palette.Accent, _active))) g.FillPath(brush, path);
                }
            }

            if (_expanded)
            {
                Rectangle iconBounds = new Rectangle(14, 0, 30, Height);
                Rectangle textBounds = new Rectangle(49, 0, Math.Max(0, Width - 61), Height);
                TextRenderer.DrawText(g, _icon, ExpandedIconFont, iconBounds, Palette.Text, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                TextRenderer.DrawText(g, _caption, Font, textBounds, Palette.Text, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);
            }
            else
            {
                Rectangle iconBounds = new Rectangle(0, 0, Width, Height);
                TextRenderer.DrawText(g, _icon, CollapsedIconFont, iconBounds, Palette.Text, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            }
        }

        private static Color Blend(Color from, Color to, double amount)
        {
            amount = Math.Max(0.0, Math.Min(1.0, amount));
            return Color.FromArgb(
                (int)Math.Round(from.R + (to.R - from.R) * amount),
                (int)Math.Round(from.G + (to.G - from.G) * amount),
                (int)Math.Round(from.B + (to.B - from.B) * amount));
        }

        private static GraphicsPath Rounded(Rectangle rectangle, int radius)
        {
            int diameter = Math.Min(radius * 2, Math.Min(rectangle.Width, rectangle.Height));
            GraphicsPath path = new GraphicsPath();
            if (diameter <= 1) { path.AddRectangle(rectangle); return path; }
            path.AddArc(rectangle.X, rectangle.Y, diameter, diameter, 180, 90);
            path.AddArc(rectangle.Right - diameter, rectangle.Y, diameter, diameter, 270, 90);
            path.AddArc(rectangle.Right - diameter, rectangle.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(rectangle.X, rectangle.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure(); return path;
        }
    }

    internal sealed class RoundPanel : Panel
    {
        public RoundPanel() { DoubleBuffered = true; ResizeRedraw = true; }
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (GraphicsPath path = Rounded(ClientRectangle, 16))
            using (SolidBrush brush = new SolidBrush(BackColor)) e.Graphics.FillPath(brush, path);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e); e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle r = new Rectangle(0, 0, Math.Max(0, Width - 1), Math.Max(0, Height - 1));
            using (GraphicsPath path = Rounded(r, 16)) using (Pen pen = new Pen(Palette.Border, 1)) e.Graphics.DrawPath(pen, path);
        }
        private static GraphicsPath Rounded(Rectangle r, int radius)
        {
            int d = radius * 2; GraphicsPath p = new GraphicsPath();
            p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90); p.AddArc(r.X, r.Bottom - d, d, d, 90, 90); p.CloseFigure(); return p;
        }
    }

    internal sealed class GameArtworkPanel : Panel
    {
        private readonly Image _artwork;
        private Image _customArtwork;
        private readonly Color _accent;

        public GameArtworkPanel(string gameKey, Color accent)
        {
            _accent = accent;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Palette.Surface2;
            try
            {
                using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("FreezerGameArt." + gameKey))
                {
                    if (stream != null) using (Image decoded = Image.FromStream(stream, true, true)) _artwork = new Bitmap(decoded);
                }
            }
            catch { _artwork = null; }
        }

        public void SetCustomArtwork(string path)
        {
            try
            {
                Image replacement = null;
                using (Image decoded = Image.FromFile(path)) replacement = new Bitmap(decoded);
                if (_customArtwork != null) _customArtwork.Dispose();
                _customArtwork = replacement; Invalidate();
            }
            catch { }
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (SolidBrush fallback = new SolidBrush(Color.FromArgb(54, _accent.R, _accent.G, _accent.B))) e.Graphics.FillRectangle(fallback, ClientRectangle);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias; g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            Rectangle bounds = ClientRectangle;
            Image artwork = _customArtwork ?? _artwork;
            if (artwork != null && bounds.Width > 0 && bounds.Height > 0)
            {
                float scale = Math.Max((float)bounds.Width / artwork.Width, (float)bounds.Height / artwork.Height);
                float sourceWidth = bounds.Width / scale, sourceHeight = bounds.Height / scale;
                float sourceX = Math.Max(0, (artwork.Width - sourceWidth) / 2f), sourceY = Math.Max(0, (artwork.Height - sourceHeight) / 2f);
                using (ImageAttributes dim = AlphaAttributes(0.48f))
                    g.DrawImage(artwork, bounds, sourceX, sourceY, sourceWidth, sourceHeight, GraphicsUnit.Pixel, dim);
            }
            using (SolidBrush tint = new SolidBrush(artwork == null ? Color.FromArgb(150, 5, 9, 15) : Color.FromArgb(112, 5, 9, 15))) g.FillRectangle(tint, bounds);
            if (artwork != null && bounds.Width > 100 && bounds.Height > 16)
            {
                int inset = 4, thumbWidth = Math.Min(66, bounds.Width / 4), thumbHeight = bounds.Height - inset * 2;
                float scale = Math.Min((float)thumbWidth / artwork.Width, (float)thumbHeight / artwork.Height);
                int drawWidth = Math.Max(1, (int)(artwork.Width * scale)), drawHeight = Math.Max(1, (int)(artwork.Height * scale));
                Rectangle thumb = new Rectangle(bounds.Right - inset - drawWidth, inset + (thumbHeight - drawHeight) / 2, drawWidth, drawHeight);
                using (SolidBrush backing = new SolidBrush(Color.FromArgb(38, 0, 0, 0))) g.FillRectangle(backing, new Rectangle(bounds.Right - thumbWidth - inset, inset, thumbWidth, thumbHeight));
                using (ImageAttributes crisp = AlphaAttributes(0.92f)) g.DrawImage(artwork, thumb, 0, 0, artwork.Width, artwork.Height, GraphicsUnit.Pixel, crisp);
                using (Pen border = new Pen(Color.FromArgb(70, 255, 255, 255), 1)) g.DrawRectangle(border, new Rectangle(thumb.X, thumb.Y, Math.Max(0, thumb.Width - 1), Math.Max(0, thumb.Height - 1)));
            }
            using (LinearGradientBrush shade = new LinearGradientBrush(bounds, Color.FromArgb(74, 5, 9, 15), Color.FromArgb(18, 5, 9, 15), LinearGradientMode.Horizontal)) g.FillRectangle(shade, bounds);
        }

        private static ImageAttributes AlphaAttributes(float alpha)
        {
            ColorMatrix matrix = new ColorMatrix(); matrix.Matrix33 = alpha;
            ImageAttributes attributes = new ImageAttributes(); attributes.SetColorMatrix(matrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap); return attributes;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) { if (_customArtwork != null) _customArtwork.Dispose(); if (_artwork != null) _artwork.Dispose(); }
            base.Dispose(disposing);
        }
    }

    internal sealed class ToggleSwitch : Control
    {
        private bool _checked;
        public event EventHandler CheckedChanged;
        public bool Checked
        {
            get { return _checked; }
            set { if (_checked == value) return; _checked = value; Invalidate(); EventHandler h = CheckedChanged; if (h != null) h(this, EventArgs.Empty); }
        }
        public void SetCheckedSilently(bool value) { if (_checked == value) return; _checked = value; Invalidate(); }
        public ToggleSwitch() { SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true); Width = 45; Height = 25; Cursor = Cursors.Hand; }
        protected override void OnMouseClick(MouseEventArgs e) { base.OnMouseClick(e); Checked = !Checked; }
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle track = new Rectangle(1, 3, Width - 3, Height - 7);
            using (GraphicsPath p = Shape(track, 11)) using (SolidBrush b = new SolidBrush(_checked ? Palette.Accent : Palette.Border)) e.Graphics.FillPath(b, p);
            int x = _checked ? Width - Height + 4 : 4;
            using (SolidBrush knob = new SolidBrush(Color.White)) e.Graphics.FillEllipse(knob, x, 5, Height - 11, Height - 11);
        }
        private static GraphicsPath Shape(Rectangle r, int radius)
        {
            GraphicsPath p = new GraphicsPath(); p.AddArc(r.X, r.Y, radius * 2, radius * 2, 90, 180); p.AddArc(r.Right - radius * 2, r.Y, radius * 2, radius * 2, 270, 180); p.CloseFigure(); return p;
        }
    }

    internal sealed class GaugeControl : Control
    {
        public string Caption = "";
        private string _details = "";
        public string Details
        {
            get { return _details; }
            set { _details = value ?? ""; AccessibleDescription = _details; Invalidate(); }
        }
        private double _value = -1;
        public double Value
        {
            get { return _value; }
            set
            {
                if (Double.IsNaN(value) || Double.IsInfinity(value) || value < 0) _value = -1;
                else _value = Math.Max(0, Math.Min(100, value));
                Invalidate();
            }
        }
        public GaugeControl() { DoubleBuffered = true; }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (ClientSize.Width <= 0 || ClientSize.Height <= 0) return;
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle rect = new Rectangle(16, 13, 84, 84);
            try
            {
                using (Pen bg = new Pen(Palette.Surface2, 8)) e.Graphics.DrawArc(bg, rect, -90, 359);
                if (_value >= 0 && !Double.IsNaN(_value) && !Double.IsInfinity(_value))
                {
                    float sweep = (float)(Math.Max(0, Math.Min(100, _value)) * 3.59);
                    // GDI+ can report a zero-length arc as OutOfMemoryException; skip it instead.
                    if (!Single.IsNaN(sweep) && !Single.IsInfinity(sweep) && sweep > 0.5F)
                        using (Pen fg = new Pen(Palette.Accent, 8)) e.Graphics.DrawArc(fg, rect, -90, sweep);
                }
            }
            catch (ArgumentException) { }
            catch (ExternalException) { }
            catch (OutOfMemoryException) { }
            string val = _value < 0 ? "—" : _value.ToString("0", CultureInfo.InvariantCulture) + "%";
            Font valueFont = UiFontCache.Get("Segoe UI Semibold", 13F, FontStyle.Bold);
            using (SolidBrush b = new SolidBrush(Palette.Text))
            { SizeF s = e.Graphics.MeasureString(val, valueFont); e.Graphics.DrawString(val, valueFont, b, rect.X + (rect.Width - s.Width) / 2, rect.Y + 31); }
            Font captionFont = UiFontCache.Get("Segoe UI", 8F, FontStyle.Regular);
            using (SolidBrush b = new SolidBrush(Palette.Muted))
            { SizeF s = e.Graphics.MeasureString(Caption, captionFont); e.Graphics.DrawString(Caption, captionFont, b, Math.Max(0, (Width - s.Width) / 2), 108); }
            if (!String.IsNullOrWhiteSpace(_details))
            {
                Rectangle detailsRect = new Rectangle(4, 128, Math.Max(0, Width - 8), Math.Max(24, Height - 130));
                TextRenderer.DrawText(e.Graphics, _details, UiFontCache.Get("Segoe UI", 7.5F, FontStyle.Regular), detailsRect,
                    Palette.Muted, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);
            }
        }
    }

    internal sealed class CrosshairPreviewControl : Control
    {
        private string _shape = "plus", _color = "lime";
        private string _imagePath = "";
        private Bitmap _image;
        private int _size = 20, _gap = 4, _thickness = 2, _opacity = 100;
        private bool _outline = true, _glow;
        public CrosshairPreviewControl()
        {
            BackColor = Palette.Surface2; SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }
        public void ApplyStyle(string shape, string color, int size, int gap, int thickness, int opacity, bool outline, bool glow, string imagePath)
        {
            _shape = shape ?? "plus"; _color = color ?? "lime"; _size = size; _gap = gap; _thickness = thickness; _opacity = opacity; _outline = outline; _glow = glow;
            string requested = imagePath ?? "";
            if (!String.Equals(requested, _imagePath, StringComparison.OrdinalIgnoreCase) || (_shape == "custom" && _image == null))
            {
                ReloadImage(); _imagePath = requested;
                try { if (_shape == "custom" && File.Exists(_imagePath)) using (Image loaded = Image.FromFile(_imagePath)) _image = new Bitmap(loaded); } catch { if (_image != null) { _image.Dispose(); _image = null; } }
            }
            Invalidate();
        }
        public void ReloadImage() { if (_image != null) { _image.Dispose(); _image = null; } _imagePath = ""; }
        protected override void OnPaintBackground(PaintEventArgs e) { e.Graphics.Clear(BackColor); }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e); Graphics g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle box = ClientRectangle; box.Width--; box.Height--;
            using (GraphicsPath path = RoundedPath(box, 12))
            using (Pen border = new Pen(Palette.Border, 1F)) g.DrawPath(border, path);
            float cx = ClientSize.Width / 2F, cy = ClientSize.Height / 2F;
            if (_shape == "custom" && _image != null)
            {
                int dimension = Math.Max(16, Math.Min(64, Math.Min(ClientSize.Width, ClientSize.Height) - 18));
                Rectangle destination = new Rectangle((ClientSize.Width - dimension) / 2, (ClientSize.Height - dimension) / 2, dimension, dimension);
                using (ImageAttributes attributes = new ImageAttributes())
                {
                    ColorMatrix matrix = new ColorMatrix(); matrix.Matrix33 = Math.Max(0.1F, Math.Min(1F, _opacity / 100F)); attributes.SetColorMatrix(matrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
                    g.DrawImage(_image, destination, 0, 0, _image.Width, _image.Height, GraphicsUnit.Pixel, attributes);
                }
                return;
            }
            float arm = Math.Max(9F, Math.Min(19F, _size * 0.65F)), gap = Math.Max(2F, Math.Min(9F, _gap * 0.55F));
            float weight = Math.Max(1F, Math.Min(5F, _thickness));
            Color baseColor = _color == "white" ? Color.White : _color == "cyan" ? Color.Cyan : _color == "yellow" ? Color.Yellow : _color == "red" ? Color.Red : _color == "magenta" ? Color.Magenta : _color == "orange" ? Color.Orange : _color == "purple" ? Color.MediumPurple : _color == "pink" ? Color.HotPink : _color == "blue" ? Color.DeepSkyBlue : Color.Lime;
            Action<Pen> draw = delegate(Pen pen)
            {
                pen.StartCap = LineCap.Round; pen.EndCap = LineCap.Round;
                if (_shape == "circle") g.DrawEllipse(pen, cx - arm / 2, cy - arm / 2, arm, arm);
                else if (_shape == "dot") using (SolidBrush dot = new SolidBrush(pen.Color)) g.FillEllipse(dot, cx - weight, cy - weight, weight * 2, weight * 2);
                else if (_shape == "x") { g.DrawLine(pen, cx - arm, cy - arm, cx - gap, cy - gap); g.DrawLine(pen, cx + gap, cy + gap, cx + arm, cy + arm); g.DrawLine(pen, cx + arm, cy - arm, cx + gap, cy - gap); g.DrawLine(pen, cx - gap, cy + gap, cx - arm, cy + arm); }
                else { g.DrawLine(pen, cx, cy - arm, cx, cy - gap); g.DrawLine(pen, cx, cy + gap, cx, cy + arm); g.DrawLine(pen, cx - arm, cy, cx - gap, cy); g.DrawLine(pen, cx + gap, cy, cx + arm, cy); }
            };
            if (_glow) using (Pen glow = new Pen(Color.FromArgb(52, baseColor), weight + 8F)) draw(glow);
            if (_outline) using (Pen outline = new Pen(Color.FromArgb(245, 5, 8, 12), weight + 3F)) draw(outline);
            using (Pen main = new Pen(Color.FromArgb(Math.Max(10, Math.Min(255, _opacity * 255 / 100)), baseColor), weight)) draw(main);
        }
        private static GraphicsPath RoundedPath(Rectangle bounds, int radius)
        {
            GraphicsPath path = new GraphicsPath(); int diameter = Math.Max(2, radius * 2);
            path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90); path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
            path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90); path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90); path.CloseFigure(); return path;
        }
        protected override void Dispose(bool disposing) { if (disposing && _image != null) { _image.Dispose(); _image = null; } base.Dispose(disposing); }
    }

    internal sealed class CrosshairForm : Form
    {
        private Rectangle _displayBounds;
        private string _shape, _color;
        private int _size, _gap, _thickness, _opacity = 100;
        private bool _outline = true, _glow;
        private string _imagePath = "";
        private Bitmap _customImage;
        public CrosshairForm(Rectangle bounds, string shape, string color, int size, int gap, int thickness, int opacity, bool outline, bool glow, string imagePath)
        {
            FormBorderStyle = FormBorderStyle.None; ShowInTaskbar = false; TopMost = true; StartPosition = FormStartPosition.Manual;
            BackColor = Color.FromArgb(1, 0, 1); TransparencyKey = BackColor; DoubleBuffered = true;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            ApplyStyle(bounds, shape, color, size, gap, thickness, opacity, outline, glow, imagePath);
        }
        protected override bool ShowWithoutActivation { get { return true; } }
        protected override CreateParams CreateParams
        {
            get { CreateParams cp = base.CreateParams; cp.ExStyle |= 0x00000020 | 0x00000080 | 0x08000000; return cp; }
        }
        public void ApplyStyle(Rectangle bounds, string shape, string color, int size, int gap, int thickness, int opacity, bool outline, bool glow, string imagePath)
        {
            _displayBounds = bounds; if (_displayBounds.Width <= 0 || _displayBounds.Height <= 0) _displayBounds = Screen.PrimaryScreen.Bounds;
            Bounds = _displayBounds; _shape = shape ?? "plus"; _color = color ?? "lime";
            _size = Math.Max(8, Math.Min(48, size)); _gap = Math.Max(0, Math.Min(16, gap)); _thickness = Math.Max(1, Math.Min(5, thickness));
            _opacity = Math.Max(10, Math.Min(100, opacity)); _outline = outline; _glow = glow; Opacity = _opacity / 100.0;
            string requestedPath = imagePath ?? "";
            if (!String.Equals(requestedPath, _imagePath, StringComparison.OrdinalIgnoreCase) || (_shape == "custom" && _customImage == null))
            {
                if (_customImage != null) { _customImage.Dispose(); _customImage = null; }
                _imagePath = requestedPath;
                try { if (_shape == "custom" && File.Exists(_imagePath)) using (Image loaded = Image.FromFile(_imagePath)) _customImage = new Bitmap(loaded); }
                catch { if (_customImage != null) { _customImage.Dispose(); _customImage = null; } }
            }
            Invalidate();
        }
        public void ReloadCustomImage()
        {
            if (_customImage != null) { _customImage.Dispose(); _customImage = null; }
            _imagePath = "";
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e); e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.CompositingQuality = CompositingQuality.HighQuality; e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
            Color color = _color == "white" ? Color.White : _color == "cyan" ? Color.Cyan : _color == "yellow" ? Color.Yellow : _color == "red" ? Color.Red : _color == "magenta" ? Color.Magenta : _color == "orange" ? Color.Orange : _color == "purple" ? Color.MediumPurple : _color == "pink" ? Color.HotPink : _color == "blue" ? Color.DeepSkyBlue : Color.Lime;
            float cx = ClientSize.Width / 2f, cy = ClientSize.Height / 2f;
            if (_shape == "custom" && _customImage != null)
            {
                float dimension = Math.Max(32, Math.Min(256, _size * 4));
                e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                e.Graphics.DrawImage(_customImage, new RectangleF(cx - dimension / 2f, cy - dimension / 2f, dimension, dimension));
                return;
            }
            Action<Pen, SolidBrush> drawShape = delegate(Pen pen, SolidBrush brush)
            {
                pen.StartCap = LineCap.Round; pen.EndCap = LineCap.Round; pen.Alignment = PenAlignment.Center; pen.MiterLimit = 2F;
                if (_shape == "cross")
                {
                    e.Graphics.DrawLine(pen, cx, cy - _size, cx, cy + _size);
                    e.Graphics.DrawLine(pen, cx - _size, cy, cx + _size, cy);
                }
                else if (_shape == "circleCross")
                {
                    float radius = _size / 2f;
                    e.Graphics.DrawEllipse(pen, cx - radius, cy - radius, _size, _size);
                    e.Graphics.DrawLine(pen, cx - _size, cy, cx - radius - _gap, cy);
                    e.Graphics.DrawLine(pen, cx + radius + _gap, cy, cx + _size, cy);
                    e.Graphics.DrawLine(pen, cx, cy - _size, cx, cy - radius - _gap);
                    e.Graphics.DrawLine(pen, cx, cy + radius + _gap, cx, cy + _size);
                }
                else if (_shape == "chevron")
                {
                    float outer = _size, inner = Math.Max(_gap, outer * 0.32f);
                    e.Graphics.DrawLine(pen, cx - outer, cy - inner, cx - inner, cy);
                    e.Graphics.DrawLine(pen, cx - inner, cy, cx - outer, cy + inner);
                    e.Graphics.DrawLine(pen, cx + outer, cy - inner, cx + inner, cy);
                    e.Graphics.DrawLine(pen, cx + inner, cy, cx + outer, cy + inner);
                }
                else if (_shape == "star")
                {
                    float diag = _size * 0.7071f;
                    e.Graphics.DrawLine(pen, cx, cy - _size, cx, cy + _size);
                    e.Graphics.DrawLine(pen, cx - _size, cy, cx + _size, cy);
                    e.Graphics.DrawLine(pen, cx - diag, cy - diag, cx + diag, cy + diag);
                    e.Graphics.DrawLine(pen, cx + diag, cy - diag, cx - diag, cy + diag);
                }
                else if (_shape == "x")
                {
                    float diagGap = _gap * 0.7071f, diagSize = _size * 0.7071f;
                    e.Graphics.DrawLine(pen, cx - diagSize, cy - diagSize, cx - diagGap, cy - diagGap);
                    e.Graphics.DrawLine(pen, cx + diagGap, cy + diagGap, cx + diagSize, cy + diagSize);
                    e.Graphics.DrawLine(pen, cx + diagSize, cy - diagSize, cx + diagGap, cy - diagGap);
                    e.Graphics.DrawLine(pen, cx - diagGap, cy + diagGap, cx - diagSize, cy + diagSize);
                }
                else if (_shape == "circle") e.Graphics.DrawEllipse(pen, cx - _size / 2f, cy - _size / 2f, _size, _size);
                else if (_shape == "dot") e.Graphics.FillEllipse(brush, cx - Math.Max(2, _thickness * 1.5f), cy - Math.Max(2, _thickness * 1.5f), Math.Max(4, _thickness * 3f), Math.Max(4, _thickness * 3f));
                else if (_shape == "square") e.Graphics.DrawRectangle(pen, cx - _size / 2f, cy - _size / 2f, _size, _size);
                else if (_shape == "diamond")
                {
                    PointF[] points = { new PointF(cx, cy - _size / 2f), new PointF(cx + _size / 2f, cy), new PointF(cx, cy + _size / 2f), new PointF(cx - _size / 2f, cy) };
                    e.Graphics.DrawPolygon(pen, points);
                }
                else if (_shape == "t")
                {
                    e.Graphics.DrawLine(pen, cx, cy - _size, cx, cy + _size);
                    e.Graphics.DrawLine(pen, cx - _size, cy - _size, cx + _size, cy - _size);
                }
                else if (_shape == "brackets")
                {
                    float outer = _size / 2f, inner = Math.Max(outer * 0.45f, outer - Math.Max(4, _gap));
                    e.Graphics.DrawLine(pen, cx - outer, cy - outer, cx - inner, cy - outer); e.Graphics.DrawLine(pen, cx - outer, cy - outer, cx - outer, cy - inner);
                    e.Graphics.DrawLine(pen, cx + outer, cy - outer, cx + inner, cy - outer); e.Graphics.DrawLine(pen, cx + outer, cy - outer, cx + outer, cy - inner);
                    e.Graphics.DrawLine(pen, cx - outer, cy + outer, cx - inner, cy + outer); e.Graphics.DrawLine(pen, cx - outer, cy + outer, cx - outer, cy + inner);
                    e.Graphics.DrawLine(pen, cx + outer, cy + outer, cx + inner, cy + outer); e.Graphics.DrawLine(pen, cx + outer, cy + outer, cx + outer, cy + inner);
                }
                else
                {
                    e.Graphics.DrawLine(pen, cx, cy - _size, cx, cy - _gap);
                    e.Graphics.DrawLine(pen, cx, cy + _gap, cx, cy + _size);
                    e.Graphics.DrawLine(pen, cx - _size, cy, cx - _gap, cy);
                    e.Graphics.DrawLine(pen, cx + _gap, cy, cx + _size, cy);
                }
            };
            if (_glow)
            {
                using (Pen glowPen = new Pen(Color.FromArgb(78, color), _thickness + 8F))
                using (SolidBrush glowBrush = new SolidBrush(Color.FromArgb(42, color))) drawShape(glowPen, glowBrush);
            }
            if (_outline)
            {
                using (Pen outlinePen = new Pen(Color.FromArgb(245, 5, 8, 12), _thickness + 3F))
                using (SolidBrush outlineBrush = new SolidBrush(Color.FromArgb(245, 5, 8, 12))) drawShape(outlinePen, outlineBrush);
            }
            using (Pen pen = new Pen(color, _thickness))
            using (SolidBrush brush = new SolidBrush(color)) drawShape(pen, brush);
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing && _customImage != null) { _customImage.Dispose(); _customImage = null; }
            base.Dispose(disposing);
        }
    }

    internal sealed class CustomCrosshairEditorForm : Form
    {
        private readonly CrosshairDrawingCanvas _canvas;
        private readonly string _exportPath;
        private readonly Label _colorPreview;
        private readonly Label _opacityValue;
        private Color _drawingColor = Color.Lime;

        [DllImport("dwmapi.dll", EntryPoint = "DwmSetWindowAttribute")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int valueSize);

        public CustomCrosshairEditorForm(string exportPath, string templatePath)
        {
            _exportPath = exportPath;
            Text = Localizer.T("crosshair.editorTitle"); StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog; MinimizeBox = false; MaximizeBox = false; ShowInTaskbar = false;
            BackColor = Palette.Background; ForeColor = Palette.Text; ClientSize = new Size(820, 680);
            Label title = new Label(); title.Text = Localizer.T("crosshair.editorTitle"); title.Font = UiFontCache.Get("Segoe UI", 15F, FontStyle.Bold); title.ForeColor = Palette.Text; title.Location = new Point(20, 16); title.Size = new Size(780, 30); Controls.Add(title);
            Label hint = new Label(); hint.Text = Localizer.T("crosshair.editorHint"); hint.Font = UiFontCache.Get("Segoe UI", 8.5F, FontStyle.Regular); hint.ForeColor = Palette.Muted; hint.Location = new Point(22, 50); hint.Size = new Size(776, 38); hint.AutoEllipsis = true; Controls.Add(hint);
            _canvas = new CrosshairDrawingCanvas(); _canvas.Location = new Point(22, 100); _canvas.Size = new Size(450, 450); Controls.Add(_canvas);
            if (!String.IsNullOrWhiteSpace(templatePath) && File.Exists(templatePath)) { try { _canvas.LoadTemplate(templatePath, true); } catch { } }

            const int controlX = 500, controlWidth = 280;
            Label colorLabel = MakeEditorLabel(Localizer.T("crosshair.editorColor"), controlX, 105, controlWidth, true); Controls.Add(colorLabel);
            _colorPreview = new Label(); _colorPreview.BackColor = _drawingColor; _colorPreview.BorderStyle = BorderStyle.FixedSingle; _colorPreview.Location = new Point(controlX + 3, 135); _colorPreview.Size = new Size(38, 28); Controls.Add(_colorPreview);
            RoundedActionButton pickColor = MakeEditorButton(Localizer.T("crosshair.editorColor"), Palette.Surface2, 230); pickColor.Location = new Point(controlX + 50, 131); pickColor.Click += delegate
            {
                using (ColorDialog dialog = new ColorDialog()) { dialog.Color = _drawingColor; dialog.FullOpen = true; if (dialog.ShowDialog(this) == DialogResult.OK) { _drawingColor = dialog.Color; _colorPreview.BackColor = _drawingColor; _canvas.DrawingColor = _drawingColor; } }
            }; Controls.Add(pickColor);

            Label widthLabel = MakeEditorLabel(Localizer.T("crosshair.editorWidth"), controlX, 178, controlWidth, true); Controls.Add(widthLabel);
            ComboBox widthPicker = MakeEditorPicker(new object[] { "2", "3", "4", "6", "8", "12" }, controlX + 3, 205, controlWidth - 6); widthPicker.SelectedIndex = 2; Controls.Add(widthPicker);
            widthPicker.SelectedIndexChanged += delegate { int width; if (Int32.TryParse(Convert.ToString(widthPicker.SelectedItem), out width)) _canvas.LineWidth = width; };
            Label opacityLabel = MakeEditorLabel(Localizer.T("crosshair.editorOpacity"), controlX, 245, controlWidth, true); Controls.Add(opacityLabel);
            ModernSlider opacity = new ModernSlider(); opacity.Minimum = 0; opacity.Maximum = 100; opacity.Value = 100; opacity.Location = new Point(controlX, 270); opacity.Size = new Size(236, 30); _opacityValue = MakeEditorLabel("100%", controlX + 238, 274, 42, true); _opacityValue.ForeColor = Palette.Accent; _opacityValue.TextAlign = ContentAlignment.MiddleRight; Controls.Add(opacity); Controls.Add(_opacityValue);
            opacity.ValueChanged += delegate { _canvas.ImageOpacityPercent = opacity.Value; _opacityValue.Text = opacity.Value.ToString(CultureInfo.InvariantCulture) + "%"; };

            Label modeLabel = MakeEditorLabel(Localizer.T("crosshair.editorMode"), controlX, 313, controlWidth, true); Controls.Add(modeLabel);
            ComboBox modePicker = MakeEditorPicker(new object[] { Localizer.T("crosshair.editorFreehand"), Localizer.T("crosshair.editorPixel") }, controlX + 3, 340, controlWidth - 6); modePicker.SelectedIndex = 0; Controls.Add(modePicker);
            modePicker.SelectedIndexChanged += delegate { _canvas.PixelMode = modePicker.SelectedIndex == 1; };

            RoundedActionButton undo = MakeEditorButton(Localizer.T("crosshair.editorUndo"), Palette.Surface2, controlWidth - 6); undo.Location = new Point(controlX + 3, 382); undo.Click += delegate { _canvas.UndoStroke(); }; Controls.Add(undo);
            RoundedActionButton clear = MakeEditorButton(Localizer.T("crosshair.editorClear"), Palette.Surface2, controlWidth - 6); clear.Location = new Point(controlX + 3, 425); clear.Click += delegate { _canvas.Clear(); }; Controls.Add(clear);
            RoundedActionButton image = MakeEditorButton(Localizer.T("crosshair.editorImage"), Palette.Surface2, controlWidth - 6); image.Location = new Point(controlX + 3, 468); image.Click += delegate { ChooseTemplate(); }; Controls.Add(image);
            Label dropHint = new Label(); dropHint.Text = Localizer.T("crosshair.dropHint"); dropHint.Font = UiFontCache.Get("Segoe UI", 8F, FontStyle.Regular); dropHint.ForeColor = Palette.Muted; dropHint.BackColor = Palette.Surface; dropHint.Location = new Point(controlX + 3, 512); dropHint.Size = new Size(controlWidth - 6, 74); dropHint.TextAlign = ContentAlignment.MiddleCenter; Controls.Add(dropHint); ConfigureDrop(dropHint);
            RoundedActionButton cancel = MakeEditorButton(Localizer.T("crosshair.editorCancel"), Palette.Surface2, 120); cancel.Location = new Point(532, 625); cancel.DialogResult = DialogResult.Cancel; Controls.Add(cancel);
            RoundedActionButton save = MakeEditorButton(Localizer.T("crosshair.editorSave"), Palette.Accent, 150); save.Location = new Point(660, 625); save.Click += delegate
            {
                try { _canvas.SavePng(_exportPath); DialogResult = DialogResult.OK; Close(); }
                catch (Exception ex) { ThemedDialog.Show(this, Localizer.T("crosshair.editorTitle"), ex.Message, false); }
            }; Controls.Add(save);
            AcceptButton = save; CancelButton = cancel; ConfigureDrop(_canvas);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try { int dark = 1; DwmSetWindowAttribute(Handle, 20, ref dark, sizeof(int)); } catch { }
            try { int caption = ColorTranslator.ToWin32(Palette.Sidebar); DwmSetWindowAttribute(Handle, 35, ref caption, sizeof(int)); } catch { }
            try { int border = ColorTranslator.ToWin32(Palette.Border); DwmSetWindowAttribute(Handle, 34, ref border, sizeof(int)); } catch { }
        }

        private Label MakeEditorLabel(string text, int x, int y, int width, bool bold)
        {
            Label label = new Label(); label.Text = text; label.Font = UiFontCache.Get("Segoe UI", 9F, bold ? FontStyle.Bold : FontStyle.Regular); label.ForeColor = Palette.Text; label.BackColor = Palette.Background; label.Location = new Point(x, y); label.Size = new Size(width, 22); return label;
        }

        private ComboBox MakeEditorPicker(object[] items, int x, int y, int width)
        {
            ComboBox picker = new ModernComboBox(); picker.DropDownStyle = ComboBoxStyle.DropDownList; picker.Items.AddRange(items); picker.BackColor = Palette.Surface2; picker.ForeColor = Palette.Text; picker.FlatStyle = FlatStyle.Flat; picker.Font = UiFontCache.Get("Segoe UI", 9F, FontStyle.Regular); picker.Location = new Point(x, y); picker.Size = new Size(width, 32); return picker;
        }

        private RoundedActionButton MakeEditorButton(string text, Color fill, int width)
        {
            RoundedActionButton button = new RoundedActionButton(); button.Text = text; button.BackColor = fill; button.ForeColor = Palette.Text; button.Font = UiFontCache.Get("Segoe UI", 8.5F, FontStyle.Bold); button.Size = new Size(width, 38); button.Margin = new Padding(0); return button;
        }

        private void ChooseTemplate()
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = Localizer.T("crosshair.editorImage"); dialog.Filter = "Images (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp";
                if (dialog.ShowDialog(this) == DialogResult.OK) TryLoadTemplate(dialog.FileName);
            }
        }

        private void ConfigureDrop(Control target)
        {
            target.AllowDrop = true;
            target.DragEnter += delegate(object sender, DragEventArgs e)
            {
                string[] files = e.Data == null ? null : e.Data.GetData(DataFormats.FileDrop) as string[];
                string ext = files != null && files.Length == 1 ? Path.GetExtension(files[0]).ToLowerInvariant() : "";
                e.Effect = new[] { ".png", ".jpg", ".jpeg", ".bmp" }.Contains(ext) ? DragDropEffects.Copy : DragDropEffects.None;
            };
            target.DragDrop += delegate(object sender, DragEventArgs e)
            {
                string[] files = e.Data == null ? null : e.Data.GetData(DataFormats.FileDrop) as string[];
                if (files != null && files.Length == 1) TryLoadTemplate(files[0]);
            };
        }

        private void TryLoadTemplate(string path)
        {
            try { _canvas.LoadTemplate(path, false); }
            catch { ThemedDialog.Show(this, Localizer.T("crosshair.editorTitle"), Localizer.T("crosshair.imageInvalid"), false); }
        }
    }

    internal sealed class CrosshairDrawingCanvas : Control
    {
        private readonly List<List<StrokePoint>> _strokes = new List<List<StrokePoint>>();
        private Bitmap _template;
        private bool _templateUsesCanvas;
        private bool _drawing;
        private RectangleF _drawingBounds;
        private int _imageOpacityPercent = 100;
        private bool _pixelMode;
        public Color DrawingColor { get; set; }
        public int LineWidth { get; set; }
        public int ImageOpacityPercent { get { return _imageOpacityPercent; } set { _imageOpacityPercent = Math.Max(0, Math.Min(100, value)); Invalidate(); } }
        public bool PixelMode { get { return _pixelMode; } set { _pixelMode = value; Invalidate(); } }

        public CrosshairDrawingCanvas()
        {
            BackColor = Palette.Surface; DrawingColor = Color.Lime; LineWidth = 4;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        public void LoadTemplate(string path, bool preserveCanvas)
        {
            string ext = Path.GetExtension(path ?? "").ToLowerInvariant();
            if (!File.Exists(path) || !new[] { ".png", ".jpg", ".jpeg", ".bmp" }.Contains(ext) || new FileInfo(path).Length > 8L * 1024L * 1024L) throw new InvalidDataException();
            using (Image image = Image.FromFile(path))
            {
                if (image.Width < 8 || image.Height < 8 || image.Width > 2048 || image.Height > 2048) throw new InvalidDataException();
                Bitmap copy = new Bitmap(image); if (_template != null) _template.Dispose(); _template = copy; _templateUsesCanvas = preserveCanvas;
            }
            Invalidate();
        }

        public void UndoStroke() { if (_strokes.Count > 0) { _strokes.RemoveAt(_strokes.Count - 1); Invalidate(); } }
        public void Clear() { _strokes.Clear(); if (_template != null) { _template.Dispose(); _template = null; } _templateUsesCanvas = false; Invalidate(); }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e); e.Graphics.SmoothingMode = SmoothingMode.AntiAlias; e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic; e.Graphics.Clear(Palette.Surface);
            float side = Math.Max(1, Math.Min(ClientSize.Width, ClientSize.Height) - 18); _drawingBounds = new RectangleF((ClientSize.Width - side) / 2f, (ClientSize.Height - side) / 2f, side, side);
            int cell = 16;
            for (int y = 0; y < side; y += cell)
                for (int x = 0; x < side; x += cell)
                    using (SolidBrush checker = new SolidBrush(((x / cell + y / cell) & 1) == 0 ? Palette.Surface2 : Palette.Background)) e.Graphics.FillRectangle(checker, _drawingBounds.Left + x, _drawingBounds.Top + y, Math.Min(cell, side - x), Math.Min(cell, side - y));
            using (Pen border = new Pen(Palette.Border)) e.Graphics.DrawRectangle(border, _drawingBounds.X, _drawingBounds.Y, _drawingBounds.Width, _drawingBounds.Height);
            DrawArtwork(e.Graphics, _drawingBounds);
        }

        private void DrawArtwork(Graphics graphics, RectangleF bounds)
        {
            if (_template != null)
            {
                float max = bounds.Width * (_templateUsesCanvas ? 1.0f : 0.90f); float scale = Math.Min(max / _template.Width, max / _template.Height); float w = _template.Width * scale, h = _template.Height * scale;
                Rectangle destination = Rectangle.Round(new RectangleF(bounds.X + (bounds.Width - w) / 2f, bounds.Y + (bounds.Height - h) / 2f, w, h));
                using (ImageAttributes attributes = new ImageAttributes())
                {
                    ColorMatrix matrix = new ColorMatrix(); matrix.Matrix33 = _imageOpacityPercent / 100F;
                    attributes.SetColorMatrix(matrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
                    graphics.DrawImage(_template, destination, 0, 0, _template.Width, _template.Height, GraphicsUnit.Pixel, attributes);
                }
            }
            SmoothingMode previousSmoothing = graphics.SmoothingMode;
            if (_pixelMode) graphics.SmoothingMode = SmoothingMode.None;
            foreach (List<StrokePoint> stroke in _strokes)
            {
                if (stroke.Count == 0) continue;
                using (Pen pen = new Pen(stroke[0].Color, Math.Max(1F, stroke[0].Width * bounds.Width / 412F)))
                {
                    pen.StartCap = _pixelMode ? LineCap.Square : LineCap.Round; pen.EndCap = _pixelMode ? LineCap.Square : LineCap.Round; pen.LineJoin = _pixelMode ? LineJoin.Bevel : LineJoin.Round;
                    if (_pixelMode) pen.Width = Math.Max(bounds.Width / 32F, pen.Width);
                    if (stroke.Count == 1)
                    {
                        PointF p = ToCanvasPoint(stroke[0], bounds); using (SolidBrush brush = new SolidBrush(stroke[0].Color))
                        {
                            if (_pixelMode) graphics.FillRectangle(brush, p.X - pen.Width / 2f, p.Y - pen.Width / 2f, pen.Width, pen.Width);
                            else graphics.FillEllipse(brush, p.X - pen.Width / 2f, p.Y - pen.Width / 2f, pen.Width, pen.Width);
                        }
                    }
                    else graphics.DrawLines(pen, stroke.Select(p => ToCanvasPoint(p, bounds)).ToArray());
                }
            }
            graphics.SmoothingMode = previousSmoothing;
        }

        private static PointF ToCanvasPoint(StrokePoint point, RectangleF bounds) { return new PointF(bounds.X + point.X * bounds.Width, bounds.Y + point.Y * bounds.Height); }
        private StrokePoint Normalize(Point point)
        {
            float x = Math.Max(_drawingBounds.Left, Math.Min(_drawingBounds.Right, point.X)); float y = Math.Max(_drawingBounds.Top, Math.Min(_drawingBounds.Bottom, point.Y));
            float normalizedX = (x - _drawingBounds.Left) / Math.Max(1, _drawingBounds.Width), normalizedY = (y - _drawingBounds.Top) / Math.Max(1, _drawingBounds.Height);
            if (_pixelMode)
            {
                const int grid = 32;
                normalizedX = (float)(Math.Round(normalizedX * (grid - 1)) + 0.5) / grid;
                normalizedY = (float)(Math.Round(normalizedY * (grid - 1)) + 0.5) / grid;
            }
            return new StrokePoint(normalizedX, normalizedY, DrawingColor, LineWidth);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button == MouseButtons.Left && _drawingBounds.Contains(e.Location)) { _strokes.Add(new List<StrokePoint> { Normalize(e.Location) }); _drawing = true; Invalidate(); }
        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (_drawing && _strokes.Count > 0)
            {
                StrokePoint point = Normalize(e.Location), last = _strokes[_strokes.Count - 1][_strokes[_strokes.Count - 1].Count - 1];
                if (Math.Abs(point.X - last.X) + Math.Abs(point.Y - last.Y) > 0.0025f) { _strokes[_strokes.Count - 1].Add(point); Invalidate(); }
            }
        }
        protected override void OnMouseUp(MouseEventArgs e) { _drawing = false; base.OnMouseUp(e); }

        public void SavePng(string path)
        {
            using (Bitmap output = new Bitmap(512, 512, PixelFormat.Format32bppArgb))
            using (Graphics graphics = Graphics.FromImage(output))
            {
                graphics.Clear(Color.Transparent); graphics.SmoothingMode = SmoothingMode.AntiAlias; graphics.InterpolationMode = InterpolationMode.HighQualityBicubic; DrawArtwork(graphics, new RectangleF(0, 0, 512, 512)); output.Save(path, ImageFormat.Png);
            }
        }

        protected override void Dispose(bool disposing) { if (disposing && _template != null) { _template.Dispose(); _template = null; } base.Dispose(disposing); }

        private struct StrokePoint
        {
            public float X, Y, Width; public Color Color;
            public StrokePoint(float x, float y, Color color, float width) { X = x; Y = y; Color = color; Width = width; }
        }
    }

    internal sealed class OverlayForm : Form
    {
        private readonly Label _cpu, _gpu, _ram, _fps;
        private Point _drag;
        private readonly int _fontSize;
        public OverlayForm(string size, int opacity, bool showCpu, bool showGpu, bool showRam, bool showFps)
        {
            FormBorderStyle = FormBorderStyle.None; ShowInTaskbar = false; TopMost = true; StartPosition = FormStartPosition.Manual;
            int width = size == "compact" ? 245 : size == "large" ? 350 : 285;
            _fontSize = size == "compact" ? 9 : size == "large" ? 13 : 11;
            int visibleCount = (showCpu ? 1 : 0) + (showGpu ? 1 : 0) + (showRam ? 1 : 0) + (showFps ? 1 : 0);
            int step = size == "compact" ? 25 : size == "large" ? 35 : 29;
            int first = size == "compact" ? 31 : 37;
            int height = first + Math.Max(0, visibleCount - 1) * step + _fontSize + 14 + 20;
            Location = new Point(Screen.PrimaryScreen.WorkingArea.Right - width - 24, Screen.PrimaryScreen.WorkingArea.Top + 80);
            Size = new Size(width, height); BackColor = Palette.Surface; Opacity = Math.Max(0.70, Math.Min(1.0, opacity / 100.0)); Padding = new Padding(12); DoubleBuffered = true;
            RoundPanel panel = new RoundPanel(); panel.Dock = DockStyle.Fill; panel.BackColor = Palette.Surface; Controls.Add(panel);
            Label title = new Label(); title.Text = Localizer.T("overlay.title"); title.Font = UiFontCache.Get("Segoe UI Semibold", 9F, FontStyle.Bold); title.ForeColor = Palette.Accent; title.Location = new Point(12, 8); title.Size = new Size(Math.Max(80, panel.ClientSize.Width - 68), 20); panel.Controls.Add(title);
            Button close = new RoundedActionButton(); close.Text = "X"; close.FlatStyle = FlatStyle.Flat; close.FlatAppearance.BorderSize = 0; close.BackColor = Palette.Surface2; close.ForeColor = Palette.Text; close.Font = UiFontCache.Get("Segoe UI", 9F, FontStyle.Bold); close.Location = new Point(Math.Max(8, panel.ClientSize.Width - 38), 4); close.Size = new Size(30, 26); close.Anchor = AnchorStyles.Top | AnchorStyles.Right; close.TabStop = false; close.AccessibleName = Localizer.T("overlay.close"); close.Click += delegate { Close(); }; panel.Controls.Add(close);
            panel.Resize += delegate
            {
                close.Location = new Point(Math.Max(8, panel.ClientSize.Width - close.Width - 6), 4);
                title.Width = Math.Max(80, close.Left - title.Left - 7);
            };
            int row = 0;
            _cpu = AddLine(panel, "CPU —", first + (showCpu ? row++ * step : 0), width, showCpu);
            _gpu = AddLine(panel, "GPU —", first + (showGpu ? row++ * step : 0), width, showGpu);
            _ram = AddLine(panel, "RAM —", first + (showRam ? row++ * step : 0), width, showRam);
            _fps = AddLine(panel, "FPS —", first + (showFps ? row++ * step : 0), width, showFps);
            foreach (Control c in panel.Controls) if (c != close) { c.MouseDown += DragStart; c.MouseMove += DragMove; }
            panel.MouseDown += DragStart; panel.MouseMove += DragMove;
        }
        private Label AddLine(Control parent, string text, int y, int width, bool visible)
        { Label l = new Label(); l.Text = text; l.Font = UiFontCache.Get("Segoe UI Semibold", _fontSize, FontStyle.Bold); l.ForeColor = Palette.Text; l.Location = new Point(13, y); l.Size = new Size(width - 38, _fontSize + 14); l.Visible = visible; parent.Controls.Add(l); return l; }
        private void DragStart(object sender, MouseEventArgs e) { if (e.Button == MouseButtons.Left) _drag = PointToClient(Cursor.Position); }
        private void DragMove(object sender, MouseEventArgs e) { if (e.Button == MouseButtons.Left) { Point p = Cursor.Position; Location = new Point(p.X - _drag.X, p.Y - _drag.Y); } }
        public void UpdateValues(Reading r, FrameStats f)
        {
            if (IsDisposed) return;
            _cpu.Text = Localizer.T("metric.cpu") + "  " + F(r.Cpu) + "%";
            _gpu.Text = Localizer.T("metric.gpu") + "  " + F(r.Gpu) + "%";
            _ram.Text = Localizer.T("metric.ram") + "  " + F(r.Ram) + "%  ·  " + r.RamUsedMb.ToString("0", CultureInfo.InvariantCulture) + " MB";
            _fps.Text = Localizer.T("metric.fps") + "  " + F(f.Current) + "  ·  " + Localizer.T("overlay.details") + " " + F(f.Minimum) + "  " + Localizer.T("overlay.average") + " " + F(f.Average);
        }
        private static string F(double value) { return value < 0 ? "—" : value.ToString("0", CultureInfo.InvariantCulture); }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e); using (Pen p = new Pen(Palette.Accent, 2)) e.Graphics.DrawRectangle(p, 0, 0, Width - 1, Height - 1);
        }
    }

    internal static class ThemedDialog
    {
        public static bool Confirm(IWin32Window owner, string title, string message) { return ShowDialog(owner, title, message, true); }
        public static void Show(IWin32Window owner, string title, string message, bool confirm) { ShowDialog(owner, title, message, confirm); }
        public static string Prompt(IWin32Window owner, string title, string message)
        {
            using (Form form = new Form())
            using (Label heading = new Label())
            using (Label hint = new Label())
            using (TextBox input = new TextBox())
            using (RoundedActionButton cancel = new RoundedActionButton())
            using (RoundedActionButton save = new RoundedActionButton())
            {
                form.Text = "Freezer"; form.FormBorderStyle = FormBorderStyle.FixedDialog; form.StartPosition = FormStartPosition.CenterParent;
                form.ClientSize = new Size(470, 190); form.BackColor = Palette.Surface; form.ForeColor = Palette.Text;
                form.MinimizeBox = false; form.MaximizeBox = false; form.ShowInTaskbar = false;
                heading.Text = title; heading.Font = UiFontCache.Get("Segoe UI Semibold", 12F, FontStyle.Bold); heading.ForeColor = Palette.Text; heading.Location = new Point(20, 17); heading.Size = new Size(430, 26);
                hint.Text = message; hint.Font = UiFontCache.Get("Segoe UI", 9F, FontStyle.Regular); hint.ForeColor = Palette.Muted; hint.Location = new Point(20, 52); hint.Size = new Size(430, 23);
                input.Location = new Point(20, 82); input.Size = new Size(430, 30); input.BackColor = Palette.Surface2; input.ForeColor = Palette.Text; input.BorderStyle = BorderStyle.FixedSingle; input.Font = UiFontCache.Get("Segoe UI", 9F, FontStyle.Regular); input.MaxLength = 40;
                cancel.Text = Localizer.T("dialog.cancel"); cancel.BackColor = Palette.Surface2; cancel.ForeColor = Palette.Text; cancel.Size = new Size(112, 36); cancel.Location = new Point(222, 135); cancel.DialogResult = DialogResult.Cancel;
                save.Text = Localizer.T("crosshair.presetSave"); save.BackColor = Palette.Accent; save.ForeColor = Color.FromArgb(28, 17, 7); save.Size = new Size(132, 36); save.Location = new Point(340, 135); save.DialogResult = DialogResult.OK;
                form.Controls.Add(heading); form.Controls.Add(hint); form.Controls.Add(input); form.Controls.Add(cancel); form.Controls.Add(save);
                form.AcceptButton = save; form.CancelButton = cancel; form.Shown += delegate { input.Focus(); };
                return form.ShowDialog(owner) == DialogResult.OK ? input.Text.Trim() : null;
            }
        }
        private static bool ShowDialog(IWin32Window owner, string title, string message, bool confirm)
        {
            using (Form f = new Form())
            using (TableLayoutPanel layout = new TableLayoutPanel())
            using (Panel header = new Panel())
            using (Panel body = new Panel())
            using (Panel footer = new Panel())
            using (Label heading = new Label())
            using (Label text = new Label())
            using (RoundedActionButton yes = new RoundedActionButton())
            using (RoundedActionButton no = new RoundedActionButton())
            {
                Font bodyFont = UiFontCache.Get("Segoe UI", 9F, FontStyle.Regular);
                Size measured = TextRenderer.MeasureText(message ?? "", bodyFont, new Size(514, 700), TextFormatFlags.WordBreak | TextFormatFlags.TextBoxControl);
                int bodyHeight = Math.Max(78, Math.Min(420, measured.Height + 20));
                f.Text = "Freezer"; f.FormBorderStyle = FormBorderStyle.None; f.StartPosition = FormStartPosition.CenterParent;
                f.ClientSize = new Size(570, 58 + bodyHeight + 60); f.BackColor = Palette.Surface; f.ForeColor = Palette.Text; f.Font = UiFontCache.Get("Segoe UI", 9F, FontStyle.Regular); f.ShowInTaskbar = false; f.MinimizeBox = false; f.MaximizeBox = false;
                layout.Dock = DockStyle.Fill; layout.ColumnCount = 1; layout.RowCount = 3; layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, bodyHeight)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60));
                header.Dock = DockStyle.Fill; header.BackColor = Palette.Sidebar; heading.Text = title; heading.Font = UiFontCache.Get("Segoe UI Semibold", 12F, FontStyle.Bold); heading.ForeColor = Palette.Text; heading.Location = new Point(20, 17); heading.Size = new Size(525, 27); header.Controls.Add(heading);
                body.Dock = DockStyle.Fill; body.Padding = new Padding(20, 17, 20, 10); body.BackColor = Palette.Surface; body.AutoScroll = measured.Height + 4 > bodyHeight - 26; text.AutoSize = true; text.MaximumSize = new Size(514, 0); text.ForeColor = Palette.Text; text.BackColor = Palette.Surface; text.Font = bodyFont; text.Text = message ?? ""; text.Location = Point.Empty; body.Controls.Add(text);
                footer.Dock = DockStyle.Fill; footer.BackColor = Palette.Surface; yes.Text = confirm ? Localizer.T("dialog.confirm") : Localizer.T("dialog.ok"); yes.FlatStyle = FlatStyle.Flat; yes.FlatAppearance.BorderSize = 0; yes.BackColor = Palette.Accent; yes.ForeColor = Color.FromArgb(28, 17, 7); yes.Font = UiFontCache.Get("Segoe UI Semibold", 9F, FontStyle.Bold); yes.Size = new Size(116, 36); yes.Location = new Point(570 - 142, 12); yes.DialogResult = DialogResult.OK; footer.Controls.Add(yes);
                if (confirm) { no.Text = Localizer.T("dialog.cancel"); no.FlatStyle = FlatStyle.Flat; no.FlatAppearance.BorderSize = 0; no.BackColor = Palette.Surface2; no.ForeColor = Palette.Text; no.Size = new Size(105, 36); no.Location = new Point(570 - 260, 12); no.DialogResult = DialogResult.Cancel; footer.Controls.Add(no); }
                layout.Controls.Add(header, 0, 0); layout.Controls.Add(body, 0, 1); layout.Controls.Add(footer, 0, 2); f.Controls.Add(layout); f.AcceptButton = yes; if (confirm) f.CancelButton = no;
                return f.ShowDialog(owner) == DialogResult.OK;
            }
        }
    }
}
