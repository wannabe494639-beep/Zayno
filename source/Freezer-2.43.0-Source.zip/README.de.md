# Freezer 2.43.0 Native

Version 2.43.0 ergänzt Potato Graphics mit drei Fortnite-Stufen. Die Seite wird nur für erkannte NVIDIA-Grafikkarten freigeschaltet, sichert `GameUserSettings.ini` vor dem Ändern und setzt sie nach dem Schreiben schreibgeschützt. Normal/Zurücksetzen entfernt den Schreibschutz und stellt die gesicherte Originaldatei wieder her. Extremes Potato kann eine vom Nutzer gewählte NVIDIA-Profile-Inspector-`.nip`-Datei importieren.

Freezer ist hier als native Windows-Desktop-App in C# WinForms neu aufgebaut. Die EXE benötigt weder Python noch PowerShell. Sie verwendet die Windows-.NET-Framework-Laufzeit, die bei üblichen Windows-10/11-Systemen bereits vorhanden ist.

## Starten

Starte `dist/Freezer-2.43.0.exe`. Es ist eine einzelne GUI-EXE ohne Konsolenfenster. PresentMon, das Dashboard-Logo und Game-Hub-Artworks sind eingebettet; PresentMon wird nach dem Anzeigen des Fensters im Hintergrund nach `%LOCALAPPDATA%\Freezer` entpackt. Die Lizenzdatei liegt unter `assets/PresentMon-LICENSE.txt`.

## Build

Mit einer Installation des Windows-.NET-Framework-C#-Compilers:

```powershell
.\build.ps1
```

Der Build erzeugt `dist/Freezer-2.43.0.exe` und `dist/Freezer-2.43.0-Source.zip`. Die EXE bindet Icon, Dashboard-Logo, PresentMon und die Game-Hub-Artworks unter `assets/game-art` als Ressourcen ein und verwendet `/target:winexe`. Das Quellarchiv enthält `Freezer.cs`, Build-Skript, Dokumentation und alle benötigten Assets.

## Neuerungen in 2.43.0

- Der neue Seitenmenüpunkt „Potato Graphics“ bietet Normal, Leichtes Potato und Extremes Potato. AMD- und Intel-Grafikkarten werden klar als noch nicht unterstützt angezeigt.
- Leichtes Potato setzt Sichtweite, Schatten und Texturdetails auf 1; Extremes Potato setzt diese drei Werte auf 0. Vor dem Schreiben wird eine verifizierte Sicherung angelegt; Fortnite muss geschlossen sein.
- Potato-Profile setzen `GameUserSettings.ini` auf schreibgeschützt. Normal und Zurücksetzen entfernen diesen Schutz und stellen die ursprüngliche Datei wieder her. Die Sicherung bleibt für spätere Wiederherstellungen erhalten.
- Extremes Potato fragt eine NVIDIA-Profile-Inspector-`.nip`-Datei ab und startet den externen NVIDIA Profile Inspector mit Administratorbestätigung. Das Tool und das `.nip`-Profil werden nicht mit Freezer ausgeliefert. Die Treiberänderung ist extern; Freezer kann sie nicht zurücksetzen. Vor dem Import sollte das NVIDIA-Profil im Inspector gesichert/exportiert werden.
- Der allgemeine Fortnite-Reset behandelt jetzt schreibgeschützte Dateien korrekt. Die lokale Version/Build-Metadaten lauten 2.43.0.

## Neuerungen in 2.41.0

- Der neue Menüpunkt „Leistung“ misst einen laufenden unterstützten Spielprozess für 30, 60 oder 120 Sekunden. Profile sind nur Kennzeichnungen für Messläufe und ändern keine Einstellungen.
- PresentMon-Framezeiten werden auf maximal 180.000 Einträge begrenzt. Der Lauf berechnet durchschnittliche FPS, 1%-Low, 0,1%-Low, mittlere Framezeit, p95-Framezeit und erfasste Frames.
- Für 1%-Low werden mindestens 1.000 Frames verlangt, für 0,1%-Low mindestens 10.000; bei kürzeren oder langsameren Messläufen bleibt der Wert als nicht verfügbar markiert.
- Bis zu 40 Messläufe werden lokal unter `%LOCALAPPDATA%\Freezer\benchmark-history.tsv` gehalten. Vergleiche zeigen absolute Läufe und Prozentänderungen; gleiche Szene, Route, Auflösung, Einstellungen und Aufwärmzeit sind für brauchbare Vergleiche erforderlich.
- Engpasshinweise sind Heuristiken, keine Diagnose. Hohe GPU-, CPU-Kern- oder RAM-Auslastung kann auf ein Limit hindeuten; andere Ursachen werden dadurch nicht ausgeschlossen. Nicht verfügbare Sensoren werden nicht geschätzt.
- Die Leistungsseite zeigt CPU-/GPU-Modell, RAM-Kapazität und -Typ, Windows- und Monitorauflösung, Top-Prozesse nach Arbeitsspeicher sowie die Anzahl der Autostart-Einträge. Einträge werden nicht automatisch gestoppt oder deaktiviert. Hersteller-Treiberseiten und Windows-Einstellungen öffnen sich nur auf Klick; es wird nichts ungefragt installiert.
- Die Reparaturseite kann einen datensparsamen Diagnosebericht zuerst zur Prüfung anzeigen. Erst nach expliziter Auswahl eines Speicherorts wird er exportiert; er schließt Benutzerpfade, Prozess-IDs, Seriennummern, Prozesslisten, Logs und Einstellungsinhalte aus.
- Unbehandelte Fehler werden in einem lokalen Log mit begrenzter Größe und drei Rotationen protokolliert. Der Diagnoseexport überträgt keine Daten und enthält diese Logs nicht.
- Die Versionsangaben sind auf 2.41.0 aktualisiert. Der Updater bleibt optional und blockiert den Start nicht.

## Neuerungen in 2.40.1

- Einheitliche dunkle Oberfläche mit abgerundeten Karten und Aktionen bleibt durchgehend erhalten; Auswahlfelder und Dialoge verwenden die vorhandenen dunklen WinForms-Steuerelemente.
- Das Fadenkreuz bietet jetzt eine direkte Vorschau, Deckkraft, optionale dunkle Kontur, optionales Neon-Leuchten und lokal gespeicherte benannte Presets. Presets lassen sich laden, überschreiben und löschen; ein verwendetes eigenes PNG wird je Preset gesichert. Eigene Bilder und Zeichnungen bleiben unterstützt.
- Das Overlay wird nach Windows-Monitor-/Auflösungsänderungen sowie WM_DPICHANGED erneut auf dem gewählten Display positioniert. Es bleibt ein normales TopMost-Fenster ohne Spiel-Injektion.
- Beim ersten Start nach diesem Update erscheint eine einmalige, mit „OK“ schließbare Einführung zu Wiederherstellung, Spielprofilen, Stretch-Skalierung und Fadenkreuz.
- Eine vorhandene Anzeigeauflösung wird weiterhin vor der Änderung beim Treiber getestet; Freezer sichert den Originalmodus und kehrt nach dem Bestätigungszeitraum automatisch zurück. Der Originalmodus lässt sich jederzeit manuell wiederherstellen.
- Der optionale Updater bleibt standardmäßig aus und läuft, wenn aktiviert, im Hintergrund. Hardware- und FPS-Sensoren werden nur für sichtbare Monitoransichten abgefragt; nicht gelieferte Werte werden nicht geschätzt.

## Einschränkungen

- Ein Fadenkreuzfenster kann von exklusivem Vollbild, Windows-Overlay-Regeln oder Anti-Cheat ausgeblendet werden. Freezer injiziert nicht in Spiele und umgeht keinen Anti-Cheat.
- Farbprofile hängen von der vom Grafiktreiber bereitgestellten Schnittstelle ab. NVIDIA stellt über die genutzte NVAPI-Schnittstelle Digital Vibrance bereit; weitere NVIDIA-Bildregler sind nicht verfügbar.
- FPS-Ausgaben stammen nur aus laufender, unterstützter PresentMon-Erfassung. Eine FPS-Steigerung oder Verringerung von Latenz wird nicht garantiert.
- Der Build benötigt zum Kompilieren den Windows-.NET-Framework-C#-Compiler. Die erzeugte EXE nutzt die Windows-.NET-Framework-Laufzeit, aber keine Python- oder PowerShell-Laufzeit.
- Die Ausgaben werden lokal erstellt. Eine Signatur oder ein Upload/Veröffentlichen auf einem externen Release-Server ist nicht Teil dieses Builds.

## Game-Hub-Profile und Anzeigeeinstellung

Der Game Hub speichert pro Spiel ein kombiniertes Profil mit Windows-Leistungsmodus, optionalem NVIDIA-/AMD-Farbprofil und optionaler Stretch-Auflösung samt Monitor. Eine gespeicherte Stretch-Auflösung wird vor dem Spielstart vom Windows-Grafiktreiber getestet, während der Sitzung angewendet und nach dem Spielende oder beim vollständigen Schließen von Freezer zurückgesetzt. Nicht unterstützte Modi werden nicht angewendet. Die Anzeigeabschaltung ist eine separate, optionale Einstellung in Freezer: Sie betrifft nur den aktuellen Energiesparplan, sichert die bisherigen Netz-/Akkuwerte und stellt sie über „Vorherige Werte wiederherstellen“ zurück. Andere Optimierungen ändern diese Einstellung nicht.

## Gaming-Sitzung

Wenn ein erkanntes Spiel läuft und der Gaming-Modus aktiv ist, erhält es vorübergehend die Prozesspriorität „Hoch“. Freezer fordert außerdem eine 1-ms-Timerauflösung an und erstellt eine eigene Kopie des Windows-Plans „Ultimative Leistung“ (Fallback: „Höchstleistung“). In dieser Kopie werden Core Parking deaktiviert sowie minimale und maximale CPU-Leistung am Netzbetrieb auf 100 % gesetzt. Die Werte ändern nur die Freezer-Kopie, nicht den ursprünglichen Plan; beim Spielende, Ausschalten des Modus oder nächsten Start werden vorheriger Plan und Freezer-Kopie wiederhergestellt/entfernt. Eine manuelle Wahl eines anderen Energieplans bleibt erhalten. Die Einstellungen können Stromverbrauch, Temperatur und Lüftergeräusch erhöhen; Firmware- und Temperaturschutz bleiben aktiv. Dienste werden nicht pauschal gestoppt und RAM nicht zwangsweise geleert.

## Farb-Profile

Der neue Menüpunkt „Farb-Profile“ enthält getrennte NVIDIA- und AMD-Bereiche. Nicht erkannte Herstellerkarten werden mit einem Hinweis gesperrt. Farbprofile speichern die Digital-Vibrance-/Sättigungsstufe je Treiberausgang; Profile können Spielen wie Fortnite zugewiesen werden. Die Hintergrundüberwachung prüft laufende unterstützte Spiele nur dann, wenn eine Zuordnung gespeichert wurde. Beim Spielende werden die vom Treiber gemeldeten Standardwerte wiederhergestellt. Treiber-Farbwerte wirken global auf den jeweiligen Bildschirmausgang.

NVIDIA benötigt einen Treiber mit verfügbarer NVAPI-Digital-Vibrance-Funktion. AMD verwendet die ADL-Farbsteuerung aus AMD Software/Adrenalin. Treiber- und Hardwareversionen können die Unterstützung einschränken; Freezer zeigt dann den Treiberfehler im jeweiligen Bereich an. Farbdaten und Spielzuweisungen bleiben lokal in `%LOCALAPPDATA%\Freezer\settings.ini`.

Version 2.32.26 zeigt bei Monitorauswahlen die ermittelte Monitorbezeichnung, Haupt-/Nebenmonitor, relative Position und Auflösung. Falls der Treiber nur einen generischen Namen liefert, wird die Bezeichnung nach Möglichkeit aus Windows-Monitorinformationen gelesen. Manuelles Anwenden und Zurücksetzen betreffen ausschließlich den ausgewählten Monitorausgang; die Auswahl wird pro NVIDIA-/AMD-Bereich gespeichert. Der Gaming-Mode-Schalter auf der Optimierungsseite bestätigt nun ebenfalls vor jeder Änderung.

Version 2.32.20 ergänzt die Übersicht um CPU, Grafikkarten, RAM-Kapazität, Mainboard und Laufwerke. Das erste Begrüßungsfenster erklärt Freezers kostenlosen Projektstatus und kennzeichnet den FPS-Vergleich ausdrücklich als Illustration. AMD-Farbprofile verwenden die vom ADL-Treiber gemeldeten Wertebereiche und Standardwerte für Sättigung, Helligkeit, Kontrast und Farbton; NVIDIA steuert weiterhin nur Digital Vibrance über NVAPI und bietet einen direkten Link zur NVIDIA-Systemsteuerung. Gamma wird nur angeboten, wenn eine unterstützte Schnittstelle es tatsächlich meldet.

Version 2.32.21 fängt ungültige Live-Messwerte im GPU-Kreis ab, gestaltet Auswahlfelder durchgehend dunkel und verschiebt das Fadenkreuz in einen eigenen Menüpunkt. Fortnite-Profile bearbeiten nur vorhandene Konfigurationswerte und verwenden weiterhin ein überprüfbares Original-Backup.

Version 2.32.22 verhindert den GDI+-Absturz bei 0-%-Messwerten, filtert virtuelle Anzeigeadapter aus der GPU-Liste und lässt automatische Update-Suchen standardmäßig aus. Maximieren nutzt den Windows-Arbeitsbereich, damit die Taskleiste sichtbar bleibt.

Version 2.32.25 korrigiert das Maximieren über mehrere Monitore mit der jeweiligen Windows-Arbeitsfläche, ordnet das FPS-Beispiel kompakter ohne große Leerstelle an und verhindert horizontales Scrollen im Hauptinhalt. Der Fadenkreuz-Editor ist größer, vollständig bedienbar und dunkel gestaltet; importierte Vorlagen können transparent eingestellt werden, und der Zeichenmodus bietet Freihand oder ein 32×32-Pixelraster. Drag-and-drop und transparenter PNG-Export bleiben erhalten.

Version 2.32.24 ergänzt einen Zeicheneditor für eigene Fadenkreuze, Bildimport per Dateiauswahl und Drag-and-drop, mehrere zusätzliche Standardformen sowie einen transparenten Bildexport, der im ausgewählten Monitor-Overlay zentriert und neu geladen wird.

Version 2.32.23 zeigt CPU-, GPU- und RAM-Details unter den Live-Kreisen, stellt Bestätigungen für Gaming- und Streamer-Modus wieder her, ergänzt OBS-Hilfe unter Reparatur und korrigiert abgeschnittene Update- und Fadenkreuz-Buttons.

Version 2.32.19 zeigte gespeicherte Profile zusätzlich als direkt auswählbare Schaltflächen an. Die dunkle Farbprofil-Oberfläche mit orangefarbenem Akzent und kompakte Statusanzeigen für nicht verfügbare Treiberbereiche bleiben erhalten.

## Game Hub und Fortnite

Die Spielkacheln verwenden eingebettete Artworks. Die Grafiken werden bei Bedarf geladen und beim Verwerfen der jeweiligen Kachel wieder freigegeben. Spielprofile umfassen Leicht, Ausgewogen, Power, Max-FPS und Streamer. Max-FPS verwendet reversible Windows-Einstellungen und den bestehenden Sitzungs-Boost; Dienste werden nicht abgeschaltet. Im Streamer-Modus erhalten Spiel und OBS vorübergehend „Über Normal“. Der OBS-Assistent empfiehlt den Hardware-Encoder anhand der erkannten GPU und erklärt sichere Startwerte; OBS-Profile oder -Einstellungen werden nicht gelesen oder geändert. Die Game-Hub-Sitzung erkennt ein unterstütztes laufendes Spiel oder lässt Spiel und Profil auswählen. Ein gewählter Launcher kann gespeichert und nach Bestätigung des Profils gestartet werden.

Fortnite bietet die Stufen Hoch, Mittel, Niedrig und Extrem/Potato sowie „Originale Sicherung wiederherstellen“. Vor der ersten Änderung erstellt Freezer `GameUserSettings.ini.freezer-original.bak`; Fortnite muss geschlossen sein.

Ein eigenes Bild lässt sich per Dateiauswahl oder Drag-and-drop als Fortnite-Kachelbild in Freezer setzen und zurücksetzen. Es wird lokal auf 1280×720 begrenzt gespeichert und ändert keine Fortnite-Dateien. Ein eigenes Bild für die Battle-Royale-Lobby ist in Fortnite nicht als Spieleroption dokumentiert; Epic unterstützt benutzerdefinierte Lobbybilder für Creator-Inseln über den Creator-Workflow, nicht durch Ersetzen lokaler Spielressourcen.

Die optionale lokale QoS-Aktion markiert den Verkehr eines laufenden unterstützten Spiels temporär mit DSCP 46. Sie benötigt eine Windows-Administratorbestätigung und ist bis zum Entfernen oder Neustart aktiv. Router oder Internetanbieter können die Markierung ignorieren; sie garantiert weder geringeren Ping noch weniger Paketverlust. Allgemeine TCP- und Nagle-Werte werden nicht pauschal geändert.

Beim Schließen lässt sich Freezer in den Infobereich minimieren. Rechtsklick auf das Symbol zeigt „Öffnen“ und „Vollständig beenden“.

## Updates

Die automatische Suche nach einer neueren EXE oder einem Freezer-Windows-ZIP ist standardmäßig ausgeschaltet. Du kannst sie in Einstellungen oder Updates einschalten; dann läuft sie nach dem Anzeigen des Hauptfensters im Hintergrund und blockiert den Start nicht. Auf „Updates“ kannst du zusätzlich lokale Dateien durchsuchen oder eine EXE/ZIP manuell auswählen. Im Windows-ZIP wird nur eine passend benannte Freezer-EXE mit neuerer Versionsnummer extrahiert. „Update installieren“ fragt vor dem Schließen nach, erstellt neben der bisherigen EXE eine Versionssicherung, ersetzt die vollständige EXE und startet Freezer danach neu. Logo, PresentMon und Spielgrafiken sind in dieser Datei eingebettet und werden so gemeinsam erneuert. Das Source-ZIP ist kein Installationspaket. Der GitHub-Download wird weiterhin manuell geprüft; es läuft nichts ungefragt.

## Navigation und Oberfläche

- Die Sidebar fährt beim Darüberfahren mit der Maus aus und beim Verlassen wieder ein. Ein Klick auf das Menü-Symbol hält sie offen.
- Die Sidebar-Animation lässt sich auf schnell (~0,1 s), reduziert (~0,4 s) oder sofort (aus) einstellen. Die Spielkarten wischen beim Seitenwechsel entsprechend dieser Einstellung.
- Das rahmenlose Fenster besitzt Minimieren-, Maximieren-/Wiederherstellen- und Schließen-Schaltflächen. „Beenden“ oben rechts schließt Freezer vollständig, auch wenn das X sonst in den Infobereich minimiert. Windows-Rahmenstile, native Größenänderung und Ziehen der Titelleiste an den oberen Bildschirmrand ermöglichen Snap Assist/Maximieren; UI-Karten passen ihre Breite beim Ändern der Fenstergröße an.
- Akzentfarben: Orange, Cyan, Violett, Limette und Pink.
- UI-Sprachen: Deutsch, Englisch, Französisch, Spanisch, Türkisch und Polnisch. Systemmeldungen aus Windows-Diagnoseprogrammen folgen weiterhin der Anzeigesprache von Windows.
- Optimierungs-Karten sind untereinander gestapelt. Jede echte Systemänderung wird bestätigt und kann über ihren Schalter zurückgesetzt werden.
- Der Gaming-Modus und der aktuelle FPS-Wert stehen oben im Kopfbereich. Die Spielauswahl zeigt vollständige Namen und wechselt per Vor/Weiter zwischen Karten.
- Kopfzeilen-, Hardware- und Reparatur-Schaltflächen haben feste Maße; dadurch überlagern sie sich nicht. Die Live-Anzeige-Schließen-Schaltfläche bleibt beim Layoutwechsel im Fenster.
- Die Startseite zeigt erkannte CPU-, GPU- und RAM-Komponenten als Klartext. CPU-/GPU-Modellnamen werden im Hintergrund ermittelt, damit das Dashboard beim Start nicht auf WMI wartet.
- Die Game-Hub-Banner zeigen jetzt den vollständigen lokalisierten Spielenamen direkt anstelle von Initialen. Lange Titel umbrechen automatisch innerhalb des Banners.
- Das beigefügte transparente Blitzlogo erscheint in Kopfzeile und Dashboard. Fehlt die eingebettete PNG-Ressource, verwendet Freezer ein Windows-Symbol als sicheren Fallback.
- Gaming-Modus aktiviert Windows Game Mode. Solange ein erkanntes Spiel läuft, fordert Freezer zeitweise 1-ms-Timerauflösung an und setzt dessen Prozesspriorität auf „Hoch“. Der vorherige Wert wird pro Prozess-ID samt Startzeit gesichert und beim Ausschalten, Beenden oder beim nächsten Start zurückgesetzt. Ein erhöhter Prozess kann durch Windows/Rechte geschützt sein; in dem Fall wird er übersprungen. Dienste werden nicht deaktiviert. Die Änderung kann Stromverbrauch und Hintergrundaktivität erhöhen und garantiert keinen FPS-/Latenzgewinn.
- Unter Optimierungen gibt es ein eigenes Ryzen-X3D-Profil. Es erkennt X3D-Prozessoren über den Windows-CPU-Namen (AM4/AM5) und aktiviert nach Bestätigung Windows Game Mode sowie die rücksetzbare Deaktivierung der Hintergrundaufnahme. Es schreibt keine CCD-/CPPC- oder BIOS-Werte und ändert keine Bildschirm-Timeouts.
- Der Desktop-Assistent zeigt erkannte CPU-, GPU- und RAM-Daten und schlägt vorsichtige Windows-Optionen passend zu RAM-Ausstattung und X3D-Prozessor vor. Die Änderungen werden vorab angezeigt und nur nach Bestätigung gesetzt.
- Beim ersten Start erscheint einmalig eine Anleitung für Windows-Wiederherstellungspunkte. Sie erklärt die Grenzen: Wiederherstellungspunkte sind eine zusätzliche Rückkehrmöglichkeit, keine Garantie und kein Backup persönlicher Dateien. Die Einstellungen lassen sich erneut unter Einstellungen öffnen.
- Die Fortnite-Karte enthält Performance- und Potato-Grafikprofile. Vorhandene Qualitätswerte in `GameUserSettings.ini` werden nach Bestätigung geändert und vor dem ersten Wechsel lokal gesichert. Fortnite muss geschlossen sein; die Originalkopie kann über das Profilmenü wiederhergestellt werden.
- Game Hub ergänzt Fortnite-Ping-Hinweise zu Ethernet, Serverregion und Hintergrunddownloads sowie weitere Titel und lokalisierte Lite-, Ausgewogen- und Ultimative-Power-Profile.
- Jede Spielkarte bietet Stretch-Auflösung. Der Treiber prüft den benutzerdefinierten Modus vor dem Wechsel; die Änderung betrifft nur den ausgewählten Monitor. Freezer fragt 15 Sekunden nach und stellt sonst automatisch die vorige Auflösung wieder her. Das Original lässt sich später zurücksetzen. GPU-Vollbildskalierung kann zusätzlich im Grafiktreiber nötig sein.
- In den Einstellungen kann ein anpassbares Fadenkreuz auf einem ausgewählten Monitor zentriert werden: Plus, X, Kreis, Punkt, Quadrat, Raute, T-Form oder Eckklammern sowie mehrere Farben. „Neu zentrieren“ lädt die aktuelle Auflösung manuell neu; bei Windows-Displayänderungen wird es automatisch auf der gewählten Anzeige neu zentriert. Antialiasing und doppelt gepufferte Darstellung glätten die Kanten. Es bleibt ein transparentes, klickdurchlässiges Desktop-Overlay ohne Spiel-Injektion; exklusives Vollbild und Anti-Cheat können es verbergen oder blockieren.
- Windows-Spieleprofile wenden Windows-Einstellungen an: Leicht aktiviert den Windows-Spielmodus, Ausgewogen schaltet zusätzlich die Hintergrundaufnahme für diesen Benutzer aus, Ultimative Power ergänzt die CPU-Maximalleistung am Netzbetrieb. Das Fortnite-Grafikprofil ist getrennt und bearbeitet nur vorhandene Qualitätswerte in der lokalen `GameUserSettings.ini`.
- Das Live-Overlay ist in Größe und Transparenz anpassbar und kann CPU, GPU, RAM und FPS einzeln ein- oder ausblenden.
- Die Seite „Updates“ fragt das öffentliche GitHub-Release ab und öffnet die Releases zum manuellen Prüfen und Herunterladen. Die automatische Update-Suche ist standardmäßig ausgeschaltet und kann in Einstellungen oder Updates aktiviert werden. Wenn sie aktiv ist, prüft Freezer nach dem Anzeigen des Fensters im Hintergrund den Download-Ordner und den eigenen Ordner auf neuere Freezer-EXE- oder Windows-ZIP-Dateien. Die Installation wird ausschließlich nach ausdrücklicher Bestätigung gestartet. Vor dem Ersetzen wird die vollständige EXE auf Produktname, Version und SHA-256 geprüft; die bisherige Datei bleibt als `.bak` erhalten. Prüfe weiterhin selbst Quelle und Signatur der Datei.
- Diagnose prüft Einstellungen, PresentMon, gespeicherte Sicherungen, Laufzeit und Rechte sowie RAM-Belegung, Grafikadapter-/Treiberversion und verfügbare ACPI-Temperaturzonen. ACPI-Zonen sind kein verlässlicher CPU-Paketsensor. Fehlende oder vom Treiber nicht offengelegte Werte werden als nicht verfügbar angezeigt.
- Die Messschleife gibt das für die Arbeitssatzmessung verwendete Prozess-Handle explizit frei. UI-Schriften werden wiederverwendet statt bei jedem Seitenaufbau neu erzeugt. Der Diagnosebericht trennt jetzt System-RAM von Freezers Arbeitssatz, privatem/virtuellem Speicher, Handles, GDI-/USER-Objekten und .NET-Heap.

## Live-Monitor und FPS-Overlay

- CPU-Auslastung: Windows `GetSystemTimes`.
- Pro-Kern-Auslastung: Windows-Performance-Counter, sofern der Zähler auf dem System verfügbar ist.
- RAM-Auslastung und belegter Speicher: `GlobalMemoryStatusEx`.
- GPU-Last: Windows `GPU Engine`-Performance-Counter für 3D-Engines. Wenn der Treiber diese Zähler nicht bereitstellt, zeigt Freezer `—` statt eines erfundenen Werts.
- FPS, Minimum und Durchschnitt: PresentMon wird automatisch an ein erkanntes unterstütztes Spiel angehängt; im Hardware-Monitor kannst du stattdessen manuell einen Prozess wählen. Die FPS-Anzeige wird viermal pro Sekunde aktualisiert.
- Dashboard, Kopfbereich und das frei verschiebbare Always-on-top-Overlay zeigen echte PresentMon-FPS inklusive Minimum und Durchschnitt. Sensorabfragen pausieren, wenn weder Home/Monitor noch Overlay sichtbar sind.
- Temperatur-, Takt- und Watt-Sensoren benötigen zusätzliche Hardware-/Treiber-Schnittstellen und werden nicht als erfundene Werte angezeigt.

## Enthaltene Aktionen

Rücksetzbare Optionen umfassen Windows Game Mode, visuelle Effekte, Game DVR, Menüverzögerung und die maximale AC-Prozessorleistung des aktiven Energieplans. Vorherige Registry-Werte werden mitsamt Typ gesichert. Zurücksetzen erhält Werte, die Windows oder eine andere App währenddessen verändert hat.

Der CPU-Energieplan-Tweak ändert ausschließlich `PROCTHROTTLEMAX` am Netzbetrieb und stellt den vorherigen Wert wieder her. Bildschirm-Timeouts, Schlafzeiten, Windows Update, Telemetriedienste, Treiber und Spieldateien werden nicht verändert. Der Power-Tweak kann Stromverbrauch, Temperatur und Lüftergeräusch erhöhen.

Temporärdateien, Discord-Cache und bekannte DirectX/NVIDIA/AMD-Shader-Caches werden erst nach Dateivorschau und Bestätigung gelöscht. Dateien müssen älter als 7 bzw. 14 Tage sein; die Suche ist auf 3.000 Dateien und 20.000 Einträge begrenzt und folgt keinen Junctions oder Symlinks.

Netzwerk-TCP/Nagle-Änderungen, GPU-Takt-Sperren und Kernel-Tweaks werden nicht generisch erzwungen. Diese hängen von Treiber und Hardware ab und können Verbindungen oder Stabilität verschlechtern. Die QoS-Option ist eine explizite, reversible DSCP-Markierung in ActiveStore und kein Server- oder ISP-Tuning.

## Ressourcen und Grenzen

Die CPU-, GPU- und RAM-Sensoren werden höchstens einmal pro Sekunde und nur bei sichtbarem Home, Hardware-Monitor oder Overlay abgefragt. FPS-Werte werden separat viermal pro Sekunde aktualisiert. GPU-Messwerte hängen von Windows-Treiberzählern ab; Temperatur-, Takt- und Watt-Werte werden nicht erfunden. FPS-Zuwächse oder niedrigere Pingzeiten werden nicht versprochen.

Die EXE ist nicht code-signiert. Windows SmartScreen kann bei einer neuen, nicht signierten Veröffentlichung eine Warnung anzeigen.
