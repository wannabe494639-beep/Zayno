# Freezer 2.42.0

Freezer ist eine native Windows-App in C# und WinForms. Diese Version ergänzt für aktive, gesicherte Optimierungen eine direkt sichtbare Schaltfläche **Rückgängig**. Sie stellt jeweils die vor dem Einschalten gesicherten Werte wieder her. Die bestehende Sammelwiederherstellung unter „Reparatur“ bleibt erhalten.

## Download und Plattformen

- Windows 10/11: [Freezer auf der Website](https://freezer-boost-hub.base44.app) · [GitHub-Releases](https://github.com/wannabe494639-beep/Zayno/releases/latest)
- Linux und macOS sind derzeit noch nicht unterstützt. Es gibt dafür noch keine getesteten Builds; die aktuelle Anwendung verwendet Windows Forms und Windows-spezifische APIs.

## Starten und bauen

Starte `dist/Freezer-2.42.0.exe`. Es ist eine einzelne GUI-EXE ohne Konsolenfenster. Die benötigten Assets sind eingebettet. Zum Kompilieren unter Windows mit dem .NET-Framework-C#-Compiler:

```powershell
.\build.ps1
```

Der Build erzeugt `dist/Freezer-2.42.0.exe` und `dist/Freezer-2.42.0-Source.zip`. Die Anwendung benötigt weder Python noch eine PowerShell-Laufzeit; PowerShell wird nur beim lokalen Build verwendet.

## Neue Funktionen in 2.42.0

- Aktive Optimierungsschalter zeigen eine **Rückgängig**-Aktion direkt an der jeweiligen Karte. Die Sicherung wird vor der Änderung gespeichert; beim Wiederherstellen werden Werte nur zurückgesetzt, wenn sie noch dem von Freezer gesetzten Wert entsprechen.
- Die vorhandene Wiederherstellung aller Freezer-Änderungen bleibt unter „Reparatur“ verfügbar.
- Version, Changelog und Build-Ausgaben sind auf 2.42.0 aktualisiert.
- Der GitHub-Workflow veröffentlicht für jeden gepushten Versions-Tag `vX.Y.Z` automatisch einen Windows-Build und ein Quellarchiv als GitHub Release.
- Update-Suche bleibt optional und blockiert den Programmstart nicht.

## Einschränkungen

- Systemänderungen können abhängig von Windows-Berechtigungen fehlschlagen. Freezer zeigt den Fehler an und lässt die übrige App weiterlaufen.
- CPU-/GPU-Treiber und einzelne Windows-Versionen können sich unterschiedlich verhalten. Freezer verspricht keine garantierten FPS- oder Ping-Zuwächse.
- Linux/macOS-Builds und deren plattformspezifische Funktionen folgen erst nach einer separaten Portierung und Prüfung.
