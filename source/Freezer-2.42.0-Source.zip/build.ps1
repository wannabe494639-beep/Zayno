$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$version = '2.42.0'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) {
    $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
}
if (-not (Test-Path -LiteralPath $compiler)) { throw 'The Windows .NET Framework C# compiler was not found.' }
New-Item -ItemType Directory -Path (Join-Path $root 'dist') -Force | Out-Null
$output = Join-Path $root ("dist\Freezer-{0}.exe" -f $version)
$icon = Join-Path $root 'assets\Freezer.ico'
$logo = Join-Path $root 'assets\FreezerLogo.png'
$presentMon = Join-Path $root 'assets\PresentMon.exe'
$source = Join-Path $root 'Freezer.cs'
$gameArtDir = Join-Path $root 'assets\game-art'
if (-not (Test-Path -LiteralPath $icon)) { throw 'Freezer.ico is missing.' }
if (-not (Test-Path -LiteralPath $logo)) { throw 'FreezerLogo.png is missing.' }
if (-not (Test-Path -LiteralPath $presentMon)) { throw 'Bundled PresentMon.exe is missing.' }
$gameArtFiles = @(Get-ChildItem -LiteralPath $gameArtDir -Filter 'game.*.jpg' -File | Sort-Object Name)
if ($gameArtFiles.Count -lt 19) { throw 'The embedded Game Hub artwork set is incomplete.' }
$resources = @("/resource:$icon,Freezer.ico", "/resource:$logo,FreezerLogo.png", "/resource:$presentMon,PresentMon.exe")
foreach ($art in $gameArtFiles) { $resources += "/resource:$($art.FullName),FreezerGameArt.$($art.BaseName)" }
& $compiler /nologo /target:winexe /platform:anycpu /optimize+ "/out:$output" "/win32icon:$icon" "/reference:System.dll" "/reference:System.Core.dll" "/reference:System.Drawing.dll" "/reference:System.Windows.Forms.dll" "/reference:System.Xml.Linq.dll" "/reference:System.Management.dll" "/reference:System.IO.Compression.dll" @resources $source
if ($LASTEXITCODE -ne 0) { throw "C# compilation failed with exit code $LASTEXITCODE." }
Write-Host "Built $output"
$sourceZip = Join-Path $root ("dist\Freezer-{0}-Source.zip" -f $version)
$packageFiles = @(
    (Join-Path $root 'Freezer.cs'),
    (Join-Path $root 'build.ps1'),
    (Join-Path $root 'README.de.md'),
    (Join-Path $root 'README.md'),
    (Join-Path $root 'CHANGELOG.md'),
    (Join-Path $root 'RELEASES.md'),
    (Join-Path $root 'assets')
)
Compress-Archive -Path $packageFiles -DestinationPath $sourceZip -CompressionLevel Optimal -Force
if (-not (Test-Path -LiteralPath $sourceZip)) { throw 'The source archive was not created.' }
Write-Host "Packaged source $sourceZip"
