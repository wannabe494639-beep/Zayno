# Version releases

The Windows Release GitHub Actions workflow runs when a release/vX.Y.Z branch is pushed. It builds the native WinForms app on windows-latest, then creates the matching vX.Y.Z tag and publishes the versioned executable, the stable Freezer-latest.exe download alias, and the source ZIP to a GitHub Release.

For each future Windows version:

1. Update the version in Freezer.cs (assembly/file metadata and AppVersion), build.ps1, the current README references, and the top of CHANGELOG.md.
2. Build and review dist/Freezer-X.Y.Z.exe and dist/Freezer-X.Y.Z-Source.zip on Windows.
3. Commit the matching source archive and documentation to main.
4. Create and push a release/vX.Y.Z branch from that commit.
5. GitHub Actions compiles the version-matched source archive, creates the vX.Y.Z GitHub release tag, and publishes the versioned executable, the stable download alias, and the source ZIP.

The release workflow currently publishes Windows only. Do not add Linux or macOS artifacts until those platforms have a real port, platform packaging, and successful CI builds. Freezer currently depends on WinForms and Windows APIs.

Updates are opt-in inside Freezer. Creating a GitHub release does not force-install it or block app startup.

