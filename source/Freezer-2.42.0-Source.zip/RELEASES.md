# Version releases

The `Windows Release` GitHub Actions workflow runs when a version tag is pushed. It builds the native WinForms app on `windows-latest` and publishes the executable and source ZIP to a GitHub Release.

For each future Windows version:

1. Update the version in `Freezer.cs` (assembly/file metadata and `AppVersion`), `build.ps1`, the current README references, and the top of `CHANGELOG.md`.
2. Build and review `dist/Freezer-X.Y.Z.exe` and `dist/Freezer-X.Y.Z-Source.zip` on Windows.
3. Commit the source and documentation, then push a matching tag such as `v2.42.1`.
4. GitHub Actions compiles the tagged source and publishes both files. Check the workflow run and the release assets before announcing the download.

The release workflow currently publishes Windows only. Do not tag Linux or macOS artifacts until those platforms have a real port, platform-specific packaging, and successful CI builds. Freezer currently depends on WinForms and Windows APIs.

Updates are opt-in inside Freezer. Creating a GitHub release does not force-install it or block app startup.
