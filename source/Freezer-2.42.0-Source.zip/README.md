# Freezer

Native C# WinForms gaming utility. The current release line is Windows only; Linux and macOS are not supported or shipped yet.

## Downloads

- Windows download page: [freezer-boost-hub.base44.app](https://freezer-boost-hub.base44.app)
- Latest GitHub release: [Releases](https://github.com/wannabe494639-beep/Zayno/releases/latest)
- Direct Windows download: [Freezer-latest.exe](https://github.com/wannabe494639-beep/Zayno/releases/latest/download/Freezer-latest.exe)

Each release includes a standalone Windows executable and a source ZIP. Read README.de.md for German build and feature notes, and RELEASES.md for the version workflow.

## Current version: 2.42.0

Active reversible optimization cards now offer a per-tweak „Rückgängig / Undo“ action that restores the saved original values. The existing full restore page remains available. See CHANGELOG.md for release details.

## Build

On Windows with the .NET Framework C# compiler installed, run .\build.ps1. The script creates dist/Freezer-2.42.0.exe and dist/Freezer-2.42.0-Source.zip. PowerShell is only used as a build shell; the application itself is native C# WinForms and does not require Python or PowerShell to run.

The GitHub Actions workflow builds and publishes Windows releases when a matching release/vX.Y.Z branch is pushed. It creates the corresponding GitHub release and vX.Y.Z tag, and uploads a stable Freezer-latest.exe asset for the website button. Linux and macOS releases will be added only after a native port and platform builds are verified.

