# Freezer

Native C# WinForms gaming utility. The current release line is **Windows only**; Linux and macOS are not supported or shipped yet.

## Downloads

- Windows download page: [freezer-boost-hub.base44.app](https://freezer-boost-hub.base44.app)
- Latest GitHub release: [Releases](https://github.com/wannabe494639-beep/Zayno/releases/latest)

Each release includes a standalone Windows executable and a source ZIP. Read [README.de.md](README.de.md) for German build and feature notes, and [RELEASES.md](RELEASES.md) for the version/tag workflow.

## Current version: 2.42.0

Active reversible optimization cards now offer a per-tweak **Rückgängig / Undo** action that restores the saved original values. The existing full restore page remains available. See [CHANGELOG.md](CHANGELOG.md) for release details.

## Build

On Windows with the .NET Framework C# compiler installed, run `.\build.ps1`. The script creates `dist/Freezer-2.42.0.exe` and `dist/Freezer-2.42.0-Source.zip`. PowerShell is only used as a build shell; the application itself is native C# WinForms and does not require Python or PowerShell to run.
