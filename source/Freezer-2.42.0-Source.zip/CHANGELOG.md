# Freezer 2.42.0

- Fügt für aktive, rücksetzbare Optimierungen eine direkte „Rückgängig“-Schaltfläche an jeder Karte hinzu. Die vorhandenen Sicherungen werden verwendet; Werte, die inzwischen von anderer Software geändert wurden, bleiben unberührt.
- Behält die Sammelwiederherstellung unter „Reparatur“ bei.
- Aktualisiert Versionsmetadaten, README und Build-Ausgaben auf 2.42.0.
- Ergänzt einen GitHub-Actions-Workflow, der bei gepushten `vX.Y.Z`-Tags Windows-EXE und Quellarchiv baut und als Release veröffentlicht. Linux/macOS bleiben bis zu einer getesteten Portierung ohne Builds.

# Freezer 2.41.0

- Ergänzt eine Leistungsseite mit wiederholbaren 30-/60-/120-Sekunden-Messläufen für laufende Spiele. Profile werden dabei nur beschriftet; sie werden nicht automatisch angewendet.
- PresentMon-Frames werden begrenzt gespeichert. Abgeschlossene Läufe enthalten FPS-Mittelwert, 1%-/0,1%-Low, mittlere und p95-Framezeit sowie CPU-/GPU-/RAM-Sensorwerte, soweit verfügbar.
- Fügt einen lokalen Verlauf mit maximal 40 Läufen, CSV-Export und Vorher-/Nachher-Vergleich hinzu.
- Ergänzt vorsichtige, klar als Hinweise bezeichnete GPU-/CPU-/RAM-Engpass-Heuristiken, Hardware-/Monitorübersicht und eine Momentaufnahme von Autostart-Anzahl und speicherintensiven Prozessen. Es werden keine Prozesse automatisch beendet oder Autostarts geändert.
- Ergänzt eine Vorschau für den Diagnoseexport. Der exportierte Bericht enthält keine Benutzerpfade, PIDs, Seriennummern, Prozesslisten, Logs oder Einstellungsinhalte.
- Ergänzt ein lokales Fehlerlog mit Größenbegrenzung und drei Rotationen. Sensor- und FPS-Abfragen laufen nur bei sichtbarer Leistungs-/Hardware-/Startansicht oder sichtbarem Overlay; minimierte Fenster pausieren die Messansichten.
- Aktualisiert Assembly-, Datei-, Fenster- und Build-Version auf 2.41.0. Das Build-Skript erzeugt zusätzlich `Freezer-2.41.0-Source.zip`.

# Freezer 2.40.1

- Erweitert das Fadenkreuz um eine Live-Vorschau, einstellbare Deckkraft, optionale dunkle Kontur und dezentes Neon-Leuchten.
- Ergänzt benannte, lokal gespeicherte Crosshair-Presets mit Laden, Überschreiben und Löschen. Die Daten werden im bestehenden `settings.ini`-Format ergänzt; eigene Bildmotive werden pro Preset gesichert, und vorhandene Spiel-, Farb- und Stretch-Zuweisungen bleiben erhalten.
- Das Fadenkreuz wird zusätzlich zu Monitor-/Auflösungswechseln bei Windows-DPI-Änderungen erneut auf dem ausgewählten Monitor zentriert.
- Ergänzt eine einmalig angezeigte, überspringbare Einführung zu Wiederherstellung, Spielprofilen, Stretch-Skalierung und Fadenkreuz. Alte Einstellungen werden weiterverwendet.
- Aktualisiert Assembly-, Fenster- und Build-Version auf 2.40.1. Der Updater bleibt optional und blockiert den Start nicht.
- Dokumentiert die Einschränkungen von Overlay, Treiber-Farbsteuerung und FPS-Erfassung. Es gibt keine Zusage garantierter Leistungsgewinne.

# Freezer 2.32.32

- Ergänzt einen eigenen Stretch-Menüpunkt, der die Anzeige unabhängig vom Start eines Spiels direkt umschalten kann.
- Monitorwahl zeigt die vorhandenen Monitorbezeichnungen; verfügbare Modi und gängige Stretch-Auflösungen werden vorab mit dem Grafiktreiber geprüft.
- Benutzerdefinierte Auflösungen lassen sich temporär anwenden, nach 15 Sekunden bestätigen oder automatisch zurücksetzen. Die ursprüngliche Auflösung kann jederzeit wiederhergestellt werden.
- Die bisherige Stretch-Zuweisung im Game Hub bleibt bestehen.

# Freezer 2.32.31

- Behoben: Beim Ändern der Game-Hub-Fenstergröße griff die Kachel-Anpassung auf einen Stretch-Button zu, der aus dem Layout entfernt wurde. Fortnite-Kacheln behalten nun ihren einzeiligen Potato-Schalter, und die Größenanpassung prüft fehlende/geschlossene Steuerelemente.

# Freezer 2.32.30

- Game-Hub-Kacheln sind kompakter; Stretch-Auflösung wird im kombinierten Spielprofil zusammen mit Monitor und Farbprofil gespeichert und vor dem Spielstart treiberseitig geprüft.
- Temporäre Stretch-Modi werden während der Spielsession gesichert und nach dem Spielende beziehungsweise beim vollständigen Schließen wiederhergestellt.
- Das untere Fortnite-Kachelbild-Menü ist aus dem Game Hub entfernt.
- Farbprofil-Editoren und Crosshair-Dateizone nutzen abgerundete, dunkle Flächen; Karten haben einheitlich weichere Ecken.
- Einstellungen enthalten eine separate Anzeigeabschaltung für den aktiven Energiesparplan. Ursprüngliche AC-/Akkuwerte werden gesichert und können wiederhergestellt werden; normale Optimierungen ändern den Timeout nicht.
- Die Reparaturprüfung akzeptiert jetzt Spielprofile, Farbprofile, Startpfade und gespeicherte Stretch-Modi, statt gültige Einstellungen als beschädigt zu melden.

# Freezer 2.32.29

- Gaming mode creates a private Ultimate Performance power-plan clone (High performance fallback), disables core parking, and requests 100% minimum/maximum CPU performance on AC power.
- The original scheme is restored and Freezer's temporary clone is deleted after the game ends, when Gaming Mode is disabled, or during startup recovery. Manual selection of another scheme is preserved.
- Process priority remains High (never Realtime). Broad service stops, network registry overrides, HAGS forcing, CPU-core affinity changes, and standby-list purges are excluded.

# Freezer 2.32.28

- Gaming sessions temporarily select an already-installed High performance or Ultimate Performance power plan while a recognized game is running, then restore the prior plan.
- A durable power-plan snapshot allows recovery after a crash and preserves a power plan the user selected manually during play.
- Game priority remains capped at High. Windows services are not indiscriminately stopped and RAM is not force-cleared.

# Freezer 2.32.27

- Gespeicherte Fortnite-Grafikprofile werden beim Spielstart aus dem Game Hub vor dem Öffnen der Spieldatei erneut in die Konfiguration geschrieben; bei Fehlern startet Fortnite nicht still mit einem anderen Profil.
- Das Fadenkreuz wird nach Windows-Monitor-/Auflösungsänderungen automatisch neu zentriert, zusätzlich zu manuellen Stretch-Änderungen in Freezer.
- Vordefinierte Stretch-Modi werden pro ausgewähltem Monitor mit dem Windows-Treibertest validiert, bevor sie im Auswahlfeld erscheinen.

# Freezer 2.32.26

- Monitor-Auswahlen zeigen den ermittelten Monitor-Namen, Haupt-/Nebenmonitor, Position und Auflösung statt der technischen DISPLAY-Kennung, soweit Windows diese Daten bereitstellt.
- Manuelles Anwenden und Zurücksetzen von Farbprofilen ist auf den ausgewählten Monitorausgang begrenzt; die Auswahl wird pro NVIDIA-/AMD-Bereich gespeichert.
- Der Gaming-Mode-Schalter in der Optimierungsansicht fragt vor jeder Änderung nach einer Bestätigung mit Auswirkungen und Rücksetz-Hinweis.
# Freezer 2.32.25

- Maximizing now uses the nearest monitor's current Windows work area, including after cross-monitor moves.
- Compactened the dashboard FPS example and removed horizontal scrolling from the main content area.
- Enlarged and darkened the custom crosshair editor; all controls now fit in the dialog.
- Added template-image opacity and a switchable 32×32 pixel drawing mode; drag-and-drop templates and transparent PNG export remain supported.

# Freezer 2.32.24

- Added an in-app custom crosshair drawing editor with color, stroke width, undo and clear controls.
- Added image import via file picker and drag-and-drop, with validation and transparent PNG normalization.
- Added four built-in crosshair shapes and localized labels.
- Custom crosshairs are saved locally and refreshed in the selected-display overlay, including after recentering.

# Freezer 2.32.23

- Repariert Header- und Button-Neuzeichnung, rundet Aktionen stärker ab und blendet den nativen Fensterrand in das dunkle Design ein; Windows-Snap- und Größenänderungsfunktionen bleiben erhalten.
- Gaming- und Streamer-Modus zeigen beim Ein- und Ausschalten wieder eine lokalisierte Bestätigung mit Erklärung der temporären Änderungen.
- CPU-, GPU- und RAM-Modell/Typ werden direkt unter dem jeweiligen Dashboard- und Hardware-Kreis angezeigt; doppelte Komponentenlisten im Hardware-Monitor entfallen.
- Die Reparaturseite enthält jetzt einen direkten OBS-Streaming-Hinweis mit GPU-passender Encoder-Empfehlung.
- Update-Aktionen und lokale Installationsaktionen umbrechen responsiv, statt bei schmalen Fenstern abgeschnitten zu werden; „Neu zentrieren“ bleibt beim Fadenkreuz rechts ausgerichtet und funktioniert auch bei deaktiviertem Overlay zum Speichern der Auswahl.
- Auswahlfelder verwenden größere, dunkle Dropdown-Zeilen und decken den hellen nativen Pfeilbereich vollständig mit dem Freezer-Chevron ab.
- Entfernt den zusätzlichen Außenabstand des Hauptfensters, der als heller Streifen am oberen Rand sichtbar sein konnte.

# Freezer 2.32.22

- Prevented a GDI+ zero-length arc error in the GPU gauge that could surface as a misleading `OutOfMemoryException` when utilization was 0%.
- Added CPU model, physical GPU model, RAM capacity, DDR generation and configured memory speed directly below the Hardware Monitor readings.
- Filtered virtual/Parsec/indirect display adapters so the physical GPU model is shown first.
- Added a direct Streamer Mode toggle next to Gaming Mode; both controls use the rounded Freezer button style and do not show a confirmation prompt on every click.
- Kept automatic update checks off by default and made the preference available in Settings and Updates; manual update checks remain available.
- Maximized windows use the monitor work area so the Windows taskbar remains visible.
- Updated the illustrative dashboard FPS comparison to 60 → 120; it remains explicitly labeled as an example, not a performance promise.
# Freezer 2.32.21

- Behoben: Ungültige GPU-/Sensorwerte wie `NaN` werden im Dashboard-Kreis als nicht verfügbar behandelt statt an GDI+ übergeben zu werden; Zeichenfehler in der Gauge reißen die Hauptoberfläche nicht mehr mit.
- Alle Auswahlfelder verwenden jetzt die dunkle, kontrastreiche Darstellung mit eigenem Akzent-Pfeil statt des weißen Windows-Dropdown-Bereichs.
- Das Fadenkreuz hat einen eigenen Sidebar-Menüpunkt und ist nicht mehr in den Einstellungen versteckt.
- Fortnite-Profile bleiben update-tolerant: Sie ändern nur bereits vorhandene Qualitätswerte, sichern die Originaldatei und erzwingen keine undokumentierten Schlüssel. Die aktuelle Epic-Hilfe empfiehlt zusätzlich Game Mode und die hohe GPU-Leistungspräferenz pro App.

# Freezer 2.32.20

- Dashboard-Komponentenliste zeigt CPU, GPU, RAM-Kapazität, Mainboard und Systemlaufwerke; WMI-Abfragen laufen im Hintergrund mit Zeitlimit.
- Erststart-Begrüßung ergänzt; der 60-zu-100-FPS-Vergleich wird als Beispiel und nicht als FPS-Garantie gekennzeichnet.
- AMD-Farbprofile lesen unterstützte ADL-Wertebereiche und Treiber-Standardwerte für Helligkeit, Kontrast, Sättigung und Farbton aus und speichern sie pro Monitor/Profil.
- AMD-Standardwerte stellen alle vom Treiber verfügbaren Farbregler wieder her. Fehler beim Anwenden rollen bereits geänderte Werte auf zuvor ausgelesene Werte zurück.
- NVIDIA-Bereich beschreibt die von NVAPI tatsächlich angebotene Digital-Vibrance-Steuerung und öffnet die NVIDIA-Systemsteuerung; nicht exponierte Regler werden nicht vorgetäuscht.
- AMD-Sättigungs-API auf das dokumentierte ADL-Feld korrigiert.

- Farbprofile übersichtlicher gestaltet: gespeicherte Profile erscheinen als direkt auswählbare Chips.
- Farbsättigungsregler neu gezeichnet und Profil-Auswahllisten dunkler gestaltet, jeweils mit orangefarbenem Akzent.
- Die Schaltfläche zum Wiederherstellen der Treiber-Standardwerte ist breiter und deutlich hervorgehoben.
- Nicht verfügbare NVIDIA-/AMD-Steuerungen zeigen einen kompakten Status statt leerer, deaktivierter Eingabefelder.

# Freezer 2.32.18

- Added a separate “Farb-Profile” sidebar page with independent NVIDIA and AMD sections, including a hardware-detection lock and localized status messages.
- Added saved per-display saturation profiles, driver-default controls, and game-to-profile assignments for supported titles.
- Added a lightweight background game watcher that activates only when assignments exist, applies a selected profile at game start, and restores driver-reported defaults when the assigned game exits or Freezer fully closes.
- NVIDIA uses driver NVAPI Digital Vibrance; AMD uses the installed driver’s ADL color controls. Unsupported driver interfaces report an in-app status instead of preventing startup.
- Color-profile settings are stored locally in the existing user settings file.

# Freezer 2.32.17

- Beschleunigt den Programmstart: gespeicherte Spielprioritäten werden nach dem Anzeigen des Hauptfensters im Hintergrund wiederhergestellt.
- PresentMon wird erst nach dem Anzeigen des Fensters geprüft und entpackt; die FPS-Messung wartet bei Bedarf, ohne den Start zu blockieren.
- Die Begrüßung zum Wiederherstellungspunkt erscheint verzögert, damit das Hauptfenster zuerst sichtbar wird.
- Ergänzt oben rechts einen direkten „Beenden“-Knopf, der Freezer auch bei aktiviertem Minimieren-in-den-Infobereich vollständig schließt.
- Buttons haben einheitlichere Rundungen und eine feine Akzent-Umrandung bei Hover; auch Bestätigungsdialoge verwenden die abgerundeten Buttons.

# Freezer 2.32.16

- Behoben: Der Hardware-Sampler gibt das wiederholt verwendete Prozess-Handle jetzt bei jeder Messung frei.
- Stabilisiert: UI-Schriftobjekte werden über einen gemeinsamen Cache wiederverwendet; temporäre Prozessobjekte werden sauber freigegeben.
- Diagnose erweitert: Der Reparaturbericht unterscheidet System-RAM von Freezers Arbeitssatz, privatem/virtuellem Speicher, Handle- und GDI-/USER-Anzahl sowie .NET-Heap.
- Beim Beenden werden alle WinForms-Timer explizit gestoppt und freigegeben.

- Fixed overlapping header controls by setting explicit widths and recalculating the FPS area against the right-side window buttons.
- Fixed hardware and repair buttons that accidentally used their intended widths as heights.
- Repositioned and themed the live overlay close button so it stays inside the overlay panel.
- Added CPU, GPU and RAM model/capacity text to the dashboard. CPU/GPU names load asynchronously and are sanitized for display.
- Added a localized OBS streaming guide with GPU-specific hardware encoder recommendations and platform-dependent settings guidance. Freezer does not modify OBS profiles.
- Balanced Streamer process priority: the game and OBS now use Above Normal priority instead of setting OBS to High.

# Freezer 2.32.14

- Local update management now discovers newer Freezer EXE files and Windows ZIP packages, with manual file selection and a dedicated install action.
- Confirmed updates replace the complete app EXE, keep a versioned backup, verify the product/version and file hash, and relaunch Freezer. If replacement fails, the old copy is restored and the selected newer build is opened when possible.
- Stretch reset now chooses a driver-enumerated mode matching the saved original resolution and refresh rate, with a fallback to the driver's default refresh rate; failed resets keep the saved recovery point.
- Standard app buttons now use shared low-overhead rounded painting to match the dark UI.
- Clarified that the current custom-image control changes only Freezer's Fortnite tile. Fortnite's documented custom lobby images are for creator islands and uploaded through the Creator Portal.

# Freezer 2.32.13

- Expanded the header FPS readout to include current, minimum and average FPS.
- Added a Game Hub session selector that detects running supported games, lets users choose a title and profile, and applies the confirmed profile before opening a saved or newly selected game/launcher file.
- The tray icon now handles its left-button double-click event and restores the main window defensively.
- Replaced the crosshair start/stop button with an on/off switch.
- Added a Fortnite Game Hub tile wallpaper picker with drag-and-drop and reset. Images are bounded and stored locally; Fortnite files are not changed.
- Added an asynchronous GitHub release check after the main window opens. It can show an optional update banner; downloading and installation remain user-controlled.
- Added reversible Windows toggles for supported UWP background activity and transparency effects, with descriptions of their effects and limits.

- Replaced square stock sidebar buttons with custom rounded navigation controls, clearer active-state accents and a shared low-overhead hover/fade animation.

# Freezer 2.32.11

- Added an optional minimize-to-tray setting. Closing with the X hides the window; the tray menu can reopen or fully exit Freezer.
- Added Max FPS and Streamer game profiles. Max FPS uses the existing reversible Windows settings and session boost; Streamer keeps the game above normal and OBS at high priority while a matching game is running. Windows services are not disabled.
- Expanded Fortnite graphics presets into High, Medium, Low and Extreme tiers, with an original backup created before the first write and a restore option.
- Added an optional per-game DSCP 46 QoS policy in Windows ActiveStore. It requires explicit confirmation and administrator approval, is removable in the app, and does not promise lower ping.
- Applied Windows 11 rounded window corners where supported.

# Freezer 2.32.10

- Removed the modal startup prompt that offered to launch a newer local EXE and then closed the current app. Startup discovery now runs in a background worker and only adds an optional dashboard/update-page notice; the user can reveal the file in Explorer and decide what to do.
- Isolated local update discovery and UI dispatch behind exception handling so missing folders, inaccessible files, or shutdown races cannot block or crash startup.
- Corrected the displayed application version to 2.32.10 so local version comparisons and the window title match the build.

# Freezer 2.32.9

- Replaced the flat Game Hub banners with embedded game artwork for the full library, including Counter-Strike 2, League of Legends, PUBG: BATTLEGROUNDS, Rocket League, Overwatch 2, Rainbow Six Siege, Apex Legends and Farming Simulator 25. Dark overlays preserve title and control contrast; image resources are loaded per visible tile and disposed with it.
- Added a one-click Fortnite Potato Graphics toggle. Freezer tracks whether its preset is active and restores the original `GameUserSettings.ini` backup when toggled off. Enabling still shows the existing confirmation; Fortnite must be closed.

# Freezer 2.32.8

- Replaced the Game Hub's initials badges with the complete localized game name directly inside each colored banner. Names wrap to the card width and remain available to accessibility tools.
- Added a localized crosshair "Recenter" action that reapplies the selected display's current bounds and settings. The overlay also recenters automatically after Windows reports a display resolution or topology change.

# Freezer 2.32.6

- Integrated the supplied transparent lightning logo as an embedded dashboard asset with a Windows icon fallback, and rebuilt the executable icon from that image.
- Added Windows sizing-frame styles and client-area resize grips while retaining the custom title bar, native maximize/minimize state, and drag-to-top Snap Assist behavior.
- Game Hub names now wrap according to actual rendered text width and preserve the complete localized title in accessibility metadata.
- Gaming Mode now temporarily requests 1 ms timer resolution only while a recognized game process is running, raises eligible game processes to High priority, and restores recorded priorities when disabled, on exit, or at the next launch. It does not disable Windows services.
- Expanded diagnostics with physical RAM usage, available ACPI thermal-zone readings, and graphics adapter driver version/status; unavailable sensors are reported honestly.
- Startup now checks the current user's top-level Downloads folder and the app folder for a newer Freezer EXE, displays its version and full path, and asks before launching it. It does not silently run or replace an executable.
- Smoothed crosshair edges with high-quality antialiasing and double-buffered painting.

# Freezer 2.32.5

- Rebuilt the seven-size application icon with a transparent background and load the header logo at 128 px, avoiding a black square and blurry enlargement in both the window and taskbar.
- Wrapped long localized game titles across multiple lines and expanded Game Hub with League of Legends, PUBG: BATTLEGROUNDS, Call of Duty: Warzone, Dota 2, Roblox and EA SPORTS FC 26.
- Localized the Lite, Balanced and Ultimate Power optimization profiles and their descriptions.
- Added a monitor-specific Stretch Resolution dialog with custom dimensions, driver `CDS_TEST` validation, a 15-second confirmation rollback and a saved original-mode reset control.
- Added practical Fortnite wired-LAN and ping guidance plus additional network and input-latency tips. The UI makes clear that routing and hardware limit results.
- PresentMon capture now auto-attaches to detected supported games while monitoring is active; FPS refreshes four times per second and appears in the header, dashboard, hardware page and configurable overlay with current/minimum/average values.
- Added overlay toggles for CPU, GPU, RAM and FPS and expanded crosshair shapes and colors.
- Added a localized Updates sidebar page to check public GitHub releases and open the release page for manual review and download.
- Added real display device names where Windows provides them and extended settings validation for overlay and display backups.

# Freezer 2.32.4

- Game Hub shows longer game names, adds League of Legends, PUBG: BATTLEGROUNDS, Call of Duty: Warzone, Dota 2, Roblox and EA SPORTS FC 26, and localizes Lite, Balanced and Ultimate Power profiles.
- Added practical Fortnite Ethernet/ping guidance and more network and input-latency tips without promising ping or FPS gains.
- Live FPS capture now automatically attaches PresentMon to a detected supported game while Home, Hardware Monitor or the live overlay is visible. Current FPS appears in the header; current, minimum and average remain in the monitor and overlay.
- Expanded crosshair customization with square, diamond, T and bracket shapes plus orange, purple, pink and blue colors.
- Updated settings validation so saved crosshair and first-run settings remain valid during diagnostics and auto-repair.
- Kept the application icon embedded for the window and taskbar; set the Windows title to Freezer 2.32.4.

# Freezer 2.32.3

- Added a hardware-aware Desktop Optimization assistant that reads CPU, GPU and RAM, then proposes reversible Windows settings for confirmation.
- Added a one-time, localized restore-point guide at first launch and a Settings shortcut to Windows System Protection.
- Added Fortnite Performance and Potato graphics presets. The app backs up the existing `GameUserSettings.ini`, updates only recognized quality keys, requires Fortnite to be closed, and can restore the original copy.
- Added a configurable, centered, click-through crosshair overlay with monitor, shape, color, size, gap and thickness controls.
- Clarified full game-profile scope and translated the new prompts across all six app languages.

# Freezer 2.32.2

- Added an eased, direction-aware swipe between Game Hub pages; animation follows the fast, reduced-motion, or off preference.
- Added a localized AMD Ryzen X3D profile for AM4/AM5 that checks the installed CPU before applying reversible Windows Game Mode and background-capture settings.
- X3D profile leaves CCD/CPPC, BIOS, power-plan, and display-timeout settings untouched.
- Disposes prior page controls and completed carousel pages to keep navigation memory use bounded.

# Freezer 2.32.1

- Added a maximize/restore button and double-click title-bar behavior.
- Added fast, reduced-speed, and no-animation sidebar settings; hover navigation remains available.
- Localized optimization tiles, state labels, game profile summaries, diagnostics, and repair prompts in all six included languages.
- Added a paged game-card carousel and explicit Windows profile application for Lite, Balanced, and Power presets.
- Added real per-logical-core CPU readings where Windows counters are available.
- Added overlay size and opacity settings.
- Replaced the generic repair message with checks for settings, PresentMon, snapshots, runtime, and administrator context, plus safe repair of Freezer-owned files.
- Added an in-header Gaming Mode state indicator and dark hover states for navigation.
- Kept display timeout and sleep settings out of all optimization and repair actions.
